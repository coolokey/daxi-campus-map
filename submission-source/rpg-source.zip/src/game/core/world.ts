import type { MapConfig, NpcConfig } from '../data/types';
import { residents } from '../data/residents';
import { movePlayer } from '../../presentation/movement';
import { isBlocked } from './collision';

export const WORLD_SCALES = [1, 1.5, 2] as const;
let selectedScale = 1.5;
export const getWorldScale = () => selectedScale;
export function safePosition(point:{x:number;y:number}, map:MapConfig) {
  const valid=(p:{x:number;y:number})=>p.x>=22&&p.y>=24&&p.x<=map.width-22&&p.y<=map.height-24&&!isBlocked({x:p.x-16,y:p.y-16,width:32,height:40},map.collisionZones);
  if(valid(point))return point;
  for(let r=4;r<=160;r+=4)for(let i=0;i<16;i++){
    const p={x:point.x+Math.cos(i*Math.PI/8)*r,y:point.y+Math.sin(i*Math.PI/8)*r};if(valid(p))return p;
  }
  return {...map.spawns['campus-start']};
}
export function setWorldScale(scale: number) {
  if (!(WORLD_SCALES as readonly number[]).includes(scale)) return;
  selectedScale = scale;
}
export function scaleMap(source: MapConfig, scale: number): MapConfig {
  if (source.id !== 'campus') scale = 1;
  const point = <T extends {x:number;y:number}>(p:T):T => ({...p,x:p.x*scale,y:p.y*scale});
  return { ...source, width:source.width*scale,height:source.height*scale,
    collisionZones:source.collisionZones.map(r=>({...point(r),width:r.width*scale,height:r.height*scale})),
    spawns:Object.fromEntries(Object.entries(source.spawns).map(([id,p])=>[id,point(p)])),
    portals:source.portals.map(p=>({...p,trigger:{...point(p.trigger),width:p.trigger.width*scale,height:p.trigger.height*scale}})),
    npcs:[...source.npcs,...(source.id==='campus'?residents:[])].map(n=>({...point(n),route:n.route?.map(point)})),
  };
}
export type Resident = NpcConfig & { waypoint:number; wait:number; moving:boolean };
export const createResidents = (map:MapConfig):Resident[] => map.npcs.map(n=>({...n,waypoint:1,wait:0,moving:false}));
export function stepResidents(npcs:Resident[], map:MapConfig, seconds:number, player:{x:number;y:number}, paused:boolean) {
  if (paused) return;
  for (const n of npcs) {
    n.moving=false;
    if (Math.hypot(n.x-player.x,n.y-player.y)<90) {
      const pdx=player.x-n.x,pdy=player.y-n.y;
      n.direction=Math.abs(pdx)>Math.abs(pdy)?(pdx>0?'right':'left'):(pdy>0?'down':'up');
      continue;
    }
    if (!n.route?.length) continue;
    if(n.wait>0) { n.wait-=Math.min(seconds,0.1); continue; }
    const dest=n.route[n.waypoint % n.route.length], dx=dest.x-n.x,dy=dest.y-n.y,dist=Math.hypot(dx,dy);
    if(dist<2) { n.waypoint=(n.waypoint+1)%n.route.length; n.wait=0.8; continue; }
    const p=movePlayer(n,dx,dy,seconds,map,Math.min(n.speed??60,dist/Math.max(0.001,Math.min(seconds,0.1))));
    n.moving=Math.hypot(p.x-n.x,p.y-n.y)>0.01;
    n.direction=Math.abs(dx)>Math.abs(dy)?dx>0?'right':'left':dy>0?'down':'up';
    n.x=p.x;n.y=p.y;
  }
}
export type WorldSnapshot = {map:MapConfig; player:{x:number;y:number;direction?:string}; npcs:NpcConfig[]};
export function publishWorld(snapshot:WorldSnapshot) {
  window.dispatchEvent(new CustomEvent('campus:snapshot',{detail:snapshot}));
}
