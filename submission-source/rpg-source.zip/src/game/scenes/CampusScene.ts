import Phaser from 'phaser';
import { PlayerController } from '../entities/PlayerController';
import { campusMap as sourceCampusMap } from '../data/maps/campus';
import { presentationMap } from '../data/presentation';
import { nearestInteractable } from '../core/interaction';
import type { NpcConfig, PortalConfig } from '../data/types';

import { getWorldScale, scaleMap, safePosition } from '../core/world';
import { WorldActors } from '../entities/WorldActors';

type Target = { type: 'npc'; value: NpcConfig } | { type: 'portal'; value: PortalConfig };


export class CampusScene extends Phaser.Scene {
  private player!: PlayerController;
  private cursors!: Phaser.Types.Input.Keyboard.CursorKeys;
  private wasd!: Record<'W' | 'A' | 'S' | 'D', Phaser.Input.Keyboard.Key>;
  private virtualDirection = { x: 0, y: 0 };
  private target?: Target;
  private map = scaleMap(sourceCampusMap,getWorldScale());
  private actors!: WorldActors;
  private mapOpen = false;
  private dialogueOpen = false;
  private worldScale = getWorldScale();
  private changeScale = () => {
    this.game.events.emit('dialogue:close');
    const ratio=getWorldScale()/this.worldScale;
    this.scene.restart({ position:{x:this.player.sprite.x*ratio,y:this.player.sprite.y*ratio} });
  };
  private toggleMap = (e:Event) => {this.mapOpen=(e as CustomEvent<boolean>).detail;this.player.enabled=!this.mapOpen&&!this.dialogueOpen;this.player.sprite.setVelocity(0,0);this.virtualDirection={x:0,y:0};this.input.keyboard?.resetKeys();};
  constructor() { super('campus'); }

  create({ spawnId = 'campus-start', position }: { spawnId?: string; position?:{x:number;y:number} } = {}) {
    this.worldScale=getWorldScale();this.map=scaleMap(presentationMap(sourceCampusMap),this.worldScale);
    const campusMap=this.map;this.mapOpen=false;this.dialogueOpen=false;this.virtualDirection={x:0,y:0};
    this.game.events.once(Phaser.Core.Events.POST_RENDER, () => {
      window.dispatchEvent(new Event('campus:world-ready'));
      if (new URLSearchParams(location.search).has('profile')) console.info('RPG_STARTUP ' + JSON.stringify({ readyMs: Math.round(performance.now()), resources: performance.getEntriesByType('resource').map(entry => { const resource = entry as PerformanceResourceTiming; return { name: resource.name.split('/').at(-1), startMs: Math.round(resource.startTime), ms: Math.round(resource.duration), bytes: resource.transferSize }; }) }));
    });
    this.add.image(0, 0, campusMap.backgroundKey).setOrigin(0).setDisplaySize(campusMap.width, campusMap.height);
    const collisions = this.physics.add.staticGroup();
    campusMap.collisionZones.forEach((zone) => collisions.create(zone.x + zone.width / 2, zone.y + zone.height / 2, undefined).setDisplaySize(zone.width, zone.height).setVisible(false).refreshBody());
    const spawn = { ...(campusMap.spawns[spawnId] ?? campusMap.spawns['campus-start']), ...(position?safePosition(position,campusMap):{}) };
    const sprite = this.physics.add.sprite(spawn.x, spawn.y, `player-${spawn.direction}-idle`).setDepth(3).setCollideWorldBounds(true);
    sprite.setSize(22, 24).setOffset(9, 22); this.player = new PlayerController(sprite); this.physics.add.collider(sprite, collisions);
    this.physics.world.setBounds(0, 0, campusMap.width, campusMap.height); this.cameras.main.setBounds(0, 0, campusMap.width, campusMap.height); this.cameras.main.startFollow(sprite, true, 0.12, 0.12);
    this.cursors = this.input.keyboard!.createCursorKeys(); this.wasd = this.input.keyboard!.addKeys('W,A,S,D') as Record<'W' | 'A' | 'S' | 'D', Phaser.Input.Keyboard.Key>;
    this.actors=new WorldActors(this,campusMap);
    window.addEventListener('campus:scale',this.changeScale);
    window.addEventListener('campus:map-open',this.toggleMap);
    this.game.events.on('input:virtual-direction', this.setVirtualDirection, this);
    this.game.events.on('interaction:action', this.activateTarget, this);
    this.game.events.on('dialogue:closed', this.resumePlayer, this);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, this.removeListeners, this);
  }

  update(_time:number,delta:number) {
    const x = Number(this.cursors.right.isDown || this.wasd.D.isDown) - Number(this.cursors.left.isDown || this.wasd.A.isDown) || this.virtualDirection.x;
    const y = Number(this.cursors.down.isDown || this.wasd.S.isDown) - Number(this.cursors.up.isDown || this.wasd.W.isDown) || this.virtualDirection.y;
    this.player.move({ x, y }); this.actors.update(delta,{x:this.player.sprite.x,y:this.player.sprite.y,direction:this.player.lastDirection},this.mapOpen||this.dialogueOpen); this.refreshTarget();
  }

  private refreshTarget() {
    const position = this.player.sprite;
    const npc = nearestInteractable(position, this.actors.npcs);
    const portal = this.map.portals.find((item) => Phaser.Geom.Rectangle.Contains(new Phaser.Geom.Rectangle(item.trigger.x - 60, item.trigger.y - 60, item.trigger.width + 120, item.trigger.height + 120), position.x, position.y));
    this.target = npc ? { type: 'npc', value: npc } : portal ? { type: 'portal', value: portal } : undefined;
    this.game.events.emit('interaction:prompt', this.target?.type === 'npc' ? `E ／空白鍵　與 ${this.target.value.name} 交談` : this.target?.type === 'portal' ? this.target.value.prompt : undefined);
  }
  private activateTarget() {
    if (!this.target || this.mapOpen || this.dialogueOpen) return;
    if (this.target.type === 'portal') {
      const portal = this.target.value; this.player.enabled = false; this.player.sprite.setVelocity(0, 0); this.game.events.emit('interaction:prompt');
      this.cameras.main.fadeOut(220, 8, 28, 45); this.cameras.main.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => this.scene.start(portal.destinationMapId, { spawnId: portal.destinationSpawnId })); return;
    }
    this.dialogueOpen=true;this.player.enabled = false; this.player.sprite.setVelocity(0, 0);
    this.game.events.emit('dialogue:open', { name: this.target.value.name, portraitKey: this.target.value.portraitKey, text: this.target.value.dialogue ?? '歡迎來到未來科技校園。先探索校園，接著到研究室挑戰數學任務吧！' });
  }
  private setVirtualDirection(direction: { x: number; y: number }) { this.virtualDirection = direction; }
  private resumePlayer() { this.dialogueOpen=false;this.player.enabled = !this.mapOpen;this.virtualDirection={x:0,y:0};this.input.keyboard?.resetKeys(); }
  private removeListeners() { window.removeEventListener('campus:scale',this.changeScale);window.removeEventListener('campus:map-open',this.toggleMap); this.game.events.off('input:virtual-direction', this.setVirtualDirection, this); this.game.events.off('interaction:action', this.activateTarget, this); this.game.events.off('dialogue:closed', this.resumePlayer, this); }
}
