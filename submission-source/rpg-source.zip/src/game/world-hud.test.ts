import { afterEach, describe, expect, it, vi } from 'vitest';
import { mountWorldHud } from './world-hud';
import { campusMap } from './data/maps/campus';
import { scaleMap } from './core/world';

let dispose: (()=>void)|undefined;
afterEach(()=>{dispose?.(); document.body.innerHTML=''; vi.restoreAllMocks();});
function setup(dpr=2) {
  Object.defineProperty(window,'devicePixelRatio',{configurable:true,value:dpr});
  const c = Object.fromEntries(['fillRect','drawImage','beginPath','arc','fill','moveTo','lineTo','stroke','save','translate','rotate','closePath','restore','setTransform','fillText'].map(k=>[k,vi.fn()]));
  vi.spyOn(HTMLCanvasElement.prototype,'getContext').mockReturnValue(c as unknown as CanvasRenderingContext2D);
  vi.spyOn(HTMLElement.prototype,'getBoundingClientRect').mockReturnValue({width:120,height:81,left:0,top:0,right:120,bottom:81,x:0,y:0,toJSON(){}});
  let now=100;vi.spyOn(performance,'now').mockImplementation(()=>now+=100);
  const frame=document.createElement('div');document.body.append(frame);dispose=mountWorldHud(frame);
  const send=(scale=1,direction='up')=>window.dispatchEvent(new CustomEvent('campus:snapshot',{detail:{map:scaleMap(campusMap,scale),player:{x:600*scale,y:400*scale,direction},npcs:[]}}));
  return {c,frame,send};
}
describe('readable minimap player',()=>{
  it('renders with CSS-sized logical coordinates and capped DPR backing',()=>{
    const {c,frame,send}=setup(3);send();
    expect(frame.querySelector('canvas')!.width).toBe(240);
    expect(c.setTransform).toHaveBeenCalledWith(2,0,0,2,0,0);
    expect(c.translate).toHaveBeenCalledWith(30,400*81/1624);
    expect(c.arc).toHaveBeenCalledWith(0,0,11,0,Math.PI*2);
    expect(c.fillText).toHaveBeenCalledWith('你在這裡',expect.any(Number),expect.any(Number));
  });
  it('uses facing instead of fake movement when world dimensions change',()=>{
    const {c,send}=setup();send();send(2,'left');
    expect(c.rotate).toHaveBeenLastCalledWith(-Math.PI/2);
  });
  for (const dpr of [1,2]) it(`keeps the player halo the same CSS size on small and full maps at DPR ${dpr}`,()=>{
    const {c,frame,send}=setup(dpr);send();
    const dialog=frame.querySelector('dialog')!;
    dialog.showModal=()=>dialog.setAttribute('open','');
    (frame.querySelector('.world-minimap') as HTMLButtonElement).click();
    for(const canvas of frame.querySelectorAll('canvas'))expect(canvas.width).toBe(120*dpr);
    expect(c.setTransform).toHaveBeenLastCalledWith(dpr,0,0,dpr,0,0);
    expect(c.arc.mock.calls.filter(args=>args[2]===11)).toHaveLength(2);
  });
});
