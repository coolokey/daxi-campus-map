import { useEffect, useRef, useState } from 'react';
import { mountWorldHud } from './world-hud';

export function GameShell({ paused = false }: { paused?: boolean }) {
  const [portalHidden, setPortalHidden] = useState(false);
  const suspended = paused || portalHidden;
  const mountRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  useEffect(() => { if (frameRef.current) return mountWorldHud(frameRef.current); }, []);
  const gameRef = useRef<import('phaser').Game | null>(null);
  useEffect(()=>{
    const direction=(e:Event)=>gameRef.current?.events.emit('input:virtual-direction',(e as CustomEvent).detail);
    const interact=()=>gameRef.current?.events.emit('ui:interact');
    const reset=()=>gameRef.current?.events.emit('input:virtual-direction',{x:0,y:0});
    window.addEventListener('campus:virtual',direction);window.addEventListener('campus:interact',interact);window.addEventListener('blur',reset);
    return()=>{window.removeEventListener('campus:virtual',direction);window.removeEventListener('campus:interact',interact);window.removeEventListener('blur',reset);};
  },[]);
  const pausedRef = useRef(suspended);
  const [error, setError] = useState(false);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const loaded = () => setReady(true);
    const failed = () => setError(true);
    window.addEventListener('campus:world-ready', loaded);
    window.addEventListener('campus:world-error', failed);
    return () => {
      window.removeEventListener('campus:world-ready', loaded);
      window.removeEventListener('campus:world-error', failed);
    };
  }, []);
  useEffect(() => {
    pausedRef.current = suspended;
    const game = gameRef.current;
    if (!game) return;
    if (suspended) { game.loop.sleep(); if (game.input.keyboard) game.input.keyboard.enabled = false; }
    else { game.scene.getScenes(false).forEach(scene => scene.input.keyboard?.resetKeys()); game.loop.wake(); if (game.input.keyboard) game.input.keyboard.enabled = true; }
  }, [suspended]);
  useEffect(() => {
    const receive = (event: MessageEvent) => {
      if (event.source !== window.parent || event.origin !== location.origin) return;
      if (event.data?.type === 'proposal:visibility' && typeof event.data.visible === 'boolean') setPortalHidden(!event.data.visible);
    };
    window.addEventListener('message', receive);
    return () => window.removeEventListener('message', receive);
  }, []);
  useEffect(() => {
    if (!mountRef.current || navigator.userAgent.includes('jsdom')) return;
    let destroyed = false;
    let destroy: (() => void) | undefined;
    void Promise.all([import('phaser'), import('./game-config')]).then(([phaserModule, configModule]) => {
      if (destroyed || !mountRef.current) return;
      const game = new phaserModule.default.Game(configModule.createGameConfig(mountRef.current));
      gameRef.current = game;
      if (pausedRef.current) { game.loop.sleep(); if (game.input.keyboard) game.input.keyboard.enabled = false; }
      destroy = () => { gameRef.current = null; game.destroy(true); };
    }).catch(() => { if (!destroyed) setError(true); });
    return () => { destroyed = true; destroy?.(); };
  }, []);
  return <>{error && <p role="alert">校園場景未能載入。請重新整理，或先使用上方的數學任務體驗。</p>}{!ready && !error && <p role="status">正在載入校園場景…也可以先體驗上方的數學任務。</p>}<div className="game-frame" ref={frameRef}><div className="game-shell" aria-label="未來科技校園 RPG 遊戲畫面" ref={mountRef} /></div></>;
}
