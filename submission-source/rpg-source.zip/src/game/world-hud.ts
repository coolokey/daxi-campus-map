import { getWorldScale, setWorldScale, WORLD_SCALES, type WorldSnapshot } from './core/world';
import { findPath } from '../presentation/navigation';

/** Screen-space controls shared by Phaser and the lightweight presentation entry. */
export function mountWorldHud(frame:HTMLElement) {
  const tools=document.createElement('div');tools.className='world-tools';
  const label=document.createElement('label');label.textContent='校園大小 ';
  const select=document.createElement('select');select.setAttribute('aria-label','校園世界比例');
  WORLD_SCALES.forEach(s=>select.add(new Option(`${s} 倍`,String(s))));select.value=String(getWorldScale());label.append(select);tools.append(label);
  const note=document.createElement('span');note.textContent='紫色：NPC　青色：入口　橙色：導航目標';tools.append(note);
  const mini=document.createElement('button');mini.className='world-minimap';mini.setAttribute('aria-label','開啟校園全圖與導航');
  const small=document.createElement('canvas');small.width=240;small.height=162;mini.append(small);
  const caption=document.createElement('span');caption.textContent='校園小地圖';mini.append(caption);
  const dialog=document.createElement('dialog');dialog.className='world-map-dialog';
  const title=document.createElement('h2');title.textContent='校園全圖與導航';
  const help=document.createElement('p');help.textContent='點選可通行區域設定目標；金色線為避障路線，請沿線手動移動。';
  const full=document.createElement('canvas');full.width=800;full.height=541;full.tabIndex=0;full.setAttribute('aria-label','全圖：點選目標；方向鍵調整目標，Enter 確認');
  full.style.width='800px';full.style.maxWidth='100%';
  const close=document.createElement('button');close.textContent='返回探索';dialog.append(title,help,full,close);
  frame.prepend(tools);frame.append(mini,dialog);
  const controls=document.createElement('div');controls.className='world-touch-controls';controls.setAttribute('aria-label','觸控移動與互動');
  if(!frame.querySelector('#world')) {
    for(const [text,x,y] of [['← 左',-1,0],['↑ 上',0,-1],['↓ 下',0,1],['→ 右',1,0]] as const){
      const b=document.createElement('button');b.textContent=text;
      const send=(x:number,y:number)=>window.dispatchEvent(new CustomEvent('campus:virtual',{detail:{x,y}}));
      b.onpointerdown=e=>{e.preventDefault();b.setPointerCapture(e.pointerId);send(x,y);};
      for(const event of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(event,()=>send(0,0));
      controls.append(b);
    }
    const action=document.createElement('button');action.textContent='互動（E）';action.onclick=()=>window.dispatchEvent(new Event('campus:interact'));controls.append(action);frame.append(controls);
  }
  let snapshot:WorldSnapshot|undefined,target:{x:number;y:number}|undefined,lastMap='',lastDraw=0,themeMode:'future'|'realistic'='future';
  let route:{x:number;y:number}[]|null=null,routeLabel='';
  const receiveRoute=(event:Event)=>{const detail=(event as CustomEvent<{mapId:string;points:{x:number;y:number}[]|null;label:string}>).detail;if(snapshot?.map.id!==detail.mapId)return;route=detail.points;const end=route?.[route.length-1];target=end?{...end}:undefined;routeLabel=detail.label;if(!route)caption.textContent='此目標目前無可通行路線';render(small);};
  const receiveTheme=(event:Event)=>{themeMode=(event as CustomEvent<'future'|'realistic'>).detail;render(small);if(dialog.open)render(full);};
  const campusImage=new Image();campusImage.src=new URL('./assets/maps/daxi-future-campus-rpg-v1.webp',document.baseURI).href;
  let heading=0,previous:{x:number;y:number;map:string;width:number}|undefined;
  const pause=(paused:boolean)=>window.dispatchEvent(new CustomEvent('campus:map-open',{detail:paused}));
  const render=(canvas:HTMLCanvasElement)=>{
    if(!snapshot)return;
    const {map,player,npcs}=snapshot,width=canvas.getBoundingClientRect().width||(canvas===full?800:240),height=Math.round(width*map.height/map.width),dpr=Math.max(1,Math.min(2,window.devicePixelRatio||1));
    canvas.width=Math.round(width*dpr);canvas.height=Math.round(height*dpr);
    const c=canvas.getContext('2d')!,sx=width/map.width,sy=height/map.height;
    c.setTransform(dpr,0,0,dpr,0,0);
    c.fillStyle='#c0dca2';c.fillRect(0,0,width,height);
    if(map.farmArea){const r=map.farmArea;c.fillStyle='#b2bd81';c.fillRect(r.x*sx,r.y*sy,r.width*sx,r.height*sy);}
    c.fillStyle='#8d9996';for(const r of map.parkingAreas??[])c.fillRect(r.x*sx,r.y*sy,r.width*sx,r.height*sy);
    if(map.id==='campus'&&map.backgroundKey!=='latest-model-v2'&&themeMode==='future'&&campusImage.complete&&campusImage.naturalWidth)c.drawImage(campusImage,0,0,width,height);
    else {if(map.floorPlan){c.fillStyle='#f1eadb';map.floorPlan.footprints.forEach(r=>c.fillRect(r.x*sx,r.y*sy,r.width*sx,r.height*sy));c.strokeStyle='#b5a88d';map.floorPlan.rooms.forEach(({rect:r,name})=>{c.strokeRect(r.x*sx,r.y*sy,r.width*sx,r.height*sy);if(canvas===full){c.fillStyle='#214b61';c.font='11px sans-serif';c.fillText(name,r.x*sx+3,r.y*sy+14,Math.max(20,r.width*sx-6));}});}c.fillStyle='#b0a58c';map.collisionZones.forEach(r=>c.fillRect(r.x*sx,r.y*sy,r.width*sx,r.height*sy));}
    c.fillStyle='#bc9d70';for(const r of map.outdoorPaving??[])c.fillRect(r.x*sx,r.y*sy,r.width*sx,r.height*sy);
    c.strokeStyle='#bc9d70';for(const p of map.outdoorPaths??[]){c.lineWidth=Math.max(1,p.width*Math.min(sx,sy));c.beginPath();p.points.forEach((q,i)=>i?c.lineTo(q.x*sx,q.y*sy):c.moveTo(q.x*sx,q.y*sy));c.stroke();}
    c.fillStyle='#8c6546';for(const r of map.farmBeds??[])c.fillRect(r.x*sx,r.y*sy,r.width*sx,r.height*sy);
    c.fillStyle='#389cc7';for(const r of map.sportsCourts??[])c.fillRect(r.x*sx,r.y*sy,r.width*sx,r.height*sy);
    c.fillStyle='#008b97';map.portals.forEach(p=>c.fillRect(p.trigger.x*sx,p.trigger.y*sy,Math.max(5,p.trigger.width*sx),Math.max(5,p.trigger.height*sy)));
    c.fillStyle='#9b40b0';npcs.forEach(n=>{c.beginPath();c.arc(n.x*sx,n.y*sy,canvas===full?5:3,0,Math.PI*2);c.fill();});
    if(target){c.strokeStyle='#e67b00';c.lineWidth=2;c.beginPath();(route??[player,target]).forEach((p,i)=>i?c.lineTo(p.x*sx,p.y*sy):c.moveTo(p.x*sx,p.y*sy));c.stroke();c.fillStyle='#e67b00';c.fillRect(target.x*sx-4,target.y*sy-4,8,8);}
    for(const m of map.landmarks??[]){c.fillStyle='#a76621';c.fillRect(m.x*sx-2,m.y*sy-2,4,4);if(canvas===full){c.font='10px sans-serif';c.fillText(m.label,m.x*sx+5,m.y*sy);}}
    for(const m of map.questMarkers??[]){const x=m.x*sx,y=m.y*sy;c.fillStyle=m.completed?'#496747':m.color;c.strokeStyle='#fffdf5';c.lineWidth=1.5;c.beginPath();c.arc(x,y,canvas===full?9:6,0,Math.PI*2);c.fill();c.stroke();c.fillStyle='white';c.textAlign='center';c.font='bold 9px sans-serif';c.fillText(m.completed?'✓':m.symbol,x,y+3);if(canvas===full){c.textAlign='left';c.fillStyle='#253b43';c.fillText(m.label,x+12,y+3);}c.textAlign='left';}
    const px=player.x*sx,py=player.y*sy;
    c.save();c.translate(px,py);
    for(const [radius,color] of [[11,'#102a43'],[8.5,'white']] as const){c.fillStyle=color;c.beginPath();c.arc(0,0,radius,0,Math.PI*2);c.fill();}
    c.rotate(heading);c.fillStyle='#005bd7';c.strokeStyle='#102a43';c.lineWidth=1.5;c.beginPath();c.moveTo(0,-10);c.lineTo(6,6);c.lineTo(0,3);c.lineTo(-6,6);c.closePath();c.fill();c.stroke();c.restore();
    const lx=Math.max(2,Math.min(width-72,px+13)),ly=Math.max(2,Math.min(height-18,py-25));
    c.fillStyle='#102a43';c.fillRect(lx,ly,70,17);c.fillStyle='white';c.font='bold 11px sans-serif';c.fillText('你在這裡',lx+7,ly+12);
  };
  const receive=(event:Event)=>{
    snapshot=(event as CustomEvent<WorldSnapshot>).detail;
    const p=snapshot.player;
    if(previous?.map===snapshot.map.id&&previous.width===snapshot.map.width){const dx=p.x-previous.x,dy=p.y-previous.y;if(Math.hypot(dx,dy)>.01)heading=Math.atan2(dx,-dy);}
    else heading=({up:0,right:Math.PI/2,down:Math.PI,left:-Math.PI/2} as Record<string,number>)[p.direction??'up'];
    previous={x:p.x,y:p.y,map:snapshot.map.id,width:snapshot.map.width};
    if(snapshot.map.id!==lastMap){target=undefined;route=null;routeLabel='';lastMap=snapshot.map.id;}
    const now=performance.now();if(now-lastDraw<90)return;lastDraw=now;
    render(small);if(dialog.open)render(full);
    let text=snapshot.map.displayName ?? (snapshot.map.id==='campus'?'校園小地圖':'科技館・數學研究室');
    if(target){const dx=target.x-snapshot.player.x,dy=target.y-snapshot.player.y,d=Math.hypot(dx,dy);text=d<35?'已抵達導航目標':`${routeLabel?routeLabel+'・':''}${Math.round(d)} 單位`;}else if(routeLabel)text='此目標目前無可通行路線';
    caption.textContent=text;
  };
  select.onchange=()=>{const previous=getWorldScale(),next=Number(select.value),custom=routeLabel==='自訂目標'&&target?{x:target.x*next/previous,y:target.y*next/previous}:undefined;setWorldScale(next);window.dispatchEvent(new CustomEvent('campus:scale',{detail:next}));if(custom&&snapshot){target=custom;navigate();}select.blur();};
  mini.onclick=()=>{if(!snapshot)return;dialog.showModal();pause(true);render(full);close.focus();};
  close.onclick=()=>dialog.close();dialog.onclose=()=>{pause(false);mini.focus();};
  const navigate=()=>{if(!snapshot||!target)return;const points=findPath(snapshot.player,target,snapshot.map);window.dispatchEvent(new CustomEvent('campus:navigation-route',{detail:{mapId:snapshot.map.id,points,label:'自訂目標'}}));};
  full.onclick=e=>{if(!snapshot)return;const r=full.getBoundingClientRect();target={x:Math.max(0,Math.min(snapshot.map.width,(e.clientX-r.left)/r.width*snapshot.map.width)),y:Math.max(0,Math.min(snapshot.map.height,(e.clientY-r.top)/r.height*snapshot.map.height))};navigate();render(full);render(small);dialog.close();};
  full.onkeydown=e=>{if(!snapshot)return;const delta={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];if(delta){e.preventDefault();target??={x:snapshot.player.x,y:snapshot.player.y};target.x=Math.max(0,Math.min(snapshot.map.width,target.x+delta[0]*50));target.y=Math.max(0,Math.min(snapshot.map.height,target.y+delta[1]*50));render(full);}if(e.key==='Enter'){navigate();dialog.close();}};
  window.addEventListener('campus:snapshot',receive);
  window.addEventListener('campus:navigation-route',receiveRoute);
  window.addEventListener('campus:theme-mode',receiveTheme);
  return ()=>{window.removeEventListener('campus:snapshot',receive);window.removeEventListener('campus:navigation-route',receiveRoute);window.removeEventListener('campus:theme-mode',receiveTheme);if(dialog.open)pause(false);tools.remove();mini.remove();dialog.remove();controls.remove();};
}
