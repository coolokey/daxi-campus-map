import { getWorldScale, setWorldScale, WORLD_SCALES, type WorldSnapshot } from './core/world';

/** Screen-space controls shared by Phaser and the lightweight presentation entry. */
export function mountWorldHud(frame:HTMLElement) {
  const tools=document.createElement('div');tools.className='world-tools';
  const label=document.createElement('label');label.textContent='校園大小 ';
  const select=document.createElement('select');select.setAttribute('aria-label','校園世界比例');
  WORLD_SCALES.forEach(s=>select.add(new Option(`${s} 倍`,String(s))));select.value=String(getWorldScale());label.append(select);tools.append(label);
  const note=document.createElement('span');note.textContent='紫色：NPC　青色：入口';tools.append(note);
  const mini=document.createElement('button');mini.className='world-minimap';mini.setAttribute('aria-label','開啟校園全圖與導航');
  const small=document.createElement('canvas');small.width=240;small.height=162;mini.append(small);
  const caption=document.createElement('span');caption.textContent='校園小地圖';mini.append(caption);
  const dialog=document.createElement('dialog');dialog.className='world-map-dialog';
  const title=document.createElement('h2');title.textContent='校園全圖與導航';
  const help=document.createElement('p');help.textContent='點選地圖設定目標；方向與距離會顯示於小地圖下方。';
  const full=document.createElement('canvas');full.width=800;full.height=541;full.tabIndex=0;full.setAttribute('aria-label','全圖：點選目標；方向鍵調整目標，Enter 確認');
  const close=document.createElement('button');close.textContent='返回探索';dialog.append(title,help,full,close);
  frame.prepend(tools);frame.append(mini,dialog);
  const controls=document.createElement('div');controls.className='world-touch-controls';controls.setAttribute('aria-label','觸控移動與互動');
  if(!frame.querySelector('#world')) {
    for(const [text,x,y] of [['← 左',-1,0],['↑ 上',0,-1],['↓ 下',0,1],['→ 右',1,0]] as const){
      const b=document.createElement('button');b.textContent=text;
      const send=(x:number,y:number)=>window.dispatchEvent(new CustomEvent('campus:virtual',{detail:{x,y}}));
      b.onpointerdown=e=>{e.preventDefault();b.setPointerCapture(e.pointerId);send(x,y);};
      for(const event of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(event,()=>send(0,0));
      controls.append(b);
    }
    const action=document.createElement('button');action.textContent='互動（E）';action.onclick=()=>window.dispatchEvent(new Event('campus:interact'));controls.append(action);frame.append(controls);
  }
  let snapshot:WorldSnapshot|undefined,target:{x:number;y:number}|undefined,lastMap='',lastDraw=0;
  const campusImage=new Image();campusImage.src=new URL('./assets/maps/daxi-future-campus-rpg-v1.webp',document.baseURI).href;
  let heading=0,previous:{x:number;y:number;map:string}|undefined;
  const pause=(paused:boolean)=>window.dispatchEvent(new CustomEvent('campus:map-open',{detail:paused}));
  const render=(canvas:HTMLCanvasElement)=>{
    if(!snapshot)return;
    const {map,player,npcs}=snapshot;canvas.height=Math.round(canvas.width*map.height/map.width);
    const c=canvas.getContext('2d')!,sx=canvas.width/map.width,sy=canvas.height/map.height;
    c.fillStyle='#e4f3ed';c.fillRect(0,0,canvas.width,canvas.height);
    if(map.id==='campus'&&campusImage.complete&&campusImage.naturalWidth)c.drawImage(campusImage,0,0,canvas.width,canvas.height);
    else {c.fillStyle='#829caf';map.collisionZones.forEach(r=>c.fillRect(r.x*sx,r.y*sy,r.width*sx,r.height*sy));}
    c.fillStyle='#008b97';map.portals.forEach(p=>c.fillRect(p.trigger.x*sx,p.trigger.y*sy,Math.max(5,p.trigger.width*sx),Math.max(5,p.trigger.height*sy)));
    c.fillStyle='#9b40b0';npcs.forEach(n=>{c.beginPath();c.arc(n.x*sx,n.y*sy,canvas===full?5:3,0,Math.PI*2);c.fill();});
    if(target){c.strokeStyle='#e67b00';c.lineWidth=2;c.beginPath();c.moveTo(player.x*sx,player.y*sy);c.lineTo(target.x*sx,target.y*sy);c.stroke();c.fillStyle='#e67b00';c.fillRect(target.x*sx-4,target.y*sy-4,8,8);}
    c.save();c.translate(player.x*sx,player.y*sy);c.rotate(heading);c.fillStyle='#005bd7';c.strokeStyle='white';c.lineWidth=1.5;c.beginPath();c.moveTo(0,-7);c.lineTo(5,5);c.lineTo(-5,5);c.closePath();c.fill();c.stroke();c.restore();
  };
  const receive=(event:Event)=>{
    snapshot=(event as CustomEvent<WorldSnapshot>).detail;
    const p=snapshot.player;
    if(previous?.map===snapshot.map.id){const dx=p.x-previous.x,dy=p.y-previous.y;if(Math.hypot(dx,dy)>.01)heading=Math.atan2(dx,-dy);}
    else heading=({up:0,right:Math.PI/2,down:Math.PI,left:-Math.PI/2} as Record<string,number>)[p.direction??'up'];
    previous={x:p.x,y:p.y,map:snapshot.map.id};
    if(snapshot.map.id!==lastMap){target=undefined;lastMap=snapshot.map.id;}
    const now=performance.now();if(now-lastDraw<90)return;lastDraw=now;
    render(small);if(dialog.open)render(full);
    let text=snapshot.map.displayName ?? (snapshot.map.id==='campus'?'校園小地圖':'科技館・數學研究室');
    if(target){const dx=target.x-snapshot.player.x,dy=target.y-snapshot.player.y,d=Math.hypot(dx,dy);text=d<35?'已抵達導航目標':`目標 ${dy<0?'北':'南'}${dx<0?'西':'東'}・${Math.round(d)} 單位`;}
    caption.textContent=text;
  };
  select.onchange=()=>{const previous=getWorldScale(),next=Number(select.value);setWorldScale(next);if(target && snapshot && (snapshot.map.id==='campus'||snapshot.map.id.startsWith('pilot-'))){target.x*=next/previous;target.y*=next/previous;}window.dispatchEvent(new CustomEvent('campus:scale',{detail:next}));select.blur();};
  mini.onclick=()=>{if(!snapshot)return;dialog.showModal();pause(true);render(full);close.focus();};
  close.onclick=()=>dialog.close();dialog.onclose=()=>{pause(false);mini.focus();};
  full.onclick=e=>{if(!snapshot)return;const r=full.getBoundingClientRect();target={x:Math.max(0,Math.min(snapshot.map.width,(e.clientX-r.left)/r.width*snapshot.map.width)),y:Math.max(0,Math.min(snapshot.map.height,(e.clientY-r.top)/r.height*snapshot.map.height))};render(full);render(small);dialog.close();};
  full.onkeydown=e=>{if(!snapshot)return;const delta={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];if(delta){e.preventDefault();target??={x:snapshot.player.x,y:snapshot.player.y};target.x=Math.max(0,Math.min(snapshot.map.width,target.x+delta[0]*50));target.y=Math.max(0,Math.min(snapshot.map.height,target.y+delta[1]*50));render(full);}if(e.key==='Enter')dialog.close();};
  window.addEventListener('campus:snapshot',receive);
  return ()=>{window.removeEventListener('campus:snapshot',receive);if(dialog.open)pause(false);tools.remove();mini.remove();dialog.remove();controls.remove();};
}
