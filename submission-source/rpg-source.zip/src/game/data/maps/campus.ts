import { INTERACTION_RADIUS } from '../../config';
import type { MapConfig } from '../types';
import { campusCollisionZones } from './campus-obstacles';

// Base-world validation route: south walkway, running track, central turf.
export const SPORTS_FIELD_ROUTE = [{x:720,y:950},{x:720,y:770},{x:720,y:515}] as const;

export const campusMap: MapConfig = {
  id: 'campus',
  width: 2400,
  height: 1624,
  backgroundKey: 'campus-background',
  spawns: {
    'campus-start': { x: 1180, y: 1360, direction: 'up' },
    'technology-door-return': { x: 1930, y: 900, direction: 'down' },
  },
  collisionZones: campusCollisionZones,
  npcs: [{
    id: 'math-researcher', mapId: 'campus', x: 1700, y: 1380, direction: 'down',
    spriteKey: 'math-陳小鈴', portraitKey: 'math-陳小鈴-portrait',
    interactionRadius: INTERACTION_RADIUS, dialogueId: 'campus-researcher', name: '陳小鈴老師',
    speed: 44, route: [{x:1700,y:1380},{x:1850,y:1380},{x:1850,y:1400},{x:1700,y:1400}],
  }],
  portals: [{
    id: 'technology-building-door', mapId: 'campus', trigger: { x: 1945, y: 750, width: 120, height: 80 },
    destinationMapId: 'research-lab', destinationSpawnId: 'lab-entry', prompt: 'E 進入科技館數學研究室',
  }],
};
