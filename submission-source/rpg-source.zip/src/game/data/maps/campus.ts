import { INTERACTION_RADIUS } from '../../config';
import type { MapConfig } from '../types';

// Base-world validation route: south walkway, running track, central turf.
export const SPORTS_FIELD_ROUTE = [{x:680,y:950},{x:680,y:770},{x:680,y:515}] as const;

export const campusMap: MapConfig = {
  id: 'campus',
  width: 2400,
  height: 1624,
  backgroundKey: 'campus-background',
  spawns: {
    'campus-start': { x: 1180, y: 1360, direction: 'up' },
    'technology-door-return': { x: 1880, y: 900, direction: 'down' },
  },
  collisionZones: [
    // Only the visible grey equipment platform and net are solid; turf/lanes remain walkable.
    { x: 904, y: 315, width: 34, height: 44 },
    { x: 958, y: 346, width: 114, height: 51 },
    { x: 1700, y: 260, width: 500, height: 520 },
    { x: 1360, y: 950, width: 300, height: 260 },
    { x: 250, y: 1060, width: 470, height: 330 },
  ],
  npcs: [{
    id: 'math-researcher', mapId: 'campus', x: 1810, y: 1030, direction: 'down',
    spriteKey: 'math-陳小鈴', portraitKey: 'math-陳小鈴-portrait',
    interactionRadius: INTERACTION_RADIUS, dialogueId: 'campus-researcher', name: '陳小鈴老師',
    speed: 44, route: [{x:1810,y:1030},{x:1810,y:900},{x:2200,y:900},{x:2200,y:1030}],
  }],
  portals: [{
    id: 'technology-building-door', mapId: 'campus', trigger: { x: 1945, y: 750, width: 120, height: 80 },
    destinationMapId: 'research-lab', destinationSpawnId: 'lab-entry', prompt: 'E 進入科技館數學研究室',
  }],
};
