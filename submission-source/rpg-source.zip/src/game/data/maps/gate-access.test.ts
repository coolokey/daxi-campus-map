import { describe, it, expect } from 'vitest';
import { campusMap } from './campus';
import { addCampusEntrances } from '../../../presentation/campus-entrances';
import { movePlayer } from '../../../presentation/movement';
import { findPath, walkable } from '../../../presentation/navigation';

describe('campus gate and entrance accessibility', () => {
  const map = addCampusEntrances({ ...campusMap });

  it('can walk from spawn to the front gate', () => {
    // Start at actual campus-start spawn (x=1180, y=1360)
    let p1 = { ...map.spawns['campus-start'] };
    for (let i = 0; i < 60; i++) {
      p1 = { ...p1, ...movePlayer(p1, 0, 1, 0.05, map) };
    }
    expect(p1.y).toBeGreaterThan(1500);

    // Also test avenue center (x=1280, y=1360)
    let p2 = { x: 1280, y: 1360, direction: 'down' as const };
    for (let i = 0; i < 60; i++) {
      p2 = { ...p2, ...movePlayer(p2, 0, 1, 0.05, map) };
    }
    expect(p2.y).toBeGreaterThan(1500);
  });

  it('tests walkability of various campus zones for character roaming', () => {
    const testRoutes = [
      // Track & Sports Field (田徑場與跑道)
      { name: 'Sports Field Track East', route: [{x:720,y:950},{x:720,y:750},{x:720,y:530}] },
      { name: 'Sports Field Turf Center', route: [{x:550,y:400},{x:550,y:700}] },
      { name: 'Sports Field South Road', route: [{x:450,y:960},{x:720,y:960}] },
      // West Plaza / Activity Center (體育館前大道)
      { name: 'Gym Front Boulevard', route: [{x:880,y:1050},{x:880,y:1350}] },
      // North Ball Courts (籃球場內步道)
      { name: 'North Basketball Court Loop', route: [{x:1560,y:350},{x:1740,y:350},{x:1740,y:520},{x:1560,y:520}] },
      // Green Volleyball Court (排球場步道)
      { name: 'North Volleyball Court', route: [{x:1340,y:330},{x:1340,y:520}] },
      // Central Courtyard & Statue Plaza (孔子銅像北側廣場)
      { name: 'Statue Plaza Walk', route: [{x:1420,y:880},{x:1660,y:880}] },
      // Central Boulevard Mid (中央林蔭道中段)
      { name: 'Central Boulevard Mid', route: [{x:1090,y:960},{x:1090,y:1380}] },
      // East Campus / Tech & Art (科技館東側林蔭步道)
      { name: 'East Technology Walkway', route: [{x:1930,y:950},{x:1930,y:1200}] },
      // South Gate Entrance Avenue (校門迎賓大道)
      { name: 'Main Gate Avenue Center', route: [{x:1280,y:1380},{x:1280,y:1540}] },
      { name: 'Main Front Road East', route: [{x:1400,y:1380},{x:1850,y:1380}] },
    ];

    const avoidsPortals = (route: {x:number;y:number}[], buffer = 50) => route.every((start, i) => {
      const end = route[(i + 1) % route.length];
      const steps = Math.ceil(Math.hypot(end.x - start.x, end.y - start.y) / 5);
      for (let step = 0; step <= steps; step++) {
        const x = start.x + (end.x - start.x) * step / steps;
        const y = start.y + (end.y - start.y) * step / steps;
        if (map.portals.some(({ trigger: r }) => x > r.x - buffer && x < r.x + r.width + buffer && y > r.y - buffer && y < r.y + r.height + buffer)) {
          return false;
        }
      }
      return true;
    });

    const validCandidates = testRoutes.filter(r => {
      for (const p of r.route) if (!walkable(p, map)) return false;
      return avoidsPortals(r.route, 50);
    });
    console.log('Routes passing BOTH walkability and portal avoidance:', validCandidates.map(r => r.name));
    expect(validCandidates.length).toBeGreaterThanOrEqual(6);
  });

  it('tests path from campus-start to all portals', () => {
    const start = map.spawns['campus-start'];
    for (const p of map.portals) {
      const target = { x: p.trigger.x + p.trigger.width / 2, y: p.trigger.y + p.trigger.height / 2 };
      const path = findPath(start, target, map);
      console.log(`Portal ${p.id} (${p.prompt}): path length = ${path?.length ?? 'BLOCKED'}`);
      expect(path, `Portal ${p.id} reachable`).not.toBeNull();
    }
  });
});
