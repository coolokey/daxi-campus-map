/** Ground footprints traced on the retained 1525×1031 illustration, not surveyed building plans.
 * Keep courts/turf, stairs, gate openings and roads walkable. Overhead gate arches are not walls.
 * Tuples are source-image pixels; convert once to the 2400×1624 base world, then scaleMap handles scale.
 */
const footprints:readonly (readonly [number,number,number,number])[]=[
  [574,200,22,28], // field equipment platform
  [608,220,73,32], // field net
  [466,508,12,27], // flagpole base
  [270,500,177,25], [500,500,139,25], // stands (y=500..525, opens 33px road south of track)
  [275,558,144,31], [523,558,145,31], // entrance gardens (y=558..589)
  [419,558,20,26], [503,558,20,26],   // gate piers
  [251,655,229,160],                   // gym building (y=655..815, leaves stairs y=815..854 open)
  [181,665,36,105], [266,631,209,24],  // gym gardens
  [243,819,65,46], [408,819,86,46],   // gym side planting/wings
  [563,653,49,49],                     // west plaza fountain base
  [505,801,30,64], [602,791,64,74],   // plaza planting beds
  [742,530,174,240],                   // west main building (x=742 opens road x=708..742)
  [1062,530,148,240],                  // east main building
  [885,777,166,80],                    // southern connector / admin front
  [954,591,55,62],                     // central statue/fountain pool
  [704,779,144,59],                    // southwest planting bed
  [1235,82,167,175], [1403,114,68,146], // northeast buildings and tower
  [1240,270,151,143],                  // eastern courtyard building
  [1403,301,64,252],                   // east circular wing
  [1239,425,163,136],                  // technology wing
  [1240,580,130,274],                  // southeast building
  [1243,865,124,93],                   // southeast gate tower
  [936,155,242,18], [924,173,15,211], [1175,173,15,211], // basketball fences
  [937,384,111,20], [1081,384,97,20], // south court gate opening
  [814,158,110,16], [800,174,14,205], // green court fences
  [814,384,40,18], [883,384,41,18],   // green court south gate
  [765,414,135,68],                    // garden south of courts
  [931,434,83,52],                     // small pavilion building
  [1028,429,150,53],                   // east garden
  [808,76,56,58],                      // north octagonal pavilion
  [746,102,38,38], [880,102,38,38],   // north circular flower beds
  [719,895,20,78], [881,895,36,78],   // main gate piers (widened gate opening to 223px)
  [365,915,354,50], [917,915,326,50], // south perimeter walls (prevents walking through wall into street)
  // Campus edge: conservative stair-step exterior masks follow the visible perimeter.
  [0,0,1525,26], [0,26,254,52], [0,78,160,65], [0,143,90,70],
  [0,213,47,399], [0,612,76,80], [0,692,101,85], [0,777,133,85],
  [0,862,174,80], [0,942,365,89], [365,973,375,58], [900,973,625,58],
  [1494,26,31,200], [1480,226,45,180], [1464,406,61,180],
  [1434,586,91,150], [1410,736,115,100], [1374,836,151,90], [1345,926,180,105],
];
export const campusCollisionZones=footprints.map(([x,y,width,height])=>({x:x*2400/1525,y:y*1624/1031,width:width*2400/1525,height:height*1624/1031}));
