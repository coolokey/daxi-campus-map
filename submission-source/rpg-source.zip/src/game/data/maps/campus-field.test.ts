import { describe, expect, it } from 'vitest';
import { campusMap, SPORTS_FIELD_ROUTE } from './campus';
import { scaleMap } from '../../core/world';
import { movePlayer } from '../../../presentation/movement';

describe('sports field access', () => {
  for (const scale of [1, 1.5, 2]) it(`walks from the south road through track onto turf at ${scale}x`, () => {
    const world = scaleMap(campusMap, scale);
    let p = { x: SPORTS_FIELD_ROUTE[0].x * scale, y: SPORTS_FIELD_ROUTE[0].y * scale };
    for (const point of SPORTS_FIELD_ROUTE.slice(1)) {
      const goal = { x: point.x * scale, y: point.y * scale };
      for (let i = 0; i < 300 && Math.hypot(goal.x-p.x,goal.y-p.y)>1; i++) {
        const distance = Math.hypot(goal.x-p.x,goal.y-p.y);
        p = movePlayer(p, goal.x-p.x, goal.y-p.y, .1, world, Math.min(220, distance/.1));
      }
      expect(p.x).toBeCloseTo(goal.x); expect(p.y).toBeCloseTo(goal.y);
    }
  });
  for (const scale of [1,1.5,2]) it(`cannot cross either visible equipment fixture at ${scale}x`,()=>{
    const world=scaleMap(campusMap,scale);
    for(const fixture of world.collisionZones.slice(0,2)) {
      let p={x:fixture.x-30,y:fixture.y+fixture.height/2};
      for(let i=0;i<20;i++)p=movePlayer(p,1,0,.1,world);
      expect(p.x).toBeLessThanOrEqual(fixture.x-11);
      expect(p.x).toBeGreaterThan(fixture.x-30);
    }
  });
  it('keeps the three existing buildings solid', () => {
    expect(campusMap.collisionZones).toEqual(expect.arrayContaining([
      { x:1700,y:260,width:500,height:520 }, { x:1360,y:950,width:300,height:260 }, { x:250,y:1060,width:470,height:330 },
    ]));
  });
});
