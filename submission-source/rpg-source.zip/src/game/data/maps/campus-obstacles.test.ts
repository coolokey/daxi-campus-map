import { describe,it,expect } from 'vitest';
import { campusMap } from './campus';
import { scaleMap,createResidents,stepResidents } from '../../core/world';
import { movePlayer } from '../../../presentation/movement';
import { isBlocked } from '../../core/collision';

const sx=2400/1525,sy=1624/1031;
describe('illustrated campus solid objects',()=>{
  it.each([1,1.5,2])('blocks representative illustrated buildings and fixtures at %sx',scale=>{
    const map=scaleMap(campusMap,scale);
    for(const [x,y]of [[810,650],[1140,650],[970,820],[1310,480],[1430,160],[586,680],[980,625],[360,520],[795,445],[732,935]]){
      expect(isBlocked({x:x*sx*scale-11,y:y*sy*scale-11,width:22,height:22},map.collisionZones),`${x},${y}`).toBe(true);
    }
  });
  it.each([1,1.5,2])('keeps spawns, NPC routes, main road and technology entrance reachable at %sx',scale=>{
    const map=scaleMap(campusMap,scale);
    for(const spawn of Object.values(map.spawns))expect(isBlocked({x:spawn.x-11,y:spawn.y-11,width:22,height:22},map.collisionZones)).toBe(false);
    for(const [x,y]of [[1065,394],[868,394],[457,520],[815,985]])expect(isBlocked({x:x*sx*scale-11,y:y*sy*scale-11,width:22,height:22},map.collisionZones),`gate ${x},${y}`).toBe(false);
    let p={...map.spawns['campus-start']};
    for(const goal of [{x:1090,y:1360},{x:1090,y:1380},{x:1930,y:1380},{x:1930,y:850}]){
      const target={x:goal.x*scale,y:goal.y*scale};
      for(let i=0;i<400&&Math.hypot(p.x-target.x,p.y-target.y)>1;i++){const d=Math.hypot(p.x-target.x,p.y-target.y);p={...p,...movePlayer(p,target.x-p.x,target.y-p.y,.1,map,Math.min(220,d/.1))};}
      expect(p.x).toBeCloseTo(target.x);expect(p.y).toBeCloseTo(target.y);
    }
    const portal=map.portals[0].trigger;expect(p.x).toBeGreaterThanOrEqual(portal.x-60);expect(p.y).toBeLessThanOrEqual(portal.y+portal.height+60);
    const npcs=createResidents(map);
    for(let step=0;step<800;step++){stepResidents(npcs,map,.1,{x:0,y:0},false);for(const n of npcs)expect(isBlocked({x:n.x-11,y:n.y-11,width:22,height:22},map.collisionZones),n.id).toBe(false);}
  });
  it('stops a real walk at the east main building instead of crossing its roof',()=>{
    let p={x:1930,y:1000};for(let i=0;i<100;i++)p=movePlayer(p,-1,0,.1,campusMap);
    expect(p.x).toBeGreaterThan(1900);
  });
});
