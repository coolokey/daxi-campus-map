import type { NpcConfig } from './types';

/** Fictional campus residents. Coordinates use the unscaled campus plan. */
export const residents: NpcConfig[] = [
  { id:'student-explorer', mapId:'campus', name:'探索同學', kind:'student', x:1180,y:980,direction:'down',spriteKey:'npc-placeholder',portraitKey:'npc-placeholder',interactionRadius:76,dialogueId:'explore',speed:62,
    route:[{x:1180,y:980},{x:1280,y:980},{x:1280,y:1440},{x:1180,y:1440}], dialogue:'沿著中央道路往北走，就能接近科技館。點開小地圖也能設定探索目標！' },
  { id:'student-science', mapId:'campus', name:'科學同學', kind:'student', x:2250,y:900,direction:'down',spriteKey:'npc-placeholder',portraitKey:'npc-placeholder',interactionRadius:76,dialogueId:'science',speed:55,
    route:[{x:2250,y:900},{x:2250,y:1420},{x:1810,y:1420},{x:1810,y:900}], dialogue:'研究室正在修復能源核心。走到發光入口，按互動就能進去挑戰數學任務。' },
  { id:'robot-patrol',mapId:'campus',name:'巡邏機器人',kind:'robot',x:40,y:40,direction:'right',spriteKey:'npc-placeholder',portraitKey:'npc-placeholder',interactionRadius:76,dialogueId:'patrol',speed:75,
    route:[{x:40,y:40},{x:2360,y:40},{x:2360,y:1580},{x:40,y:1580}],dialogue:'校園巡邏中。我是 NPC，不是真正在線玩家。請沿道路探索；小地圖的紫色點是校園角色。' },
];
