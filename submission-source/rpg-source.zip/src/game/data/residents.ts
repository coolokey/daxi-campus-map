import type { NpcConfig } from './types';

/** Fictional campus residents. Coordinates use the unscaled campus plan. */
export const residents: NpcConfig[] = [
  { id:'student-explorer', mapId:'campus', name:'探索同學', kind:'student', x:1090,y:980,direction:'down',spriteKey:'npc-placeholder',portraitKey:'npc-placeholder',interactionRadius:76,dialogueId:'explore',speed:62,
    route:[{x:1090,y:980},{x:1090,y:1380}], dialogue:'沿著中央道路往北走，就能接近科技館。點開小地圖也能設定探索目標！' },
  { id:'student-science', mapId:'campus', name:'科學同學', kind:'student', x:1930,y:1000,direction:'down',spriteKey:'npc-placeholder',portraitKey:'npc-placeholder',interactionRadius:76,dialogueId:'science',speed:55,
    route:[{x:1930,y:1000},{x:1930,y:1380},{x:1800,y:1380},{x:1930,y:1380}], dialogue:'研究室正在修復能源核心。走到發光入口，按互動就能進去挑戰數學任務。' },
  { id:'robot-patrol',mapId:'campus',name:'巡邏機器人',kind:'robot',x:1800,y:1380,direction:'left',spriteKey:'npc-placeholder',portraitKey:'npc-placeholder',interactionRadius:76,dialogueId:'patrol',speed:75,
    route:[{x:1800,y:1380},{x:1090,y:1380},{x:1090,y:980},{x:1090,y:1380},{x:1930,y:1380},{x:1930,y:980},{x:1930,y:1380}],dialogue:'校園巡邏中。我是 NPC，不是真正在線玩家。請沿道路探索；小地圖的紫色點是校園角色。' },
];
