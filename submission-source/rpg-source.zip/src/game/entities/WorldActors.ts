import Phaser from 'phaser';
import type { MapConfig } from '../data/types';
import { createResidents, publishWorld, stepResidents } from '../core/world';

export class WorldActors {
  readonly npcs;
  private sprites:Phaser.GameObjects.Sprite[];
  private labels:Phaser.GameObjects.Text[];
  constructor(scene:Phaser.Scene, readonly map:MapConfig) {
    this.npcs=createResidents(map);
    this.sprites=this.npcs.map(n=>scene.add.sprite(n.x,n.y,n.spriteKey).setDepth(2));
    this.labels=this.npcs.map(n=>scene.add.text(n.x,n.y-33,`${n.name} · NPC`,{fontSize:'14px',color:'#123d54',backgroundColor:'#ffffffcc',padding:{x:4,y:2}}).setOrigin(.5).setDepth(4));
    this.sprites.forEach((s,i)=>{if(this.npcs[i].kind)s.setTint(this.npcs[i].kind==='robot'?0x9ab6c8:0x7ecab4);});
  }
  update(delta:number,player:{x:number;y:number;direction?:string},paused:boolean) {
    stepResidents(this.npcs,this.map,delta/1000,player,paused);
    this.npcs.forEach((n,i)=>{this.sprites[i].setPosition(n.x,n.y);if(n.kind)this.sprites[i].setTexture(`player-${n.direction}-${n.moving&&!paused&&Math.floor(performance.now()/160)%2?'walk':'idle'}`);this.labels[i].setPosition(n.x,n.y-33);});
    publishWorld({map:this.map,player:{...player},npcs:this.npcs});
  }
}
