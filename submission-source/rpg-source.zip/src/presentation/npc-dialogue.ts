import type { NpcConfig } from '../game/data/types';
export function showNpcDialogue(npc:NpcConfig,dialogue:HTMLElement) {
  dialogue.querySelector('p')!.textContent=`${npc.name} · NPC：${npc.dialogue ?? '歡迎來到未來校園！前往科技館入口，與研究室助教一起修復能源核心。'}`;
  dialogue.hidden=false;document.getElementById('dialogue-close')!.focus();
}
