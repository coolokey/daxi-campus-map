import {describe,it,expect} from 'vitest';
import {basketballConfig as B,basketballCourts,basketballHoops,basketballTarget} from './basketball-courts';
import {createModelWorld} from './model-world';
import {walkable,clearSegment,canReach} from './navigation';
describe('guide basketball complex restored in RPG',()=>{
 it('uses three source courts and six hoops rather than the existing volleyball rectangles',()=>{expect(basketballCourts.map(c=>[c.x,c.z])).toEqual([[12,-52],[12,-38],[12,-24]]);expect(basketballHoops).toHaveLength(6);expect(B.source.sha256).toHaveLength(64);for(const c of basketballCourts){expect(c.x1-c.x0).toBe(28);expect(c.z1-c.z0).toBeCloseTo(12.6);}});
 it('keeps court surfaces playable and reachable at every world scale',()=>{for(const scale of [1,1.5,2]){const w=createModelWorld(scale),m=w.maps.campus,t=w.transforms.campus;expect(m.sportsCourts).toHaveLength(3);expect(m.landmarks?.some(p=>p.label===basketballTarget.name)).toBe(true);for(const c of basketballCourts){expect(canReach(m.spawns['campus-start'],t.toGame(c),m)).toBe(true);expect(clearSegment(t.toGame({x:c.x-12,z:c.z}),t.toGame({x:c.x+12,z:c.z}),m)).toBe(true);expect(walkable(t.toGame({x:c.x,z:c.z+4}),m)).toBe(true);}}});
 it('blocks only hoop support bases and permits passage beside them and under raised backboards',()=>{for(const scale of [1,1.5,2]){const w=createModelWorld(scale),m=w.maps.campus,t=w.transforms.campus;for(const h of basketballHoops){expect(m.collisionZones).toContainEqual(t.rect(h.rect));expect(walkable(t.toGame(h),m)).toBe(false);expect(clearSegment(t.toGame({x:h.x-2,z:h.z}),t.toGame({x:h.x+2,z:h.z}),m)).toBe(false);expect(walkable(t.toGame({x:h.x,z:h.z+2}),m)).toBe(true);expect(walkable(t.toGame({x:h.x-h.side*1.3,z:h.z}),m)).toBe(true);}}});
});
