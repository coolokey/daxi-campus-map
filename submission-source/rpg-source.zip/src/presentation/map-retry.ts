/** Error-only UI should not consume the normal startup budget. */
export function showMapRetry(status:HTMLElement,image:HTMLImageElement) {
  status.textContent='地圖暫時下載失敗，可先體驗數學任務，或按重新載入。';
  const retry=document.createElement('button');retry.textContent='重新載入地圖';
  retry.onclick=()=>{retry.remove();image.src=`${image.src.split('?')[0]}?retry=${Date.now()}`;};status.append(retry);
}
