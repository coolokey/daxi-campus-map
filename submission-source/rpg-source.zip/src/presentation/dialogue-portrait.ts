import type { Character } from './character-runtime';
/** Observe visibility only: existing dialogue text and task controls remain owned by their caller. */
export function mountDialoguePortrait(panel:HTMLElement,character:()=>Character|undefined){
  let figure:HTMLElement|undefined;
  function refresh(){
    figure?.remove();figure=undefined;panel.classList.remove('with-portrait');
    if(panel.hidden)return;
    const c=character();if(!c)return;
    const card=document.createElement('figure'),caption=document.createElement('figcaption');
    figure=card;card.className='dialogue-portrait';
    caption.textContent=`${c.name}・RPG 創意造型`;
    card.append(caption);panel.prepend(card);panel.classList.add('with-portrait');
    const fallback=(message:string)=>{if(figure===card)caption.textContent=`${c.name}・${message}（RPG 創意造型）`;};
    if(!c.portrait){fallback('立繪暫缺');return;}
    const image=document.createElement('img');image.alt=`${c.name}的半身立繪（RPG 創意造型，非真實照片）`;
    image.onerror=()=>{image.remove();fallback('立繪載入失敗');};
    card.prepend(image);image.src=new URL(c.portrait,document.baseURI).href;
  }
  new MutationObserver(refresh).observe(panel,{attributes:true,attributeFilter:['hidden']});
  refresh();return refresh;
}
