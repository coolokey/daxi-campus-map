type Camera={a:number;b:number;c:number;d:number;e:number;f:number};
/** Stable tile variation independent of camera position and animation time. */
export function terrainSeed(col:number,row:number){let n=(Math.imul(col,374761393)+Math.imul(row,668265263))|0;n=Math.imul(n^(n>>>13),1274126177);return (n^(n>>>16))>>>0;}
/** Inverse affine camera + inverse isometric projection bounds candidate cells. */
export function visibleHexRange(camera:Camera,canvasWidth:number,canvasHeight:number,width:number,height:number,radius:number){
 const {a,b,c,d,e,f}=camera,det=a*d-b*c;
 if(Math.abs(det)<1e-12)return {col0:0,col1:-1,row0:0,row1:-1};
 const points=[[-48,-48],[canvasWidth+48,-48],[canvasWidth+48,canvasHeight+48],[-48,canvasHeight+48]].map(([x,y])=>{const qx=(d*(x-e)-c*(y-f))/det,qy=(-b*(x-e)+a*(y-f))/det;return {x:qy+qx/Math.sqrt(3),y:qy-qx/Math.sqrt(3)};});
 const dx=radius*1.5,dy=Math.sqrt(3)*radius;
 return {col0:Math.max(0,Math.floor((Math.min(...points.map(p=>p.x))-radius)/dx)),col1:Math.min(Math.ceil(width/dx),Math.ceil((Math.max(...points.map(p=>p.x))+radius)/dx)),row0:Math.max(-1,Math.floor((Math.min(...points.map(p=>p.y))-radius)/dy)-1),row1:Math.min(Math.ceil(height/dy),Math.ceil((Math.max(...points.map(p=>p.y))+radius)/dy)+1)};
}
