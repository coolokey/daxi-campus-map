import {activityBall,type Activity} from './campus-activities';
import {modelTransform,projectIso} from './model-world';
import type {NpcConfig} from '../game/data/types';
import type {BoundaryObject} from './boundary-renderer';
let reduced=false;
if(typeof window!=='undefined'&&window.matchMedia){const q=window.matchMedia('(prefers-reduced-motion: reduce)');reduced=q.matches;q.addEventListener?.('change',e=>{reduced=e.matches;});}
/** Hands and held props share the existing atlas actor's pixel scale and depth. */
export function paintActivityHands(ctx:CanvasRenderingContext2D,kind:Activity,time:number){
 const phase=(reduced?0:time)%7;
 ctx.save();ctx.lineCap='round';
 if(kind==='gardening'){
  ctx.strokeStyle='#ddb599';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(7,-27);ctx.lineTo(15,-21);ctx.stroke();
  ctx.strokeStyle='#4d827b';ctx.lineWidth=2.5;ctx.beginPath();ctx.ellipse(17,-23,5,5,0,Math.PI,Math.PI*2);ctx.stroke();
  ctx.fillStyle='#7bada2';ctx.fillRect(12,-23,11,10);ctx.fillStyle='#a2c9b6';ctx.fillRect(12,-23,11,3);
  ctx.strokeStyle='#638f87';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(22,-21);ctx.lineTo(29,-28);ctx.stroke();ctx.fillStyle='#aac4a9';ctx.beginPath();ctx.ellipse(29,-28,4,2,-.5,0,Math.PI*2);ctx.fill();
 }
 if(kind==='basketball'&&phase>=3&&phase<4.5){ctx.strokeStyle='#e2bda1';ctx.lineWidth=5;for(const side of [-1,1]){ctx.beginPath();ctx.moveTo(side*8,-27);ctx.lineTo(side*10,-37);ctx.lineTo(side*5,-46);ctx.stroke();}}
 ctx.restore();
}
/** Moving balls/water use the same depth queue as people and hoops, not an independent timer. */
export function activityScene(ctx:CanvasRenderingContext2D,actors:NpcConfig[],unit:number,u:number):BoundaryObject[]{
 const t=modelTransform({x:-162,z:-90},unit),objects:BoundaryObject[]=[],m=ctx.getTransform();
 const add=(x:number,z:number,height:number,draw:(p:{x:number;y:number})=>void)=>{const g=t.toGame({x,z}),p=projectIso(g);p.y-=height*unit*.85;const sx=m.a*p.x+m.c*p.y+m.e,sy=m.b*p.x+m.d*p.y+m.f;if(sx<-25||sy<-25||sx>ctx.canvas.width+25||sy>ctx.canvas.height+25)return;objects.push({depth:g.x+g.y,draw:()=>{ctx.save();draw(p);ctx.restore();}});};
 for(const a of actors){if(!a.activity)continue;const time=reduced?0:a.activityTime??0;
  if(a.activity==='basketball'){const ball=activityBall(time),phase=time%7;if(ball){let height=ball.height;if(phase<3)height=.3+Math.abs(Math.sin(time*8))*24*u/(unit*.85);else if(phase<4.5){const f=(phase-3)/1.5,release=45*u/(unit*.85);height=release+(3.6-release)*f+2.6*Math.sin(Math.PI*f);}add(ball.x,ball.z,height,p=>{const r=5.5*u,g=ctx.createRadialGradient(p.x-r*.4,p.y-r*.5,1,p.x,p.y,r);g.addColorStop(0,'#eab77a');g.addColorStop(1,'#b96935');ctx.fillStyle=g;ctx.beginPath();ctx.arc(p.x,p.y,r,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#784c31';ctx.lineWidth=.8*u;ctx.stroke();ctx.beginPath();ctx.moveTo(p.x-r,p.y);ctx.lineTo(p.x+r,p.y);ctx.moveTo(p.x,p.y-r);ctx.lineTo(p.x,p.y+r);ctx.stroke();});}}
  if(a.activity==='gardening'&&(time%14)<8){const site=t.fromGame(a),spoutHeight=Math.max(.4,(28*u-.3*unit)/(unit*.85));for(let i=0;i<7;i++){const s=((time*1.25+i/7)%1);add(site.x+.95,site.z-1.55-s*2,spoutHeight*(1-s),p=>{ctx.fillStyle='#88cbdccc';ctx.beginPath();ctx.ellipse(p.x,p.y,1.2*u,2.2*u,-.5,0,Math.PI*2);ctx.fill();});}}
 }
 return objects;
}
