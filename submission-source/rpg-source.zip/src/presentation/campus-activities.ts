import config from '../../public/data/pavilion-activities-v1.json';
import {lanePoint} from './athletics-garden';
import {campusModel,modelMapInfo,modelTransform,projectIso} from './model-world';
import {clearSegment} from './navigation';
import type {MapConfig} from '../game/data/types';
import type {Resident} from '../game/core/world';
export type Activity='basketball'|'gardening'|'running';
export const activityConfig=config.activities;
export function activityPose(kind:Activity,time:number){
 if(kind==='running')return lanePoint(campusModel.outdoor.track,20.25,51+time*6);
 if(kind==='gardening'){const phase=time%14;return{x:-100+(phase<8?0:3*Math.sin((phase-8)/6*Math.PI)),z:-66.8};}
 const phase=time%7;return{x:18+(phase<3?Math.sin(phase*Math.PI*2/3)*1.2:0),z:-38};
}
export function activityBall(time:number){const phase=time%7,a=activityPose('basketball',time);if(phase<3)return{x:a.x+1,z:a.z+.35,height:.3+Math.abs(Math.sin(time*8))*1.05};if(phase<4.5){const s=(phase-3)/1.5;return{x:18+7.8*s,z:-38,height:1.8+1.8*s+2.6*Math.sin(Math.PI*s)};}if(phase<5.3)return{x:25.8,z:-38,height:3.6-(phase-4.5)/.8*3.3};return null;}
export function createActivityResidents(students:{id:string;name:string}[],map:MapConfig):Resident[]{
 const info=modelMapInfo(map);if(!info?.outdoor||students.length<3)return[];const t=modelTransform({x:-162,z:-90},info.unit);
 return activityConfig.map((site,i)=>({id:'activity-'+site.id,mapId:map.id,...t.toGame(activityPose(site.id as Activity,0)),direction:'down',spriteKey:students[i].id,portraitKey:students[i].id,name:students[i].name,kind:'student',interactionRadius:76,dialogueId:'guide-character',dialogue:site.dialogue,activity:site.id as Activity,activityTime:0,waypoint:0,wait:0,moving:false}));
}
/** Existing game tick owns the time: no timer, teleport loop, or motion through collision. */
export function stepActivityResidents(actors:Resident[],map:MapConfig,seconds:number,player:{x:number;y:number}){
 const info=modelMapInfo(map);if(!info?.outdoor||seconds<=0)return;const t=modelTransform({x:-162,z:-90},info.unit),dt=Math.min(seconds,.1);
 for(const n of actors){if(!n.activity)continue;n.moving=false;if(Math.hypot(n.x-player.x,n.y-player.y)<90)continue;
  const nextTime=(n.activityTime??0)+dt,next=t.toGame(activityPose(n.activity,nextTime));if(!clearSegment(n,next,map))continue;
  n.moving=Math.hypot(next.x-n.x,next.y-n.y)>.01;n.x=next.x;n.y=next.y;n.activityTime=nextTime;
 }
}
export function activityFacing(kind:Activity,time:number){const a=activityPose(kind,time),b=kind==='gardening'?{x:a.x,z:a.z-1}:kind==='basketball'?{x:26.2,z:-38}:activityPose(kind,time+.1);const p=projectIso({x:b.x-a.x,y:b.z-a.z});return(Math.round(Math.atan2(-p.x,p.y)/(Math.PI/4))+8)%8;}
