import { createRoot } from 'react-dom/client';
import { ThreeCentersQuest } from '../components/ThreeCentersQuest';
import type { CenterId } from '../data/three-centers';
export function mountThreeCentersQuest(container: HTMLElement, onClose: () => void) {
  const root = createRoot(container);
  let serial = 0;
  return { open(center?: CenterId) { root.render(<ThreeCentersQuest onClose={onClose} openRequest={{ center, serial: ++serial }} />); } };
}
