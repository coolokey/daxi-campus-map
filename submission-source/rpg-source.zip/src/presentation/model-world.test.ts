import { describe,it,expect } from 'vitest';
import { createModelWorld, projectIso, unprojectIso, screenMotion } from './model-world';
import { walkable,findPath,canReach,clearSegment } from './navigation';
describe('latest campus model as the RPG geometry authority',()=>{
  it('uses the merged administration and current technology/art footprints without changing source coordinates',()=>{
    const w=createModelWorld(1);
    expect(w.source.buildings.some(b=>b.id==='admin-back')).toBe(false);
    expect(w.source.buildings.find(b=>b.id==='tech-building')!.bounds.z1).toBeGreaterThan(30);
    expect(Object.keys(w.maps).length).toBe(29);
  });
  it('returns each independent entrance to its own outdoor position',()=>{
    const w=createModelWorld(1),campus=w.maps.campus;
    for(const door of campus.portals){const indoor=w.maps[door.destinationMapId],arrival=indoor.spawns[door.destinationSpawnId];const exit=indoor.portals.find(p=>p.destinationMapId==='campus'&&Math.hypot(p.trigger.x+22-arrival.x,p.trigger.y+22-arrival.y)<1)!;expect(exit,door.id).toBeDefined();const back=campus.spawns[exit.destinationSpawnId];expect(Math.hypot(back.x-door.trigger.x-22,back.y-door.trigger.y-22),door.id).toBeLessThan(1);}
  });
  it('has reversible isometric projection and screen-aligned controls',()=>{
    const p={x:1740,y:920};expect(unprojectIso(projectIso(p)).x).toBeCloseTo(p.x);expect(unprojectIso(projectIso(p)).y).toBeCloseTo(p.y);
    const m=screenMotion(1,0),q=projectIso(m);expect(q.x).toBeGreaterThan(0);expect(q.y).toBeCloseTo(0);
  });
  it('keeps every entrance, room, staircase and reverse spawn reachable at all scales',()=>{
    for(const scale of [1,1.5,2]){
      const w=createModelWorld(scale),campus=w.maps.campus;
      for(const map of Object.values(w.maps)){
        for(const s of Object.values(map.spawns))expect(walkable(s,map),`${map.id} spawn`).toBe(true);
        const start=map.spawns.entry??map.spawns['campus-start'];
        for(const target of w.targets[map.id]??[]){const entry=Object.values(map.spawns).find(s=>canReach(s,target.point,map));expect(entry,`${map.id}: ${target.name} at ${scale}`).toBeDefined();const path=entry?findPath(entry,target.point,map):null;expect(path).toBeTruthy();for(let i=1;i<(path?.length??0);i++)expect(clearSegment(path![i-1],path![i],map)).toBe(true);}
        for(const p of map.portals){expect(w.maps[p.destinationMapId]?.spawns[p.destinationSpawnId],p.id).toBeDefined();expect(Object.values(map.spawns).some(s=>canReach(s,{x:p.trigger.x+22,y:p.trigger.y+22},map)),`${map.id}: ${p.id} at ${scale}`).toBe(true);}
      }
      expect(campus.portals.length).toBeGreaterThan(w.source.buildings.length);
      const visitedComponents=new Map<string,{x:number;y:number}[]>();
      const queue=[{mapId:'campus',point:campus.spawns['campus-start']}],seen=new Set<string>(),rooms=new Set<string>();
      for(let n=0;n<queue.length;n++){const state=queue[n],map=w.maps[state.mapId],previous=visitedComponents.get(map.id)??[];if(previous.some(p=>canReach(p,state.point,map)))continue;previous.push(state.point);visitedComponents.set(map.id,previous);for(const room of w.targets[map.id]??[])if(canReach(state.point,room.point,map))rooms.add(room.id);for(const portal of map.portals){const key=portal.destinationMapId+portal.destinationSpawnId;if(seen.has(key)||!canReach(state.point,{x:portal.trigger.x+22,y:portal.trigger.y+22},map))continue;seen.add(key);queue.push({mapId:portal.destinationMapId,point:w.maps[portal.destinationMapId].spawns[portal.destinationSpawnId]});}}
      expect(rooms.size,`reachable rooms at ${scale}`).toBe(w.source.buildings.reduce((n,b)=>n+b.rooms.length,0));
    }
  },180000);
});
