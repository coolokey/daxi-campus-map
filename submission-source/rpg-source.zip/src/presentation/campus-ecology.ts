import config from '../../public/data/campus-ecology-v1.json';
import {terrainSeed} from './hex-terrain';
import {walkable} from './navigation';
import {entranceLandmarks} from './entrance-landmarks';
import type {MapConfig,Rect} from '../game/data/types';
import type {CampusModel} from './model-world';
type P={x:number;y:number};type C={x:number;z:number};type T={unit:number;toGame:(p:C)=>P};
export type EcologyPlant=C&{kind:string;seed:number};
export type EcologyInsect=C&{kind:'butterfly'|'dragonfly';seed:number;radius:number};
export type Ecology={plants:EcologyPlant[];insects:EcologyInsect[]};
export const ecologyConfig=config;
export const ecologyVisibleCaps=(cssWidth:number)=>cssWidth<=640?config.visibleCaps.mobile:config.visibleCaps.desktop;
const cache=new WeakMap<MapConfig,Ecology>();
const within=(p:P,r:Rect,pad:number)=>p.x>=r.x-pad&&p.x<=r.x+r.width+pad&&p.y>=r.y-pad&&p.y<=r.y+r.height+pad;
function distance(p:P,a:P,b:P){const dx=b.x-a.x,dy=b.y-a.y,l=dx*dx+dy*dy,f=l?Math.max(0,Math.min(1,((p.x-a.x)*dx+(p.y-a.y)*dy)/l)):0;return Math.hypot(p.x-a.x-dx*f,p.y-a.y-dy*f);}
function polygon(p:C,points:{x:number;z:number}[]){let inside=false;for(let i=0,j=points.length-1;i<points.length;j=i++){const a=points[i],b=points[j];if((a.z>p.z)!==(b.z>p.z)&&p.x<(b.x-a.x)*(p.z-a.z)/(b.z-a.z)+a.x)inside=!inside;}return inside;}
/** Landscape only: retain clear paths, playing surfaces, real doors and the shared foot collision. */
export function ecologyHabitat(p:C,map:MapConfig,t:T,model:CampusModel){
 const q=t.toGame(p),u=t.unit;
 const avenue=entranceLandmarks.plan;
 if(!polygon(p,model.outdoor.perimeter.outline.map(([x,z])=>({x,z})))&&!(p.z>=avenue.z0&&p.z<=avenue.z1&&Math.abs(p.x-avenue.x)<=14))return false;
 if(!walkable(q,map,u*1.5))return false;
 if(map.portals.some(d=>Math.hypot(q.x-d.trigger.x-22,q.y-d.trigger.y-22)<u*4))return false;
 if([...(map.outdoorPaving??[]),...(map.parkingAreas??[]),...(map.sportsCourts??[])].some(r=>within(q,r,u*1.25)))return false;
 if([model.forecourt.parking,...model.outdoor.courts,...model.outdoor.outerCourts,model.outdoor.stage].some(r=>within(q,{x:t.toGame({x:r.x0,z:r.z0}).x,y:t.toGame({x:r.x0,z:r.z0}).y,width:(r.x1-r.x0)*u,height:(r.z1-r.z0)*u},u*1.25)))return false;
 for(const path of map.outdoorPaths??[])for(let i=1;i<path.points.length;i++)if(distance(q,path.points[i-1],path.points[i])<path.width/2+u*1.25)return false;
 if(distance(q,t.toGame(model.outdoor.entrance.pedestrian.inside),t.toGame(model.outdoor.entrance.target))<u*3.05)return false;
 const tr=model.outdoor.track,x=Math.max(tr.x-tr.halfStraight,Math.min(tr.x+tr.halfStraight,p.x));if(Math.hypot(p.x-x,p.z-tr.z)<tr.outerRadius+1.5)return false;
 if(polygon(p,entranceLandmarks.trail.approach))return false;
 const trail=entranceLandmarks.trail;for(let i=1;i<trail.path.length;i++)if(distance(q,t.toGame(trail.path[i-1]),t.toGame(trail.path[i]))<u*(trail.width/2+1.25))return false;
 // The art-side paved pedestrian edge is independent of the road rectangles.
 if(p.x>58&&p.x<87&&p.z>52&&p.z<82)return false;
 return true;
}
export function campusEcology(map:MapConfig,t:T,model:CampusModel):Ecology{
 const saved=cache.get(map);if(saved)return saved;const plants:EcologyPlant[]=[];
 config.zones.forEach((zone,k)=>{let accepted=0;for(let i=0;i<zone.count*35&&accepted<zone.count;i++){const seed=terrainSeed(i,k+271),angle=(seed%10000)/10000*Math.PI*2,r=Math.sqrt(((seed>>>14)%10000)/10000),p={x:zone.x+Math.cos(angle)*zone.rx*r,z:zone.z+Math.sin(angle)*zone.rz*r};if(!ecologyHabitat(p,map,t,model)||plants.some(a=>Math.hypot(a.x-p.x,a.z-p.z)<1.8))continue;plants.push({...p,kind:zone.kind,seed});accepted++;}});
 const insects:EcologyInsect[]=[],flowers=plants.filter(p=>p.kind==='flowers');
 // Distribute butterflies across distant flower patches instead of crowding one corner.
 for(const p of [...flowers].sort((a,b)=>a.seed-b.seed)){if(insects.length>=config.butterflies)break;if(insects.some(a=>Math.hypot(a.x-p.x,a.z-p.z)<9))continue;insects.push({x:p.x,z:p.z,kind:'butterfly',seed:p.seed,radius:.65});}
 for(let i=0;i<config.dragonflies;i++)insects.push({x:model.outdoor.pond.x,z:model.outdoor.pond.z,kind:'dragonfly',seed:terrainSeed(i,901),radius:3.8+i*.65});
 const result={plants,insects};cache.set(map,result);return result;
}
export function ecologyInsectPose(insect:EcologyInsect,seconds:number,reducedMotion=false){const phase=(insect.seed%1000)/1000*Math.PI*2,time=reducedMotion?0:seconds,angle=time*(insect.kind==='dragonfly'?.45:.75)+phase;return {x:insect.x+Math.cos(angle)*insect.radius,z:insect.z+Math.sin(angle*.9)*insect.radius*.6,height:insect.kind==='dragonfly'?.9+Math.sin(angle)*.12:.7+Math.sin(angle*1.7)*.16,wing:reducedMotion?.7:.3+Math.abs(Math.sin(time*9+phase))*.7};}
