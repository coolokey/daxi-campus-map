import { planBuildings } from './floor-expansion';
import type { MapConfig } from '../game/data/types';
import { safePilotPosition } from './pilot-adapter';
export function addCampusEntrances(map:MapConfig){
  const technology=map.portals.find(p=>p.id==='technology-building-door');if(technology){const x=1930/2400*map.width,y=850/1624*map.height;technology.trigger={x:x-22,y:y-22,width:44,height:44};}
  for(const b of planBuildings){if(b.buildingId==='tech-building'||!b.enabledLevels.length)continue;
    const point=safePilotPosition({x:b.artAnchor[0]/1525*map.width,y:b.artAnchor[1]/1031*map.height},map);
    map.portals.push({id:`building-entry:${b.buildingId}`,mapId:'campus',trigger:{x:point.x-22,y:point.y-22,width:44,height:44},destinationMapId:`floor-${b.buildingId}-1`,destinationSpawnId:'entry',prompt:`E：進入${b.name.split(' / ')[0]} 1F`});
  }return map;
}
