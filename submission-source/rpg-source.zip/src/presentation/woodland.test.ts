import {describe,it,expect} from 'vitest';
import {woodRoofGeometry,woodBuildingOccludes,woodBuildingScreenPoints} from './wood-architecture';
import {createModelWorld,modelMapInfo,unprojectIso} from './model-world';
import {canReach,walkable} from './navigation';
import {buildingMaterial} from './campus-materials';
describe('woodland theme keeps game geometry functional',()=>{
 it('scales the pitched roof and eaves with the world while leaving its floor footprint separate',()=>{
  const roof=woodRoofGeometry({x:100,y:200,width:320,height:160},170,16);
  expect(roof.rise).toBeGreaterThan(0);expect(roof.faces).toHaveLength(4);expect(roof.corners[0].x).toBeLessThan(100);
  for(const scale of [1.5,2]){const other=woodRoofGeometry({x:100*scale,y:200*scale,width:320*scale,height:160*scale},170*scale,16*scale);expect(other.rise).toBeCloseTo(roof.rise*scale);expect(other.corners[0].x).toBeCloseTo(roof.corners[0].x*scale);}
 });
 it('places wooden benches only on clear ground and gives every visible bench a collision footprint',()=>{
  for(const scale of [1,1.5,2]){const w=createModelWorld(scale),map=w.maps.campus,decor=modelMapInfo(map)!.furniture;
   expect(decor.length).toBeGreaterThan(0);
   for(const item of decor){expect(map.collisionZones).toContainEqual(item.rect);expect(walkable({x:item.rect.x+item.rect.width/2,y:item.rect.y+item.rect.height/2},map)).toBe(false);}
   for(const p of map.portals)expect(canReach(map.spawns['campus-start'],{x:p.trigger.x+22,y:p.trigger.y+22},map),p.id).toBe(true);
  }
 });
 it('keeps building identifiers distinct through accents and retains the original appearance option',()=>{
  const world=createModelWorld(1),materials=world.source.buildings.map(b=>buildingMaterial(b.id));expect(new Set(materials.map(m=>m.accent)).size).toBe(11);
  expect(buildingMaterial('admin-front').wood).toBeDefined();expect(buildingMaterial('admin-front',true).wall).not.toBe(buildingMaterial('admin-front').wall);
 });
});

it('fades the added eaves above the old flat-roof envelope and never fades for a player in front',()=>{
 const r={x:1000,y:2000,width:320,height:160},points=woodBuildingScreenPoints(r,170,16),tip=points.reduce((a,b)=>a.y<b.y?a:b);
 const behind=unprojectIso({x:tip.x,y:tip.y+1});expect(woodBuildingOccludes(r,170,16,behind,1)).toBe(true);
 expect(woodBuildingOccludes(r,170,16,{x:1400,y:2300},1)).toBe(false);
 expect(woodBuildingOccludes(r,170,16,unprojectIso({x:tip.x,y:tip.y-100}),1)).toBe(false);
});
