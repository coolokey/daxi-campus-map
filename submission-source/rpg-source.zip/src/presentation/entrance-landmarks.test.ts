import {describe,it,expect} from 'vitest';
import {entranceLandmarks as L,landmarkSolids} from './entrance-landmarks';
import {createModelWorld} from './model-world';
import {walkable,canReach,clearSegment} from './navigation';
describe('source-derived gate landmarks and complete palm avenue',()=>{
 it('retains the guide avenue, tree rows and source anchors',()=>{expect(L.palms).toHaveLength(20);expect(L.plan.z1).toBe(171);expect(L.trail.sign).toMatchObject({x:-61,z:84});expect(L.statue).toMatchObject({x:-36,z:28.5});expect(L.source.files.every(f=>f.sha256.length===64)).toBe(true);});
 it('extends real world space and keeps avenue, all landmarks and building entrances reachable at every scale',()=>{for(const scale of [1,1.5,2]){const w=createModelWorld(scale),map=w.maps.campus,t=w.transforms.campus;expect(t.fromGame({x:0,y:map.height}).z).toBeGreaterThan(174);expect(clearSegment(t.toGame({x:L.plan.x,z:94}),t.toGame({x:L.plan.x,z:169}),map)).toBe(true);for(const target of L.targets){expect(canReach(map.spawns['campus-start'],t.toGame(target),map),target.id).toBe(true);}for(const p of map.portals)expect(canReach(map.spawns['campus-start'],{x:p.trigger.x+22,y:p.trigger.y+22},map),p.id).toBe(true);}});
 it('blocks each physical trunk, sign, base, wall and pole with its exact drawing footprint',()=>{for(const scale of [1,1.5,2]){const w=createModelWorld(scale),map=w.maps.campus,t=w.transforms.campus;for(const s of landmarkSolids()){expect(map.collisionZones).toContainEqual(t.rect(s.rect));const r=t.rect(s.rect);expect(walkable({x:r.x+r.width/2,y:r.y+r.height/2},map),s.id).toBe(false);}const p=L.palms[8];expect(walkable(t.toGame({x:p.x+2,z:p.z}),map)).toBe(true);expect(walkable(t.toGame({x:-62,z:10}),map)).toBe(true);}});
});
