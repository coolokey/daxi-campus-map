import {it,expect} from 'vitest';
import {buildingRoof,buildingFloorCount,surfaceCoversActor} from './building-art';
import {cartoonBuildingHeight,cartoonBuildingScreenPoints} from './cartoon-renderer';
import {projectIso} from './model-world';
it('matches guide roof types and preserves the full source floor count',()=>{
 const r={x:100,y:200,width:600,height:240};
 expect(buildingRoof(r,80,16,'admin-front').pitched).toBe(true);
 expect(buildingRoof(r,80,16,'tech-building').pitched).toBe(false);
 expect(buildingRoof(r,80,16,'gym-bld').solar).toBe(true);
 for(const floors of [1,2,3,4])expect(buildingFloorCount(floors*16*5.4,16)).toBe(floors);
});
it('keeps roof vertices within existing footprints and conservative culling bounds at all scales',()=>{
 for(const scale of [1,1.5,2])for(const id of ['admin-front','tech-building','gym-bld'])for(const tall of [false,true]){
  const unit=16*scale,r={x:1000*scale,y:2000*scale,width:(tall?120:600)*scale,height:(tall?600:120)*scale},source=unit*5.4*3;
  const roof=buildingRoof(r,cartoonBuildingHeight(source,unit),unit,id),bounds=cartoonBuildingScreenPoints(r,source,unit);
  for(const p of roof.faces.flat()){
   expect(p.x).toBeGreaterThanOrEqual(r.x);expect(p.x).toBeLessThanOrEqual(r.x+r.width);
   expect(p.y).toBeGreaterThanOrEqual(r.y);expect(p.y).toBeLessThanOrEqual(r.y+r.height);
   const q=projectIso(p);expect(q.y-p.z).toBeGreaterThanOrEqual(Math.min(...bounds.map(v=>v.y)));
  }
 }
});
it('fades only the face overlapping the character silhouette',()=>{
 const left=[{x:0,y:0},{x:40,y:0},{x:40,y:100},{x:0,y:100}],right=left.map(p=>({x:p.x+100,y:p.y}));
 expect(surfaceCoversActor(left,{x:20,y:70},1)).toBe(true);
 expect(surfaceCoversActor(right,{x:20,y:70},1)).toBe(false);
 expect(surfaceCoversActor([{x:10,y:12},{x:30,y:12},{x:30,y:20},{x:10,y:20}],{x:20,y:70},1)).toBe(true);
 expect(surfaceCoversActor([{x:40,y:40},{x:44,y:40},{x:44,y:50},{x:40,y:50}],{x:20,y:70},1)).toBe(true);
});
