import {paintCartoonBuilding,cartoonBuildingHeight} from './cartoon-renderer';
import {describe,it,expect} from 'vitest';
import {meadowTreeProfile,meadowTreeOccludes,meadowTheme} from './meadow-renderer';
import {createModelWorld,modelTrees,projectIso,unprojectIso} from './model-world';
import {outdoorBuildingRect} from './cartoon-layout';
import {walkable,canReach} from './navigation';
describe('reference-inspired meadow maintains physical campus',()=>{
 it('shares all drawn tree roots with collision and excludes new source trees from buildings',()=>{expect(modelTrees().length).toBeGreaterThanOrEqual(13);for(const scale of [1,1.5,2]){const w=createModelWorld(scale),map=w.maps.campus,t=w.transforms.campus;for(const tree of modelTrees()){const p=t.toGame(tree);expect(walkable(p,map)).toBe(false);expect(map.collisionZones).toContainEqual({x:p.x-t.unit*.3,y:p.y-t.unit*.3,width:t.unit*.6,height:t.unit*.6});if(meadowTheme.sourceTrees.some(s=>s.x===tree.x&&s.z===tree.z))for(const b of w.source.buildings)for(const f of b.footprints.filter(f=>f.floor===1)){const r=outdoorBuildingRect(b,f.rect);expect(tree.x>r.x0&&tree.x<r.x1&&tree.z>r.z0&&tree.z<r.z1).toBe(false);}}}});
 it('retains entrance access through the added source planting at every scale',()=>{for(const scale of [1,1.5,2]){const w=createModelWorld(scale),map=w.maps.campus;for(const p of map.portals)expect(canReach(map.spawns['campus-start'],{x:p.trigger.x+22,y:p.trigger.y+22},map),p.id).toBe(true);}});
 it('fades a larger canopy when player is behind it, while front positions remain opaque',()=>{const point={x:2600,y:2400},seed=91;for(const unit of [16,24,32]){const size=meadowTreeProfile(seed,unit),p=projectIso(point),behind=unprojectIso({x:p.x,y:p.y-size.height*.6});expect(meadowTreeOccludes(point,behind,seed,unit)).toBe(true);expect(meadowTreeOccludes(point,{x:point.x+100,y:point.y+100},seed,unit)).toBe(false);expect(meadowTreeProfile(seed,unit)).toEqual(size);expect(size.width).toBeLessThan(unit*10);}});
});

it('covers both rear roof bevels instead of showing grass through a gap',()=>{
 const fills:{x:number;y:number}[][]=[];let path:{x:number;y:number}[]=[];
 const ctx={canvas:{width:10000,height:10000},getTransform:()=>({a:1,b:0,c:0,d:1,e:0,f:0}),save(){},restore(){},beginPath(){path=[];},moveTo(x:number,y:number){path.push({x,y});},lineTo(x:number,y:number){path.push({x,y});},closePath(){},fill(){fills.push([...path]);},stroke(){},roundRect(){path=[];},fillText(){},createLinearGradient:()=>({addColorStop(){}})} as unknown as CanvasRenderingContext2D;
 const r={x:1000,y:1000,width:360,height:240},h=cartoonBuildingHeight(260,16),corners=[{x:r.x,y:r.y},{x:r.x+r.width,y:r.y},{x:r.x+r.width,y:r.y+r.height},{x:r.x,y:r.y+r.height}].map(p=>{const q=projectIso(p);return {x:q.x,y:q.y-h};}),center=corners.reduce((p,q)=>({x:p.x+q.x/4,y:p.y+q.y/4}),{x:0,y:0});
 const inside=(p:{x:number;y:number},poly:{x:number;y:number}[])=>{let result=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const a=poly[i],b=poly[j];if((a.y>p.y)!==(b.y>p.y)&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)result=!result;}return result;};
 paintCartoonBuilding(ctx,r,260,16,1,'tech-building');for(const edge of [[0,1],[3,0]]){const a=corners[edge[0]],b=corners[edge[1]],p={x:(a.x+b.x)/2*.97+center.x*.03,y:(a.y+b.y)/2*.97+center.y*.03};expect(fills.some(poly=>inside(p,poly))).toBe(true);}
});

it('keeps pond water inaccessible at every world scale, including the old gaps between shoreline samples',()=>{for(const scale of [1,1.5,2]){const w=createModelWorld(scale),pond=w.source.outdoor.pond,p=w.transforms.campus.toGame(pond);expect(walkable(p,w.maps.campus)).toBe(false);expect(canReach(w.maps.campus.spawns['campus-start'],p,w.maps.campus)).toBe(false);}});
