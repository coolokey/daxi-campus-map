import { afterEach, describe, expect, it, vi } from 'vitest';
import { actorFrame, chooseRoster, shuffleRoster, searchRoster, validateRoute, validateRegistry, type Character } from './character-runtime';
import { mountCharacterWorld } from './character-world';
import { scaleMap, createResidents } from '../game/core/world';
import { campusMap } from '../game/data/maps/campus';
import registry from '../../public/data/rpg-characters.json';

const teachers = Array.from({length:91},(_,i)=>({id:`staff${String(i+1).padStart(3,'0')}`,name:`老師${i+1}`,role:'teacher' as const,appearance:'示意',appearanceStatus:'source' as const,atlas:`assets/${i}.png`}));
describe('campus character runtime',()=>{
  it('shuffles a copy for random rotation without losing identities or changing searchable roster order',()=>{
    const input=teachers.slice(0,3),before=[...input],randomized=shuffleRoster(input,()=>0);
    expect(randomized.map(c=>c.id)).toEqual([input[1].id,input[2].id,input[0].id]);
    expect(input).toEqual(before);expect(new Set(randomized)).toEqual(new Set(input));
  });
  it('exposes all 91 teachers to search while keeping rotating cohorts unique',()=>{
    expect(searchRoster(teachers,'老師91')).toEqual([teachers[90]]);
    const ids = new Set<string>();
    for(let page=0;page<31;page++){
      const cohort=chooseRoster(teachers,'teacher',page,3);
      expect(new Set(cohort.map(c=>c.id)).size).toBe(3);
      cohort.forEach(c=>ids.add(c.id));
    }
    expect(ids.size).toBe(91);
  });
  it('includes requested teacher once and retains the mobile cap',()=>{
    const cohort=chooseRoster(teachers,'teacher',0,3,['staff091','staff091']);
    expect(cohort).toHaveLength(3);
    expect(cohort.filter(c=>c.id==='staff091')).toHaveLength(1);
  });
  it('rejects a route whose endpoints are safe but segment crosses a wall',()=>{
    const map={width:500,height:500,collisionZones:[{x:200,y:100,width:20,height:100}]};
    expect(validateRoute([{x:100,y:150},{x:300,y:150}],map)).toBe(false);
    expect(validateRoute([{x:100,y:240},{x:300,y:240}],map)).toBe(true);
    expect(validateRoute([{x:5,y:240},{x:300,y:240}],map)).toBe(false);
  });
  it('derives eight directions and walking frames from actual displacement',()=>{
    expect(actorFrame({x:0,y:0},{x:1,y:-1},200)).toMatchObject({direction:'up-right',column:5,moving:true});
    expect(actorFrame({x:0,y:0},{x:-1,y:1},200)).toMatchObject({direction:'down-left',column:1});
    expect(actorFrame({x:1,y:1},{x:1,y:1},400,'left')).toMatchObject({direction:'left',row:0,moving:false});
  });
  it('rejects duplicate ids and incomplete or unsafe sprite contracts',()=>{
    const registry={version:1,tile:{width:64,height:88,columns:8,rows:3},directions:['down','down-left','left','up-left','up','up-right','right','down-right'],characters:teachers};
    expect(()=>validateRegistry(registry)).not.toThrow();
    expect(()=>validateRegistry({...registry,characters:[teachers[0],teachers[0]]})).toThrow(/重複/);
    expect(()=>validateRegistry({...registry,characters:[{...teachers[0],atlas:'https://example.com/a.png'}]})).toThrow(/圖集/);
    expect(()=>validateRegistry({...registry,characters:[{...teachers[0],portrait:'assets/portraits/staff001.png'}]})).not.toThrow();
    expect(()=>validateRegistry({...registry,characters:[{...teachers[0],portrait:'assets/../staff001.png'}]})).toThrow(/立繪/);
    expect(()=>validateRegistry({...registry,characters:[{...teachers[0],portrait:'https://example.com/a.png'}]})).toThrow(/立繪/);
  });
  it('accepts local lossless WebP atlases and portraits while rejecting unsafe paths',()=>{
    const value={tile:{width:64,height:88,columns:8,rows:3},directions:['down','down-left','left','up-left','up','up-right','right','down-right'],characters:[{...teachers[0],atlas:'assets/characters/staff.webp',portrait:'assets/portraits/staff.webp'}]};
    expect(()=>validateRegistry(value)).not.toThrow();
    expect(()=>validateRegistry({...value,characters:[{...value.characters[0],atlas:'assets/../staff.webp'}]})).toThrow();
    expect(()=>validateRegistry({...value,characters:[{...value.characters[0],portrait:'https://example.com/staff.webp'}]})).toThrow();
  });
  it('preserves the projected foot anchor instead of anchoring transparent tile padding',()=>{
    const registry={version:1,anchor:{x:32,y:77.0177},tile:{width:64,height:88,columns:8,rows:3},directions:['down','down-left','left','up-left','up','up-right','right','down-right'],characters:teachers};
    expect(validateRegistry(registry)).toMatchObject({anchor:{x:32,y:77.0177}});
    expect(()=>validateRegistry({...registry,anchor:{x:32,y:200}})).toThrow(/腳底/);
  });
});

describe('original map character service',()=>{
  afterEach(()=>{vi.unstubAllGlobals();vi.restoreAllMocks();document.body.replaceChildren();localStorage.clear();});
  function setup(width=1280,failFirst=false,withPortraits=false){
    Object.defineProperty(window,'innerWidth',{value:width,writable:true,configurable:true});
    vi.spyOn(Math,'random').mockReturnValue(.999999);
    let requests=0;
    vi.stubGlobal('fetch',vi.fn(async()=>({ok:!failFirst||requests++>0,status:404,json:async()=>withPortraits?{...registry,characters:registry.characters.map(c=>({...c,portrait:`assets/portraits/${c.id}.png`}))}:registry})));
    const imageRequests:string[]=[];
    class FakeImage {naturalWidth=512;naturalHeight=264;onload:(()=>void)|undefined;onerror:(()=>void)|undefined;set src(value:string){imageRequests.push(value);queueMicrotask(()=>this.onload?.());}}
    vi.stubGlobal('Image',FakeImage);
    const map=scaleMap(campusMap,1.5),npcs=createResidents(map),player={...map.spawns['campus-start']},host={read:()=>({map,npcs,player}),redraw:vi.fn()};
    const service=mountCharacterWorld(host);return {service,host,map,npcs,player,imageRequests};
  }
  it('requests the player first and warms only the next limited cohort after the current batch',async()=>{
    const {service,imageRequests}=setup();await service.ready;await Promise.resolve();
    expect(imageRequests[0]).toContain('player-male-uniform');
    service.step(1);
    const next=chooseRoster(registry.characters as Character[],'teacher',1,3);
    await vi.waitFor(()=>expect(next.every(c=>imageRequests.some(url=>url.endsWith(c.atlas)))).toBe(true));
    expect(imageRequests.length).toBeLessThan(40);
    expect(imageRequests.every(url=>!url.includes('/portraits/'))).toBe(true);
  });
  it('starts rotation timing only after a delayed registry has loaded',async()=>{
    const {service,npcs}=setup();service.step(20000);
    await service.ready;
    const first=npcs.filter(n=>n.kind==='teacher').map(n=>n.spriteKey);
    service.step(40000);
    expect(npcs.filter(n=>n.kind==='teacher').map(n=>n.spriteKey)).toEqual(first);
    service.step(54001);
    expect(npcs.filter(n=>n.kind==='teacher').map(n=>n.spriteKey)).not.toEqual(first);
  });
  it('keeps researcher and robot functions and caps mobile teachers with safe routes',async()=>{
    const {service,map,npcs}=setup(390);await service.ready;
    expect(npcs.find(n=>n.id==='math-researcher')?.dialogueId).toBe('campus-researcher');
    expect(npcs.some(n=>n.id==='robot-patrol')).toBe(true);
    expect(npcs.filter(n=>n.kind==='teacher')).toHaveLength(1);
    expect(npcs.filter(n=>n.kind==='student')).toHaveLength(2);
    for(const npc of npcs.filter(n=>n.id.startsWith('guide-')))expect(validateRoute(npc.route!,map)).toBe(true);
  });
  it('loads all teachers, invites any searched teacher without changing player coordinates',async()=>{
    const {service,player,npcs}=setup();await service.ready;
    const before={...player},last=registry.characters.filter(c=>c.role==='teacher').at(-1)!;
    const search=document.querySelector<HTMLInputElement>('input[type=search]')!;search.value=last.name;search.dispatchEvent(new Event('input'));
    const invite=Array.from(document.querySelectorAll<HTMLButtonElement>('.character-card button')).find(b=>b.textContent==='邀請到校園')!;
    invite.click();expect(player).toEqual(before);expect(npcs.some(n=>n.spriteKey===last.id)).toBe(true);
    expect(new Set(npcs.filter(n=>n.kind==='teacher').map(n=>n.spriteKey)).size).toBe(3);
  });
  it('adapts teacher caps when a desktop window becomes a phone width',async()=>{
    const {service,npcs}=setup();await service.ready;expect(npcs.filter(n=>n.kind==='teacher')).toHaveLength(3);
    Object.defineProperty(window,'innerWidth',{value:390,writable:true});window.dispatchEvent(new Event('resize'));
    service.onMapChange();expect(npcs.filter(n=>n.kind==='teacher')).toHaveLength(1);
  });
  it('places the guard by the campus gate and keeps every added spawn distinct',async()=>{
    const {service,npcs,map}=setup();await service.ready;
    const managed=npcs.filter(n=>n.id.startsWith('guide-'));
    expect(new Set(managed.map(n=>`${n.x},${n.y}`)).size).toBe(managed.length);
    expect(npcs.find(n=>n.kind==='guard')!.y).toBeGreaterThan(map.height*.9);
    managed.forEach(n=>expect(map.portals.some(({trigger:r})=>n.x>r.x-95&&n.x<r.x+r.width+95&&n.y>r.y-95&&n.y<r.y+r.height+95)).toBe(false));
  });
  it('retries a failed manifest without mounting duplicate controls',async()=>{
    const status=document.createElement('p');status.id='world-status';document.body.append(status);
    const {service,npcs}=setup(1280,true);await service.ready;
    expect(status.dataset.characterError).toContain('角色名冊載入失敗');
    const retry=Array.from(document.querySelectorAll<HTMLButtonElement>('button')).find(b=>b.textContent==='重試載入角色');
    expect(retry).toBeDefined();retry!.click();
    await vi.waitFor(()=>expect(npcs.filter(n=>n.kind==='teacher')).toHaveLength(3));
    expect(status.dataset.characterError).toBeUndefined();expect(document.querySelectorAll('.character-entry')).toHaveLength(1);
  });
  it('uses a compact teacher label and no overhead student label',async()=>{
    const {service,npcs}=setup();await service.ready;await Promise.resolve();
    const fonts:string[]=[],texts:string[]=[],rects:number[][]=[];
    const ctx={canvas:{width:10000,height:10000},getTransform:()=>({a:1,d:1,e:0,f:0}),save(){},restore(){},translate(){},scale(){},beginPath(){},ellipse(){},fill(){},drawImage(){},measureText:()=>({width:30}),fillRect:(...r:number[])=>rects.push(r),fillText:(text:string)=>texts.push(text),set font(value:string){fonts.push(value);}} as unknown as CanvasRenderingContext2D;
    service.draw(ctx,npcs.find(n=>n.kind==='teacher')!);
    expect(fonts).toContain('600 10px system-ui');
    expect(rects.at(-1)?.[3]).toBe(14);
    texts.length=0;
    service.draw(ctx,npcs.find(n=>n.kind==='student')!);
    expect(texts).toEqual([]);
    expect(vi.mocked(fetch).mock.calls[0][0].toString()).toContain('rpg-characters-v4.json');
    expect(npcs.filter(n=>n.kind==='student').every(n=>!n.name.includes('示意學生'))).toBe(true);
  });
  it('selects the nearer overlapping NPC portrait even when later in the array and resolves the pilot mentor',async()=>{
    document.body.innerHTML='<div id="dialogue" hidden><p>任務對話</p><button id="pilot-accept">接受任務</button></div>';
    const {service,npcs,player}=setup(1280,false,true);await service.ready;
    const npc=npcs.find(n=>n.id.startsWith('guide-teacher-'))!;
    npcs.splice(0,npcs.length,{...npc,id:'farther',name:'較遠老師',x:npc.x+25,spriteKey:registry.characters.find(c=>c.role==='robot')!.id},npc);player.x=npc.x;player.y=npc.y;
    const panel=document.getElementById('dialogue')!;
    expect(panel.querySelector('img')).toBeNull();panel.hidden=false;
    await vi.waitFor(()=>expect(panel.querySelector('img')?.src).toContain(`${npc.spriteKey}.png`));
    panel.hidden=true;await Promise.resolve();
    npc.id='pilot-math-mentor';npc.spriteKey='robot';npc.name='數學任務導師';panel.hidden=false;
    const robot=registry.characters.find(c=>c.role==='robot')!;
    await vi.waitFor(()=>expect(panel.querySelector('img')?.src).toContain(`${robot.id}.png`));
    expect(panel.querySelector('figcaption')?.textContent).toContain('數學任務導師');
    expect(panel.querySelector('img')?.alt).toContain('數學任務導師');
    expect(panel.querySelector('figcaption')?.textContent).not.toContain(robot.name);
    expect(panel.querySelector('#pilot-accept')).not.toBeNull();
    expect(panel.querySelector('p')?.textContent).toBe('任務對話');
  });
});
