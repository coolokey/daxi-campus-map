import {campusBoundary,wallStrip} from './campus-boundary';
import {modelTransform,projectIso} from './model-world';
type P={x:number;y:number};type C={x:number;z:number};
export type BoundaryObject={depth:number;draw:()=>void};
const geometry=campusBoundary();
let masonry:HTMLCanvasElement|undefined;
function masonryTile(){
 if(masonry)return masonry;const cv=document.createElement('canvas');cv.width=256;cv.height=128;const c=cv.getContext('2d')!;c.fillStyle='#8a8478';c.fillRect(0,0,256,128);
 for(let row=0;row<8;row++)for(let col=-1;col<9;col++){const x=col*32+(row%2)*16,y=row*16;c.fillStyle=['#c9bea5','#d6cbb3','#bfb69f'][(row+col+12)%3];c.fillRect(x+1,y+1,30,14);}masonry=cv;return cv;
}
/** Shallow wall bays participate in the same foot-depth ordering as actors. */
export function boundaryObjects(ctx:CanvasRenderingContext2D,unit:number,screenUnit:number,player:P,heightScale=1):BoundaryObject[]{
 const t=modelTransform({x:-162,z:-90},unit),vertical=unit*1.5*heightScale,objects:BoundaryObject[]=[],u=screenUnit;
 const project=(p:C)=>projectIso(t.toGame(p));
 const polygon=(points:P[],color:string,stroke?:string)=>{ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=color;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=u;ctx.stroke();}};
 const segment=(a:P,b:P,color:string,width=1)=>{ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=color;ctx.lineWidth=width*u;ctx.stroke();};
 const sides=(points:C[],bottom:number,top:number,wall:string,side:string,roof:string)=>{
  const q=points.map(project),faces=q.map((a,i)=>({a,b:q[(i+1)%q.length],i,depth:points[i].x+points[i].z+points[(i+1)%points.length].x+points[(i+1)%points.length].z})).sort((a,b)=>a.depth-b.depth);
  for(const face of faces){const {a,b}=face;polygon([{x:a.x,y:a.y-bottom*vertical},{x:b.x,y:b.y-bottom*vertical},{x:b.x,y:b.y-top*vertical},{x:a.x,y:a.y-top*vertical}],face.i%2?side:wall,'#7f8170');}
  polygon(q.map(p=>({x:p.x,y:p.y-top*vertical})),roof,'#b9baa7');return faces;
 };
 const camera=ctx.getTransform(),buffer=ctx.canvas;
 const add=(points:C[],top:number,draw:()=>void)=>{
  const q=points.map(project),screen=q.flatMap(p=>[p,{x:p.x,y:p.y-top*vertical}]).map(p=>({x:camera.a*p.x+camera.c*p.y+camera.e,y:camera.b*p.x+camera.d*p.y+camera.f}));
  if(Math.max(...screen.map(p=>p.x))<-48||Math.min(...screen.map(p=>p.x))>buffer.width+48||Math.max(...screen.map(p=>p.y))<-48||Math.min(...screen.map(p=>p.y))>buffer.height+48)return;
  const depth=Math.max(...points.map(p=>{const g=t.toGame(p);return g.x+g.y;}));objects.push({depth,draw:()=>{
   const foot=projectIso(player),occluded=player.x+player.y<depth&&foot.x>Math.min(...q.map(p=>p.x))-15*u&&foot.x<Math.max(...q.map(p=>p.x))+15*u&&foot.y>Math.min(...q.map(p=>p.y))-top*vertical&&foot.y-50*u<Math.max(...q.map(p=>p.y));
   ctx.save();if(occluded)ctx.globalAlpha=.32;draw();ctx.restore();
  }});
 };
 const facePoint=(a:P,b:P,along:number,height:number)=>({x:a.x+(b.x-a.x)*along,y:a.y+(b.y-a.y)*along-height*vertical});
 for(const wall of geometry.walls){const n=Math.max(1,Math.ceil(wall.length/geometry.style.bayLength));for(let i=0;i<n;i++){
  const at=(k:number)=>({x:wall.a.x+(wall.b.x-wall.a.x)*k/n,z:wall.a.z+(wall.b.z-wall.a.z)*k/n}),a=at(i),b=at(i+1),points=wallStrip(a,b,wall.thickness),height=wall.metal?geometry.style.metalBaseHeight:geometry.style.solidHeight;
  add(points,geometry.style.metalTopHeight,()=>{
   sides(points,0,height,wall.metal?'#d1c6ad':'#c3b8a0',wall.metal?'#a8a58d':'#a69b87','#dbd8c3');
   const edges=[[points[0],points[1]],[points[2],points[3]]].sort((a,b)=>b[0].x+b[0].z+b[1].x+b[1].z-a[0].x-a[0].z-a[1].x-a[1].z),[from,to]=edges[0],p=project(from),q=project(to);
   if(!wall.metal){ctx.save();ctx.transform(q.x-p.x,q.y-p.y,0,-height*vertical,p.x,p.y);ctx.drawImage(masonryTile(),0,0,1,1);ctx.restore();}
   sides(points,height,height+.14,wall.metal?'#cbd0bb':'#a16f56',wall.metal?'#a8af9d':'#845a48',wall.metal?'#e3e3cc':'#b58264');
   if(wall.metal){const p=project(a),q=project(b),bars=Math.ceil(wall.length/n/geometry.style.metalSpacing);for(let j=0;j<=bars;j++)segment(facePoint(p,q,j/bars,1.65),facePoint(p,q,j/bars,2.84),'#6e6047',1.5);for(const h of [1.72,2.84])segment(facePoint(p,q,0,h),facePoint(p,q,1,h),'#6e6047',2);}
  });
 }}
 for(const p of geometry.posts){const d=geometry.style.postWidth/2,points=[{x:p.x-d,z:p.z-d},{x:p.x+d,z:p.z-d},{x:p.x+d,z:p.z+d},{x:p.x-d,z:p.z+d}];add(points,3.06,()=>{sides(points,0,2.96,p.metal?'#d1d2bf':'#b58369',p.metal?'#a3ae9e':'#92694f','#d0ba97');const cap=points.map(q=>({x:p.x+(q.x-p.x)*geometry.style.capWidth/geometry.style.postWidth,z:p.z+(q.z-p.z)*geometry.style.capWidth/geometry.style.postWidth}));sides(cap,2.96,3.08,'#d4cfb6','#aaa88f',p.metal?'#dedfcb':'#a57359');});}
 for(const b of geometry.blocks){add(b.points,b.top,()=>{
  const isBase=b.id.startsWith('guard-')&&b.id.endsWith('-base'),cap=b.kind==='decorated';
  const faces=sides(b.points,b.bottom,b.top,isBase?'#a18b67':cap?'#cfb996':b.wall,isBase?'#806d50':cap?'#a58d68':b.side,cap?'#d5c59f':b.roof),front=faces[faces.length-1];
  if(b.kind==='guard')for(let j=0;j<2;j++){const lo=.15+j*.4,hi=lo+.25;polygon([facePoint(front.a,front.b,lo,1.35),facePoint(front.a,front.b,hi,1.35),facePoint(front.a,front.b,hi,2.55),facePoint(front.a,front.b,lo,2.55)],'#8b9f94','#f5edda');}
  if(b.kind==='tower'){
   const q=project(geometry.at(b.cross,b.inward));ctx.fillStyle='#b48c28';ctx.textAlign='center';ctx.font=`bold ${10*u}px serif`;[...'大溪國中'].forEach((c,i)=>ctx.fillText(c,q.x,q.y-(6.15-i*.8)*vertical));
   for(const h of [3.25,6.6])segment(facePoint(front.a,front.b,0,h),facePoint(front.a,front.b,1,h),'#9b7650',3);
  }
  if(b.kind==='decorated'){
   for(const h of [7.1,8.35])segment(facePoint(front.a,front.b,.04,h),facePoint(front.a,front.b,.96,h),'#a66e50',3);
   const arch=Array.from({length:17},(_,i)=>facePoint(front.a,front.b,.16+.68*i/16,7.4+Math.sin(Math.PI*i/16)*.65));for(let i=1;i<arch.length;i++)segment(arch[i-1],arch[i],'#f2e4c3',2);
  }
  if(b.kind==='folded-gate'||b.kind==='open-leaf'){const divisions=b.kind==='folded-gate'?5:6;for(let j=0;j<divisions;j++){segment(facePoint(front.a,front.b,j/divisions,b.bottom+.1),facePoint(front.a,front.b,(j+1)/divisions,b.top-.1),'#e1e9de',1);segment(facePoint(front.a,front.b,j/divisions,b.top-.1),facePoint(front.a,front.b,(j+1)/divisions,b.bottom+.1),'#6c8684',1);}}
 });}
 const roof=geometry.gable;
 add(roof.points,roof.eaves+roof.rise,()=>{const q=roof.points.map(project),ridge=[geometry.at(roof.cross-roof.width/2,roof.inward+roof.depth/2-roof.ridgeInset),geometry.at(roof.cross+roof.width/2,roof.inward+roof.depth/2-roof.ridgeInset)].map(project),e=roof.eaves*vertical,h=(roof.eaves+roof.rise)*vertical,at=(p:P,height:number)=>({x:p.x,y:p.y-height});
  polygon([at(q[0],e),at(q[3],e),at(ridge[0],h)],'#f0e5ce','#a28568');polygon([at(q[1],e),at(q[2],e),at(ridge[1],h)],'#d0cab5','#a28568');
  polygon([at(q[2],e),at(q[3],e),at(ridge[0],h),at(ridge[1],h)],'#657266','#805441');polygon([at(q[0],e),at(q[1],e),at(ridge[1],h),at(ridge[0],h)],'#7e8978','#805441');segment(at(ridge[0],h),at(ridge[1],h),'#b4b79c',2);
  for(let i=1;i<8;i++){const a={x:q[0].x+(q[1].x-q[0].x)*i/8,y:q[0].y+(q[1].y-q[0].y)*i/8-e},b={x:ridge[0].x+(ridge[1].x-ridge[0].x)*i/8,y:ridge[0].y+(ridge[1].y-ridge[0].y)*i/8-h};segment(a,b,'#52604f',1);}
 });
 const ball=geometry.ball,ballPoints=geometry.points(ball.cross,ball.inward,ball.radius*2,ball.radius*2);add(ballPoints,ball.height+ball.radius,()=>{const q=project(ball),y=q.y-ball.height*vertical,r=ball.radius*unit;const g=ctx.createRadialGradient(q.x-r*.3,y-r*.4,r*.1,q.x,y,r);g.addColorStop(0,'#fff4ad');g.addColorStop(.4,'#e8bc47');g.addColorStop(1,'#ad7a21');ctx.fillStyle=g;ctx.beginPath();ctx.arc(q.x,y,r,0,Math.PI*2);ctx.fill();});
 return objects;
}
