import config from '../../public/data/campus-surroundings-v1.json';
import model from '../../public/data/campus-model-v2.json';
export const surroundings=config;
type P={x:number;z:number};type R={x0:number;x1:number;z0:number;z1:number};
export function insideCampus(p:P){const points=model.outdoor.perimeter.outline;let hit=false;for(let i=0,j=points.length-1;i<points.length;j=i++){const [ax,az]=points[i],[bx,bz]=points[j];if((az>p.z)!==(bz>p.z)&&p.x<(bx-ax)*(p.z-az)/(bz-az)+ax)hit=!hit;}return hit;}
export const creekSamples=config.creek.points.flatMap((a,i,ps)=>{if(i===ps.length-1)return[a];const b=ps[i+1],before=ps[Math.max(0,i-1)],after=ps[Math.min(ps.length-1,i+2)],count=Math.ceil(Math.hypot(b.x-a.x,b.z-a.z)/.4);return Array.from({length:count},(_,j)=>{const t=j/count,t2=t*t,t3=t2*t,at=(k:'x'|'z')=>.5*(2*a[k]+(b[k]-before[k])*t+(2*before[k]-5*a[k]+4*b[k]-after[k])*t2+(-before[k]+3*a[k]-3*b[k]+after[k])*t3);return{x:at('x'),z:at('z')};});});
export function creekBanks(width:number){const left:P[]=[],right:P[]=[];creekSamples.forEach((p,i,points)=>{const a=points[Math.max(0,i-1)],b=points[Math.min(points.length-1,i+1)],dx=b.x-a.x,dz=b.z-a.z,l=Math.hypot(dx,dz)||1,r=width/2*(.96+.07*Math.sin(i*.07));left.push({x:p.x-dz/l*r,z:p.z+dx/l*r});right.push({x:p.x+dz/l*r,z:p.z-dx/l*r});});return{left,right,outline:[...left,...[...right].reverse()]};}
const bounds=(ps:P[]):R=>({x0:Math.min(...ps.map(p=>p.x)),x1:Math.max(...ps.map(p=>p.x)),z0:Math.min(...ps.map(p=>p.z)),z1:Math.max(...ps.map(p=>p.z))});
function subtract(r:R,h:R):R[]{const x0=Math.max(r.x0,h.x0),x1=Math.min(r.x1,h.x1),z0=Math.max(r.z0,h.z0),z1=Math.min(r.z1,h.z1);if(x0>=x1||z0>=z1)return[r];return[{x0:r.x0,x1:x0,z0:r.z0,z1:r.z1},{x0:x1,x1:r.x1,z0:r.z0,z1:r.z1},{x0,x1,z0:r.z0,z1:z0},{x0,x1,z0:z1,z1:r.z1}].filter(q=>q.x1-q.x0>.001&&q.z1-q.z0>.001);}
const banks=creekBanks(config.creek.width);
/** The same bank geometry drives water paint, collision and the minimap, except the passable deck. */
export const waterSolids=banks.left.slice(1).flatMap((p,i)=>subtract(bounds([banks.left[i],p,banks.right[i],banks.right[i+1]]),config.bridge));
export const bridgePosts=[-66.7,-62,-57,-51.3].flatMap(x=>[129.8,134.2].map(z=>({x,z})));
const rect=(p:P,w:number,d:number):R=>({x0:p.x-w/2,x1:p.x+w/2,z0:p.z-d/2,z1:p.z+d/2});
export const surroundingSolids=[...config.forestTrees.filter(p=>p.x>-161&&p.x<123&&p.z>-89&&p.z<181).map(p=>rect(p,p.kind==='bamboo'?3.8:.72,p.kind==='bamboo'?1.4:.72)),...config.plants.filter(p=>p.kind==='shrub').map(p=>rect(p,.8,.8)),...config.fixtures.map(f=>rect(f,f.width,f.depth)),...bridgePosts.map(p=>rect(p,.22,.22)),...waterSolids];
