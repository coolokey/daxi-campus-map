import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  CAMPUS_PHOTOS,
  getFloorPhotos,
  nearestOutdoorPhoto,
  createPhotoModal,
  drawOutdoorPhotoSpots,
} from './photo-exhibit';

describe('photo-exhibit', () => {
  beforeEach(() => {
    document.body.innerHTML = '';
  });

  it('contains comprehensive authentic photos from 3d campus explorer', () => {
    expect(CAMPUS_PHOTOS.length).toBeGreaterThanOrEqual(12);
    for (const p of CAMPUS_PHOTOS) {
      expect(p.id).toBeTruthy();
      expect(p.title).toBeTruthy();
      expect(p.src).toMatch(/^\.\/assets\/photos\/.*\.(jpg|webp)$/);
      expect(p.location).toBeTruthy();
      expect(p.description).toBeTruthy();
    }
  });

  it('maps every building floor to authentic real photos', () => {
    const floorKeys = [
      'admin-front:floor-1',
      'admin-front:floor-2',
      'admin-front:floor-3',
      'floor-admin-back-1',
      'floor-gym-bld-1',
      'floor-grade8-front-1',
      'floor-grade9-back-1',
      'floor-grade8-mid-1',
      'floor-new-grade7-1',
      'floor-multi-building-1',
      'floor-art-building-1',
      'floor-health-bld-1',
      'floor-recycle-bld-1',
      'pilot-tech-1',
    ];

    for (const key of floorKeys) {
      const photos = getFloorPhotos(key);
      expect(photos.length, `floor ${key} should have photos`).toBeGreaterThan(0);
      expect(photos[0].src).toBeTruthy();
    }
  });

  it('detects nearest outdoor photo hotspot within proximity threshold', () => {
    // Stage photo is at outdoorPoint { x: 490, y: 740 }
    const scale = 1;
    const nearPlayer = { x: 492, y: 742 };
    const found = nearestOutdoorPhoto(nearPlayer, scale, 65);
    expect(found).toBeDefined();
    expect(found?.id).toBe('stage-2019');

    const farPlayer = { x: 1200, y: 1200 };
    const notFound = nearestOutdoorPhoto(farPlayer, scale, 65);
    expect(notFound?.id).not.toBe('stage-2019');
  });

  it('creates photo modal, renders dialog, and handles open/close cycle', () => {
    const modal = createPhotoModal();
    const dialog = document.querySelector<HTMLDialogElement>('#campus-photo-dialog');
    expect(dialog).not.toBeNull();

    // Mock HTMLDialogElement methods in jsdom
    dialog!.showModal = vi.fn(function (this: HTMLDialogElement) {
      this.setAttribute('open', '');
    });
    dialog!.close = vi.fn(function (this: HTMLDialogElement) {
      this.removeAttribute('open');
      this.dispatchEvent(new Event('close'));
    });

    const mapOpenListener = vi.fn();
    window.addEventListener('campus:map-open', mapOpenListener);

    modal.open('stage-2019');
    expect(dialog!.showModal).toHaveBeenCalled();
    expect(mapOpenListener).toHaveBeenCalledWith(
      expect.objectContaining({ detail: true })
    );

    const captionTitle = dialog!.querySelector('#photo-modal-caption-title');
    expect(captionTitle?.textContent).toContain('操場司令台');

    // Click next button
    const nextBtn = dialog!.querySelector<HTMLButtonElement>('#photo-modal-next');
    nextBtn?.click();
    expect(captionTitle?.textContent).not.toBe('');

    // Close modal
    modal.close();
    expect(dialog!.close).toHaveBeenCalled();

    window.removeEventListener('campus:map-open', mapOpenListener);
  });

  it('draws outdoor photo spots without error', () => {
    const ctx = Object.fromEntries(
      ['fillRect', 'strokeRect', 'measureText', 'drawImage', 'beginPath', 'arc', 'fill', 'moveTo', 'lineTo', 'stroke', 'save', 'translate', 'rotate', 'closePath', 'restore', 'setTransform', 'fillText'].map(k => [
        k,
        k === 'measureText' ? vi.fn(() => ({ width: 50 })) : vi.fn()
      ])
    ) as unknown as CanvasRenderingContext2D;

    expect(() => {
      drawOutdoorPhotoSpots(ctx, 1, 1, { x: 500, y: 700 }, Date.now());
    }).not.toThrow();
  });
});
