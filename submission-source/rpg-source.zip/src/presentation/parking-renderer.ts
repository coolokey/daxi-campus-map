import {parkingLayout as L,parkingAreas,parkingShelters,parkingVehicles,parkingPosts,parkingRect,type ParkingRect} from './parking-layout';
import {modelTransform,projectIso} from './model-world';
import type {BoundaryObject} from './boundary-renderer';
type P={x:number;y:number};type C={x:number;z:number};
/** Ground and foot-sorted props share the collision layout; canopy roofs stay overhead. */
export function parkingScene(ctx:CanvasRenderingContext2D,unit:number,u:number,player:P):BoundaryObject[]{
 const t=modelTransform({x:-162,z:-90},unit),objects:BoundaryObject[]=[],v=unit*1.2;
 const point=(p:C,h=0)=>{const q=projectIso(t.toGame(p));return {x:q.x,y:q.y-h*v};};
 const corners=(r:ParkingRect)=>[{x:r.x0,z:r.z0},{x:r.x1,z:r.z0},{x:r.x1,z:r.z1},{x:r.x0,z:r.z1}];
 const polygon=(ps:P[],fill:string,stroke?:string)=>{ctx.beginPath();ps.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=.8*u;ctx.stroke();}};
 const surface=(r:ParkingRect,color:string,stroke?:string)=>polygon(corners(r).map(p=>point(p)),color,stroke);
 const line=(a:C,b:C,color:string,width=.045)=>{const p=point(a),q=point(b);ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.strokeStyle=color;ctx.lineWidth=width*unit;ctx.stroke();};
 const box=(r:ParkingRect,h:number,side:string,roof:string,bottom=0)=>{const ps=corners(r),q=ps.map(p=>point(p,bottom)),top=ps.map(p=>point(p,h));polygon([q[1],q[2],top[2],top[1]],side);polygon([q[2],q[3],top[3],top[2]],side);polygon(top,roof,'#65777b');};
 const label=(p:C,text:string,height=0)=>{const q=point(p,height);ctx.font=`600 ${10*u}px system-ui`;ctx.textAlign='center';const w=ctx.measureText(text).width+12*u;ctx.fillStyle='#fff9e8ee';ctx.fillRect(q.x-w/2,q.y-14*u,w,20*u);ctx.fillStyle='#315744';ctx.fillText(text,q.x,q.y);};
 const visible=(r:ParkingRect,h=0)=>{const matrix=ctx.getTransform(),q=corners(r).flatMap(p=>[point(p),point(p,h)]).map(p=>({x:matrix.a*p.x+matrix.c*p.y+matrix.e,y:matrix.b*p.x+matrix.d*p.y+matrix.f}));return !(Math.max(...q.map(p=>p.x))<-50||Math.min(...q.map(p=>p.x))>ctx.canvas.width+50||Math.max(...q.map(p=>p.y))<-50||Math.min(...q.map(p=>p.y))>ctx.canvas.height+50);};
 const add=(r:ParkingRect,h:number,draw:()=>void,canopy=false)=>{if(!visible(r,h))return;const p=t.toGame({x:r.x1,z:r.z1});objects.push({depth:p.x+p.y,draw:()=>{ctx.save();if(canopy){const foot=projectIso(player),q=corners(r).flatMap(p=>[point(p),point(p,h)]);if(player.x+player.y<p.x+p.y&&foot.x>Math.min(...q.map(p=>p.x))-18*u&&foot.x<Math.max(...q.map(p=>p.x))+18*u&&foot.y>Math.min(...q.map(p=>p.y))&&foot.y-50*u<Math.max(...q.map(p=>p.y)))ctx.globalAlpha=.42;}draw();ctx.restore();}});};
 const T=L.twoWheel,C=L.cars;
 for(const r of parkingAreas)if(visible(r))surface(r,'#929c91','#c5c7b2');
 surface(parkingRect(19.5,T.aisleZ,32,1.65),'#d8cbb1');
 surface(parkingRect(60.4,66.9,1.9,27.4),'#e2d4b9','#c6aa8e');surface(parkingRect(71.1,54.1,29.2,1.5),'#e2d4b9');surface(parkingRect(C.aisleX,81,6,1.2),'#929c91');
 for(let z=54;z<80.5;z+=1)line({x:59.5,z},{x:61.3,z},'#c5b694',.025);
 const bay=(x:number,z:number,w=6,d=3.5)=>{const r=parkingRect(x,z,w,d);if(visible(r))surface(r,'#ffffff00','#f7f2dd');};
 surface(parkingRect(C.westX,57.5,6,4.4),'#638eaf','#f8f1d8');bay(C.westX,57.5,6,4.4);
 for(let z=59.9;z<61.4;z+=.32)line({x:C.westX-3,z},{x:C.westX+3,z:z+.1},'#f6f1df',.06);
 const accessible=point({x:C.westX,z:57.5});ctx.save();ctx.fillStyle='#fff9e8';ctx.font=`${unit*1.6}px system-ui`;ctx.textAlign='center';ctx.fillText('♿',accessible.x,accessible.y+unit*.35);ctx.restore();
 for(const z of [63.5,67.2,70.9,74.6,78.3])bay(C.westX,z);for(const z of [57.3,61,64.7,68.4,72.1,75.8])bay(C.eastX,z);
 for(let x=70.6;x<92;x+=4.8)bay(x,C.coveredZ,4.7,2.35);
 for(let x=5.1;x<34.2;x+=1.35)line({x,z:T.bikeZ-.8},{x,z:T.bikeZ+.8},'#ece6ce',.025);
 for(let x=4.9;x<34.2;x+=1.8)line({x,z:T.motoZ-.9},{x,z:T.motoZ+.9},'#ece6ce',.025);
 for(const [x,z,d] of [[71.6,69,-1],[74.9,66,1]]){line({x,z:z-d*.7},{x,z:z+d*.6},'#fff9e8',.12);polygon([{x:x-.45,z:z+d*.35},{x:x+.45,z:z+d*.35},{x,z:z+d*1.15}].map(p=>point(p)),'#fff9e8');}
 for(const r of parkingPosts)add(r,L.roofHeight,()=>box(r,L.roofHeight,'#9ba9a4','#c5cfc1'));
 for(const car of parkingVehicles)add(car.rect,1.7,()=>{
  const shadow=point(car);ctx.fillStyle='#30453430';ctx.beginPath();ctx.ellipse(shadow.x,shadow.y,unit*(car.kind==='car'?2.2:.65),unit*.6,0,0,Math.PI*2);ctx.fill();
  if(car.kind==='car'){for(const x of [-1.18,1.18])for(const z of [-.86,.86]){const p=point({x:car.x+x,z:car.z+z},.25);ctx.fillStyle='#35423e';ctx.beginPath();ctx.ellipse(p.x,p.y,unit*.22,unit*.28,0,0,Math.PI*2);ctx.fill();}box(car.rect,.9,'#647a79',car.color,.3);box(parkingRect(car.x,car.z,2,1.5),1.5,'#526b77','#91aeb5',.9);box(parkingRect(car.x,car.z,1.35,1.45),1.62,car.color,car.color,1.5);for(const x of [-1.98,1.98])box(parkingRect(car.x+x,car.z,.08,1.25),.7,'#eae2b8','#f4ebc3',.48);}
  else {const wheels=[-.6,.6].map(z=>point({x:car.x,z:car.z+z},.3));for(const p of wheels){ctx.strokeStyle='#35423e';ctx.lineWidth=unit*.08;ctx.beginPath();ctx.ellipse(p.x,p.y,unit*.18,unit*.3,0,0,Math.PI*2);ctx.stroke();}
   if(car.kind==='moto'){box(parkingRect(car.x,car.z,.55,1.05),.85,'#586e70',car.color,.34);box(parkingRect(car.x,car.z+.2,.5,.65),1.02,'#3e4942','#3e4942',.85);box(parkingRect(car.x,car.z-.57,.5,.17),1.05,'#a9b9b5','#d5ddd0',.4);}
   else {const a=point({x:car.x,z:car.z-.6},.34),b=point({x:car.x,z:car.z+.6},.34),seat=point({x:car.x,z:car.z-.2},.85),handle=point({x:car.x,z:car.z+.45},1.04);ctx.strokeStyle=car.color;ctx.lineWidth=unit*.075;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(seat.x,seat.y);ctx.lineTo(b.x,b.y);ctx.lineTo(a.x,a.y);ctx.moveTo(seat.x,seat.y);ctx.lineTo(handle.x,handle.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.fillStyle='#39453f';ctx.fillRect(seat.x-unit*.15,seat.y-unit*.06,unit*.3,unit*.09);}
  }
 });
 for(const shelter of parkingShelters)add(shelter.rect,L.roofHeight+.18,()=>{box(shelter.rect,L.roofHeight+.16,'#4b6985',L.roofColor,L.roofHeight);for(let x=shelter.rect.x0+1;x<shelter.rect.x1;x+=1.5){const a=point({x,z:shelter.rect.z0},L.roofHeight+.17),b=point({x,z:shelter.rect.z1},L.roofHeight+.17);ctx.strokeStyle='#8ba2b780';ctx.lineWidth=.6*u;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();}ctx.globalAlpha=1;label({x:(shelter.rect.x0+shelter.rect.x1)/2,z:shelter.rect.z1},shelter.name,3.7);},true);
 label({x:73.2,z:53.4},'藝術館旁汽車停車區');return objects;
}
