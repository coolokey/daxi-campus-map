import type { Rect } from '../game/data/types';

export type RoomCategory = 'grade7' | 'grade8' | 'grade9' | 'admin' | 'special' | 'sports' | 'other';
export type RoomKind =
  | 'classroom'
  | 'computer'
  | 'lab'
  | 'workshop'
  | 'music'
  | 'office'
  | 'meeting'
  | 'health'
  | 'library'
  | 'sports'
  | 'kitchen'
  | 'exhibit'
  | 'shop'
  | 'utility'
  | 'unconfirmed';

export interface CategoryPalette {
  badge: string;
  badgeText: string;
  bg: string;
  border: string;
  text: string;
}

export function getRoomCategory(name: string): RoomCategory {
  const m = name.match(/^([789])\d{2}/);
  if (m) {
    if (m[1] === '7') return 'grade7';
    if (m[1] === '8') return 'grade8';
    if (m[1] === '9') return 'grade9';
  }
  if (/校長|教務|學務|總務|人事|會計|輔導|導師|辦公|檔案|油印|健康|幼兒園|特教辦公/.test(name)) return 'admin';
  if (/電腦|理化|實驗|生物|生科|木工|木藝|科技|創作|美術|音樂|圖書|視聽|社團|語言|特教|研習|自造/.test(name)) return 'special';
  if (/體適能|體育|體能|柔道|重訓|桌球|看台|禮堂|訓練/.test(name)) return 'sports';
  return 'other';
}

export function getCategoryPalette(category: RoomCategory): CategoryPalette {
  switch (category) {
    case 'grade7':
      return { badge: '#63b54f', badgeText: '#ffffff', bg: '#f2faf2', border: '#7ecb6e', text: '#1b4317' };
    case 'grade8':
      return { badge: '#409ed1', badgeText: '#ffffff', bg: '#f0f8fd', border: '#68b5e2', text: '#0c4a6e' };
    case 'grade9':
      return { badge: '#e86482', badgeText: '#ffffff', bg: '#fff2f4', border: '#f0889f', text: '#881337' };
    case 'admin':
      return { badge: '#8470dc', badgeText: '#ffffff', bg: '#f5f3ff', border: '#a795ea', text: '#3b0764' };
    case 'special':
      return { badge: '#b95bc2', badgeText: '#ffffff', bg: '#fdf2f8', border: '#cf80d6', text: '#701a75' };
    case 'sports':
      return { badge: '#2563eb', badgeText: '#ffffff', bg: '#eff6ff', border: '#93c5fd', text: '#1e3a8a' };
    case 'other':
    default:
      return { badge: '#69889a', badgeText: '#ffffff', bg: '#f8fafc', border: '#94a3b8', text: '#1e293b' };
  }
}

export function getRoomKind(name: string): RoomKind {
  if (/名稱待確認/.test(name)) return 'unconfirmed';
  if (/^[789]\d{2}(?:\s|$)|幼兒園/.test(name)) return 'classroom';
  if (/機房|回收|消防/.test(name)) return 'utility';
  if (/圖書/.test(name)) return 'library';
  if (/健康中心/.test(name)) return 'health';
  if (/合作社/.test(name)) return 'shop';
  if (/校史/.test(name)) return 'exhibit';
  if (/會客|會議|研習中心/.test(name)) return 'meeting';
  if (/導師|辦公|研究室|教練室|校長|教務|學務|總務|人事|會計|輔導室|檔案室|油印室/.test(name)) return 'office';
  if (/電腦/.test(name)) return 'computer';
  if (/理化|實驗|生物/.test(name)) return 'lab';
  if (/木工|木藝|科技|生科|創作|美術|自造/.test(name)) return 'workshop';
  if (/音樂/.test(name)) return 'music';
  if (/烹飪|餐飲/.test(name)) return 'kitchen';
  if (/體適能|體能|柔道|重訓|禮堂|看台|桌球|球場|訓練室/.test(name)) return 'sports';
  return /教室|班|語言/.test(name) ? 'classroom' : 'office';
}

const AUTHENTIC_STAIR_MAP: Record<string, string> = {
  'grade8-front-west': '八年級西側半圓樓梯塔',
  'grade8-front-east': '八年級東側樓梯',
  'gym-bld-south': '活動中心南側雙圓柱梯',
  'gym-bld-north': '活動中心北側雙圓柱梯',
  'admin-back-central': '行政大樓中段折返梯',
  'admin-front-central': '行政大樓中段樓梯',
  'health-bld-east': '健康中心東側樓梯',
  'grade9-back-south': '九年級南側樓梯',
  'grade9-back-north': '九年級北側樓梯',
  'grade8-mid-south': '八年級中棟南側樓梯',
  'grade8-mid-north': '八年級中棟北側樓梯',
  'new-grade7-west': '七年級西側樓梯',
  'new-grade7-east': '特教學習園地樓梯',
  'multi-building-north': '綜合大樓東北側樓梯',
  'multi-building': '綜合大樓樓梯',
  'tech-building-south': '科技館南翼樓梯',
  'tech-building': '科技館樓梯',
  'art-building-main': '藝術館主樓梯間',
  'art-building': '藝術館主樓梯間',
};

export function getAuthenticStairName(id: string, originalName: string, buildingId?: string): string {
  if (AUTHENTIC_STAIR_MAP[id]) return AUTHENTIC_STAIR_MAP[id];
  if (buildingId && AUTHENTIC_STAIR_MAP[buildingId]) return AUTHENTIC_STAIR_MAP[buildingId];
  if (/西側半圓/.test(originalName)) return '八年級西側半圓樓梯塔';
  if (/折返/.test(originalName)) return '行政大樓中段折返梯';
  if (/圓柱/.test(originalName)) return '活動中心雙圓柱梯';
  return originalName;
}

/**
 * Draws CAD/architectural furnishings inside an indoor room, keeping aisles open.
 */
export function drawRoomFurnishings(
  ctx: CanvasRenderingContext2D,
  rect: Rect,
  door: { x: number; y: number },
  name: string,
  unit: number
): void {
  const kind = getRoomKind(name);
  if (kind === 'unconfirmed') return;

  const w = rect.width;
  const h = rect.height;
  if (w < 40 || h < 40) return;

  // Determine wall closest to door: 0: North, 1: South, 2: West, 3: East
  const dNorth = Math.abs(door.y - rect.y);
  const dSouth = Math.abs(door.y - (rect.y + h));
  const dWest = Math.abs(door.x - rect.x);
  const dEast = Math.abs(door.x - (rect.x + w));
  const minDist = Math.min(dNorth, dSouth, dWest, dEast);
  const doorWall = minDist === dNorth ? 'north' : minDist === dSouth ? 'south' : minDist === dWest ? 'west' : 'east';

  ctx.save();

  switch (kind) {
    case 'classroom': {
      // Chalkboard on opposite wall of door
      const boardY = doorWall === 'south' ? rect.y + 6 : rect.y + h - 10;
      const boardW = Math.min(w * 0.55, 120);
      const boardX = rect.x + (w - boardW) / 2;
      ctx.fillStyle = '#1e392a'; // chalkboard green
      ctx.fillRect(boardX, boardY, boardW, 5);
      ctx.fillStyle = '#d97706'; // chalk tray
      ctx.fillRect(boardX + 2, boardY + (doorWall === 'south' ? 5 : -2), boardW - 4, 2);

      // Teacher dais & desk
      const daisY = doorWall === 'south' ? rect.y + 16 : rect.y + h - 28;
      ctx.fillStyle = '#e2d5c3';
      ctx.fillRect(boardX + boardW * 0.25, daisY, boardW * 0.5, 10);
      ctx.fillStyle = '#b48c65';
      ctx.fillRect(boardX + boardW * 0.32, daisY + 2, boardW * 0.36, 6);

      // Student desk rows (left and right columns leaving center aisle)
      const colW = Math.min(w * 0.28, 48);
      const rowCount = Math.max(1, Math.min(3, Math.floor((h - 55) / 24)));
      const startY = doorWall === 'south' ? rect.y + 36 : rect.y + 16;
      for (let r = 0; r < rowCount; r++) {
        const ry = startY + r * 22;
        // Left column
        const lx = rect.x + 10;
        ctx.fillStyle = '#dfc299';
        ctx.fillRect(lx, ry, colW, 11);
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(lx + 4, ry + (doorWall === 'south' ? 12 : -3), colW - 8, 3);

        // Right column
        const rx = rect.x + w - colW - 10;
        ctx.fillStyle = '#dfc299';
        ctx.fillRect(rx, ry, colW, 11);
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(rx + 4, ry + (doorWall === 'south' ? 12 : -3), colW - 8, 3);
      }
      break;
    }

    case 'computer': {
      // Front projector screen
      const screenW = Math.min(w * 0.5, 110);
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(rect.x + (w - screenW) / 2, rect.y + 6, screenW, 4);

      // Computer desk banks
      const deskW = Math.min(w * 0.32, 54);
      const rowCount = Math.max(1, Math.min(3, Math.floor((h - 50) / 26)));
      for (let r = 0; r < rowCount; r++) {
        const ry = rect.y + 24 + r * 24;
        for (const dx of [rect.x + 10, rect.x + w - deskW - 10]) {
          ctx.fillStyle = '#cbd5e1';
          ctx.fillRect(dx, ry, deskW, 12);
          // Monitors on desks
          for (let m = 0; m < 2; m++) {
            const mx = dx + 6 + m * (deskW * 0.45);
            ctx.fillStyle = '#1e293b';
            ctx.fillRect(mx, ry + 2, 12, 3);
            ctx.fillStyle = '#0284c7';
            ctx.fillRect(mx + 2, ry + 2, 8, 2);
          }
        }
      }
      break;
    }

    case 'lab': {
      // Blackboard
      ctx.fillStyle = '#1e392a';
      ctx.fillRect(rect.x + w * 0.25, rect.y + 6, w * 0.5, 4);
      // Heavy lab workbenches with sinks
      const benchW = Math.min(w * 0.32, 60);
      const rowCount = Math.max(1, Math.min(3, Math.floor((h - 45) / 28)));
      for (let r = 0; r < rowCount; r++) {
        const ry = rect.y + 20 + r * 26;
        for (const bx of [rect.x + 10, rect.x + w - benchW - 10]) {
          ctx.fillStyle = '#64748b';
          ctx.fillRect(bx, ry, benchW, 14);
          // Stainless sink
          ctx.fillStyle = '#e2e8f0';
          ctx.fillRect(bx + 4, ry + 3, 10, 8);
          ctx.fillStyle = '#0284c7'; // faucet
          ctx.fillRect(bx + 8, ry + 6, 2, 2);
        }
      }
      break;
    }

    case 'workshop': {
      // Woodwork / Living Technology craft tables
      const benchW = Math.min(w * 0.34, 62);
      const rowCount = Math.max(1, Math.min(2, Math.floor((h - 45) / 32)));
      for (let r = 0; r < rowCount; r++) {
        const ry = rect.y + 20 + r * 30;
        for (const bx of [rect.x + 10, rect.x + w - benchW - 10]) {
          ctx.fillStyle = '#a16207'; // wooden workbench
          ctx.fillRect(bx, ry, benchW, 16);
          ctx.strokeStyle = '#78350f';
          ctx.lineWidth = 1;
          ctx.strokeRect(bx, ry, benchW, 16);
          // Bench vise
          ctx.fillStyle = '#475569';
          ctx.fillRect(bx - 2, ry + 4, 4, 6);
        }
      }
      // Tool cabinets along top
      ctx.fillStyle = '#475569';
      ctx.fillRect(rect.x + w * 0.3, rect.y + 5, w * 0.4, 6);
      break;
    }

    case 'music': {
      // Grand Piano
      const px = rect.x + 14;
      const py = rect.y + 18;
      ctx.fillStyle = '#0f172a'; // black lacquer piano
      ctx.beginPath();
      ctx.moveTo(px, py);
      ctx.lineTo(px + 28, py);
      ctx.arcTo(px + 36, py + 12, px + 28, py + 26, 8);
      ctx.lineTo(px, py + 26);
      ctx.closePath();
      ctx.fill();
      // Piano keyboard
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(px + 2, py + 22, 24, 4);
      for (let k = 0; k < 6; k++) {
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(px + 4 + k * 4, py + 22, 2, 3);
      }
      // Music stands & chairs
      const chairArcX = rect.x + w - 30;
      const chairArcY = rect.y + h / 2;
      for (let a = -2; a <= 2; a++) {
        const cx = chairArcX + Math.cos(a * 0.4) * 16;
        const cy = chairArcY + Math.sin(a * 0.4) * 20;
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(cx - 3, cy - 3, 6, 6);
      }
      break;
    }

    case 'office': {
      // Staff desks with desktop dividers
      const deskW = Math.min(w * 0.34, 56);
      const rowCount = Math.max(1, Math.min(3, Math.floor((h - 45) / 26)));
      for (let r = 0; r < rowCount; r++) {
        const ry = rect.y + 20 + r * 24;
        for (const dx of [rect.x + 8, rect.x + w - deskW - 8]) {
          ctx.fillStyle = '#cbd5e1';
          ctx.fillRect(dx, ry, deskW, 13);
          // Desk screen partition
          ctx.fillStyle = '#818cf8';
          ctx.fillRect(dx, ry + 1, deskW, 2);
          // Monitor
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(dx + deskW * 0.3, ry + 4, 12, 4);
          // Swivel chair
          ctx.fillStyle = '#334155';
          ctx.beginPath();
          ctx.arc(dx + deskW * 0.5, ry + (doorWall === 'south' ? 18 : -5), 4, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      // File cabinet on back wall
      ctx.fillStyle = '#475569';
      ctx.fillRect(rect.x + w * 0.35, rect.y + 5, w * 0.3, 6);
      break;
    }

    case 'meeting': {
      // Large conference table in center
      const tableW = Math.min(w * 0.52, 90);
      const tableH = Math.min(h * 0.4, 40);
      const tx = rect.x + (w - tableW) / 2;
      const ty = rect.y + (h - tableH) / 2;
      ctx.fillStyle = '#9a3412'; // polished mahogany
      ctx.beginPath();
      ctx.roundRect ? ctx.roundRect(tx, ty, tableW, tableH, 8) : ctx.rect(tx, ty, tableW, tableH);
      ctx.fill();
      ctx.strokeStyle = '#7c2d12';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Conference chairs around table
      ctx.fillStyle = '#334155';
      const chairCount = Math.max(2, Math.floor(tableW / 18));
      for (let c = 0; c < chairCount; c++) {
        const cx = tx + 10 + c * ((tableW - 20) / (chairCount - 1 || 1));
        ctx.fillRect(cx - 3, ty - 5, 6, 4);
        ctx.fillRect(cx - 3, ty + tableH + 1, 6, 4);
      }
      break;
    }

    case 'health': {
      // 2 Clinical sick beds with pillows
      const bedW = Math.min(w * 0.32, 42);
      const bedH = Math.min(h * 0.45, 46);
      for (const bx of [rect.x + 8, rect.x + 16 + bedW]) {
        if (bx + bedW > rect.x + w - 10) continue;
        ctx.fillStyle = '#f8fafc'; // mattress
        ctx.fillRect(bx, rect.y + 16, bedW, bedH);
        ctx.strokeStyle = '#93c5fd';
        ctx.strokeRect(bx, rect.y + 16, bedW, bedH);
        // Pillow
        ctx.fillStyle = '#60a5fa';
        ctx.fillRect(bx + 4, rect.y + 18, bedW - 8, 8);
        // Blanket
        ctx.fillStyle = '#bfdbfe';
        ctx.fillRect(bx + 2, rect.y + 30, bedW - 4, bedH - 16);
      }
      // Nurse station desk
      const nx = rect.x + w - 45;
      const ny = rect.y + 16;
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(nx, ny, 35, 18);
      // Red Cross emblem
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(nx + 15, ny + 5, 4, 8);
      ctx.fillRect(nx + 13, ny + 7, 8, 4);
      break;
    }

    case 'library': {
      // Bookshelves along walls
      const shelfW = Math.min(w * 0.38, 70);
      ctx.fillStyle = '#92400e';
      ctx.fillRect(rect.x + 10, rect.y + 6, shelfW, 7);
      ctx.fillRect(rect.x + w - shelfW - 10, rect.y + 6, shelfW, 7);

      // Book spines
      for (let b = 0; b < 6; b++) {
        ctx.fillStyle = ['#dc2626', '#2563eb', '#16a34a', '#ca8a04', '#9333ea'][b % 5];
        ctx.fillRect(rect.x + 12 + b * 10, rect.y + 7, 8, 5);
      }

      // Reading tables
      const tableW = Math.min(w * 0.35, 50);
      ctx.fillStyle = '#dfc299';
      ctx.fillRect(rect.x + (w - tableW) / 2, rect.y + 24, tableW, 16);
      break;
    }

    case 'sports': {
      // Table tennis or gym bench
      if (/桌球|重訓|體適能/.test(name)) {
        const ttW = Math.min(w * 0.45, 68);
        const ttH = Math.min(h * 0.38, 38);
        const tx = rect.x + (w - ttW) / 2;
        const ty = rect.y + 20;
        ctx.fillStyle = '#15803d'; // table tennis green
        ctx.fillRect(tx, ty, ttW, ttH);
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1;
        ctx.strokeRect(tx, ty, ttW, ttH);
        // Center net
        ctx.fillStyle = '#f8fafc';
        ctx.fillRect(tx + ttW / 2 - 1, ty - 2, 2, ttH + 4);
      } else {
        // Gym sports benches
        ctx.fillStyle = '#b45309';
        ctx.fillRect(rect.x + 12, rect.y + 20, w * 0.35, 8);
        ctx.fillRect(rect.x + w * 0.55, rect.y + 20, w * 0.35, 8);
      }
      break;
    }

    case 'exhibit': {
      // History display vitrines
      const caseW = Math.min(w * 0.35, 48);
      for (const cx of [rect.x + 12, rect.x + w - caseW - 12]) {
        ctx.fillStyle = '#bae6fd';
        ctx.fillRect(cx, rect.y + 18, caseW, 16);
        ctx.strokeStyle = '#0284c7';
        ctx.lineWidth = 1;
        ctx.strokeRect(cx, rect.y + 18, caseW, 16);
      }
      break;
    }

    case 'kitchen': {
      // Cooking prep tables
      const cookW = Math.min(w * 0.35, 52);
      ctx.fillStyle = '#64748b';
      ctx.fillRect(rect.x + 12, rect.y + 20, cookW, 16);
      ctx.fillRect(rect.x + w - cookW - 12, rect.y + 20, cookW, 16);
      // Hobs
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(rect.x + 22, rect.y + 28, 4, 0, Math.PI * 2);
      ctx.arc(rect.x + 38, rect.y + 28, 4, 0, Math.PI * 2);
      ctx.fill();
      break;
    }

    case 'shop': {
      // Store checkout counter and shelves
      ctx.fillStyle = '#ca8a04';
      ctx.fillRect(rect.x + 12, rect.y + 18, w * 0.4, 10);
      ctx.fillStyle = '#475569';
      ctx.fillRect(rect.x + 12, rect.y + h - 14, w - 24, 6);
      break;
    }

    case 'utility': {
      // Server racks with status lights
      const rackW = Math.min(w * 0.4, 60);
      const rx = rect.x + 12;
      const ry = rect.y + 16;
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(rx, ry, rackW, 16);
      for (let led = 0; led < 4; led++) {
        ctx.fillStyle = '#22c55e'; // green blinking light
        ctx.fillRect(rx + 6 + led * 12, ry + 6, 3, 3);
      }
      break;
    }
  }

  ctx.restore();
}

/**
 * Draws architectural door sign plaque with category badge.
 */
export function drawRoomBadgePlaque(
  ctx: CanvasRenderingContext2D,
  rect: Rect,
  name: string,
  unit: number,
  spaceCode?: string
): void {
  const category = getRoomCategory(name);
  const pal = getCategoryPalette(category);
  const cleanName = name.replace(/\s*\(\d+F\)/, '');

  ctx.save();
  // Pill badge showing category accent
  const badgeH = 18 * unit;
  const badgeY = rect.y + 8 * unit;
  const badgeW = Math.min(rect.width - 16, Math.max(34 * unit, cleanName.length * 15 * unit + 18));
  const badgeX = rect.x + (rect.width - badgeW) / 2;

  // Background pill
  ctx.fillStyle = pal.badge;
  ctx.beginPath();
  if (ctx.roundRect) {
    ctx.roundRect(badgeX, badgeY, badgeW, badgeH, 4 * unit);
  } else {
    ctx.rect(badgeX, badgeY, badgeW, badgeH);
  }
  ctx.fill();

  // Text
  ctx.fillStyle = pal.badgeText;
  ctx.font = `bold ${12 * unit}px system-ui`;
  ctx.textAlign = 'center';
  ctx.fillText(cleanName, badgeX + badgeW / 2, badgeY + 13 * unit, badgeW - 6);

  // If space code is distinct, show tiny code below
  if (spaceCode && spaceCode !== cleanName && !cleanName.includes(spaceCode)) {
    ctx.fillStyle = pal.text;
    ctx.font = `${10 * unit}px monospace`;
    ctx.fillText(spaceCode, rect.x + rect.width / 2, badgeY + badgeH + 11 * unit);
  }

  ctx.textAlign = 'left';
  ctx.restore();
}

/**
 * Draws authentic architectural staircase with treads, landing, and direction.
 */
export function drawArchitecturalStairs(
  ctx: CanvasRenderingContext2D,
  rect: Rect,
  stairId: string,
  stairName: string,
  buildingId: string,
  unit: number
): void {
  const authenticName = getAuthenticStairName(stairId, stairName, buildingId);
  ctx.save();

  // Concrete stair floor
  ctx.fillStyle = '#e2e8f0';
  ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
  ctx.strokeStyle = '#475569';
  ctx.lineWidth = 1.5;
  ctx.strokeRect(rect.x, rect.y, rect.width, rect.height);

  // Stair treads hatching
  const steps = 8;
  for (let i = 1; i < steps; i++) {
    const y = rect.y + (rect.height * i) / steps;
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(rect.x + 4, y);
    ctx.lineTo(rect.x + rect.width - 4, y);
    ctx.stroke();

    // Tread shadow
    ctx.strokeStyle = '#cbd5e1';
    ctx.beginPath();
    ctx.moveTo(rect.x + 4, y + 1);
    ctx.lineTo(rect.x + rect.width - 4, y + 1);
    ctx.stroke();
  }

  // Handrail in center
  ctx.strokeStyle = '#334155';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(rect.x + rect.width / 2, rect.y + 4);
  ctx.lineTo(rect.x + rect.width / 2, rect.y + rect.height - 4);
  ctx.stroke();

  // Stair banner badge
  const labelH = 20 * unit;
  const labelY = rect.y + (rect.height - labelH) / 2;
  ctx.fillStyle = '#1e293bdd';
  ctx.fillRect(rect.x + 4, labelY, rect.width - 8, labelH);

  ctx.fillStyle = '#f8fafc';
  ctx.font = `bold ${12 * unit}px system-ui`;
  ctx.textAlign = 'center';
  ctx.fillText(`🪜 ${authenticName}`, rect.x + rect.width / 2, labelY + 14 * unit, Math.max(28, rect.width - 12));
  ctx.textAlign = 'left';

  ctx.restore();
}
