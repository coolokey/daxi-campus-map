import plan from '../../public/data/campus-boundary-v1.json';
import source from '../../public/data/campus-model-v2.json';
import type {CampusModel} from './model-world';
import type {Rect} from '../game/data/types';
type P={x:number;z:number};
const bounds=(points:P[])=>({x0:Math.min(...points.map(p=>p.x)),x1:Math.max(...points.map(p=>p.x)),z0:Math.min(...points.map(p=>p.z)),z1:Math.max(...points.map(p=>p.z))});
export function wallStrip(a:P,b:P,thickness:number){const dx=b.x-a.x,dz=b.z-a.z,length=Math.hypot(dx,dz)||1,n={x:-dz/length*thickness/2,z:dx/length*thickness/2};return [{x:a.x+n.x,z:a.z+n.z},{x:b.x+n.x,z:b.z+n.z},{x:b.x-n.x,z:b.z-n.z},{x:a.x-n.x,z:a.z-n.z}];}
export function campusBoundary(model=source as unknown as CampusModel){
 const entrance=model.outdoor.entrance,dx=entrance.target.x-entrance.gate.x,dz=entrance.target.z-entrance.gate.z,length=Math.hypot(dx,dz),axis={x:dx/length,z:dz/length},right={x:-axis.z,z:axis.x};
 const at=(cross:number,inward:number):P=>({x:entrance.gate.x+right.x*cross+axis.x*inward,z:entrance.gate.z+right.z*cross+axis.z*inward});
 const points=(cross:number,inward:number,width:number,depth:number)=>[[cross-width/2,inward-depth/2],[cross+width/2,inward-depth/2],[cross+width/2,inward+depth/2],[cross-width/2,inward+depth/2]].map(([c,i])=>at(c,i));
 const blocks=plan.blocks.map(b=>{const footprint=points(b.cross,b.inward,b.width,b.depth);return {...b,points:footprint,rect:bounds(footprint)};});
 const walls=model.outdoor.perimeter.segments.map((s,i)=>{const a={x:s.ax,z:s.az},b={x:s.bx,z:s.bz},thickness=s.thickness??model.outdoor.perimeter.thickness;return {id:'perimeter-'+i,a,b,thickness,length:Math.hypot(b.x-a.x,b.z-a.z),metal:s.az>=78&&s.bz>=78};});
 const posts=model.outdoor.perimeter.outline.map(([x,z])=>({x,z,metal:z>=78}));
 for(const wall of walls)if(!wall.metal){const n=Math.max(1,Math.round(wall.length/plan.wallStyle.bayLength));for(let i=1;i<n;i++)posts.push({x:wall.a.x+(wall.b.x-wall.a.x)*i/n,z:wall.a.z+(wall.b.z-wall.a.z)*i/n,metal:false});}
 return {source:plan.source,blocks,walls,posts,style:plan.wallStyle,playerHeight:plan.playerHeight,at,points,gable:{...plan.gable,points:points(plan.gable.cross,plan.gable.inward,plan.gable.width,plan.gable.depth)},ball:{...plan.goldBall,...at(plan.goldBall.cross,plan.goldBall.inward)}};
}
/** Continuous overlapping short strips avoid leaks when the world grows but feet stay small. */
export function boundaryColliders(model:CampusModel,toRect:(b:{x0:number;x1:number;z0:number;z1:number})=>Rect){
 const geometry=campusBoundary(model),zones:Rect[]=[];
 for(const wall of geometry.walls){const n=Math.ceil(wall.length/.5);for(let i=0;i<n;i++){const point=(k:number)=>({x:wall.a.x+(wall.b.x-wall.a.x)*k/n,z:wall.a.z+(wall.b.z-wall.a.z)*k/n});zones.push(toRect(bounds(wallStrip(point(i),point(i+1),wall.thickness))));}}
 for(const p of geometry.posts){const half=geometry.style.postWidth/2;zones.push(toRect({x0:p.x-half,x1:p.x+half,z0:p.z-half,z1:p.z+half}));}
 for(const b of geometry.blocks)if(b.bottom<geometry.playerHeight)zones.push(toRect(b.rect));
 return zones;
}
export type BoundaryGeometry=ReturnType<typeof campusBoundary>;
