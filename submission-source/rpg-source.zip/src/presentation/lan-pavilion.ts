import config from '../../public/data/pavilion-activities-v1.json';
export const pavilion=config.pavilion;
export const pavilionRing=(radius:number)=>Array.from({length:6},(_,i)=>({x:pavilion.x+Math.cos(i*Math.PI/3)*radius,z:pavilion.z+Math.sin(i*Math.PI/3)*radius}));
export const pavilionSeats=pavilionRing(2.7).flatMap((a,i,points)=>i===1?[]:[{a,b:points[(i+1)%6]}]);
export const pavilionSolids=[...pavilionRing(pavilion.columnRadius).map(q=>({x0:q.x-.32,x1:q.x+.32,z0:q.z-.32,z1:q.z+.32})),...pavilionSeats.map(({a,b})=>({x0:Math.min(a.x,b.x)-.23,x1:Math.max(a.x,b.x)+.23,z0:Math.min(a.z,b.z)-.23,z1:Math.max(a.z,b.z)+.23}))];
