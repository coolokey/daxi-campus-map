import data from '../../public/data/entrance-landmarks-v1.json';
export const entranceLandmarks=data;
type B={x0:number;x1:number;z0:number;z1:number};
export function landmarkSolids():{id:string;rect:B}[]{
 const center=(id:string,x:number,z:number,w:number,d:number)=>({id,rect:{x0:x-w/2,x1:x+w/2,z0:z-d/2,z1:z+d/2}}),s=data.statue,stage=data.stage;
 return [center('statue-base',s.x,s.z,s.width,s.depth),center('trail-sign',data.trail.sign.x,data.trail.sign.z,.24,6.6),...data.palms.map((p,i)=>center('palm-'+i,p.x,p.z,.88,.88)),center('stage-left',stage.x0+.12,11.95,.24,7.7),center('stage-right',stage.x1-.12,11.95,.24,7.7),center('stage-back',-62,stage.z1-.12,16,.24),...[-67.2,-56.8].map((x,i)=>center('stage-column-'+i,x,8.5,.35,.45)),...[-52,-49.5,-47].map((x,i)=>center('flagpole-'+i,x,9,.16,.16))];
}
