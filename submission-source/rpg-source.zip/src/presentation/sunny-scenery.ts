/** Screen-space distant scenery. It has no collision, map coordinates, or animation state. */
export function drawSunnyHorizon(ctx:CanvasRenderingContext2D,width:number,height:number){
 const horizon=Math.min(126,height*.18);
 const sky=ctx.createLinearGradient(0,0,0,horizon);
 sky.addColorStop(0,'#91cef1');sky.addColorStop(1,'#e4f4fc');
 ctx.fillStyle=sky;ctx.fillRect(0,0,width,horizon);
 const cloud=(x:number,y:number,scale:number)=>{
  ctx.save();ctx.translate(x,y);ctx.scale(scale,scale);ctx.fillStyle='#fffefb';
  ctx.beginPath();ctx.ellipse(0,6,44,13,0,0,Math.PI*2);ctx.ellipse(-19,0,20,17,0,0,Math.PI*2);ctx.ellipse(5,-7,25,23,0,0,Math.PI*2);ctx.ellipse(27,3,21,16,0,0,Math.PI*2);ctx.fill();ctx.restore();
 };
 cloud(width*.15,horizon*.58,.8);cloud(width*.51,horizon*.38,1.05);cloud(width*.84,horizon*.59,.72);cloud(width*.72,horizon*.57,.68);
 ctx.fillStyle='#a8d584';ctx.beginPath();ctx.moveTo(0,horizon);ctx.lineTo(0,horizon-8);
 ctx.bezierCurveTo(width*.16,horizon-25,width*.24,horizon-2,width*.42,horizon-10);
 ctx.bezierCurveTo(width*.64,horizon-28,width*.8,horizon-10,width,horizon-18);
 ctx.lineTo(width,horizon);ctx.closePath();ctx.fill();
 // A meadow-colored feather merges the distant bank into the projected ground.
 const meadow=ctx.createLinearGradient(0,horizon-1,0,horizon+24);meadow.addColorStop(0,'#a8d584');meadow.addColorStop(1,'#a8d58400');ctx.fillStyle=meadow;ctx.fillRect(0,horizon-1,width,25);
}
