import {describe,it,expect} from 'vitest';
import {centerStageView} from './center-stage';
import {mountThreeCenterGuide,centerPoints} from './three-centers-guide';
import {createModelWorld,modelScene} from './model-world';
import {saveCenterProgress,CENTER_STATIONS} from '../data/three-centers';
import {BUILDING_MATERIALS} from './campus-materials';
describe('visible three-center stage progression',()=>{
 it('starts at the first stage and guides discovery before questions',()=>{
  const p={discovered:[],completed:[]} as any;
  expect(centerStageView(p).states).toEqual(['current','locked','locked']);
  expect(centerStageView(p).action).toBe('navigate');
  expect(centerStageView(p,'incenter').action).toBe('discover');
  expect(centerStageView({...p,discovered:['incenter']},'incenter').action).toBe('challenge');
 });
 it('advances only the active stage and shows completion distinctly',()=>{
  const p={discovered:['incenter'],completed:['incenter']} as any;
  expect(centerStageView(p).states).toEqual(['done','current','locked']);
  expect(centerStageView(p,'incenter').action).toBe('navigate');
  const done=centerStageView({discovered:['incenter','centroid','circumcenter'],completed:['incenter','centroid','circumcenter']});
  expect(done.states).toEqual(['done','done','done']);expect(done.action).toBe('review');expect(done.index).toBe(3);
 });
});

describe('stage tracker integration',()=>{
 it('covers all buildings with stable distinct colors',()=>{
  const world=createModelWorld(1);
  expect(Object.keys(BUILDING_MATERIALS).sort()).toEqual(world.source.buildings.map(b=>b.id).sort());
  expect(new Set(Object.values(BUILDING_MATERIALS).map(m=>m.accent)).size).toBe(11);
 });
 it('navigates, discovers and updates completed stages using actual world stations',()=>{
  document.body.innerHTML='<div class="explore-toolbar"><button id="quest-start"></button></div><section id="exploration"></section><div id="dialogue" hidden><p></p></div>';
  saveCenterProgress({discovered:[],completed:[]});
  const model=createModelWorld(1);let map=model.maps.campus,player={...map.spawns.entry};
  const routes:string[]=[];const handler=(e:Event)=>routes.push((e as CustomEvent).detail.stationId);
  window.addEventListener('campus:three-centers-navigate',handler);
  let opened:string|undefined;
  const guide=mountThreeCenterGuide({read:()=>({model,map,player}),open:async id=>{opened=id;},pause:()=>{},redraw:()=>{}});
  guide.syncMarkers();const tracker=document.getElementById('center-stage-tracker')!;
  expect(tracker.querySelectorAll('.stage-badge')).toHaveLength(3);expect(tracker.querySelector('[aria-current=step] .stage-badge')!.textContent).toBe('01');expect(tracker.querySelector('.center-phase-flow')!.textContent).toContain('找線索');
  (tracker.querySelector('button') as HTMLButtonElement).click();expect(routes).toEqual(['incenter']);
  map=model.maps[modelScene('tech-building',1)];player={...player,...centerPoints(model,map)[0].point};guide.syncMarkers();
  expect(tracker.textContent).toContain('已抵達');(tracker.querySelector('button') as HTMLButtonElement).click();
  expect(document.getElementById('dialogue')!.hidden).toBe(false);guide.syncMarkers();
  expect(tracker.textContent).toContain('線索已找到');(tracker.querySelector('button') as HTMLButtonElement).click();expect(opened).toBe('incenter');
  saveCenterProgress({discovered:['incenter'],completed:['incenter']});guide.syncMarkers();expect(tracker.textContent).toContain('第 2 階段');
  const ids=CENTER_STATIONS.map(s=>s.id);saveCenterProgress({discovered:ids,completed:ids});guide.syncMarkers();expect(tracker.textContent).toContain('全部完成');
  window.removeEventListener('campus:three-centers-navigate',handler);
 });
});
