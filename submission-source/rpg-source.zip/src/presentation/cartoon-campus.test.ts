import {nearestPortal} from './portal-target';
import {describe,it,expect} from 'vitest';
import {outdoorBuildingPoint,outdoorBuildingRect,CARTOON_CAMPUS} from './cartoon-layout';
import {createModelWorld,modelMapInfo} from './model-world';
import {walkable,canReach} from './navigation';
import {cartoonBuildingHeight,cartoonBuildingOccludes,cartoonBuildingScreenPoints} from './cartoon-renderer';
import {unprojectIso} from './model-world';
describe('spacious cartoon exterior with original interior rooms',()=>{
 it('preserves building centers and aspects but opens real space between building exteriors',()=>{
  const w=createModelWorld(1);for(const b of w.source.buildings){const r=outdoorBuildingRect(b,b.bounds),center={x:(b.bounds.x0+b.bounds.x1)/2,z:(b.bounds.z0+b.bounds.z1)/2};expect((r.x0+r.x1)/2).toBeCloseTo(center.x);expect((r.z0+r.z1)/2).toBeCloseTo(center.z);expect(r.x1-r.x0).toBeCloseTo((b.bounds.x1-b.bounds.x0)*CARTOON_CAMPUS.buildingFootprintScale);expect(outdoorBuildingPoint(b,center)).toEqual(center);}
  const tech=w.source.buildings.find(b=>b.id==='tech-building')!,art=w.source.buildings.find(b=>b.id==='art-building')!;
  expect(outdoorBuildingRect(art,art.bounds).z0-outdoorBuildingRect(tech,tech.bounds).z1).toBeGreaterThan(8);
 });
 it('uses the compact footprint for collision and keeps every outdoor entrance reachable at all scales',()=>{
  for(const scale of [1,1.5,2]){const w=createModelWorld(scale),map=w.maps.campus,t=w.transforms.campus;
   for(const b of w.source.buildings)for(const f of b.footprints.filter(f=>f.floor===1)){const r=t.rect(outdoorBuildingRect(b,f.rect));expect(map.collisionZones).toContainEqual(r);expect(modelMapInfo(map)!.structures.some(s=>JSON.stringify(s.rect)===JSON.stringify(r))).toBe(true);}
   for(const p of map.portals){const goal={x:p.trigger.x+22,y:p.trigger.y+22};expect(walkable(goal,map)).toBe(true);expect(canReach(map.spawns['campus-start'],goal,map),p.id).toBe(true);}
  }
 });
 it('selects each outdoor entrance at its own marker even when interaction ranges overlap',()=>{for(const scale of [1,1.5,2]){const map=createModelWorld(scale).maps.campus;for(const p of map.portals){const player={x:p.trigger.x+p.trigger.width/2,y:p.trigger.y+p.trigger.height/2};expect(nearestPortal(map,player,60)?.id,p.id).toBe(p.id);}}});
 it('keeps low cartoon roofs visible and uses their own envelope for occlusion',()=>{
  const r={x:1000,y:2000,width:300,height:170},h=260,points=cartoonBuildingScreenPoints(r,h,16),tip=points.reduce((a,b)=>a.y<b.y?a:b);expect(cartoonBuildingHeight(h,16)).toBeLessThan(h*.4);
  expect(cartoonBuildingOccludes(r,h,16,unprojectIso({x:tip.x,y:tip.y+1}),1)).toBe(true);expect(cartoonBuildingOccludes(r,h,16,{x:1600,y:2600},1)).toBe(false);
 });
});
