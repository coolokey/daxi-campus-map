import { expect, it, vi } from 'vitest';
import { mountCampusDirectory } from './campus-directory';
import type { MapConfig } from '../game/data/types';
it('a custom minimap target cancels the old directory goal across scene refreshes',()=>{
  document.body.innerHTML='<div class="explore-toolbar"></div>';
  let map:MapConfig={id:'campus',width:500,height:500,backgroundKey:'test',collisionZones:[],npcs:[],spawns:{},portals:[{id:'building-entry:art-building',mapId:'campus',trigger:{x:300,y:300,width:36,height:36},destinationMapId:'floor-art-building-1',destinationSpawnId:'entry',prompt:'E'}]};
  mountCampusDirectory(()=>({state:{map,player:{x:50,y:50,direction:'up'}}}));
  const dialog=document.querySelector('dialog')!;dialog.showModal=()=>{};dialog.close=()=>{};
  (document.querySelector('#campus-directory-open') as HTMLButtonElement).click();
  const select=document.querySelector('select')!;select.value='art-building';select.dispatchEvent(new Event('change'));
  expect(document.querySelectorAll('.directory-plan-tabs button').length).toBe(6);
  expect((document.querySelector('.directory-plan-link') as HTMLAnchorElement)?.href).toContain('floor-plans/');
  const observe=vi.fn();window.addEventListener('campus:navigation-route',observe);
  (document.querySelector('.directory-rooms button') as HTMLButtonElement).click();expect(observe).toHaveBeenCalledTimes(1);
  window.dispatchEvent(new CustomEvent('campus:navigation-route',{detail:{mapId:'campus',points:[{x:50,y:50},{x:100,y:100}],label:'自訂目標'}}));
  map={...map};window.dispatchEvent(new CustomEvent('campus:snapshot',{detail:{map}}));
  expect(observe).toHaveBeenCalledTimes(2);window.removeEventListener('campus:navigation-route',observe);document.body.innerHTML='';
});
