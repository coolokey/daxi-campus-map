import {athleticsLayout as A,lanePoint,laneStarts} from './athletics-garden';
import {campusModel,modelTransform,projectIso} from './model-world';
import type {BoundaryObject} from './boundary-renderer';
type C={x:number;z:number};type P={x:number;y:number};
const sprites=new Map<string,HTMLCanvasElement>();
function foliage(kind:string,variant:number){
 const key=kind+variant,saved=sprites.get(key);if(saved)return saved;
 const cv=document.createElement('canvas');cv.width=160;cv.height=144;const c=cv.getContext('2d')!;
 c.fillStyle='#36583233';c.beginPath();c.ellipse(80,123,60,13,0,0,Math.PI*2);c.fill();
 const petals=['#d9a0be','#f3dfa0','#b6b4df','#f0c3b1'];
 if(kind==='shrub'){
  for(const [x,y,r] of [[49,91,34],[104,88,35],[77,64,39],[78,99,38]]){const g=c.createRadialGradient(x-10,y-15,3,x,y,r);g.addColorStop(0,'#abc877');g.addColorStop(.55,'#7ca45c');g.addColorStop(1,'#4f7e49');c.fillStyle=g;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();}
  for(let i=0;i<22;i++){const x=39+(i*37+variant*11)%86,y=45+(i*23)%58;c.fillStyle=petals[variant];for(let k=0;k<5;k++){const a=k*Math.PI*2/5;c.beginPath();c.arc(x+Math.cos(a)*4,y+Math.sin(a)*4,3.8,0,Math.PI*2);c.fill();}c.fillStyle='#f8edb3';c.beginPath();c.arc(x,y,2,0,Math.PI*2);c.fill();}
 }else for(let i=0;i<22;i++){
  const x=24+(i*37+variant*13)%110,y=112+(i*7)%12,h=24+(i*19)%53;
  c.strokeStyle=i%2?'#82a95b':'#b6c97c';c.lineWidth=2.6;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x-4,y-h*.7,x+(i%2?12:-12),y-h);c.stroke();
  if(kind==='flowers'&&i%2===0){const xx=x+(i%2?12:-12),yy=y-h;c.fillStyle=petals[(variant+i)%4];for(let k=0;k<5;k++){const a=k*Math.PI*2/5;c.beginPath();c.arc(xx+Math.cos(a)*4.7,yy+Math.sin(a)*4.7,4.5,0,Math.PI*2);c.fill();}c.fillStyle='#d5aa52';c.beginPath();c.arc(xx,yy,2.5,0,Math.PI*2);c.fill();}
  if(kind==='grass'&&i%3===0){c.strokeStyle='#dac798';c.lineWidth=4;c.beginPath();c.moveTo(x+(i%2?12:-12),y-h);c.lineTo(x+(i%2?14:-14),y-h-13);c.stroke();}
 }
 sprites.set(key,cv);return cv;
}
/** Source-sized athletics marking overlay and low-poly garden. Ground precedes actor depth sorting. */
export function athleticsScene(ctx:CanvasRenderingContext2D,unit:number,u:number):BoundaryObject[]{
 const t=modelTransform({x:-162,z:-90},unit),tr=campusModel.outdoor.track,objects:BoundaryObject[]=[],m=ctx.getTransform();
 const p=(q:C,h=0)=>{const a=projectIso(t.toGame(q));return{x:a.x,y:a.y-h*unit*.85};};
 const poly=(ps:P[],color:string,stroke?:string)=>{ctx.beginPath();ps.forEach((q,i)=>i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y));ctx.closePath();ctx.fillStyle=color;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=u;ctx.stroke();}};
 const line=(a:P,b:P,color='#fff8e5',w=1.5)=>{ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=color;ctx.lineWidth=w*u;ctx.stroke();};
 const rect=(r:{x0:number;x1:number;z0:number;z1:number},h=0)=>[{x:r.x0,z:r.z0},{x:r.x1,z:r.z0},{x:r.x1,z:r.z1},{x:r.x0,z:r.z1}].map(q=>p(q,h));
 const box=(r:{x0:number;x1:number;z0:number;z1:number},h:number,top:string,front:string)=>{const a=rect(r),b=rect(r,h);poly([b[1],b[2],a[2],a[1]],front);poly([b[2],b[3],a[3],a[2]],front);poly(b,top,'#67775b');};
 const text=(q:C,title:string,height=0,size=10,color='#fff9e7')=>{const a=p(q,height);ctx.save();ctx.font=`bold ${size*u}px system-ui`;ctx.textAlign='center';ctx.fillStyle=color;ctx.fillText(title,a.x,a.y);ctx.restore();};
 const visible=(q:P,w:number,h:number)=>{const x=m.a*q.x+m.c*q.y+m.e,y=m.b*q.x+m.d*q.y+m.f,s=Math.max(Math.abs(m.a),Math.abs(m.d));return x+w*s>0&&x-w*s<ctx.canvas.width&&y+w*s>0&&y-h*s<ctx.canvas.height;};
 // Six equal lanes, including inner and outer boundaries. No distance certification is implied.
 const lw=(tr.outerRadius-tr.innerRadius)/6;
 for(let i=0;i<=6;i++){const r=tr.innerRadius+i*lw,total=tr.halfStraight*4+2*Math.PI*r;ctx.beginPath();for(let k=0;k<=180;k++){const q=p(lanePoint(tr,r,total*k/180));k?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y);}ctx.closePath();ctx.strokeStyle='#fff4d9';ctx.lineWidth=(i===0||i===6?1.7:1.1)*u;ctx.stroke();}
 const finishX=tr.x-tr.halfStraight+3,sprintStartX=tr.x+tr.halfStraight-2;
 line(p({x:finishX,z:tr.z+tr.innerRadius}),p({x:finishX,z:tr.z+tr.outerRadius}),'#fffef2',3);
 line(p({x:sprintStartX,z:tr.z+tr.innerRadius}),p({x:sprintStartX,z:tr.z+tr.outerRadius}),'#fffef2',2);
 for(let i=0;i<6;i++){
  const r=tr.innerRadius+(i+.5)*lw;
  text({x:finishX-2.5,z:tr.z+r},String(i+1),0,11);
  const s=laneStarts(tr)[i],cx=Math.max(tr.x-tr.halfStraight,Math.min(tr.x+tr.halfStraight,s.x)),nx=(s.x-cx)/r,nz=(s.z-tr.z)/r;
  const a=p({x:s.x-nx*lw*.44,z:s.z-nz*lw*.44}),b=p({x:s.x+nx*lw*.44,z:s.z+nz*lw*.44});line(a,b,'#fffefa',2.5);
  const dir=p(lanePoint(tr,r,s.distance+2));poly([a,b,dir],'#f4e0a66b');
  // Exchange zone brackets on the far straight, with restrained blue/yellow lane ticks.
  for(const x of [tr.x-tr.halfStraight+12,tr.x-tr.halfStraight+23])line(p({x,z:tr.z-r+lw*.35}),p({x,z:tr.z-r-lw*.35}),i%2?'#f7db83':'#98d6d5',2.4);
  const arrow=lanePoint(tr,r,18),nose=p({x:arrow.x-1.3,z:arrow.z});line(p({x:arrow.x+1,z:arrow.z}),nose,'#f9f0d0',1.6);line(nose,p({x:arrow.x-.3,z:arrow.z-.3}));line(nose,p({x:arrow.x-.3,z:arrow.z+.3}));
 }
 text({x:finishX,z:tr.z+tr.outerRadius+1.4},'終點 FINISH',0,10,'#795947');
 text({x:sprintStartX,z:tr.z+tr.outerRadius+1.4},'短跑起點',0,10,'#795947');
 // Long-jump run-up and low white take-off board are walkable ground paint.
 poly(rect({x0:-121,x1:-106,z0:-14,z1:-12}),'#c79872');
 poly(rect({x0:-107.5,x1:-107,z0:-14,z1:-12}),'#faf4e2');
 for(let i=0;i<5;i++)line(p({x:-120+i*2.6,z:-14}),p({x:-120+i*2.6,z:-13.7}),'#eee4c5',1);
 for(const plant of A.plants){const foot=t.toGame(plant),q=projectIso(foot),w=unit*(plant.kind==='shrub'?4.4:2.8),h=unit*(plant.kind==='shrub'?3.8:2.1);if(!visible(q,w,h))continue;objects.push({depth:foot.x+foot.y,draw:()=>{ctx.save();ctx.drawImage(foliage(plant.kind,plant.variant),q.x-w/2,q.y-h*.86,w,h);ctx.restore();}});}
 for(const e of A.equipment){const r=e.rect,q={x:(r.x0+r.x1)/2,z:(r.z0+r.z1)/2},foot=t.toGame(q);if(!visible(p(q),unit*10,unit*6))continue;
  if(e.kind==='sand'){poly(rect(r),'#d8bf86','#ab996c');for(let i=0;i<18;i++){const x=r.x0+.5+(i*1.7)%(r.x1-r.x0-1),z=r.z0+.4+(i*.7)%(r.z1-r.z0-.8);line(p({x,z}),p({x:x+.5,z:z+.1}),'#bea477',.8);}}
  objects.push({depth:foot.x+foot.y,draw:()=>{ctx.save();
   if(e.kind==='mat'){box(r,.65,'#82b9d0','#4f8fac');line(p({x:r.x0,z:r.z0},.66),p({x:r.x1,z:r.z1},.66),'#b8d9df');for(const x of [r.x0-.3,r.x1+.3])line(p({x,z:r.z0}),p({x,z:r.z0},2.5),'#e7e3cb',3);line(p({x:r.x0-.3,z:r.z0},2.1),p({x:r.x1+.3,z:r.z0},2.1),'#e9b778',2.4);}
   if(e.kind==='hurdle'){for(const z of [r.z0,r.z1]){line(p({x:q.x-.55,z}),p({x:q.x+.55,z}),'#577e94',3);line(p({x:q.x,z}),p({x:q.x,z},1.3),'#f3ead4',2.6);}line(p({x:q.x,z:r.z0},1.3),p({x:q.x,z:r.z1},1.3),'#f4e4ca',5);line(p({x:q.x,z:q.z-.5},1.3),p({x:q.x,z:q.z+.5},1.3),'#db795f',5);}
   if(e.kind==='sand'){for(const x of [r.x0,r.x1])line(p({x,z:r.z0}),p({x,z:r.z1}),'#98764d',3);text({x:q.x,z:r.z1+.7},'跳遠沙坑',0,9,'#6d7053');}
   if(e.kind==='timing'){box(r,.8,'#d9cbaa','#928466');for(const x of [r.x0+.2,r.x1-.2])line(p({x,z:q.z}),p({x,z:q.z},3.1),'#a58a67',2.5);poly(rect({x0:r.x0-.4,x1:r.x1+.4,z0:r.z0-.3,z1:r.z1+.3},3.2),'#e9c781','#a18e64');text(q,'田徑・計時',2.1,10,'#4e6548');}
   if(e.kind==='rack'){box(r,.65,'#c9bb92','#8f865f');for(let i=0;i<5;i++){const x=r.x0+.45+i*.65;line(p({x,z:q.z},.7),p({x:x+.6,z:q.z-1.1},1.5),['#ba7b64','#d4b459','#6599a4'][i%3],4);}text({x:q.x,z:r.z1+.8},'器材收納',0,9,'#5d7150');}
   ctx.restore();}});
 }
 // Small event bunting stays beside equipment, with clear ground beneath.
 for(const z of [-40,-19]){const a={x:-85,z},b={x:-73,z};for(const q of [a,b])objects.push({depth:t.toGame(q).x+t.toGame(q).y,draw:()=>line(p(q),p(q,2.4),'#9b8d69',2)});const mid=t.toGame({x:-79,z});objects.push({depth:mid.x+mid.y,draw:()=>{line(p(a,2.3),p(b,2.3),'#938365',1);for(let i=0;i<8;i++){const x=a.x+.4+i*1.4;poly([p({x,z},2.3),p({x:x+1,z},2.3),p({x:x+.5,z},1.5)],['#d8957c','#e9cf86','#96b8aa'][i%3]);}}});}
 return objects;
}
