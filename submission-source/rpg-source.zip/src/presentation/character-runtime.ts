export type Character = {id:string;name:string;role:'teacher'|'student'|'guard'|'player'|'robot';title?:string;destination?:string;appearance:Record<string,unknown>|string;appearanceStatus:'source'|'generic';atlas:string};
export type Point = {x:number;y:number};
export type WalkMap = {width:number;height:number;collisionZones:{x:number;y:number;width:number;height:number}[]};
export const DIRECTIONS=['down','down-left','left','up-left','up','up-right','right','down-right'] as const;
export type Facing=typeof DIRECTIONS[number];
export function searchRoster(roster:Character[],query:string):Character[]{
  const q=query.trim().toLocaleLowerCase();
  return roster.filter(c=>`${c.id} ${c.name} ${c.title??''} ${c.destination??''}`.toLocaleLowerCase().includes(q));
}
export function chooseRoster(roster:Character[],role:Character['role'],page:number,cap:number,invited:string[]=[]):Character[]{
  const list=roster.filter(c=>c.role===role), result:Character[]=[];
  const add=(c:Character|undefined)=>{if(c&&result.length<cap&&!result.some(r=>r.id===c.id))result.push(c);};
  invited.forEach(id=>add(list.find(c=>c.id===id)));
  for(let i=0;i<list.length;i++)add(list[(Math.max(0,page)*cap+i)%list.length]);
  return result;
}
export function validateRoute(points:Point[],map:WalkMap):boolean{
  const safe=(p:Point)=>Number.isFinite(p.x)&&Number.isFinite(p.y)&&p.x>=11&&p.y>=11&&p.x<=map.width-11&&p.y<=map.height-11&&!map.collisionZones.some(r=>p.x+11>r.x&&p.x-11<r.x+r.width&&p.y+11>r.y&&p.y-11<r.y+r.height);
  if(!points.length)return false;
  return points.every((p,i)=>{
    const end=points[(i+1)%points.length],count=Math.ceil(Math.hypot(end.x-p.x,end.y-p.y)/5);
    if(!safe(p))return false;
    for(let n=1;n<=count;n++)if(!safe({x:p.x+(end.x-p.x)*n/count,y:p.y+(end.y-p.y)*n/count}))return false;
    return true;
  });
}
export function actorFrame(previous:Point,current:Point,time:number,facing:Facing='down'){
  const dx=current.x-previous.x,dy=current.y-previous.y,moving=Math.hypot(dx,dy)>.05;
  const column=moving?(Math.round(Math.atan2(-dx,dy)/(Math.PI/4))+8)%8:DIRECTIONS.indexOf(facing);
  return {direction:DIRECTIONS[column],column,row:moving?1+Math.floor(time/170)%2:0,moving};
}
export function validateRegistry(value:unknown):{characters:Character[];anchor:Point}{
  const data=value as {anchor?:Point;tile?:{width:number;height:number;columns:number;rows:number};directions?:string[];characters?:Character[]};
  if(data?.tile?.width!==64||data.tile.height!==88||data.tile.columns!==8||data.tile.rows!==3||JSON.stringify(data.directions)!==JSON.stringify(DIRECTIONS)||!Array.isArray(data.characters))throw new Error('角色圖集契約不相容');
  const ids=new Set<string>();
  for(const c of data.characters){
    if(ids.has(c.id))throw new Error('角色名冊 ID 重複');
    if(!c.id||!c.name||!['teacher','student','guard','player','robot'].includes(c.role)||!/^assets\/[\w./-]+\.png$/.test(c.atlas)||c.atlas.includes('..'))throw new Error('角色圖集或名冊格式錯誤');
    ids.add(c.id);
  }
  const anchor=data.anchor??{x:32,y:77.0177039725223};
  if(!Number.isFinite(anchor.x)||!Number.isFinite(anchor.y)||anchor.x<0||anchor.x>64||anchor.y<0||anchor.y>88)throw new Error('角色腳底錨點錯誤');
  return {characters:data.characters,anchor};
}
