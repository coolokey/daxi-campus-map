import type {Rect} from '../game/data/types';
import {projectIso} from './model-world';
import {buildingMaterial} from './campus-materials';
type P={x:number;y:number};type V=P&{z:number};
/** A roof is overhead artwork; it never expands the ground-level collision footprint. */
export function woodRoofGeometry(r:Rect,height:number,worldUnit:number){
 const overhang=worldUnit*.7,rise=Math.min(worldUnit*2.4,Math.min(r.width,r.height)*.24),eave=height+worldUnit*.1;
 const corners=[{x:r.x-overhang,y:r.y-overhang,z:eave},{x:r.x+r.width+overhang,y:r.y-overhang,z:eave},{x:r.x+r.width+overhang,y:r.y+r.height+overhang,z:eave},{x:r.x-overhang,y:r.y+r.height+overhang,z:eave}];
 const alongX=r.width>=r.height,inset=Math.min(r.width,r.height)*.42;
 const ridge:V[]=alongX?[{x:r.x+inset,y:r.y+r.height/2,z:eave+rise},{x:r.x+r.width-inset,y:r.y+r.height/2,z:eave+rise}]:[{x:r.x+r.width/2,y:r.y+inset,z:eave+rise},{x:r.x+r.width/2,y:r.y+r.height-inset,z:eave+rise}];
 const [a,b,c,d]=corners,[p,q]=ridge;
 const faces=alongX?[[a,b,q,p],[b,c,q],[c,d,p,q],[d,a,p]]:[[a,b,p],[b,c,q,p],[c,d,q],[d,a,p,q]];
 return {corners,ridge,faces,rise,eave};
}
export function woodBuildingScreenPoints(r:Rect,height:number,worldUnit:number){
 const roof=woodRoofGeometry(r,height,worldUnit);
 return [...roof.faces.flat().map(p=>{const q=projectIso(p);return {x:q.x,y:q.y-p.z};}),...[
  {x:r.x,y:r.y},{x:r.x+r.width,y:r.y},{x:r.x+r.width,y:r.y+r.height},{x:r.x,y:r.y+r.height}
 ].map(projectIso)];
}
export function woodBuildingOccludes(r:Rect,height:number,worldUnit:number,player:P,actorUnit:number){
 if(player.x+player.y>=r.x+r.y+r.width+r.height)return false;
 const points=woodBuildingScreenPoints(r,height,worldUnit),foot=projectIso(player);
 return foot.x>Math.min(...points.map(p=>p.x))-22*actorUnit&&foot.x<Math.max(...points.map(p=>p.x))+22*actorUnit&&foot.y>Math.min(...points.map(p=>p.y))&&foot.y-50*actorUnit<Math.max(...points.map(p=>p.y));
}
export function paintWoodBuilding(ctx:CanvasRenderingContext2D,r:Rect,height:number,worldUnit:number,u:number,id:string){
 const m=buildingMaterial(id),roof=woodRoofGeometry(r,height,worldUnit),camera=ctx.getTransform();
 const screen=(p:V)=>{const q=projectIso(p);q.y-=p.z;return q;},bounds=woodBuildingScreenPoints(r,height,worldUnit).map(p=>({x:camera.a*p.x+camera.c*p.y+camera.e,y:camera.b*p.x+camera.d*p.y+camera.f}));
 if(Math.max(...bounds.map(p=>p.x))<-64||Math.min(...bounds.map(p=>p.x))>ctx.canvas.width+64||Math.max(...bounds.map(p=>p.y))<-64||Math.min(...bounds.map(p=>p.y))>ctx.canvas.height+64)return false;
 ctx.save();
 const poly=(pts:P[],fill:string,stroke?:string)=>{ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=u;ctx.stroke();}};
 const line=(a:P,b:P,color:string,width=1)=>{ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=color;ctx.lineWidth=width*u;ctx.stroke();};
 const c=[{x:r.x,y:r.y},{x:r.x+r.width,y:r.y},{x:r.x+r.width,y:r.y+r.height},{x:r.x,y:r.y+r.height}].map(projectIso);
 const floorHeight=worldUnit*5.4;
 for(const [index,a,b] of [[0,c[1],c[2]],[1,c[2],c[3]]] as const){
  const at=(t:number,z:number)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t-z});
  poly([at(0,0),at(1,0),at(1,height),at(0,height)],index?m.side:m.wall,m.woodDark);
  poly([at(0,0),at(1,0),at(1,worldUnit*.65),at(0,worldUnit*.65)],'#b2a58d');
  const bays=Math.max(2,Math.round(Math.hypot(b.x-a.x,b.y-a.y)/(worldUnit*2.3)));
  for(let z=worldUnit*.9;z<height-worldUnit*.7;z+=floorHeight){
   const topZ=Math.min(z+worldUnit*1.9,height-worldUnit*.6);
   for(let i=0;i<bays;i++){
    const left=(i+.17)/bays,right=(i+.83)/bays;
    poly([at(left,z),at(right,z),at(right,topZ),at(left,topZ)],index?'#889d92':m.glass,m.wood);
    for(const fraction of [.33,.66])line(at(left+(right-left)*fraction,z),at(left+(right-left)*fraction,topZ),m.wood,1.5);
    line(at(left,(z+topZ)/2),at(right,(z+topZ)/2),m.wood,1.2);
    // Individual timber lintels and sills create depth without projecting into walking space.
    line(at(left-.025/bays,topZ+worldUnit*.12),at(right+.025/bays,topZ+worldUnit*.12),m.woodDark,2);
    line(at(left,z-worldUnit*.1),at(right,z-worldUnit*.1),'#ad9673',2);
   }
   const beam=Math.min(z+worldUnit*2.55,height-worldUnit*.1);
   line(at(0,beam),at(1,beam),m.woodDark,3);line(at(0,beam+worldUnit*.14),at(1,beam+worldUnit*.14),'#c5ad83',1);
  }
  for(let i=0;i<=bays;i+=Math.max(1,Math.round(bays/9)))line(at(i/bays,worldUnit*.65),at(i/bays,height),m.wood,2);
  line(at(0,worldUnit*.7),at(1,worldUnit*.7),m.accent,3);
  if(m.entry==='old-street'){
   // Brick-and-plaster pediment decorates the existing facade, not a new freestanding obstacle.
   const lo=.39,hi=.61,w=(hi-lo)*Math.hypot(b.x-a.x,b.y-a.y),cap=Math.min(worldUnit*2.6,w*.32),base=height-floorHeight*.6;
   poly([at(lo,base),at(hi,base),at(hi,base+cap*.45),at(.5,base+cap),at(lo,base+cap*.45)],m.brick,'#f1e1c3');
   line(at(lo,base+cap*.45),at(.5,base+cap),'#e8d7b6',2);line(at(.5,base+cap),at(hi,base+cap*.45),'#e8d7b6',2);
   const center=at(.5,base+cap*.4);ctx.fillStyle=m.accent;ctx.beginPath();ctx.arc(center.x,center.y,Math.min(cap*.15,7*u),0,Math.PI*2);ctx.fill();
  }
 }
 // Hipped gray-tile roof with a broad timber fascia; no solar box or flat colored cap.
 const colors=[m.roofLight,m.roofShade,m.roof,m.roofShade];
 roof.faces.forEach((face,index)=>{
  const pts=face.map(screen);poly(pts,colors[index],m.woodDark);
  const [a,b]=pts,leftTop=pts[pts.length-1],rightTop=pts.length===4?pts[2]:leftTop;
  for(let row=1;row<5;row++){const t=row/5;line({x:a.x+(leftTop.x-a.x)*t,y:a.y+(leftTop.y-a.y)*t},{x:b.x+(rightTop.x-b.x)*t,y:b.y+(rightTop.y-b.y)*t},'#a2aa96',.7);}
  const columns=Math.max(3,Math.min(22,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/(worldUnit*.7))));
  for(let j=1;j<columns;j++){const t=j/columns;line({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t},{x:leftTop.x+(rightTop.x-leftTop.x)*t,y:leftTop.y+(rightTop.y-leftTop.y)*t},'#4b594f',.6);}
 });
 for(let i=0;i<4;i++){const a=screen(roof.corners[i]),b=screen(roof.corners[(i+1)%4]);line({x:a.x,y:a.y+worldUnit*.2},{x:b.x,y:b.y+worldUnit*.2},m.woodDark,3);line(a,b,'#b7b59e',1);}
 line(screen(roof.ridge[0]),screen(roof.ridge[1]),'#c2bfaa',3);
 ctx.restore();return true;
}

export function paintWoodBench(ctx:CanvasRenderingContext2D,r:Rect,axis:string,worldUnit:number,u:number){
 const q=[{x:r.x,y:r.y},{x:r.x+r.width,y:r.y},{x:r.x+r.width,y:r.y+r.height},{x:r.x,y:r.y+r.height}].map(projectIso),seat=worldUnit*.65,back=worldUnit*1.4;
 const poly=(points:P[],fill:string)=>{ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();ctx.strokeStyle='#634c36';ctx.lineWidth=u;ctx.stroke();};
 const lift=(p:P,z:number)=>({x:p.x,y:p.y-z});
 ctx.save();
 for(const i of [0,1,2,3]){ctx.fillStyle='#665d47';ctx.fillRect(q[i].x-2*u,q[i].y-seat,4*u,seat);}
 poly(q.map(p=>lift(p,seat)),'#aa8153');const [a,b]=axis==='x'?[q[0],q[1]]:[q[0],q[3]];poly([lift(a,seat),lift(b,seat),lift(b,back),lift(a,back)],'#936d48');
 ctx.strokeStyle='#c6a16e';ctx.lineWidth=u;ctx.beginPath();ctx.moveTo(a.x,a.y-(seat+back)/2);ctx.lineTo(b.x,b.y-(seat+back)/2);ctx.stroke();ctx.restore();
}
