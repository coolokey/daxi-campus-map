import config from '../../public/data/cartoon-campus-v1.json';
import type {ModelBuilding} from './model-world';
type C={x:number;z:number};type R={x0:number;x1:number;z0:number;z1:number};
export const CARTOON_CAMPUS=config;
/** One transform per building preserves wings, aspect, orientation and the source center. */
export function outdoorBuildingPoint(b:ModelBuilding,p:C):C{const cx=(b.bounds.x0+b.bounds.x1)/2,cz=(b.bounds.z0+b.bounds.z1)/2,k=config.buildingFootprintScale;return {x:cx+(p.x-cx)*k,z:cz+(p.z-cz)*k};}
export function outdoorBuildingRect(b:ModelBuilding,r:R):R{const a=outdoorBuildingPoint(b,{x:r.x0,z:r.z0}),z=outdoorBuildingPoint(b,{x:r.x1,z:r.z1});return {x0:a.x,x1:z.x,z0:a.z,z1:z.z};}
