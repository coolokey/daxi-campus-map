import type { MapConfig, Rect, SpawnPoint } from '../game/data/types';
export type Canonical = {x:number;z:number;height:number};
export type Bounds = {x0:number;x1:number;z0:number;z1:number};
export type RuntimeNode = {id:string;position:Canonical;buildingId:string|null;level:number|null};
export type Volume = {buildingId:string|null;minX:number;maxX:number;minZ:number;maxZ:number;minHeight:number;maxHeight:number};
export type Room = {id:string;buildingId:string;floorId:string;name:string;rect:Bounds;center:Canonical;door:Canonical;sourceAliases:string[]};
export type Floor = {id:string;buildingId:string;level:number;elevation:number;footprints:Bounds[];corridors:Bounds[];holes:Bounds[]};
export type Entrance = {id:string;buildingId:string;inside:Canonical;outside:Canonical};
export type SharedCampus = {buildings:{id:string;name:string;bounds:Bounds}[];rooms:Room[];floors:Floor[];entrances:Entrance[];stairs:{id:string;buildingId:string;rect:Bounds;name:string}[]};
export type RuntimeCampus = {navigation:{nodes:RuntimeNode[];gateNodeId:string};collisionVolumes:Volume[];pilotRoute:{nodeIds:string[];targetSourceRoomId:string}};
export type PilotId = 'pilot-outdoor'|'pilot-tech-1'|'pilot-tech-2';
const PIXELS_PER_UNIT=48;
/** One reversible canonical → game transform. Height selects a scene; it never becomes screen y. */
export function createTransform(origin:{x:number;z:number},scale:number) {
  const unit=PIXELS_PER_UNIT*scale;
  return {origin,unit,toGame:(p:{x:number;z:number})=>({x:(p.x-origin.x)*unit,y:(p.z-origin.z)*unit}),
    fromGame:(p:{x:number;y:number},height=0):Canonical=>({x:p.x/unit+origin.x,z:p.y/unit+origin.z,height}),
    rect:(b:Bounds):Rect=>({x:(b.x0-origin.x)*unit,y:(b.z0-origin.z)*unit,width:(b.x1-b.x0)*unit,height:(b.z1-b.z0)*unit})};
}
export const blocksFloor=(v:Volume,height:number)=>v.maxHeight>height+0.08 && v.minHeight<height+1.65;
/** Same fixed 11px foot collision contract as movePlayer, including a safe indoor fallback. */
export function safePilotPosition(point:{x:number;y:number},map:MapConfig):{x:number;y:number} {
  const valid=(p:{x:number;y:number})=>p.x>=11&&p.y>=11&&p.x<=map.width-11&&p.y<=map.height-11&&!map.collisionZones.some(r=>p.x+11>r.x&&p.x-11<r.x+r.width&&p.y+11>r.y&&p.y-11<r.y+r.height);
  if(valid(point))return point;
  for(let radius=2;radius<=144;radius+=2)for(let angle=0;angle<32;angle++){
    const p={x:point.x+Math.cos(angle*Math.PI/16)*radius,y:point.y+Math.sin(angle*Math.PI/16)*radius};if(valid(p))return p;
  }
  const fallback=Object.values(map.spawns).find(valid);if(fallback)return {x:fallback.x,y:fallback.y};
  throw new Error(`No safe spawn in ${map.id}`);
}
export function createPilot(shared:SharedCampus,runtime:RuntimeCampus,scale:number) {
  const nodes=new Map(runtime.navigation.nodes.map(n=>[n.id,n]));
  const route=runtime.pilotRoute.nodeIds.map(id=>{const n=nodes.get(id);if(!n)throw new Error(`Missing route node ${id}`);return n;});
  const firstIndoor=route.findIndex(n=>n.buildingId==='tech-building');
  if(firstIndoor<1)throw new Error('Pilot route has no technology building entrance');
  const equal=(a:Canonical,b:Canonical)=>Math.hypot(a.x-b.x,a.z-b.z)<0.001;
  const entrance=shared.entrances.find(e=>e.buildingId==='tech-building'&&equal(e.outside,route[firstIndoor-1].position)&&equal(e.inside,route[firstIndoor].position));
  if(!entrance)throw new Error('Runtime entrance does not match the shared source');
  const rising=route.findIndex(n=>n.position.height>0.01);
  const upperIndex=route.findIndex(n=>n.position.height>=3.59);
  const lower=route.slice(0,rising).reverse().find(n=>n.id.includes('lower'));
  const upper=route.slice(upperIndex).find(n=>n.id.includes('upper'));
  const room=shared.rooms.find(r=>r.sourceAliases.includes(runtime.pilotRoute.targetSourceRoomId));
  if(!lower||!upper||!room)throw new Error('Pilot staircase/room references missing');
  const building=shared.buildings.find(b=>b.id==='tech-building')!;
  const stair=shared.stairs.find(s=>s.buildingId==='tech-building'&&lower.id.startsWith(s.id));
  if(!stair)throw new Error('Pilot staircase geometry missing');
  const indoorOrigin={x:building.bounds.x0-5,z:building.bounds.z0-5};
  const allBounds=shared.buildings.map(b=>b.bounds);
  const outdoorOrigin={x:Math.min(...allBounds.map(b=>b.x0),route[0].position.x)-18,z:Math.min(...allBounds.map(b=>b.z0),route[0].position.z)-18};
  const outdoorMax={x:Math.max(...allBounds.map(b=>b.x1),route[0].position.x)+18,z:Math.max(...allBounds.map(b=>b.z1),route[0].position.z)+18};
  const transforms={
    'pilot-outdoor':createTransform(outdoorOrigin,scale),
    'pilot-tech-1':createTransform(indoorOrigin,scale),
    'pilot-tech-2':createTransform(indoorOrigin,scale),
  };
  const title:Record<PilotId,string>={'pilot-outdoor':'校門 → 科技館','pilot-tech-1':'科技館 1F・南翼樓梯','pilot-tech-2':'科技館 2F・電腦教室二'};
  const canonicalRoutes:Record<PilotId,RuntimeNode[]>={
    'pilot-outdoor':route.slice(0,firstIndoor),
    'pilot-tech-1':route.slice(firstIndoor,route.indexOf(lower)+1),
    'pilot-tech-2':route.slice(route.indexOf(upper)),
  };
  const maps={} as Record<PilotId,MapConfig>;
  const routes={} as Record<PilotId,{x:number;y:number}[]>;
  for(const id of Object.keys(transforms) as PilotId[]) {
    const t=transforms[id],level=id==='pilot-tech-2'?2:1,height=level===2?3.6:0;
    const volumes=runtime.collisionVolumes.filter(v=>blocksFloor(v,height)&&(id==='pilot-outdoor'||v.buildingId==='tech-building'));
    const collisionZones=volumes.map(v=>t.rect({x0:v.minX,x1:v.maxX,z0:v.minZ,z1:v.maxZ}));
    if(id!=='pilot-outdoor') {
      const floor=shared.floors.find(f=>f.buildingId==='tech-building'&&f.level===level)!;
      // Complement of the union of footprints keeps upper-floor players out of the open courtyard.
      const xs=[...new Set([indoorOrigin.x,building.bounds.x1+5,...floor.footprints.flatMap(b=>[b.x0,b.x1])])].sort((a,b)=>a-b);
      const zs=[...new Set([indoorOrigin.z,building.bounds.z1+5,...floor.footprints.flatMap(b=>[b.z0,b.z1])])].sort((a,b)=>a-b);
      for(let x=0;x<xs.length-1;x++)for(let z=0;z<zs.length-1;z++){
        const b={x0:xs[x],x1:xs[x+1],z0:zs[z],z1:zs[z+1]},cx=(b.x0+b.x1)/2,cz=(b.z0+b.z1)/2;
        if(!floor.footprints.some(f=>cx>=f.x0&&cx<=f.x1&&cz>=f.z0&&cz<=f.z1))collisionZones.push(t.rect(b));
      }
      // Stair voids stay visual metadata. A 2D discrete stair portal represents the landing;
      // flattening the ramp/void into a wall would destroy the checked upper landing route.
    }
    routes[id]=canonicalRoutes[id].map(n=>t.toGame(n.position));
    maps[id]={id,width:(id==='pilot-outdoor'?outdoorMax.x-outdoorOrigin.x:building.bounds.x1-indoorOrigin.x+5)*t.unit,height:(id==='pilot-outdoor'?outdoorMax.z-outdoorOrigin.z:building.bounds.z1-indoorOrigin.z+5)*t.unit,backgroundKey:'canonical-schematic',collisionZones,npcs:[],portals:[],spawns:{}};
  }
  const spawn=(id:PilotId,key:string,p:Canonical):SpawnPoint=>maps[id].spawns[key]={...transforms[id].toGame(p),direction:'up'};
  spawn('pilot-outdoor','campus-start',route[0].position);spawn('pilot-outdoor','exit',entrance.outside);
  spawn('pilot-tech-1','entry',entrance.inside);spawn('pilot-tech-1','stairs',lower.position);spawn('pilot-tech-2','stairs',upper.position);
  const portal=(id:PilotId,key:string,p:Canonical,dest:PilotId,destSpawn:string,prompt:string)=>{
    const point=transforms[id].toGame(p);maps[id].portals.push({id:key,mapId:id,trigger:{x:point.x-18,y:point.y-18,width:36,height:36},destinationMapId:dest,destinationSpawnId:destSpawn,prompt});
  };
  portal('pilot-outdoor','tech-entry',entrance.outside,'pilot-tech-1','entry','E：進入科技館 1F');
  portal('pilot-tech-1','tech-exit',entrance.inside,'pilot-outdoor','exit','E：離開科技館，返回校園');
  portal('pilot-tech-1','tech-up',lower.position,'pilot-tech-2','stairs','E：沿南翼樓梯前往 2F');
  portal('pilot-tech-2','tech-down',upper.position,'pilot-tech-1','stairs','E：沿南翼樓梯返回 1F');
  maps['pilot-tech-2'].npcs.push({id:'pilot-math-mentor',mapId:'pilot-tech-2',...transforms['pilot-tech-2'].toGame(room.center),direction:'down',spriteKey:'robot',portraitKey:'robot',interactionRadius:62,dialogueId:'pilot-original-quest',name:'數學任務導師',kind:'robot',dialogue:'這裡是電腦教室二。我是遊戲 NPC，邀請你完成原版 5 題數學任務。完成後會回到目前的位置。'});
  for(const id of Object.keys(maps) as PilotId[])maps[id].displayName=title[id];
  return {maps,transforms,routes,title,shared,room,entrance,stair,landings:{lower,upper},canonicalRoutes,scale};
}
export type Pilot = ReturnType<typeof createPilot>;
export async function loadPilot(scale:number):Promise<{pilot:Pilot;shared:SharedCampus;runtime:RuntimeCampus}> {
  const base=new URL('./data/',document.baseURI);
  const [shared,runtime]=await Promise.all(['campus.shared.json','technology-demo-runtime.json'].map(async name=>{const response=await fetch(new URL(name,base));if(!response.ok)throw new Error(`${name}: ${response.status}`);return response.json();}));
  return {pilot:createPilot(shared,runtime,scale),shared,runtime};
}
