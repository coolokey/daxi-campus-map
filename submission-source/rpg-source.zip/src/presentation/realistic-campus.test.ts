import { describe, it, expect, vi, beforeEach } from 'vitest';
import {
  getCampusThemeMode,
  setCampusThemeMode,
  toggleCampusThemeMode,
  mountCampusThemeSwitcher,
  drawRealisticOutdoorCampus,
} from './realistic-campus';
import { campusMap } from '../game/data/maps/campus';

describe('realistic-campus mode switcher and renderer', () => {
  beforeEach(() => {
    document.body.innerHTML = `
      <header class="app-header">
        <p class="eyebrow">DAXI FUTURE CAMPUS · 校園探索雛型</p>
        <h1>未來科技校園 RPG</h1>
        <p>走進熟悉的校園，展開能源核心修復任務。</p>
      </header>
      <div class="explore-toolbar"></div>
      <div id="world-frame"></div>
    `;
    setCampusThemeMode('future');
  });

  it('toggles between future and realistic campus modes and updates header', () => {
    expect(getCampusThemeMode()).toBe('future');
    const next = toggleCampusThemeMode();
    expect(next).toBe('realistic');
    expect(getCampusThemeMode()).toBe('realistic');
    expect(document.querySelector('h1')?.textContent).toBe('大溪木藝校園 RPG');

    const back = toggleCampusThemeMode();
    expect(back).toBe('future');
    expect(document.querySelector('h1')?.textContent).toBe('未來科技校園 RPG');
  });

  it('mounts toolbar and floating mode switcher buttons for student interaction', () => {
    const onChange = vi.fn();
    mountCampusThemeSwitcher(onChange);

    const buttons = document.querySelectorAll<HTMLButtonElement>('.campus-mode-btn');
    expect(buttons.length).toBe(2);
    const futureBtn = buttons[0];
    const realisticBtn = buttons[1];

    expect(futureBtn.getAttribute('aria-pressed')).toBe('true');
    expect(realisticBtn.getAttribute('aria-pressed')).toBe('false');

    // Click realistic button
    realisticBtn.click();
    expect(getCampusThemeMode()).toBe('realistic');
    expect(realisticBtn.getAttribute('aria-pressed')).toBe('true');
    expect(onChange).toHaveBeenCalledWith('realistic');

    // Click floating toggle button to switch back
    const floatingBtn = document.querySelector<HTMLButtonElement>('#campus-floating-mode-toggle')!;
    expect(floatingBtn).not.toBeNull();
    floatingBtn.click();
    expect(getCampusThemeMode()).toBe('future');
    expect(futureBtn.getAttribute('aria-pressed')).toBe('true');
    expect(onChange).toHaveBeenCalledWith('future');
  });

  it('renders realistic outdoor campus map cleanly across scales', () => {
    const ctx = Object.fromEntries(
      [
        'fillRect',
        'strokeRect',
        'measureText',
        'drawImage',
        'beginPath',
        'arc',
        'arcTo',
        'fill',
        'moveTo',
        'lineTo',
        'stroke',
        'save',
        'translate',
        'rotate',
        'closePath',
        'restore',
        'setTransform',
        'fillText',
        'setLineDash',
      ].map((k) => [k, k === 'measureText' ? vi.fn(() => ({ width: 60 })) : vi.fn()])
    ) as unknown as CanvasRenderingContext2D;

    for (const scale of [1, 1.5, 2]) {
      expect(() => {
        drawRealisticOutdoorCampus(ctx, campusMap, scale, 1);
      }).not.toThrow();
    }
    expect(ctx.fillText).toHaveBeenCalled();
  });
});
