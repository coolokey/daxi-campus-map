import B from '../../public/data/basketball-courts-v1.json';
export const basketballConfig=B;
export const basketballCourts=B.offsets.map(z=>({x:B.center.x,z:B.center.z+z,x0:B.center.x-B.width/2,x1:B.center.x+B.width/2,z0:B.center.z+z-B.depth/2,z1:B.center.z+z+B.depth/2}));
export const basketballHoops=basketballCourts.flatMap(c=>[-1,1].map(side=>({x:c.x+side*B.hoopX,z:c.z,side,rect:{x0:c.x+side*B.hoopX-B.postRadius,x1:c.x+side*B.hoopX+B.postRadius,z0:c.z-B.postRadius,z1:c.z+B.postRadius}})));
export const basketballTarget={id:'basketball',name:'籃球場群（三面全場）',x:B.center.x,z:B.center.z};
