import {ecologyScene} from './ecology-renderer';
import {parkingScene} from './parking-renderer';
import {paintMeadowTrail,paintMeadowGround,paintMeadowPaving,paintMeadowTree,paintMeadowTreeShadow,paintMeadowPond} from './meadow-renderer';
import {terrainSeed} from './hex-terrain';
import {basketballScene} from './basketball-renderer';
import {entranceScene} from './entrance-renderer';
import type { MapConfig,SpawnPoint,NpcConfig,Rect } from '../game/data/types';
import { campusModel,modelTrees,modelMapInfo,modelTransform,projectIso } from './model-world';
import {viewport,screenUnit} from './viewport';
import { drawSunnyHorizon } from './sunny-scenery';
import { buildingMaterial } from './campus-materials';
import { paintStonePaving } from './stone-paving';
import { boundaryObjects } from './boundary-renderer';
import {paintWoodBuilding,paintWoodBench,woodBuildingOccludes} from './wood-architecture';
import {paintCartoonBuilding,cartoonBuildingHeight,cartoonBuildingOccludes} from './cartoon-renderer';
import {CARTOON_CAMPUS} from './cartoon-layout';
type P={x:number;y:number};
export function drawModelWorld(ctx:CanvasRenderingContext2D,map:MapConfig,player:SpawnPoint,npcs:NpcConfig[],paint:((ctx:CanvasRenderingContext2D,actor:any,isPlayer:boolean)=>boolean)|undefined,realistic=false,path?:P[]|null,overlay?:(ctx:CanvasRenderingContext2D,unit:number)=>void){
 const screenTransform=ctx.getTransform();
 const info=modelMapInfo(map)!,zoom=info.outdoor?.55:.85;
 if(info.outdoor){ctx.save();ctx.fillStyle='#91b372';ctx.fillRect(0,0,viewport.logicalWidth,viewport.logicalHeight);ctx.restore();}
 ctx.save();ctx.scale(zoom,zoom);const pp=projectIso(player),offset={x:viewport.logicalWidth/zoom/2-pp.x,y:viewport.logicalHeight/zoom*.62-pp.y},unit=screenUnit(ctx.getTransform().a);
 ctx.translate(offset.x,offset.y);
 const poly=(points:P[],fill:string,stroke?:string)=>{ctx.beginPath();points.forEach((p,i)=>{const q=projectIso(p);i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y)});ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=unit;ctx.stroke();}};
 const corners=(r:Rect)=>[{x:r.x,y:r.y},{x:r.x+r.width,y:r.y},{x:r.x+r.width,y:r.y+r.height},{x:r.x,y:r.y+r.height}];
 const tile=(r:Rect,color:string,stroke?:string)=>poly(corners(r),color,stroke);
 const line=(a:P,b:P,color:string,width=2)=>{const p=projectIso(a),q=projectIso(b);ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.strokeStyle=color;ctx.lineWidth=width*unit;ctx.stroke();};
 const label=(p:P,text:string,color='#fffdf5',elevation=0)=>{const q=projectIso(p);q.y-=elevation;ctx.font=`600 ${12*unit}px system-ui`;ctx.textAlign='center';const w=ctx.measureText(text).width+16*unit;ctx.fillStyle=realistic?'#69513bef':'#f7f4e4f0';ctx.fillRect(q.x-w/2,q.y-17*unit,w,22*unit);ctx.fillStyle=realistic?color:'#36583b';ctx.fillText(text,q.x,q.y-2*unit);ctx.textAlign='left';};
 const box=(r:Rect,h:number,color:string,roof:string,side='#d8c9ab')=>{
  const c=corners(r).map(projectIso);
  const screenPoly=(pts:P[],fill:string,stroke?:string)=>{ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=unit;ctx.stroke();}};
  const face=(idx:number[],fill:string)=>screenPoly(idx.map(n=>({x:c[n%4].x,y:c[n%4].y-(n<4?h:0)})),fill,'#b9aa8a');
  face([1,2,6,5],color);face([2,3,7,6],side);face([0,1,2,3],roof);
  if(h>50){
   // Window bays stay inside each original wall plane; the building footprint is unchanged.
   const spacing=86.4*(info.outdoor?info.unit/16:1),windowHeight=Math.min(20*unit,spacing*.42);
   for(const [a,b] of [[c[1],c[2]],[c[2],c[3]]]){
    const bays=Math.max(2,Math.round(Math.hypot(b.x-a.x,b.y-a.y)/(29*unit)));
    const at=(t:number,z:number)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t-z});
    for(let z=24;z<h-14;z+=spacing){
     for(let i=0;i<bays;i++){
      const left=(i+.18)/bays,right=(i+.82)/bays,top=Math.min(z+windowHeight,h-8);
      screenPoly([at(left,z),at(right,z),at(right,top),at(left,top)],a===c[1]?'#80adbd':'#60899d','#f9f4e7');
      const glint=at(left+.08/bays,top-3*unit),end=at(right-.06/bays,top-3*unit);
      ctx.beginPath();ctx.moveTo(glint.x,glint.y);ctx.lineTo(end.x,end.y);ctx.strokeStyle='#cbe0e5';ctx.lineWidth=unit;ctx.stroke();
     }
     ctx.beginPath();const start=at(0,z-4*unit),end=at(1,z-4*unit);ctx.moveTo(start.x,start.y);ctx.lineTo(end.x,end.y);ctx.strokeStyle='#e8dcc2';ctx.lineWidth=2*unit;ctx.stroke();
    }
   }
   ctx.save();ctx.translate(0,-h);
   const inset={x:r.x+r.width*.08,y:r.y+r.height*.08,width:r.width*.84,height:r.height*.84};
   tile(inset,roof,'#e1b39a');
   // A single compact rooftop installation leaves most of the roof calm and uncluttered.
   const panel={x:r.x+r.width*.22,y:r.y+r.height*.25,width:r.width*.30,height:r.height*.32};
   tile(panel,realistic?'#b7b5a7':'#536c78','#b8c6c7');
   if(!realistic)for(let i=1;i<3;i++)line({x:panel.x+panel.width*i/3,y:panel.y},{x:panel.x+panel.width*i/3,y:panel.y+panel.height},'#a8bfcb',1);
   ctx.restore();
  }
 };
 tile({x:0,y:0,width:map.width,height:map.height},info.outdoor?(realistic?'#8faf6a':'#9ad062'):'#e7ddc9');
 if(info.outdoor){
 const t=modelTransform({x:-162,z:-90},info.unit),o=campusModel.outdoor;
 if(realistic)poly(o.perimeter.outline.map(([x,z])=>t.toGame({x,z})),'#a0d765','#76af4b');
 else paintMeadowGround(ctx,map.width,map.height,info.unit);
 const pave=(points:P[])=>realistic?paintStonePaving(ctx,points,info.unit):paintMeadowPaving(ctx,points,info.unit);
 // Shared plan-derived roads are also consumed by the minimap, underneath buildings and navigation.
 for(const r of map.outdoorPaving??[])pave(corners(r));
 for(const p of map.outdoorPaths??[]){if(realistic){for(let i=1;i<p.points.length;i++)line(p.points[i-1],p.points[i],'#c2ad84',p.width/unit);}else paintMeadowTrail(ctx,p.points,p.width,info.unit);}
 // The campus plaza is stone-paved; source sports fields and planting overwrite it below.
 // Keep the meadow visible; masonry is concentrated around actual buildings and the entrance promenade.
 // Source entrance axis becomes a paved promenade with an inset center strip.
 const gate=t.toGame(o.entrance.pedestrian.inside),destination=t.toGame(o.entrance.target);
 const dx=destination.x-gate.x,dy=destination.y-gate.y,len=Math.hypot(dx,dy),nx=-dy/len*info.unit*1.8,ny=dx/len*info.unit*1.8;
 pave([{x:gate.x+nx,y:gate.y+ny},{x:destination.x+nx,y:destination.y+ny},{x:destination.x-nx,y:destination.y-ny},{x:gate.x-nx,y:gate.y-ny}]);
 // Warm paving aprons are visual surfaces around the original footprints.
 for(const structure of info.structures){const r=structure.rect,pad=info.unit*1.6;const apron={x:r.x-pad,y:r.y-pad,width:r.width+pad*2,height:r.height+pad*2};if(realistic)tile(apron,'#e4dcc8','#c4b99d');pave(corners(apron));
 if(realistic)for(let x=apron.x;x<apron.x+apron.width;x+=info.unit*3)line({x,y:apron.y},{x,y:apron.y+apron.height},'#ccc1a9',.6);
 if(realistic)for(let y=apron.y;y<apron.y+apron.height;y+=info.unit*3)line({x:apron.x,y},{x:apron.x+apron.width,y},'#ccc1a9',.6);
 // Colored entrance edging visually connects the ground to its building.
 const m=buildingMaterial(structure.id);if(realistic)line({x:apron.x,y:apron.y+apron.height},{x:apron.x+apron.width,y:apron.y+apron.height},m.roof,3);
 }
 if(realistic){tile(t.rect(campusModel.forecourt.driveway),'#899393','#dedbc8');tile(t.rect(campusModel.forecourt.parking),'#b9b49f');}else{pave(corners(t.rect(campusModel.forecourt.driveway)));pave(corners(t.rect(campusModel.forecourt.parking)));}
 if(realistic)for(let z=51;z<70;z+=6)line(t.toGame({x:-41,z}),t.toGame({x:-31,z}),'#c3ece2',1);
 // Inlaid compass diamonds decorate the real entrance forecourt without creating obstacles.
 const plaza=t.toGame(o.entrance.target),radius=info.unit*3;
 if(realistic)poly([{x:plaza.x-radius,y:plaza.y},{x:plaza.x,y:plaza.y-radius},{x:plaza.x+radius,y:plaza.y},{x:plaza.x,y:plaza.y+radius}],'#d7c29a','#a28d67');
 if(realistic)poly([{x:plaza.x-radius*.6,y:plaza.y},{x:plaza.x,y:plaza.y-radius*.6},{x:plaza.x+radius*.6,y:plaza.y},{x:plaza.x,y:plaza.y+radius*.6}],'#a3b8b4','#7f9792');
 // Source-derived track capsule; its infield remains open for exploration.
 const tr=o.track;const capsule=(radius:number,color:string)=>{const points:P[]=[];for(let i=0;i<=24;i++){const a=-Math.PI/2+i*Math.PI/24;points.push(t.toGame({x:tr.x+tr.halfStraight+Math.cos(a)*radius,z:tr.z+Math.sin(a)*radius}));}for(let i=0;i<=24;i++){const a=Math.PI/2+i*Math.PI/24;points.push(t.toGame({x:tr.x-tr.halfStraight+Math.cos(a)*radius,z:tr.z+Math.sin(a)*radius}));}poly(points,color);};
 capsule(tr.outerRadius,'#bc735d');for(let r=tr.outerRadius-1;r>tr.innerRadius;r-=1.4){const points:P[]=[];for(let i=0;i<=64;i++){const a=i*Math.PI/32;points.push(t.toGame({x:tr.x+(Math.cos(a)>0?tr.halfStraight:-tr.halfStraight)+Math.cos(a)*r,z:tr.z+Math.sin(a)*r}));}ctx.beginPath();points.map(projectIso).forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.strokeStyle='#e2fbf28c';ctx.lineWidth=unit;ctx.stroke();}capsule(tr.innerRadius,'#8faf6a');
 [...o.courts,...o.outerCourts].forEach((r,i)=>{const rect=t.rect(r);tile(rect,i<2?'#839f86':'#c6a576','#efffff');line({x:rect.x,y:rect.y+rect.height/2},{x:rect.x+rect.width,y:rect.y+rect.height/2},'#fff',1);});

 const pond=t.toGame({x:o.pond.x,z:o.pond.z});const ring=Array.from({length:48},(_,i)=>({x:pond.x+Math.cos(i*Math.PI/24)*o.pond.radius*info.unit,y:pond.y+Math.sin(i*Math.PI/24)*o.pond.radius*info.unit}));if(realistic){poly(ring,'#6ab4cb','#e2efdb');label(pond,'訓平池');}
 label(t.toGame({x:tr.x,z:tr.z}),'運動場・自由探索');label(t.toGame(o.entrance.gate),realistic?'大溪木藝學園・正門':'大溪草甸學園・正門');if(realistic)line(t.toGame(o.entrance.pedestrian.inside),t.toGame(o.entrance.target),'#b6a786',2);
 }else{for(const r of info.surfaces)tile(r,'#ece0cb','#c3b89c');for(const r of info.rooms){tile(r.rect,'#e5d2ac','#ad9673');for(let y=r.rect.y+info.unit*.55;y<r.rect.y+r.rect.height;y+=info.unit*.55)line({x:r.rect.x,y},{x:r.rect.x+r.rect.width,y},'#c3ad86',.55);label(r.point,r.name,'#fff0d0');}}
 const ecologyObjects=info.outdoor?ecologyScene(ctx,map,info.unit,unit,viewport.cssWidth):[];
 const parkingObjects=info.outdoor?parkingScene(ctx,info.unit,unit,player):[];
 const sportsObjects=info.outdoor?basketballScene(ctx,info.unit,unit,player):[];
 const entranceObjects=info.outdoor?entranceScene(ctx,info.unit,unit,player,!realistic):[];
 if(info.outdoor&&!realistic){const t=modelTransform({x:-162,z:-90},info.unit),pond=campusModel.outdoor.pond;paintMeadowPond(ctx,t.toGame({x:pond.x,z:pond.z}),pond.radius*info.unit,info.unit);label(t.toGame({x:pond.x,z:pond.z}),'訓平池');}
 if(path?.length){ctx.setLineDash([10*unit,7*unit]);for(let i=1;i<path.length;i++)line(path[i-1],path[i],'#e79819',4);ctx.setLineDash([]);}
 if(info.outdoor&&realistic){ctx.save();ctx.setTransform(screenTransform);drawSunnyHorizon(ctx,viewport.logicalWidth,viewport.logicalHeight);ctx.restore();}
 if(info.outdoor)for(const structure of info.structures){const r=structure.rect;tile({x:r.x+info.unit*1.6,y:r.y+info.unit,width:r.width,height:r.height},'#394b3320');}
 const objects:{depth:number;draw:()=>void}[]=info.outdoor?boundaryObjects(ctx,info.unit,unit,player,realistic?1:CARTOON_CAMPUS.boundaryHeightScale):[];
 objects.push(...entranceObjects,...sportsObjects,...parkingObjects,...ecologyObjects);
 if(info.outdoor){const t=modelTransform({x:-162,z:-90},info.unit);for(const b of [campusModel.forecourt.planting,campusModel.forecourt.southTreeRow])tile(t.rect(b),realistic?'#8faf6a':'#71954f20');for(const tree of modelTrees()){const p=t.toGame({x:tree.x,z:tree.z}),seed=terrainSeed(Math.round(tree.x*10),Math.round(tree.z*10));paintMeadowTreeShadow(ctx,p,seed,info.unit);objects.push({depth:p.x+p.y,draw:()=>paintMeadowTree(ctx,p,player,seed,info.unit)});}}


 for(const item of info.furniture){const r=item.rect;objects.push({depth:r.x+r.y+r.width+r.height,draw:()=>paintWoodBench(ctx,r,item.axis,info.unit,unit)});}
 for(const s of info.structures){const r=s.rect,h=s.height;objects.push({depth:r.x+r.y+r.width+r.height,draw:()=>{const c=projectIso({x:r.x+r.width/2,y:r.y+r.height/2});const blocked=realistic?woodBuildingOccludes(r,h,info.unit,player,unit):cartoonBuildingOccludes(r,h,info.unit,player,unit);if(blocked)ctx.globalAlpha=.28;if(realistic)paintWoodBuilding(ctx,r,h,info.unit,unit,s.id);else paintCartoonBuilding(ctx,r,h,info.unit,unit,s.id);ctx.globalAlpha=1;if(!info.structures.some(o=>o.id===s.id&&o.rect.width*o.rect.height>r.width*r.height))label({x:r.x+r.width/2,y:r.y+r.height/2},s.name.split(' / ')[0],'#fff4d8',realistic?h+info.unit*3:cartoonBuildingHeight(h,info.unit)+info.unit*.8);void c;}});}
 if(!info.outdoor)for(const r of map.collisionZones){if(r.width>15&&r.height>15)continue;objects.push({depth:r.x+r.y+r.width+r.height,draw:()=>box(r,22,'#b7a589','#ead8b8')});}
 for(const portal of map.portals){const p={x:portal.trigger.x+portal.trigger.width/2,y:portal.trigger.y+portal.trigger.height/2};tile(portal.trigger,'#b28b4e55','#f4e6c6');if(Math.hypot(p.x-player.x,p.y-player.y)<250)label({...p,y:p.y-15},portal.prompt.replace('E：',''),'#fbef93');}
 for(const actor of [...npcs,player])objects.push({depth:actor.x+actor.y,draw:()=>{const p=projectIso(actor),clone={...actor,...p};if(paint?.(ctx,clone,actor===player))return;ctx.fillStyle=actor===player?'#fff2a0':'#68dcdb';ctx.beginPath();ctx.arc(p.x,p.y-30*unit,16*unit,0,Math.PI*2);ctx.fill();ctx.fillRect(p.x-9*unit,p.y-20*unit,18*unit,20*unit);}});
 objects.sort((a,b)=>a.depth-b.depth).forEach(o=>o.draw());
 overlay?.(ctx,unit);
 ctx.restore();
}
