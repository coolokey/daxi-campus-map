import type { MapConfig,SpawnPoint,NpcConfig,Rect } from '../game/data/types';
import { campusModel,modelTrees,modelMapInfo,modelTransform,projectIso } from './model-world';
import {viewport,screenUnit} from './viewport';
type P={x:number;y:number};
export function drawModelWorld(ctx:CanvasRenderingContext2D,map:MapConfig,player:SpawnPoint,npcs:NpcConfig[],paint:((ctx:CanvasRenderingContext2D,actor:any,isPlayer:boolean)=>boolean)|undefined,realistic=false,path?:P[]|null){
 const info=modelMapInfo(map)!,zoom=info.outdoor?.55:.85;ctx.save();ctx.scale(zoom,zoom);const pp=projectIso(player),offset={x:viewport.logicalWidth/zoom/2-pp.x,y:viewport.logicalHeight/zoom*.62-pp.y},unit=screenUnit(ctx.getTransform().a);
 ctx.translate(offset.x,offset.y);
 const poly=(points:P[],fill:string,stroke?:string)=>{ctx.beginPath();points.forEach((p,i)=>{const q=projectIso(p);i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y)});ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=unit;ctx.stroke();}};
 const corners=(r:Rect)=>[{x:r.x,y:r.y},{x:r.x+r.width,y:r.y},{x:r.x+r.width,y:r.y+r.height},{x:r.x,y:r.y+r.height}];
 const tile=(r:Rect,color:string,stroke?:string)=>poly(corners(r),color,stroke);
 const line=(a:P,b:P,color:string,width=2)=>{const p=projectIso(a),q=projectIso(b);ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.strokeStyle=color;ctx.lineWidth=width*unit;ctx.stroke();};
 const label=(p:P,text:string,color='#d9faff',elevation=0)=>{const q=projectIso(p);q.y-=elevation;ctx.font=`600 ${12*unit}px system-ui`;ctx.textAlign='center';const w=ctx.measureText(text).width+16*unit;ctx.fillStyle='#09283aeb';ctx.fillRect(q.x-w/2,q.y-17*unit,w,22*unit);ctx.fillStyle=color;ctx.fillText(text,q.x,q.y-2*unit);ctx.textAlign='left';};
 const box=(r:Rect,h:number,color:string,roof:string)=>{const c=corners(r).map(projectIso);const face=(idx:number[],fill:string)=>{ctx.beginPath();idx.forEach((n,i)=>{const p=c[n%4],y=p.y-(n<4?h:0);i?ctx.lineTo(p.x,y):ctx.moveTo(p.x,y)});ctx.closePath();ctx.fillStyle=fill;ctx.fill();ctx.strokeStyle=realistic?'#825744':'#53dbe266';ctx.lineWidth=unit;ctx.stroke();};face([1,2,6,5],color);face([2,3,7,6],realistic?'#b9947c':'#164760');face([0,1,2,3],roof);
 if(h>50){ctx.save();ctx.translate(0,-h);const inset={x:r.x+r.width*.15,y:r.y+r.height*.15,width:r.width*.7,height:r.height*.7};tile(inset,realistic?'#96735d':'#1b526a','#79d9df');for(let i=1;i<5;i++)line({x:inset.x+inset.width*i/5,y:inset.y},{x:inset.x+inset.width*i/5,y:inset.y+inset.height},realistic?'#c4a98d':'#4698b0',1);ctx.restore();for(let height=24;height<h-12;height+=86.4*(info.outdoor?info.unit/16:1)){for(const[a,b]of [[c[1],c[2]],[c[2],c[3]]]){ctx.beginPath();ctx.moveTo(a.x,a.y-height);ctx.lineTo(b.x,b.y-height);ctx.lineWidth=7*unit;ctx.strokeStyle=realistic?'#7aa3ad':'#71eff5';ctx.stroke();}}}
 };
 tile({x:0,y:0,width:map.width,height:map.height},realistic?'#d9ded0':'#163d45');
 if(info.outdoor){
 const t=modelTransform({x:-162,z:-90},info.unit),o=campusModel.outdoor;
 poly(o.perimeter.outline.map(([x,z])=>t.toGame({x,z})),realistic?'#e4e0ce':'#c8e7df','#7fe8e9');
 tile(t.rect({x0:-65,x1:93,z0:81.5,z1:90.5}),'#547b83','#a1dddd');tile(t.rect({x0:-42,x1:-30,z0:48,z1:70}),'#6c8c91');
 for(let z=51;z<70;z+=6)line(t.toGame({x:-41,z}),t.toGame({x:-31,z}),'#c3ece2',1);
 // Source-derived track capsule; its infield remains open for exploration.
 const tr=o.track;const capsule=(radius:number,color:string)=>{const points:P[]=[];for(let i=0;i<=24;i++){const a=-Math.PI/2+i*Math.PI/24;points.push(t.toGame({x:tr.x+tr.halfStraight+Math.cos(a)*radius,z:tr.z+Math.sin(a)*radius}));}for(let i=0;i<=24;i++){const a=Math.PI/2+i*Math.PI/24;points.push(t.toGame({x:tr.x-tr.halfStraight+Math.cos(a)*radius,z:tr.z+Math.sin(a)*radius}));}poly(points,color);};
 capsule(tr.outerRadius,realistic?'#b66b62':'#486985');for(let r=tr.outerRadius-1;r>tr.innerRadius;r-=1.4){const points:P[]=[];for(let i=0;i<=64;i++){const a=i*Math.PI/32;points.push(t.toGame({x:tr.x+(Math.cos(a)>0?tr.halfStraight:-tr.halfStraight)+Math.cos(a)*r,z:tr.z+Math.sin(a)*r}));}ctx.beginPath();points.map(projectIso).forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.strokeStyle='#e2fbf28c';ctx.lineWidth=unit;ctx.stroke();}capsule(tr.innerRadius,realistic?'#93b878':'#68b294');
 [...o.courts,...o.outerCourts].forEach((r,i)=>{const rect=t.rect(r);tile(rect,i<2?'#538e91':'#b6a773','#efffff');line({x:rect.x,y:rect.y+rect.height/2},{x:rect.x+rect.width,y:rect.y+rect.height/2},'#fff',1);});
 for(const s of o.perimeter.segments)line(t.toGame({x:s.ax,z:s.az}),t.toGame({x:s.bx,z:s.bz}),realistic?'#94877c':'#25889b',5);
 const pond=t.toGame({x:o.pond.x,z:o.pond.z});const ring=Array.from({length:48},(_,i)=>({x:pond.x+Math.cos(i*Math.PI/24)*o.pond.radius*info.unit,y:pond.y+Math.sin(i*Math.PI/24)*o.pond.radius*info.unit}));poly(ring,'#208fb2','#c6fcff');label(pond,'訓平池');
 label(t.toGame({x:tr.x,z:tr.z}),'運動場・自由探索');label(t.toGame(o.entrance.gate),'大溪未來學園・正門');line(t.toGame(o.entrance.pedestrian.inside),t.toGame(o.entrance.target),'#59b5b0',4);
 }else{for(const r of info.surfaces)tile(r,realistic?'#ece0cb':'#b4d2d6','#72b5c0');for(const r of info.rooms){tile(r.rect,realistic?'#dac7a6':'#d3e7ea','#4e9baa');label(r.point,r.name,'#fff5c2');}}
 if(path?.length){ctx.setLineDash([10*unit,7*unit]);for(let i=1;i<path.length;i++)line(path[i-1],path[i],'#e79819',4);ctx.setLineDash([]);}
 const objects:{depth:number;draw:()=>void}[]=[];
 if(info.outdoor){const t=modelTransform({x:-162,z:-90},info.unit);for(const b of [campusModel.forecourt.planting,campusModel.forecourt.southTreeRow])tile(t.rect(b),realistic?'#95ad6e':'#79bca1','#50a590');for(const tree of modelTrees()){const p=t.toGame({x:tree.x,z:tree.z}),q=projectIso(p);objects.push({depth:p.x+p.y,draw:()=>{ctx.fillStyle='#395e59';ctx.fillRect(q.x-3*unit,q.y-40*unit,6*unit,40*unit);ctx.fillStyle=realistic?'#587d51':'#3c9e91';ctx.beginPath();ctx.ellipse(q.x,q.y-47*unit,23*unit,30*unit,0,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#80e5c0';ctx.lineWidth=unit;ctx.stroke();}});}}

 for(const s of info.structures){const r=s.rect,h=s.height;objects.push({depth:r.x+r.y+r.width+r.height,draw:()=>{const c=projectIso({x:r.x+r.width/2,y:r.y+r.height/2});const shape=corners(r).map(projectIso),foot=projectIso(player),blocked=foot.x>Math.min(...shape.map(p=>p.x))-22*unit&&foot.x<Math.max(...shape.map(p=>p.x))+22*unit&&foot.y>Math.min(...shape.map(p=>p.y))-h&&foot.y-50*unit<Math.max(...shape.map(p=>p.y));if(blocked)ctx.globalAlpha=.28;box(r,h,realistic?'#d1baa0':'#327c91',realistic?'#a76050':'#237c91');ctx.globalAlpha=1;if(!info.structures.some(o=>o.id===s.id&&o.rect.width*o.rect.height>r.width*r.height))label({x:r.x+r.width/2,y:r.y+r.height/2},s.name.split(' / ')[0],'#d9faff',h);void c;}});}
 if(!info.outdoor)for(const r of map.collisionZones){if(r.width>15&&r.height>15)continue;objects.push({depth:r.x+r.y+r.width+r.height,draw:()=>box(r,22,realistic?'#aa8d6e':'#528998',realistic?'#ead8b8':'#b4f4ef')});}
 for(const portal of map.portals){const p={x:portal.trigger.x+portal.trigger.width/2,y:portal.trigger.y+portal.trigger.height/2};tile(portal.trigger,'#21b6c2aa','#d8ffff');if(Math.hypot(p.x-player.x,p.y-player.y)<250)label({...p,y:p.y-15},portal.prompt.replace('E：',''),'#fbef93');}
 for(const actor of [...npcs,player])objects.push({depth:actor.x+actor.y,draw:()=>{const p=projectIso(actor),clone={...actor,...p};if(paint?.(ctx,clone,actor===player))return;ctx.fillStyle=actor===player?'#fff2a0':'#68dcdb';ctx.beginPath();ctx.arc(p.x,p.y-30*unit,16*unit,0,Math.PI*2);ctx.fill();ctx.fillRect(p.x-9*unit,p.y-20*unit,18*unit,20*unit);}});
 objects.sort((a,b)=>a.depth-b.depth).forEach(o=>o.draw());
 ctx.restore();
}
