import theme from '../../public/data/meadow-theme-v1.json';
import {terrainSeed} from './hex-terrain';
import {projectIso} from './model-world';
type P={x:number;y:number};
export const meadowTheme=theme;
let grass:HTMLCanvasElement|undefined,gravel:HTMLCanvasElement|undefined;
const trees=new Map<number,HTMLCanvasElement>();
const canvas=(w:number,h:number)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c;};
function grassTexture(){
 if(grass)return grass;grass=canvas(1024,1024);const c=grass.getContext('2d')!;c.fillStyle=theme.ground;c.fillRect(0,0,1024,1024);
 for(let i=0;i<35;i++){const seed=terrainSeed(i,47),x=seed%1024,y=(seed>>>10)%1024,r=90+(seed%170);for(const dx of [-1024,0,1024])for(const dy of [-1024,0,1024]){const g=c.createRadialGradient(x+dx,y+dy,0,x+dx,y+dy,r);g.addColorStop(0,theme.grass[i%theme.grass.length]+'a0');g.addColorStop(1,theme.grass[i%theme.grass.length]+'00');c.fillStyle=g;c.fillRect(x+dx-r,y+dy-r,r*2,r*2);}}
 for(let i=0;i<8500;i++){const n=terrainSeed(i,91),x=n%1024,y=(n>>>10)%1024,s=5+n%9;c.strokeStyle=i%3?'#c6db863d':'#456f493a';c.lineWidth=1.1;c.beginPath();c.moveTo(x-s,y+s*.2);c.quadraticCurveTo(x-s*.4,y-s*.8,x,y);c.quadraticCurveTo(x+s*.3,y-s,x+s*.8,y-s*.3);c.stroke();}
 // Flower patches stay clustered; tiny vegetation never changes collision.
 for(let i=0;i<900;i++){const n=terrainSeed(i,104),x=n%1024,y=(n>>>10)%1024;if(Math.sin(x*.012)+Math.cos(y*.015)<.6)continue;c.fillStyle=['#f6edc7','#e8bd71','#e7c2d7','#d6c5e1'][i%4];c.beginPath();c.ellipse(x,y,1.8,2.7,.4,0,Math.PI*2);c.fill();}
 return grass;
}
function gravelTexture(){
 if(gravel)return gravel;gravel=canvas(512,512);const c=gravel.getContext('2d')!;c.fillStyle='#bf9c69';c.fillRect(0,0,512,512);
 for(let i=0;i<20;i++){const n=terrainSeed(i,312),x=n%512,y=(n>>>9)%512,r=65+n%90;for(const dx of [-512,0,512])for(const dy of [-512,0,512]){const g=c.createRadialGradient(x+dx,y+dy,0,x+dx,y+dy,r);g.addColorStop(0,i%2?'#ead2a377':'#92734e45');g.addColorStop(1,'#c4a27100');c.fillStyle=g;c.fillRect(x+dx-r,y+dy-r,r*2,r*2);}}
 for(let i=0;i<1200;i++){const n=terrainSeed(i,31),x=n%512,y=(n>>>9)%512;c.fillStyle=i%3?'#ecd3a67a':'#7d684c38';c.beginPath();c.ellipse(x,y,1+n%4,1+(n>>>4)%2,.3,0,Math.PI*2);c.fill();}
 return gravel;
}
// Restrained irregularity follows the existing route envelope; no new physical obstacle.
function naturalEdge(points:P[],unit:number){
 const area=points.reduce((sum,p,i)=>{const q=points[(i+1)%points.length];return sum+p.x*q.y-q.x*p.y;},0),sign=area>=0?1:-1;const edge:P[]=[];
 for(let k=0;k<points.length;k++){const a=points[k],b=points[(k+1)%points.length],length=Math.hypot(b.x-a.x,b.y-a.y),count=Math.max(2,Math.ceil(length/(unit*.7)));if(length<.001)continue;
  for(let i=0;i<count;i++){const f=i/count,x=a.x+(b.x-a.x)*f,y=a.y+(b.y-a.y)*f,n=terrainSeed(Math.round(x/unit*6),Math.round(y/unit*6)),d=unit*(.08+.3*(.5+.5*Math.sin(x/unit*.8+y/unit*.5))+(n%100)/100*.25);edge.push({x:x-(b.y-a.y)/length*d*sign,y:y+(b.x-a.x)/length*d*sign});}}
 return edge;
}
/** Continuous, globally aligned material: no tiles, cell borders or camera-dependent recoloring. */
export function paintMeadowGround(ctx:CanvasRenderingContext2D,width:number,height:number,unit:number,padding=0){ctx.save();ctx.transform(Math.sqrt(3)/2,.5,-Math.sqrt(3)/2,.5,0,0);const scale=unit/16;ctx.scale(scale,scale);ctx.fillStyle=ctx.createPattern(grassTexture(),'repeat')!;ctx.fillRect(-padding/scale,-padding/scale,(width+padding*2)/scale,(height+padding*2)/scale);ctx.restore();}
export function paintMeadowPaving(ctx:CanvasRenderingContext2D,points:P[],unit:number){
 if(points.length<3)return;
 const matrix=ctx.getTransform(),bounds=points.map(projectIso).map(p=>({x:matrix.a*p.x+matrix.c*p.y+matrix.e,y:matrix.b*p.x+matrix.d*p.y+matrix.f})),pad=unit*Math.max(Math.abs(matrix.a),Math.abs(matrix.d))*2;
 if(Math.max(...bounds.map(p=>p.x))<-pad||Math.min(...bounds.map(p=>p.x))>ctx.canvas.width+pad||Math.max(...bounds.map(p=>p.y))<-pad||Math.min(...bounds.map(p=>p.y))>ctx.canvas.height+pad)return;
 const edge=naturalEdge(points,unit),screen=edge.map(projectIso);ctx.save();ctx.beginPath();screen.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();
 ctx.fillStyle='#bfa779';ctx.shadowColor='#b49b6f9c';ctx.shadowBlur=unit*.42;ctx.fill();ctx.shadowBlur=0;ctx.save();ctx.clip();ctx.transform(Math.sqrt(3)/2,.5,-Math.sqrt(3)/2,.5,0,0);const scale=unit/16;ctx.scale(scale,scale);ctx.fillStyle=ctx.createPattern(gravelTexture(),'repeat')!;ctx.fillRect(0,0,20000,20000);ctx.restore();
 // Sparse stones and grass fringes grow along the same world-aligned edge, never across doorways as colliders.
 for(let i=0;i<edge.length;i+=2){const p=edge[i],q=screen[i],n=terrainSeed(Math.round(p.x/unit*9),Math.round(p.y/unit*9));
  if(n%5===0){ctx.fillStyle=n%2?'#a6a17f':'#c5ba97';ctx.beginPath();ctx.ellipse(q.x,q.y-unit*.035,unit*.12,unit*.075,.2,0,Math.PI*2);ctx.fill();}
  if(n%3===0){ctx.strokeStyle=n%2?'#83a456b0':'#a9c374b0';ctx.lineWidth=unit*.045;ctx.beginPath();ctx.moveTo(q.x-unit*.12,q.y);ctx.quadraticCurveTo(q.x-unit*.2,q.y-unit*.3,q.x-unit*.27,q.y-unit*.2);ctx.moveTo(q.x,q.y);ctx.quadraticCurveTo(q.x+unit*.05,q.y-unit*.3,q.x+unit*.15,q.y-unit*.24);ctx.stroke();}}
 ctx.restore();
}
export function paintMeadowTrail(ctx:CanvasRenderingContext2D,points:P[],width:number,unit:number){
 if(points.length<2)return;const left:P[]=[],right:P[]=[];
 points.forEach((p,i)=>{const a=points[Math.max(0,i-1)],b=points[Math.min(points.length-1,i+1)],dx=b.x-a.x,dy=b.y-a.y,l=Math.hypot(dx,dy)||1,nx=-dy/l*width/2,ny=dx/l*width/2;left.push({x:p.x+nx,y:p.y+ny});right.push({x:p.x-nx,y:p.y-ny});});paintMeadowPaving(ctx,[...left,...right.reverse()],unit);
}
export function meadowTreeProfile(seed:number,unit:number){const id=(seed>>>0)%12;return {id,width:unit*(8.4+(id%3)*.5),height:unit*(12+(id%4)*.65)};}
export function meadowTreeOccludes(point:P,player:P,seed:number,unit:number){const size=meadowTreeProfile(seed,unit),p=projectIso(point),q=projectIso(player);return player.x+player.y<point.x+point.y&&q.x>p.x-size.width*.5&&q.x<p.x+size.width*.5&&q.y>p.y-size.height&&q.y-45<p.y;}
function treeSprite(id:number){
 if(trees.has(id))return trees.get(id)!;const cv=canvas(256,384),c=cv.getContext('2d')!,colors=theme.treeGreens[id%3];
 const polygon=(ps:P[],color:string)=>{c.beginPath();ps.forEach((p,i)=>i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y));c.closePath();c.fillStyle=color;c.fill();};
 polygon([{x:112,y:375},{x:119,y:310},{x:115,y:271},{x:98,y:239},{x:80,y:210},{x:99,y:220},{x:127,y:263},{x:151,y:212},{x:172,y:198},{x:148,y:262},{x:139,y:310},{x:144,y:375}], '#765435');
 polygon([{x:121,y:374},{x:124,y:311},{x:121,y:272},{x:130,y:285},{x:133,y:312},{x:132,y:374}], '#a77e4c');
 const lobes=[{x:67,y:198,r:58},{x:183,y:183,r:64},{x:72,y:138,r:57},{x:177,y:116,r:61},{x:116,y:83,r:64},{x:130,y:164,r:76}];
 lobes.forEach((original,index)=>{const b={x:128+(original.x-128)*.87,y:original.y+29,r:original.r*1.12};const points=Array.from({length:11},(_,i)=>{const a=i*Math.PI*2/11,r=b.r*(.91+(terrainSeed(i+id,index)%16)/100);return {x:b.x+Math.cos(a)*r,y:b.y+Math.sin(a)*r*.8};});const g=c.createLinearGradient(b.x-b.r,b.y-b.r,b.x+b.r,b.y+b.r);g.addColorStop(0,colors[2]);g.addColorStop(.46,colors[1]);g.addColorStop(1,colors[0]);c.beginPath();points.forEach((p,i)=>i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y));c.closePath();c.fillStyle=g;c.fill();const center={x:b.x-b.r*.16,y:b.y-b.r*.15};for(let i=0;i<points.length;i++)polygon([center,points[i],points[(i+1)%points.length]],i%3===0?'#ffffff08':i%4===0?'#1d4d2910':'#ffffff00');});
 if(id%4===0)for(let i=0;i<12;i++){const n=terrainSeed(i,id);c.fillStyle='#efd1df';c.beginPath();c.ellipse(48+n%154,105+(n>>>10)%100,3.2,5.2,.4,0,Math.PI*2);c.fill();}
 for(let i=0;i<32;i++){const n=terrainSeed(i,id+57),x=88+n%79,y=369+(n>>>8)%7,h=5+n%9;c.strokeStyle=i%2?'#729e48':'#a2be5f';c.lineWidth=1.2;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x-3,y-h,x-6,y-h*.7);c.moveTo(x,y);c.quadraticCurveTo(x+1,y-h,x+4,y-h);c.stroke();}
 trees.set(id,cv);return cv;
}
export function paintMeadowTreeShadow(ctx:CanvasRenderingContext2D,point:P,seed:number,unit:number){const p=projectIso(point),size=meadowTreeProfile(seed,unit);ctx.save();ctx.translate(p.x+unit*1.7,p.y+unit*.65);ctx.scale(1,.43);const g=ctx.createRadialGradient(0,0,0,0,0,size.width*.58);g.addColorStop(0,'#315f364d');g.addColorStop(.7,'#315f3629');g.addColorStop(1,'#315f3600');ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,size.width*.58,0,Math.PI*2);ctx.fill();ctx.restore();}
export function paintMeadowTree(ctx:CanvasRenderingContext2D,point:P,player:P,seed:number,unit:number){const p=projectIso(point),size=meadowTreeProfile(seed,unit),m=ctx.getTransform(),x=m.a*p.x+m.c*p.y+m.e,y=m.b*p.x+m.d*p.y+m.f,pad=size.width*Math.max(Math.abs(m.a),Math.abs(m.d));if(x+pad<0||x-pad>ctx.canvas.width||y+pad<0||y-size.height*Math.abs(m.d)>ctx.canvas.height)return false;ctx.save();if(meadowTreeOccludes(point,player,seed,unit))ctx.globalAlpha=.32;ctx.imageSmoothingEnabled=true;ctx.drawImage(treeSprite(size.id),p.x-size.width/2,p.y-size.height*375/384,size.width,size.height);ctx.restore();return true;}
/** Uses original pond center/radius and existing 24 barrier positions. */
export function paintMeadowPond(ctx:CanvasRenderingContext2D,center:P,radius:number,unit:number){
 const q=projectIso(center),ry=radius*.707,rx=radius*1.225;ctx.save();ctx.translate(q.x,q.y);const water=ctx.createRadialGradient(-rx*.18,-ry*.15,rx*.03,0,0,rx);water.addColorStop(0,'#6fc1d0');water.addColorStop(.6,'#88cfcb');water.addColorStop(1,'#c2ddd0');ctx.fillStyle=water;ctx.beginPath();ctx.ellipse(0,0,rx,ry,0,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#e1ebc6';ctx.lineWidth=unit*.35;ctx.stroke();
 for(let i=0;i<7;i++){const n=terrainSeed(i,73),x=(n%100/100-.5)*rx*1.1,y=((n>>>8)%100/100-.5)*ry;ctx.strokeStyle='#daf2df70';ctx.lineWidth=.8;ctx.beginPath();ctx.ellipse(x,y,unit*.8,unit*.3,0,.1,Math.PI*1.6);ctx.stroke();if(i%2===0){ctx.fillStyle='#83b86c';ctx.beginPath();ctx.ellipse(x+unit,y+unit*.4,unit*.48,unit*.22,-.2,0,Math.PI*1.85);ctx.fill();ctx.fillStyle='#f1dfce';ctx.beginPath();ctx.arc(x+unit,y+unit*.3,unit*.08,0,Math.PI*2);ctx.fill();}}
 ctx.restore();for(let i=0;i<24;i++){const a=i*Math.PI/12,p=projectIso({x:center.x+Math.cos(a)*radius,y:center.y+Math.sin(a)*radius});ctx.fillStyle=theme.stone[i%3];ctx.beginPath();ctx.ellipse(p.x,p.y-unit*.16,unit*.43,unit*.25,.2,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#66955f';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(p.x+unit*.45,p.y);ctx.lineTo(p.x+unit*.7,p.y-unit*.7);ctx.lineTo(p.x+unit*.65,p.y);ctx.lineTo(p.x+unit*.9,p.y-unit*.45);ctx.stroke();}
}
