import {it,expect,vi,afterEach} from 'vitest';
import registry from '../../public/data/rpg-characters-v4.json';
import {createModelWorld} from './model-world';
import {mountCharacterWorld} from './character-world';
import type {Resident} from '../game/core/world';
afterEach(()=>{vi.unstubAllGlobals();document.body.replaceChildren();});
it('replaces generic students with three activities and avoids duplicates on mobile resize',async()=>{
 vi.stubGlobal('fetch',vi.fn().mockResolvedValue({ok:true,json:async()=>structuredClone(registry)}));
 Object.defineProperty(window,'innerWidth',{value:1280,writable:true,configurable:true});
 const w=createModelWorld(1.5),map=w.maps.campus,npcs:Resident[]=[],player=map.spawns['campus-start'];
 const layer=mountCharacterWorld({read:()=>({map,npcs,player}),redraw:()=>{}});await layer.ready;
 expect(npcs).toHaveLength(7);expect(npcs.filter(n=>n.activity)).toHaveLength(3);expect(npcs.some(n=>n.id.startsWith('guide-student-'))).toBe(false);
 Object.defineProperty(window,'innerWidth',{value:390,writable:true});layer.onMapChange();layer.onMapChange();expect(npcs).toHaveLength(5);expect(new Set(npcs.map(n=>n.id)).size).toBe(5);
 layer.step(1000);layer.step(1100);const positions=npcs.filter(n=>n.activity).map(n=>({x:n.x,y:n.y,time:n.activityTime,sprite:n.spriteKey}));Object.defineProperty(window,'innerWidth',{value:1280,writable:true});layer.onMapChange();expect(npcs.filter(n=>n.activity).map(n=>({x:n.x,y:n.y,time:n.activityTime,sprite:n.spriteKey}))).toEqual(positions);const times=npcs.filter(n=>n.activity).map(n=>n.activityTime);
 const dialog=document.querySelector('dialog')!;dialog.showModal=()=>{};(document.querySelector('.character-entry') as HTMLButtonElement).click();layer.step(2000);expect(npcs.filter(n=>n.activity).map(n=>n.activityTime)).toEqual(times);
});
