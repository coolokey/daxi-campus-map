import {it,expect} from 'vitest';
import {createModelWorld} from './model-world';
import {clearSegment,walkable,canReach} from './navigation';
import layout from '../../public/data/parking-layout-v1.json';
it('blocks parked vehicles and shelter posts at every scale',()=>{for(const scale of [1,1.5,2]){const w=createModelWorld(scale),m=w.maps.campus,t=w.transforms.campus;for(const p of [{x:5.6,z:91.65},{x:5.7,z:95.3},{x:65.2,z:63.5},{x:81,z:57.3},{x:70.6,z:92.1},{x:4.3,z:90.82}])expect(walkable(t.toGame(p),m),JSON.stringify(p)).toBe(false);}});
it('leaves the two-wheel aisle, car aisle and accessible space clear',()=>{for(const scale of [1,1.5,2]){const w=createModelWorld(scale),m=w.maps.campus,t=w.transforms.campus;for(const [a,b] of [[{x:5,z:93.45},{x:34,z:93.45}],[{x:73.2,z:54.5},{x:73.2,z:86}],[{x:60.4,z:54.1},{x:60.4,z:80}]])expect(clearSegment(t.toGame(a),t.toGame(b),m)).toBe(true);expect(walkable(t.toGame({x:65.2,z:57.5}),m)).toBe(true);}});
it('exposes real reachable parking destinations on the shared campus map',()=>{for(const scale of [1,1.5,2]){const w=createModelWorld(scale),m=w.maps.campus;for(const p of layout.targets){const q=w.transforms.campus.toGame(p);expect(m.landmarks?.some(l=>l.label===p.name&&l.x===q.x&&l.y===q.y)).toBe(true);expect(canReach(m.spawns['campus-start'],q,m)).toBe(true);}}});
