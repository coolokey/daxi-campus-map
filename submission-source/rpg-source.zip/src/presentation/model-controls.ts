import type {MapConfig,SpawnPoint,NpcConfig} from '../game/data/types';
import type {ModelWorld} from './model-world';
export function createModelControls(host:{read:()=>{map:MapConfig;player:SpawnPoint};place:(map:MapConfig,p:SpawnPoint)=>void;openQuest:()=>Promise<void>;pause:()=>void},model:()=>ModelWorld){
 let lock:{map:string;x:number;y:number;at:number}|undefined;
 const dialogue=document.getElementById('dialogue')!,accept=document.createElement('button');accept.id='pilot-accept';accept.className='primary-button';accept.textContent='接受原版 5 題數學任務';accept.hidden=true;dialogue.append(accept);accept.onclick=()=>{dialogue.hidden=true;accept.hidden=true;void host.openQuest();};
 const mark=()=>{const s=host.read();lock={map:s.map.id,x:s.player.x,y:s.player.y,at:performance.now()};};
 return {directoryState:()=>({model:model()}),prompt:()=>`${host.read().map.displayName}・入口／樓梯按 E；校園建築可規劃路線`,closeDialogue:()=>{accept.hidden=true;},
 interact(npc:NpcConfig){if(!npc.id.startsWith('pilot-math-')&&!npc.id.startsWith('floor-mentor:'))return false;dialogue.querySelector('p')!.textContent=`${npc.name}・遊戲 NPC：${npc.dialogue}`;accept.hidden=false;dialogue.hidden=false;host.pause();accept.focus();return true;},
 canPortal:()=>!lock,onPortal:mark,step(now:number){const s=host.read();if(lock&&(s.map.id!==lock.map||(Math.hypot(s.player.x-lock.x,s.player.y-lock.y)>58&&now-lock.at>500)))lock=undefined;},
 enter(portal:MapConfig['portals'][number]){const next=model().maps[portal.destinationMapId];host.place(next,{...next.spawns[portal.destinationSpawnId]});mark();},reset:()=>{lock=undefined;}};
}
