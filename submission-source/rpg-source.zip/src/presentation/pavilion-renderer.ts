import {pavilion as L,pavilionRing,pavilionSeats} from './lan-pavilion';
import {modelTransform,projectIso} from './model-world';
import type {BoundaryObject} from './boundary-renderer';
type C={x:number;z:number};type P={x:number;y:number};
export function pavilionScene(ctx:CanvasRenderingContext2D,unit:number,u:number,player:P):BoundaryObject[]{
 const t=modelTransform({x:-162,z:-90},unit),objects:BoundaryObject[]=[],center=projectIso(t.toGame(L)),m=ctx.getTransform(),sx=m.a*center.x+m.c*center.y+m.e,sy=m.b*center.x+m.d*center.y+m.f,margin=unit*10*Math.max(Math.abs(m.a),Math.abs(m.d));
 if(sx+margin<0||sx-margin>ctx.canvas.width||sy+margin<0||sy-margin>ctx.canvas.height)return[];
 const p=(q:C,h=0)=>{const a=projectIso(t.toGame(q));return{x:a.x,y:a.y-h*unit*.85};};
 const poly=(ps:P[],fill:string,stroke?:string)=>{ctx.beginPath();ps.forEach((q,i)=>i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=u;ctx.stroke();}};
 const line=(a:P,b:P,color:string,width=1)=>{ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=color;ctx.lineWidth=width*u;ctx.stroke();};
 const box=(q:C,w:number,d:number,bottom:number,top:number,roof:string,side:string)=>{const c=[{x:q.x-w/2,z:q.z-d/2},{x:q.x+w/2,z:q.z-d/2},{x:q.x+w/2,z:q.z+d/2},{x:q.x-w/2,z:q.z+d/2}],a=c.map(v=>p(v,bottom)),b=c.map(v=>p(v,top));poly([b[1],b[2],a[2],a[1]],side);poly([b[2],b[3],a[3],a[2]],side);poly(b,roof);};
 const add=(q:C,draw:()=>void)=>{const g=t.toGame(q);objects.push({depth:g.x+g.y,draw});};
 // Ground and shallow stone plinth do not seal the open front entrance.
 poly(pavilionRing(4.7).map(q=>p({x:q.x+.5,z:q.z+.7})),'#3e513526');
 poly(pavilionRing(L.radius).map(q=>p(q,.08)),'#a7afa1','#7f8d83');
 for(const [dz,w] of [[4.2,2.8],[3.75,2.6]])box({x:L.x,z:L.z+dz},w,.6,0,.13,'#c5cbbb','#919e92');
 for(const {a,b} of pavilionSeats)add({x:(a.x+b.x)/2,z:(a.z+b.z)/2},()=>{line(p(a,.52),p(b,.52),'#9ca99a',6);for(const f of [.22,.78]){const q={x:a.x+(b.x-a.x)*f,z:a.z+(b.z-a.z)*f};line(p(q,.1),p(q,.52),'#8b978b',4);}});
 for(const q of pavilionRing(L.columnRadius))add(q,()=>{box(q,.62,.62,.08,.3,'#778276','#58655e');box(q,.42,.42,.3,4.02,'#c65e45','#a23f35');line(p({x:q.x-.08,z:q.z-.12},.35),p({x:q.x-.08,z:q.z-.12},3.95),'#db8e68',1.3);box(q,.65,.65,3.95,4.22,'#f0e7cf','#d6cfb9');});
 const rings=pavilionRing(3.35);
 for(let i=0;i<6;i++){const a=rings[i],b=rings[(i+1)%6],mid={x:(a.x+b.x)/2,z:(a.z+b.z)/2};add(mid,()=>{
  line(p(a,4.12),p(b,4.12),'#ece2c8',7);
  for(const h of [3.26,3.5,3.73])line(p(a,h),p(b,h),'#eee5ce',1.7);
  for(let j=1;j<8;j++){const f=j/8,q={x:a.x+(b.x-a.x)*f,z:a.z+(b.z-a.z)*f};line(p(q,3.27),p(q,3.74),'#f2ead8',1.25);}
 });}
 const roofDepth=Math.max(...pavilionRing(L.roofRadius).map(q=>{const g=t.toGame(q);return g.x+g.y;}));
 objects.push({depth:roofDepth,draw:()=>{
  const source=t.fromGame(player),underOrBehind=Math.hypot(source.x-L.x,source.z-L.z)<L.radius+.2||source.x+source.z<L.x+L.z;
  const foot=projectIso(player),top=p(L,L.roofTop),bottom=p(L,4.3),hidden=underOrBehind&&player.x+player.y<roofDepth&&Math.abs(foot.x-center.x)<unit*5.7&&foot.y>top.y-5*u&&foot.y-66*u<bottom.y+unit*2.3;
  ctx.save();if(hidden)ctx.globalAlpha=.28;
  const profile=[[.1,6.95],[.7,6.2],[1.8,5.25],[3.35,4.6],[4.3,4.42],[4.75,4.58]],faces=Array.from({length:6},(_,i)=>i).sort((a,b)=>{const ring=pavilionRing(3),aa=t.toGame(ring[a]),bb=t.toGame(ring[b]);return aa.x+aa.y-bb.x-bb.y;});
  for(const i of faces)for(let j=0;j<profile.length-1;j++){const [r,h]=profile[j],[r2,h2]=profile[j+1],a=i*Math.PI/3,b=(i+1)*Math.PI/3,q=(radius:number,angle:number)=>({x:L.x+Math.cos(angle)*radius,z:L.z+Math.sin(angle)*radius});poly([p(q(r,a),h),p(q(r,b),h),p(q(r2,b),h2),p(q(r2,a),h2)],['#8b493b','#9f5743','#b36e50','#a76249','#834237','#743e35'][i]);}
  for(let i=0;i<36;i++){const a=Math.floor(i/6)*Math.PI/3,b=a+Math.PI/3,f=(i%6)/6,points=profile.map(([r,h])=>p({x:L.x+r*((1-f)*Math.cos(a)+f*Math.cos(b)),z:L.z+r*((1-f)*Math.sin(a)+f*Math.sin(b))},h+.03));for(let k=1;k<points.length;k++)line(points[k-1],points[k],i%6?'#c28c64':'#ddaa78',i%6?.7:1.8);}
  for(const q of pavilionRing(4.75)){const vx=q.x-L.x,vz=q.z-L.z;line(p(q,4.58),p({x:L.x+vx*1.06,z:L.z+vz*1.06},4.98),'#8c4a39',3);}
  const finial=p(L,7.13);ctx.fillStyle='#8c4c3e';ctx.beginPath();ctx.ellipse(finial.x,finial.y,3*u,5*u,0,0,Math.PI*2);ctx.fill();ctx.restore();
 }});
 add({x:L.x,z:L.z+3.3},()=>{const q=p({x:L.x,z:L.z+3.3},3.96);ctx.save();ctx.fillStyle='#384338';ctx.fillRect(q.x-15*u,q.y-8*u,30*u,16*u);ctx.font=`bold ${12*u}px serif`;ctx.textAlign='center';ctx.fillStyle='#eed18a';ctx.fillText('蘭亭',q.x,q.y+4*u);ctx.restore();});
 return objects;
}
