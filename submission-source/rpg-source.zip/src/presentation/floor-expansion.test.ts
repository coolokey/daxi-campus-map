import { describe, it, expect } from 'vitest';
import shared from '../../public/data/campus.shared.json';
import runtime from '../../public/data/technology-demo-runtime.json';
import { createFloorExpansion } from './floor-expansion';
import { findPath, walkable } from './navigation';
import { createPilot } from './pilot-adapter';
import { addCampusEntrances } from './campus-entrances';
import { campusMap } from '../game/data/maps/campus';
import { scaleMap } from '../game/core/world';
import { nextPortal } from './campus-directory';

describe('plan checked floor expansion',()=>{
  it('all ten technology rooms and every art floor remain reachable, including a two-wing administration route',()=>{
    for(const scale of [1,1.5,2]){
      const pilot=createPilot(shared,runtime,scale),expanded=createFloorExpansion(shared,runtime,scale);
      expect(pilot.shared.rooms.find(r=>r.id==='tech-building:TC-NE-2')?.name).toBe('科技創作教室 (2F)');
      for(const room of pilot.shared.rooms.filter(r=>r.buildingId==='tech-building')){
        const id=room.floorId.endsWith('-1')?'pilot-tech-1':'pilot-tech-2',map=pilot.maps[id];
        expect(findPath(Object.values(map.spawns)[0],pilot.transforms[id].toGame(room.center),map),room.id).not.toBeNull();
      }
      expect(nextPortal(expanded.maps['floor-admin-front-1'],'floor-admin-front-3',expanded.maps)?.destinationMapId).toBe('floor-admin-back-1');
      const map=addCampusEntrances(scaleMap(campusMap,scale)),start=map.spawns['campus-start'];
      expect(map.portals.length).toBe(12);
      for(const p of map.portals)expect(findPath(start,{x:p.trigger.x+p.trigger.width/2,y:p.trigger.y+p.trigger.height/2},map),`${p.id}, scale ${scale}`).not.toBeNull();
    }
  });
  it('opens checked floors, preserves art 4F and withholds unverified activity-centre levels and respects horizontal grade 7 floor labels',()=>{
    const p=createFloorExpansion(shared,runtime,1);
    expect(p.shared.rooms.filter(r=>r.name.includes('待確認')).length).toBe(0);
    expect(p.maps['floor-admin-front-1'].floorPlan?.rooms.some(r=>r.name.includes('導師室（西側）'))).toBe(true);
    expect(p.maps['floor-admin-front-1'].floorPlan?.rooms.some(r=>r.name.includes('男女廁 (WC)'))).toBe(true);
    expect(p.maps['floor-art-building-4']).toBeDefined();
    expect(p.maps['floor-gym-bld-2']).toBeUndefined();
    expect(p.maps['floor-new-grade7-2']).toBeDefined();
    expect(p.targets['floor-new-grade7-2'].some(r=>r.name.startsWith('704'))).toBe(true);
    expect(p.targets['floor-new-grade7-3'].some(r=>r.name.startsWith('708'))).toBe(true);
    expect(p.targets['floor-new-grade7-3'].some(r=>r.name==='706 教室 (3F)')).toBe(true);
    expect(Object.keys(p.maps).length).toBe(28); // Technology floors remain in the existing adapter.
  });
  it('all connected spawns and room interiors are reachable at every world scale',()=>{
    for(const scale of [1,1.5,2]){
      const p=createFloorExpansion(shared,runtime,scale);
      for(const map of Object.values(p.maps)){
        for(const spawn of Object.values(map.spawns))expect(walkable(spawn,map),`${map.id} spawn`).toBe(true);
        const start=map.spawns.entry;
        for(const target of p.targets[map.id])expect(findPath(start,target.point,map),`${map.id}: ${target.name}`).not.toBeNull();
        for(const portal of map.portals){
          if(portal.destinationMapId==='campus')continue;
          const dest=p.maps[portal.destinationMapId];
          expect(dest?.spawns[portal.destinationSpawnId],`${portal.id} destination`).toBeDefined();
          expect(findPath(start,{x:portal.trigger.x+18,y:portal.trigger.y+18},map),`${portal.id} reachable`).not.toBeNull();
        }
      }
    }
  });
  it('routes around a wall and reports an enclosed destination',()=>{
    const map={width:300,height:300,collisionZones:[{x:140,y:40,width:20,height:220}]};
    const route=findPath({x:80,y:150},{x:220,y:150},map)!;
    expect(route.length).toBeGreaterThan(2);
    expect(route.every(p=>walkable(p,map))).toBe(true);
    route.forEach((p,i)=>{if(i)expect(p.x===route[i-1].x||p.y===route[i-1].y,'manual keyboard routes use axis-aligned turns').toBe(true);});
    expect(findPath({x:80,y:150},{x:150,y:150},map)).toBeNull();
  });
});
