import theme from '../../public/data/woodland-theme-v1.json';
// Stable building IDs keep all wings of a building in the same material family.
const LEGACY_MATERIALS:Record<string,{wall:string;side:string;roof:string}>={
 'gym-bld':{wall:'#a7c8ed',side:'#7ea6d1',roof:'#547eaf'},
 'recycle-bld':{wall:'#bad995',side:'#94b774',roof:'#6e9252'},
 'admin-front':{wall:'#f4cf89',side:'#dcad67',roof:'#b98649'},
 'health-bld':{wall:'#f4b8c4',side:'#d795a6',roof:'#ae6d87'},
 'grade8-front':{wall:'#c3b7e9',side:'#a296cd',roof:'#7c6da8'},
 'grade9-back':{wall:'#efb59a',side:'#cf927b',roof:'#ab6f58'},
 'grade8-mid':{wall:'#a6d8cc',side:'#7ab6aa',roof:'#548b86'},
 'new-grade7':{wall:'#c7d98e',side:'#a7bb6f',roof:'#7f944f'},
 'multi-building':{wall:'#e8bbd6',side:'#ca97b8',roof:'#a36e94'},
 'tech-building':{wall:'#99d5e5',side:'#72b4c9',roof:'#477f9f'},
 'art-building':{wall:'#f1cea7',side:'#d6aa7e',roof:'#b4855b'},
};
export const BUILDING_MATERIALS=Object.fromEntries(Object.entries(theme.buildings).map(([id,style])=>[id,{...theme.materials,...style}])) as Record<string,typeof theme.materials&{accent:string;entry:string}>;
export const buildingMaterial=(id:string,original=false)=>{const material=BUILDING_MATERIALS[id]??{...theme.materials,accent:'#8b785b',entry:'wood'};return original?{...material,...LEGACY_MATERIALS[id]}:material;};
export {theme as woodlandTheme};
