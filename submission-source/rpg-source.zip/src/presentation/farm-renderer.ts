import {farmLayout as F,farmFences,type FarmRect} from './campus-farm';
import {modelTransform,projectIso} from './model-world';
import type {BoundaryObject} from './boundary-renderer';
const cropSprites=new Map<string,HTMLCanvasElement>();
function cropSprite(id:string,stage:string){
 const key=id+stage,saved=cropSprites.get(key);if(saved)return saved;const cv=document.createElement('canvas');cv.width=96;cv.height=112;const c=cv.getContext('2d')!;
 const leaf=(x:number,y:number,rx:number,ry:number,angle:number,color:string)=>{c.fillStyle=color;c.beginPath();c.ellipse(x,y,rx,ry,angle,0,Math.PI*2);c.fill();};
 c.fillStyle='#3c4b282d';c.beginPath();c.ellipse(48,99,28,8,0,0,Math.PI*2);c.fill();
 if(stage==='young'){c.strokeStyle='#749a43';c.lineWidth=4;c.beginPath();c.moveTo(48,99);c.lineTo(48,77);c.stroke();leaf(36,77,15,7,.45,'#9ec561');leaf(59,72,16,7,-.5,'#7eaf4f');}
 else if(id==='tomato'){c.strokeStyle='#a78550';c.lineWidth=4;c.beginPath();c.moveTo(50,99);c.lineTo(50,13);c.stroke();c.strokeStyle='#5c8b3f';c.lineWidth=3;c.beginPath();c.moveTo(46,98);c.quadraticCurveTo(36,53,52,23);c.stroke();for(let i=0;i<6;i++){const x=i%2?61:32,y=32+i*10;leaf(x,y,15,6,i%2?-.5:.5,i%2?'#7da64e':'#588c40');if(i%2){leaf(x-6,y+12,7,8,0,'#d67953');leaf(x-8,y+10,3,2,0,'#ecb66e');}}}
 else if(id==='pumpkin'){c.strokeStyle='#6f9644';c.lineWidth=4;c.beginPath();c.moveTo(20,97);c.quadraticCurveTo(50,68,80,94);c.stroke();leaf(26,79,18,9,-.35,'#83aa51');leaf(72,75,16,9,.45,'#638e44');leaf(49,85,22,18,0,'#dda34d');for(const dx of [-12,0,12]){c.strokeStyle='#bd7f38';c.lineWidth=2;c.beginPath();c.ellipse(49+dx*.2,85,Math.abs(dx)+4,17,0,0,Math.PI*2);c.stroke();}c.strokeStyle='#688544';c.lineWidth=4;c.beginPath();c.moveTo(49,68);c.lineTo(53,61);c.stroke();}
 else if(id==='carrot'){c.fillStyle='#e29a53';c.beginPath();c.moveTo(37,83);c.lineTo(60,83);c.lineTo(48,105);c.closePath();c.fill();for(let i=0;i<7;i++)leaf(48+(i-3)*5,68-Math.abs(i-3)*2,6,23,(i-3)*.22,i%2?'#87ac4c':'#5c8b3f');}
 else if(id==='herbs'){for(let i=0;i<5;i++){const x=25+i*11,y=94-i%2*7;c.strokeStyle='#64894b';c.lineWidth=2.5;c.beginPath();c.moveTo(x,y);c.lineTo(x-3,36);c.stroke();for(let k=0;k<4;k++){leaf(x-9,48+k*12,10,5,.4,'#8ab371');leaf(x+6,53+k*11,10,5,-.4,'#689d60');}leaf(x-3,33,4,7,0,'#c6b4d4');}}
 else if(id==='seedling'){c.fillStyle='#9c8055';c.fillRect(15,73,66,29);for(let i=0;i<6;i++){const x=27+i%3*21,y=82+Math.floor(i/3)*14;c.fillStyle='#6e5137';c.fillRect(x-8,y-5,16,10);leaf(x-5,y-8,8,4,.4,'#9dbc62');leaf(x+5,y-11,8,4,-.4,'#7da84e');}}
 else {for(let i=0;i<9;i++){const a=i*Math.PI*2/9;leaf(48+Math.cos(a)*14,83+Math.sin(a)*9,19,10,a,i%2?'#91b951':'#6b9f46');}leaf(48,77,14,13,0,'#b2cd71');leaf(46,74,8,8,0,'#95bb57');}
 cropSprites.set(key,cv);return cv;
}
export function farmScene(ctx:CanvasRenderingContext2D,unit:number,u:number,player:{x:number;y:number}):BoundaryObject[]{
 const t=modelTransform({x:-162,z:-90},unit),objects:BoundaryObject[]=[],v=unit*1.2;
 const point=(p:{x:number;z:number},h=0)=>{const q=projectIso(t.toGame(p));return {x:q.x,y:q.y-h*v};};
 const corners=(r:FarmRect)=>[{x:r.x0,z:r.z0},{x:r.x1,z:r.z0},{x:r.x1,z:r.z1},{x:r.x0,z:r.z1}];
 const poly=(ps:{x:number;y:number}[],color:string,stroke?:string)=>{ctx.beginPath();ps.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=color;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=.8*u;ctx.stroke();}};
 const surface=(r:FarmRect,color:string,h=0,stroke?:string)=>poly(corners(r).map(p=>point(p,h)),color,stroke);
 const box=(r:FarmRect,h:number,color:string,roof:string,bottom=0)=>{const c=corners(r),a=c.map(p=>point(p,bottom)),b=c.map(p=>point(p,h));poly([a[1],a[2],b[2],b[1]],color);poly([a[2],a[3],b[3],b[2]],color);poly(b,roof,'#7d7354');};
 const center=(r:FarmRect)=>({x:(r.x0+r.x1)/2,z:(r.z0+r.z1)/2});
 const rect=(x:number,z:number,w:number,d:number)=>({x0:x-w/2,x1:x+w/2,z0:z-d/2,z1:z+d/2});
 const line=(a:{x:number;z:number},b:{x:number;z:number},color:string,width:number,h=0)=>{const p=point(a,h),q=point(b,h);ctx.strokeStyle=color;ctx.lineWidth=width*u;ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.stroke();};
 const label=(p:{x:number;z:number},text:string,h=0,size=9)=>{const q=point(p,h);ctx.font=`600 ${size*u}px system-ui`;ctx.textAlign='center';const w=ctx.measureText(text).width+12*u;ctx.fillStyle='#fff5dfee';ctx.fillRect(q.x-w/2,q.y-14*u,w,20*u);ctx.fillStyle='#49623b';ctx.fillText(text,q.x,q.y);};
 const camera=ctx.getTransform();
 const visible=(r:FarmRect,h=0)=>{const q=corners(r).flatMap(p=>[point(p),point(p,h)]).map(p=>({x:camera.a*p.x+camera.c*p.y+camera.e,y:camera.b*p.x+camera.d*p.y+camera.f}));return !(Math.max(...q.map(p=>p.x))<-50||Math.min(...q.map(p=>p.x))>ctx.canvas.width+50||Math.max(...q.map(p=>p.y))<-50||Math.min(...q.map(p=>p.y))>ctx.canvas.height+50);};
 const add=(r:FarmRect,h:number,draw:()=>void)=>{if(!visible(r,h))return;const p=t.toGame({x:r.x1,z:r.z1});objects.push({depth:p.x+p.y,draw:()=>{ctx.save();draw();ctx.restore();}});};
 if(!visible(F.bounds,3))return objects;
 surface(F.bounds,'#b8bf87');surface(F.path,'#d5c092');
 for(let i=0;i<5;i++)surface({x0:-106.7+i*9.3,x1:-104.7+i*9.3,z0:-73.5,z1:-57.5},'#d2bd90');
 for(const bed of F.beds){const r=bed.rect,crop=F.crops.find(c=>c.id===bed.crop)!;if(!visible(r,2))continue;box(r,.24,'#ab8b5b','#b99a65');surface({x0:r.x0+.17,x1:r.x1-.17,z0:r.z0+.17,z1:r.z1-.17},'#79583a',.25);for(let z=r.z0+.55;z<r.z1;z+=.75)line({x:r.x0+.25,z},{x:r.x1-.25,z},'#a27b4c',1,.26);
  // Bed surfaces are ground; only upright crops join the actor depth queue.

  for(let x=0;x<6;x++)for(let z=0;z<3;z++){const p={x:r.x0+.65+x*(r.x1-r.x0-1.3)/5,z:r.z0+.55+z*(r.z1-r.z0-1.1)/2};add(rect(p.x,p.z,.4,.4),1.6,()=>{const q=point(p,.26),width=unit*1.1,height=unit*(bed.stage==='young'?.65:bed.crop==='tomato'?1.6:1.15);ctx.imageSmoothingEnabled=true;ctx.drawImage(cropSprite(bed.crop,bed.stage),q.x-width/2,q.y-height*.9,width,height);});}
  if(bed.stage==='mature')add(rect((r.x0+r.x1)/2,r.z1,.2,.2),.7,()=>label({x:(r.x0+r.x1)/2,z:r.z1+.25},crop.name,.45));
 }
 for(const r of farmFences){const horizontal=r.x1-r.x0>r.z1-r.z0,length=horizontal?r.x1-r.x0:r.z1-r.z0,n=Math.max(1,Math.ceil(length/4));for(let i=0;i<n;i++){const p=(j:number)=>horizontal?{x:r.x0+length*j/n,z:(r.z0+r.z1)/2}:{x:(r.x0+r.x1)/2,z:r.z0+length*j/n},a=p(i),b=p(i+1);add(rect((a.x+b.x)/2,(a.z+b.z)/2,horizontal?length/n:.2,horizontal?.2:length/n),1.1,()=>{for(const h of [.4,.82])line(a,b,'#ad8f5f',2,h);for(const p of [a,b])box(rect(p.x,p.z,.18,.18),1.05,'#a18455','#d3bb84');});}}
 for(const fixture of F.fixtures){const r=fixture.rect,p=center(r);add(r,3,()=>{
  if(fixture.id==='water'){box(r,.9,'#9ba88c','#c1c3a4');surface({x0:r.x0+.3,x1:r.x1-.3,z0:r.z0+.3,z1:r.z1-.3},'#83bfc0',.92,'#d9dfbc');for(let i=0;i<3;i++)line({x:r.x0+.7,z:r.z0+.7+i*.6},{x:r.x1-.7,z:r.z0+.7+i*.6},'#cce6d0',.7,.93);label(p,'灌溉水槽',1.2);}
  else if(fixture.id==='compost'){box(r,.8,'#9c7b4d','#795f3b');for(let i=1;i<4;i++)line({x:r.x0,z:r.z1},{x:r.x1,z:r.z1},'#c5a471',1,i*.18);surface({x0:r.x0+.3,x1:r.x1-.3,z0:r.z0+.3,z1:r.z1-.3},'#7c8451',.82);label(p,'堆肥區',1.2);}
  else if(fixture.id==='crates'){for(let i=0;i<2;i++)box(rect(p.x+(i-.5)*1.15,p.z,.95,1.2),.5,'#b48f51','#dac18a');for(let i=0;i<5;i++){const q=point({x:p.x+(i%3-.9)*.55,z:p.z+(i%2-.5)*.55},.6);ctx.fillStyle=i%2?'#dd9f4c':'#9db55c';ctx.beginPath();ctx.arc(q.x,q.y,unit*.15,0,Math.PI*2);ctx.fill();}}
  else if(fixture.id==='tools'){for(const x of [r.x0,r.x1])box(rect(x,p.z,.2,.2),2.1,'#9b7a4e','#c6ae7d');line({x:r.x0,z:p.z},{x:r.x1,z:p.z},'#b79764',3,1.9);for(let i=0;i<3;i++){const x=r.x0+.6+i*.85;const a=point({x,z:p.z},.25),b=point({x,z:p.z},1.8);ctx.strokeStyle='#bca16b';ctx.lineWidth=2*u;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.fillStyle='#819c94';ctx.fillRect(a.x-unit*.15,a.y-unit*.1,unit*.3,unit*.45);}label(p,'農具角',2.4);}
  else if(fixture.id==='scarecrow'){box(r,2.3,'#9f7e4f','#b79c61');const q=point(p,1.6);ctx.strokeStyle='#9d6952';ctx.lineWidth=unit*.23;ctx.beginPath();ctx.moveTo(q.x-unit*.65,q.y);ctx.lineTo(q.x+unit*.65,q.y);ctx.stroke();ctx.fillStyle='#7196a1';ctx.fillRect(q.x-unit*.28,q.y,unit*.56,unit*.6);const head=point(p,2.15);ctx.fillStyle='#d1b881';ctx.beginPath();ctx.arc(head.x,head.y,unit*.29,0,Math.PI*2);ctx.fill();ctx.fillStyle='#ba9654';ctx.fillRect(head.x-unit*.45,head.y-unit*.27,unit*.9,unit*.1);ctx.beginPath();ctx.moveTo(head.x-unit*.3,head.y-unit*.3);ctx.lineTo(head.x,head.y-unit*.6);ctx.lineTo(head.x+unit*.3,head.y-unit*.3);ctx.closePath();ctx.fill();}
  else {box(r,2.6,'#a48652','#cdb579');box(rect(p.x,p.z,4.4,.2),2.6,'#bda66f','#d5c188',1.65);label(p,'開心農場',4,12);label(p,'技藝教育・農業職群',2.2,10);}
 });}
 label({x:-116,z:-70.5},'育苗示範',.5,9);return objects;
}
