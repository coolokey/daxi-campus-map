import layout from '../../public/data/campus-farm-v1.json';
import {findPath} from './navigation';
import type {MapConfig} from '../game/data/types';
export const farmLayout=layout;
export type FarmRect={x0:number;x1:number;z0:number;z1:number};
const b=layout.bounds,g=layout.gate,w=.18;
export const farmFences:FarmRect[]=[{x0:b.x0,x1:b.x1,z0:b.z0-w/2,z1:b.z0+w/2},{x0:b.x0,x1:b.x1,z0:b.z1-w/2,z1:b.z1+w/2},{x0:b.x0-w/2,x1:b.x0+w/2,z0:b.z0,z1:b.z1},{x0:b.x1-w/2,x1:b.x1+w/2,z0:b.z0,z1:g.z0},{x0:b.x1-w/2,x1:b.x1+w/2,z0:g.z1,z1:b.z1}];
export const farmSolids=[...layout.beds.map(p=>p.rect),...layout.fixtures.map(p=>p.rect),...farmFences];
export function attachFarmApproach(map:MapConfig,t:{unit:number;toGame:(p:{x:number;z:number})=>{x:number;y:number}}){const path=findPath(t.toGame(layout.approach[0]),t.toGame(layout.target),map);if(!path)throw Error('Farm entrance is unreachable');(map.outdoorPaths??=[]).push({id:'farm-approach',label:'農場入口步道',points:path,width:2.8*t.unit});}
