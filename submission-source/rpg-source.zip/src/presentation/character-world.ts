import {modelRoamingRoutes,projectIso,modelGuardPoint} from './model-world';
import type { MapConfig } from '../game/data/types';
import type { Resident } from '../game/core/world';
import { actorFrame, chooseRoster, shuffleRoster, DIRECTIONS, searchRoster, validateRegistry, validateRoute, type Character, type Facing, type Point } from './character-runtime';
import './character-world.css';
import { viewport, screenUnit } from './viewport';
import { mountDialoguePortrait } from './dialogue-portrait';
import { nearestInRange } from './interaction-target';

type Actor = Point & {id?:string;name?:string;direction?:string;spriteKey?:string};
type Host={read:()=>{map:MapConfig;player:Actor;npcs:Resident[]};redraw:()=>void};
type Sprite={image:HTMLImageElement;state:'loading'|'ready'|'error';promise:Promise<void>};
const roleLabels:Record<Character['role'],string>={teacher:'教師',student:'學生',guard:'校門警衛',player:'玩家',robot:'巡邏機器人'};
const storageKey='campus:rpg-player';
const players=['player-male-uniform','player-female-uniform','player-male-casual','player-female-casual'];
const playerLabels=['男生・制服','女生・制服','男生・便服','女生・便服'];
const el=<K extends keyof HTMLElementTagNameMap>(tag:K,text?:string)=>{const node=document.createElement(tag);if(text)node.textContent=text;return node;};

/** Deferred original-map character layer. Never changes the player position or source map. */
export function mountCharacterWorld(host:Host){
  let roster:Character[]=[],rotationRoster:Character[]=[],currentMap:MapConfig|undefined,page=0,lastRotation=0,now=0,loaded=false;
  let anchor:Point={x:32,y:77.0177039725223};
  let mobileLayout=window.innerWidth<700;
  let selected=players[0],invited:string|undefined,pendingInvite:string|undefined,paused=false;
  try{const saved=localStorage.getItem(storageKey);if(saved&&players.includes(saved))selected=saved;}catch{/* Storage can be disabled in an embedded browser. */}
  const sprites=new Map<string,Sprite>(),samples=new Map<string,{point:Point;frame:ReturnType<typeof actorFrame>}>();
  const entry=el('button','校園角色');entry.type='button';entry.className='character-entry';entry.disabled=true;
  const dialog=el('dialog');dialog.className='character-dialog';dialog.setAttribute('aria-labelledby','character-heading');
  const header=el('header'),title=el('h2','校園角色');title.id='character-heading';
  const close=el('button','關閉');close.type='button';close.className='character-close';header.append(title,close);
  const intro=el('p','角色由導覽素材改編，服裝為 RPG 創意造型，位置為遊戲示意。');intro.className='character-intro';
  const status=el('p','正在載入角色名冊……');status.className='character-status';status.setAttribute('role','status');
  const retry=el('button','重試載入角色');retry.type='button';retry.hidden=true;
  retry.onclick=()=>{void loadRoster();};
  const playerSection=el('section'),playerHeading=el('h3','我的角色'),choices=el('div');choices.className='character-choices';
  playerSection.append(playerHeading,choices);
  const rosterSection=el('section'),rosterHeading=el('h3','校園名冊'),search=el('input');search.type='search';search.placeholder='搜尋姓名、職稱或導覽目的地';search.setAttribute('aria-label','搜尋校園名冊');
  const filter=el('select');filter.setAttribute('aria-label','角色類別');
  for(const [value,label] of [['all','全部角色'],['teacher','教師'],['student','學生'],['guard','警衛'],['player','玩家'],['robot','機器人']]){const option=el('option',label);option.value=value;filter.append(option);}
  const searchRow=el('div');searchRow.className='character-search';searchRow.append(search,filter);
  const resultCount=el('p'),list=el('div');resultCount.className='character-result-count';list.className='character-list';rosterSection.append(rosterHeading,searchRow,resultCount,list);
  dialog.append(header,intro,status,retry,playerSection,rosterSection);
  (document.querySelector('.explore-toolbar')??document.body).append(entry);
  document.body.append(dialog);
  function announce(text:string){status.textContent=text;}
  function setPaused(value:boolean){paused=value;window.dispatchEvent(new CustomEvent('campus:map-open',{detail:value}));}
  entry.onclick=()=>{dialog.showModal();setPaused(true);search.focus();renderRoster();};
  close.onclick=()=>dialog.close();dialog.addEventListener('close',()=>{setPaused(false);entry.focus();host.redraw();});
  dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}});
  search.oninput=filter.onchange=renderRoster;
  const dialogue=document.getElementById('dialogue');
  const refreshPortrait=dialogue?mountDialoguePortrait(dialogue,()=>{
    const {npcs,player}=host.read(),npc=nearestInRange(npcs,player);
    const c=npc?characterFor(npc,false):undefined;return c&&npc?{...c,name:npc.name}:undefined;
  }):()=>{};

  function sprite(character:Character,priority:'high'|'low'|'auto'='auto'):Sprite{
    const cached=sprites.get(character.id);if(cached)return cached;
    const image=new Image(),item:Sprite={image,state:'loading',promise:Promise.resolve()};image.fetchPriority=priority;
    item.promise=new Promise(resolve=>{
      image.onload=()=>{item.state=image.naturalWidth===512&&image.naturalHeight===264?'ready':'error';if(item.state==='error'){announce(`${character.name} 圖集尺寸不符，請重試載入角色。`);retry.hidden=false;}resolve();host.redraw();};
      image.onerror=()=>{item.state='error';announce(`${character.name} 圖像載入失敗，請重試載入角色。`);retry.hidden=false;resolve();host.redraw();};
    });
    sprites.set(character.id,item);image.src=new URL(character.atlas,document.baseURI).href;return item;
  }
  function renderChoices(){
    choices.replaceChildren();
    players.forEach((id,index)=>{
      const button=el('button',playerLabels[index]);button.type='button';button.className='character-choice';button.setAttribute('aria-pressed',String(selected===id));
      button.onclick=()=>{selected=id;try{localStorage.setItem(storageKey,id);}catch{}const c=roster.find(c=>c.id===id);if(c)sprite(c);renderChoices();host.redraw();announce(`已選擇${playerLabels[index]}，關閉名冊即可繼續探索。`);};choices.append(button);
    });
  }
  function renderRoster(){
    const matches=searchRoster(roster,search.value).filter(c=>filter.value==='all'||filter.value===c.role);
    resultCount.textContent=`顯示 ${matches.length}／${roster.length} 位角色；教師全名冊 ${roster.filter(c=>c.role==='teacher').length} 位。`;
    list.replaceChildren();
    for(const c of matches){
      const card=el('article');card.className='character-card';const content=el('div'),name=el('strong',c.name),meta=el('p',[roleLabels[c.role],c.title,'導覽角色・位置為遊戲示意'].filter(Boolean).join('・'));
      content.append(name,meta);card.append(content);
      if(c.role==='teacher'){
        const invite=el('button',pendingInvite===c.id?'等待安全入場':'邀請到校園');invite.type='button';invite.disabled=pendingInvite===c.id;
        invite.onclick=()=>{
          pendingInvite=c.id;invited=c.id;
          const campus=host.read().map.id==='campus';
          if(campus)applyInvitation();
          announce(campus?`${c.name} 已受邀；會在離玩家較遠的安全道路入場。`:`已邀請 ${c.name}；返回戶外校園後即可遇見。`);
          renderRoster();host.redraw();
        };card.append(invite);
      }else card.append(el('span',c.role==='player'?'上方可選擇':'校園角色'));
      list.append(card);
    }
  }
  function routes(map:MapConfig):Point[][]{
    if(map.backgroundKey==='latest-model-v2')return modelRoamingRoutes(map);
    const sx=map.width/2400,sy=map.height/1624;
    const candidates=[
      // 1. Sports field running track (西側操場跑道東段)
      [{x:720,y:950},{x:720,y:750},{x:720,y:530}],
      // 2. Sports field turf center (西側操場草皮中段)
      [{x:550,y:400},{x:550,y:700}],
      // 3. Sports field south walkway (操場南側跑道步道)
      [{x:450,y:960},{x:720,y:960}],
      // 4. North basketball court (北側籃球場活動環線)
      [{x:1560,y:350},{x:1740,y:350},{x:1740,y:520},{x:1560,y:520}],
      // 5. North volleyball court (北側排球場運動步道)
      [{x:1340,y:330},{x:1340,y:520}],
      // 6. Central boulevard mid (中央林蔭大道)
      [{x:1090,y:960},{x:1090,y:1350}],
      // 7. Main entrance avenue (校門中央迎賓步道)
      [{x:1280,y:1420},{x:1280,y:1530}],
    ].map(route=>route.map(p=>({x:p.x*sx,y:p.y*sy})));
    const avoidsPortals=(route:Point[])=>route.every((start,i)=>{
      const end=route[(i+1)%route.length],steps=Math.ceil(Math.hypot(end.x-start.x,end.y-start.y)/5);
      for(let step=0;step<=steps;step++){
        const x=start.x+(end.x-start.x)*step/steps,y=start.y+(end.y-start.y)*step/steps;
        if(map.portals.some(({trigger:r})=>x>r.x-45&&x<r.x+r.width+45&&y>r.y-45&&y<r.y+r.height+45))return false;
      }return true;
    });
    return candidates.filter(route=>validateRoute(route,map)&&avoidsPortals(route));
  }
  function setIdentity(npc:Resident,c:Character){
    npc.name=c.name;npc.spriteKey=c.id;npc.kind=c.role==='teacher'?'teacher':c.role==='guard'?'guard':'student';
    npc.dialogue=c.role==='guard'?'同學好！歡迎來到大溪國中未來校園。請沿著中央林蔭大道參觀，或點擊左上方「校園建築」查看各大樓教室與專科教室。':`我是${c.name}${c.title?`（${c.title}）`:''}。位置與穿著為遊戲示意。沿道路前往科技館，可接受數學任務。`;
    sprite(c);
  }
  function warmNextBatch(){
    const map=currentMap,batch=page;
    if(map?.id!=='campus')return;
    // Wait for the player/current cohort before warming a bounded future cohort.
    void Promise.all([...sprites.values()].map(s=>s.promise)).then(()=>{
      if(currentMap!==map||page!==batch)return;
      const mobile=window.innerWidth<700;
      [...chooseRoster(rotationRoster,'teacher',batch+1,mobile?1:3,invited?[invited]:[]),...chooseRoster(rotationRoster,'student',batch+1,mobile?2:3)].forEach(c=>sprite(c,'low'));
    });
  }
  function onMapChange(){
    const state=host.read(),mobile=window.innerWidth<700;if(!loaded||(currentMap===state.map&&mobile===mobileLayout))return;
    currentMap=state.map;mobileLayout=mobile;samples.clear();
    if(state.map.id!=='campus')return;
    const paths=routes(state.map);
    if(!paths.length){announce('目前地圖沒有通過碰撞檢查的角色路線，暫停新增角色。');return;}
    // Rebuild only this layer's actors and former generic students.
    for(let i=state.npcs.length-1;i>=0;i--)if(state.npcs[i].id.startsWith('guide-')||['student-explorer','student-science'].includes(state.npcs[i].id))state.npcs.splice(i,1);
    const cohort=[...chooseRoster(rotationRoster,'teacher',page,mobile?1:3,invited?[invited]:[]),...chooseRoster(rotationRoster,'student',page,mobile?2:3),...chooseRoster(roster,'guard',0,1)];
    cohort.forEach((c,i)=>{
      const gateRoute=state.map.backgroundKey==='latest-model-v2'?[modelGuardPoint(state.map)]:[{x:1340,y:1540}].map(p=>({x:p.x*state.map.width/2400,y:p.y*state.map.height/1624}));
      const route=c.role==='guard'&&validateRoute(gateRoute,state.map)?gateRoute:paths[i%paths.length];
      // Spread actors along the complete loop, even when collision checks leave only one route.
      const pathIndex=i%paths.length,slot=Math.floor(i/paths.length),slots=Math.ceil((cohort.length-pathIndex)/paths.length);
      const lengths=route.map((p,j)=>Math.hypot(route[(j+1)%route.length].x-p.x,route[(j+1)%route.length].y-p.y));
      const spreadLength=route.length===2?lengths[0]:lengths.reduce((a,b)=>a+b,0);
      let distance=c.role==='guard'?0:spreadLength*(state.map.backgroundKey==='latest-model-v2'?(i+1)/(cohort.length+1):slot/slots),segment=0;
      while(segment<route.length-1&&distance>lengths[segment]){distance-=lengths[segment];segment++;}
      const a=route[segment],b=route[(segment+1)%route.length],fraction=distance/Math.max(1,lengths[segment]);
      const start={x:a.x+(b.x-a.x)*fraction,y:a.y+(b.y-a.y)*fraction};
      const ordered=[start,...route.slice(segment+1),...route.slice(0,segment+1)];
      const npc:Resident={id:`guide-${c.role}-${i}`,mapId:state.map.id,...start,direction:c.role==='guard'?'up':'down',spriteKey:c.id,portraitKey:c.id,name:c.name,interactionRadius:76,dialogueId:'guide-character',route:ordered,speed:c.role==='guard'?0:38+(i%4)*7,waypoint:1,wait:i*.3,moving:false};
      setIdentity(npc,c);state.npcs.push(npc);
    });
    pendingInvite=undefined;
    if(lastRotation)warmNextBatch();
  }
  function applyInvitation(){
    if(!pendingInvite)return;
    const state=host.read(),c=roster.find(c=>c.id===pendingInvite);if(!c||state.map.id!=='campus')return;
    if(state.npcs.some(n=>n.spriteKey===c.id)){pendingInvite=undefined;return;}
    const slot=state.npcs.find(n=>n.id.startsWith('guide-teacher-')&&Math.hypot(n.x-state.player.x,n.y-state.player.y)>150);
    if(slot){setIdentity(slot,c);pendingInvite=undefined;}
  }
  function characterFor(actor:Actor,isPlayer:boolean){
    if(isPlayer)return roster.find(c=>c.id===selected);
    const exact=roster.find(c=>c.id===actor.spriteKey||c.id===actor.id);if(exact)return exact;
    if(actor.id==='math-researcher')return roster.find(c=>c.role==='teacher');
    if(actor.id?.includes('robot')||actor.spriteKey==='robot')return roster.find(c=>c.role==='robot');
    return roster.find(c=>c.role==='teacher');
  }
  const sampleKey=(actor:Actor,isPlayer:boolean)=>isPlayer?'player':actor.id??actor.spriteKey??actor.name??'npc';
  function step(time:number){
    now=time;onMapChange();if(!loaded||paused)return;
    if(!lastRotation){lastRotation=time;warmNextBatch();}
    const state=host.read();
    if(state.map.id==='campus'){
      applyInvitation();
      if(time-lastRotation>14000){
        lastRotation=time;page++;
        const mobile=window.innerWidth<700,teachers=chooseRoster(rotationRoster,'teacher',page,mobile?1:3,invited?[invited]:[]),students=chooseRoster(rotationRoster,'student',page,mobile?2:3);
        for(const role of ['teacher','student'] as const){
          const cohort=role==='teacher'?teachers:students;
          state.npcs.filter(n=>n.id.startsWith(`guide-${role}-`)).forEach((n,i)=>{
            const c=cohort[i];if(c&&!state.npcs.some(other=>other!==n&&other.spriteKey===c.id)&&Math.hypot(n.x-state.player.x,n.y-state.player.y)>150)setIdentity(n,c);
          });
        }
        warmNextBatch();
      }
    }
    for(const actor of [...state.npcs,state.player]){
      const key=sampleKey(actor,actor===state.player),previous=samples.get(key),facing=previous?.frame.direction??(DIRECTIONS.includes(actor.direction as Facing)?actor.direction as Facing:'down');
      const point=state.map.backgroundKey==='latest-model-v2'?projectIso(actor):actor;
      samples.set(key,{point:{...point},frame:actorFrame(previous?.point??point,point,time,facing)});
    }
  }
  function draw(ctx:CanvasRenderingContext2D,actor:Actor,isPlayer=false):boolean{
    if(!loaded)return false;
    const c=characterFor(actor,isPlayer);if(!c)return false;
    const transform=ctx.getTransform(),x=actor.x*transform.a+transform.e,y=actor.y*transform.d+transform.f;
    if(x< -80*viewport.pixelRatio||x>ctx.canvas.width+80*viewport.pixelRatio||y< -80*viewport.pixelRatio||y>ctx.canvas.height+100*viewport.pixelRatio)return true;
    const item=sprite(c),sample=samples.get(sampleKey(actor,isPlayer)),fallback=DIRECTIONS.includes(actor.direction as Facing)?actor.direction as Facing:'down';
    const frame=sample?.frame??actorFrame(actor,actor,now,fallback);
    ctx.save();ctx.translate(actor.x,actor.y);const unit=screenUnit(transform.a);ctx.scale(unit,unit);
    ctx.fillStyle='#28472c33';ctx.beginPath();ctx.ellipse(0,-2,15,5,0,0,Math.PI*2);ctx.fill();
    if(item.state==='ready'){
      ctx.imageSmoothingEnabled=true;
      ctx.drawImage(item.image,frame.column*64,(paused?0:frame.row)*88,64,88,-anchor.x*.75,-anchor.y*.75,48,66);
    }else{
      ctx.fillStyle=item.state==='error'?'#be5365':'#5e8799';ctx.fillRect(-13,-42,26,42);
      ctx.fillStyle='#fff';ctx.font='bold 10px system-ui';ctx.textAlign='center';ctx.fillText(item.state==='error'?'圖像失敗':'載入中',0,-23);
    }
    if(!isPlayer&&c.role!=='student'){
      const label=actor.name??c.name;ctx.font=`600 ${c.role==='teacher'?10:11}px system-ui`;ctx.textAlign='center';
      const width=ctx.measureText(label).width+14;ctx.fillStyle='#ffffffed';ctx.fillRect(-width/2,-82,width,14);
      ctx.fillStyle='#173f58';ctx.fillText(label,0,-71);
    }
    ctx.restore();return true;
  }
  async function loadRoster(){
    retry.disabled=true;entry.disabled=true;announce('正在載入角色名冊……');
    return fetch(new URL('data/rpg-characters-v4.json',document.baseURI)).then(async response=>{
    if(!response.ok)throw new Error(`名冊 HTTP ${response.status}`);
    const registry=validateRegistry(await response.json());roster=registry.characters;anchor=registry.anchor;
    roster.filter(c=>c.role==='student').forEach((c,i)=>{c.name=`學生 ${i+1}`;});
    rotationRoster=shuffleRoster(roster);
    if(roster.length!==109||Object.entries({teacher:91,student:12,guard:1,player:4,robot:1}).some(([role,count])=>roster.filter(c=>c.role===role).length!==count))throw new Error('角色名冊尚未完整');
    for(const [id,item] of sprites)if(item.state==='error')sprites.delete(id);
    const worldStatus=document.getElementById('world-status');if(worldStatus)delete worldStatus.dataset.characterError;
    const player=roster.find(c=>c.id===selected);if(player)sprite(player,'high');
    loaded=true;currentMap=undefined;entry.disabled=false;retry.hidden=true;renderChoices();renderRoster();onMapChange();refreshPortrait();
    announce(`名冊已載入 ${roster.length} 位角色。桌面 3 師／3 生、手機 1 師／2 生隨機輪替；可搜尋全部 91 位教師並邀請入場。`);
    window.dispatchEvent(new CustomEvent('campus:characters-ready',{detail:{count:roster.length,roles:Object.fromEntries(Object.keys(roleLabels).map(role=>[role,roster.filter(c=>c.role===role).length]))}}));
    // Load the optional interior painter after the original map is already usable.
    void import('./pilot-renderer').then(module=>module.setActorPainter(draw));host.redraw();
    }).catch(error=>{
      entry.disabled=false;retry.hidden=false;
      const message='角色名冊載入失敗，仍可探索；請開啟校園角色重試。';
      const worldStatus=document.getElementById('world-status');if(worldStatus)worldStatus.dataset.characterError=message;
      announce(`角色名冊載入失敗：${error instanceof Error?error.message:'請重試載入角色'}。`);host.redraw();
    }).finally(()=>{retry.disabled=false;});
  }
  const ready=loadRoster();
  return {ready,draw,step,onMapChange};
}


