import type { FloorExpansion } from './floor-expansion';
import type { NpcConfig } from '../game/data/types';
import { cameraOrigin, screenUnit } from './viewport';
import { paintActor, auxiliaryZones, roomPalette, type DepthItem } from './pilot-renderer';
import { drawRoomFurnishings, drawRoomBadgePlaque, drawArchitecturalStairs } from './room-furnishings';

export function drawExpandedFloor(ctx:CanvasRenderingContext2D,data:FloorExpansion,id:string,player:{x:number;y:number},npcs:NpcConfig[]){
  const map=data.maps[id],f=data.floors[id],t=data.transforms[id],unit=screenUnit(ctx.getTransform().a),origin=cameraOrigin(map,player);
  ctx.save();ctx.translate(-origin.x,-origin.y);ctx.fillStyle='#acc5b5';ctx.fillRect(0,0,map.width,map.height);
  for(const r of f.footprints){const b=t.rect(r);ctx.fillStyle='#f1eadb';ctx.fillRect(b.x,b.y,b.width,b.height);}
  for(const r of f.corridors){const b=t.rect(r);ctx.fillStyle='#d4e7ec';ctx.fillRect(b.x,b.y,b.width,b.height);}

  for(const room of data.shared.rooms.filter(r=>r.floorId===f.id)){
    const r=t.rect(room.rect),door=t.toGame(room.door),pal=roomPalette(room.name);
    ctx.fillStyle=pal.bg;ctx.fillRect(r.x,r.y,r.width,r.height);
    ctx.strokeStyle=pal.border;ctx.lineWidth=2;ctx.strokeRect(r.x,r.y,r.width,r.height);

    // Architectural CAD-style furnishings adapted from CampusRoomLayout
    drawRoomFurnishings(ctx, r, door, room.name, unit);

    if(f.id!=='admin-front:floor-1'){
      drawRoomBadgePlaque(ctx, r, room.name, unit, (room as any).spaceCode);
    }
    // Architectural door opening representation
    ctx.fillStyle='#0284c7';ctx.fillRect(door.x-15,door.y-4,30,8);
    ctx.fillStyle='#e0f2fe';ctx.fillRect(door.x-12,door.y-2,24,4);
  }

  for(const z of auxiliaryZones(f.id)){
    const r=t.rect(z.rect),pal=roomPalette(z.name,z.kind);
    ctx.fillStyle=pal.bg;ctx.fillRect(r.x,r.y,r.width,r.height);
    ctx.strokeStyle=pal.border;ctx.lineWidth=2;ctx.strokeRect(r.x,r.y,r.width,r.height);

    if(z.kind==='office'){
      drawRoomFurnishings(ctx, r, {x:r.x+r.width/2,y:r.y+r.height}, z.name, unit);
      drawRoomBadgePlaque(ctx, r, z.name, unit);
    } else if(z.kind==='passage'){
      // Architectural cross-hall pattern
      ctx.strokeStyle='#94a3b8';ctx.lineWidth=1;
      for(let x=r.x+10;x<r.x+r.width;x+=18){ctx.beginPath();ctx.moveTo(x,r.y+2);ctx.lineTo(x,r.y+r.height-2);ctx.stroke();}
      ctx.fillStyle=pal.text;ctx.font=`bold ${14*unit}px system-ui`;ctx.textAlign='center';
      ctx.fillText(z.name,r.x+r.width/2,r.y+Math.min(26*unit,r.height/2+5*unit),Math.max(28,r.width-12));ctx.textAlign='left';
    } else {
      ctx.fillStyle=pal.text;ctx.font=`bold ${14*unit}px system-ui`;ctx.textAlign='center';
      ctx.fillText(z.name,r.x+r.width/2,r.y+Math.min(26*unit,r.height/2+5*unit),Math.max(28,r.width-12));ctx.textAlign='left';
    }
  }

  // Architectural stairs with authentic designations from campus-explorer
  for(const stair of data.shared.stairs.filter(s=>s.buildingId===f.buildingId)){
    const r=t.rect(stair.rect);
    drawArchitecturalStairs(ctx, r, stair.id, stair.name, f.buildingId, unit);
  }

  const depth:DepthItem[]=[];
  for(const r of map.collisionZones){if(r.width>t.unit*10&&r.height>t.unit*4)continue;depth.push({depth:r.y+r.height,paint:()=>{ctx.fillStyle='#718c9b';ctx.fillRect(r.x,r.y-10,r.width,r.height+10);ctx.fillStyle='#b4c7cb';ctx.fillRect(r.x,r.y-10,r.width,7);}});}
  for(const portal of map.portals){const r=portal.trigger;ctx.fillStyle='#15a7a9aa';ctx.fillRect(r.x,r.y,r.width,r.height);ctx.fillStyle='#173c53';ctx.font=`bold ${14*unit}px system-ui`;ctx.fillText(portal.prompt,r.x,r.y-12*unit);}
  for(const npc of npcs)depth.push({depth:npc.y,paint:()=>paintActor(ctx,npc,false)});
  depth.push({depth:player.y,paint:()=>paintActor(ctx,player,true)});depth.sort((a,b)=>a.depth-b.depth).forEach(v=>v.paint());
  ctx.fillStyle='#214b61';ctx.font='bold 23px system-ui';ctx.fillText(`${map.displayName}・建築平面示意`,30,38);ctx.restore();
}
