import type { FloorExpansion } from './floor-expansion';
import type { NpcConfig } from '../game/data/types';
import { cameraOrigin, screenUnit } from './viewport';
import { paintActor, type DepthItem } from './pilot-renderer';
export function drawExpandedFloor(ctx:CanvasRenderingContext2D,data:FloorExpansion,id:string,player:{x:number;y:number},npcs:NpcConfig[]){
  const map=data.maps[id],f=data.floors[id],t=data.transforms[id],unit=screenUnit(ctx.getTransform().a),origin=cameraOrigin(map,player);
  ctx.save();ctx.translate(-origin.x,-origin.y);ctx.fillStyle='#acc5b5';ctx.fillRect(0,0,map.width,map.height);
  for(const r of f.footprints){const b=t.rect(r);ctx.fillStyle='#f1eadb';ctx.fillRect(b.x,b.y,b.width,b.height);}
  for(const r of f.corridors){const b=t.rect(r);ctx.fillStyle='#d4e7ec';ctx.fillRect(b.x,b.y,b.width,b.height);}
  for(const room of data.shared.rooms.filter(r=>r.floorId===f.id)){const r=t.rect(room.rect),door=t.toGame(room.door);ctx.strokeStyle='#c3b69d';ctx.lineWidth=2;ctx.strokeRect(r.x,r.y,r.width,r.height);ctx.fillStyle='#234559';ctx.font=`bold ${16*unit}px system-ui`;ctx.textAlign='center';ctx.fillText(room.name,r.x+r.width/2,r.y+26*unit,Math.max(30,r.width-16));ctx.textAlign='left';ctx.fillStyle='#078f99';ctx.fillRect(door.x-15,door.y-5,30,10);}
  for(const stair of data.shared.stairs.filter(s=>s.buildingId===f.buildingId)){const r=t.rect(stair.rect);ctx.fillStyle='#c9d3d7';ctx.fillRect(r.x,r.y,r.width,r.height);ctx.strokeStyle='#78919a';for(let i=1;i<8;i++){ctx.beginPath();ctx.moveTo(r.x,r.y+r.height*i/8);ctx.lineTo(r.x+r.width,r.y+r.height*i/8);ctx.stroke();}}
  const depth:DepthItem[]=[];
  for(const r of map.collisionZones){if(r.width>t.unit*10&&r.height>t.unit*4)continue;depth.push({depth:r.y+r.height,paint:()=>{ctx.fillStyle='#718c9b';ctx.fillRect(r.x,r.y-10,r.width,r.height+10);ctx.fillStyle='#b4c7cb';ctx.fillRect(r.x,r.y-10,r.width,7);}});}
  for(const portal of map.portals){const r=portal.trigger;ctx.fillStyle='#15a7a9aa';ctx.fillRect(r.x,r.y,r.width,r.height);ctx.fillStyle='#173c53';ctx.font=`bold ${14*unit}px system-ui`;ctx.fillText(portal.prompt,r.x,r.y-12*unit);}
  for(const npc of npcs)depth.push({depth:npc.y,paint:()=>paintActor(ctx,npc,false)});
  depth.push({depth:player.y,paint:()=>paintActor(ctx,player,true)});depth.sort((a,b)=>a.depth-b.depth).forEach(v=>v.paint());
  ctx.fillStyle='#214b61';ctx.font='bold 23px system-ui';ctx.fillText(`${map.displayName}・樓層示意`,30,38);ctx.restore();
}
