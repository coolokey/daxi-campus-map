/** Overlapping shallow bands cover water, independent of shoreline decoration sampling. */
export function pondWaterFootprints(pond:{x:number;z:number;radius:number}){
 const count=Math.ceil(pond.radius*4),step=pond.radius*2/count;
 return Array.from({length:count},(_,i)=>{const dz=-pond.radius+(i+.5)*step,half=Math.sqrt(Math.max(0,pond.radius**2-dz**2));return {x0:pond.x-half,x1:pond.x+half,z0:pond.z+dz-step*.55,z1:pond.z+dz+step*.55};});
}
