import type {MapConfig,SpawnPoint} from '../game/data/types';
import {clearSegment} from './navigation';
/** Overlapping interaction ranges resolve to the nearest visible door. */
export function nearestPortal(map:MapConfig,player:Pick<SpawnPoint,'x'|'y'>,margin:number){
 const distance=(p:MapConfig['portals'][number])=>Math.hypot(player.x-p.trigger.x-p.trigger.width/2,player.y-p.trigger.y-p.trigger.height/2);
 return map.portals.filter(p=>player.x>=p.trigger.x-margin&&player.x<=p.trigger.x+p.trigger.width+margin&&player.y>=p.trigger.y-margin&&player.y<=p.trigger.y+p.trigger.height+margin&&clearSegment(player,{x:p.trigger.x+p.trigger.width/2,y:p.trigger.y+p.trigger.height/2},map)).sort((a,b)=>distance(a)-distance(b))[0];
}
