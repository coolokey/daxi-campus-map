import {surroundings as S,creekBanks,bridgePosts} from './campus-surroundings';
import {modelTransform,projectIso} from './model-world';
import {paintMeadowTree,paintMeadowTreeShadow} from './meadow-renderer';
import type {BoundaryObject} from './boundary-renderer';
type C={x:number;z:number};type P={x:number;y:number};
const bank=creekBanks(S.creek.width+2.6),water=creekBanks(S.creek.width),shallow=creekBanks(S.creek.width*.6),sprites=new Map<string,HTMLCanvasElement>();
let reduced=false;if(typeof window!=='undefined'&&window.matchMedia){const q=window.matchMedia('(prefers-reduced-motion: reduce)');reduced=q.matches;q.addEventListener?.('change',e=>{reduced=e.matches;});}
function foliage(kind:string,variant:number){const key=kind+variant,saved=sprites.get(key);if(saved)return saved;const cv=document.createElement('canvas');cv.width=160;cv.height=kind==='bamboo'?256:144;const c=cv.getContext('2d')!,base=cv.height-12;
 c.fillStyle='#315c3424';c.beginPath();c.ellipse(80,base,57,10,0,0,Math.PI*2);c.fill();
 if(kind==='bamboo'){
  for(let i=0;i<7;i++){const x=34+i*15,y=base-i%3*4,h=125+(i*37+variant*23)%82,lean=(i%2?1:-1)*(6+i);c.strokeStyle=i%2?'#698958':'#91ac67';c.lineWidth=4;c.beginPath();c.moveTo(x,y);c.lineTo(x+lean,y-h);c.stroke();for(let k=1;k<8;k++){const f=k/8,xx=x+lean*f,yy=y-h*f;c.strokeStyle='#c1c790';c.lineWidth=1.5;c.beginPath();c.moveTo(xx-3,yy);c.lineTo(xx+3,yy);c.stroke();if(k>3)for(const side of [-1,1])for(let j=0;j<3;j++){c.fillStyle=['#4e8057','#6a9a62','#8fb575'][(i+j)%3];c.beginPath();c.ellipse(xx+side*(7+j*4),yy-10-j*3,12,3,side*-.6,0,Math.PI*2);c.fill();}}}
 }else if(kind==='shrub'){
  for(const [x,y,r] of [[48,95,31],[106,91,32],[78,67,38],[78,104,36]]){const g=c.createRadialGradient(x-9,y-12,2,x,y,r);g.addColorStop(0,'#b5ca80');g.addColorStop(1,'#588653');c.fillStyle=g;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();}
  for(let i=0;i<24;i++){const x=39+(i*37+variant*13)%85,y=43+(i*23)%62;c.fillStyle=['#eac0d0','#f1dfaa','#c9bde0','#edc8ac'][variant];for(let k=0;k<5;k++){const a=k*Math.PI*2/5;c.beginPath();c.arc(x+Math.cos(a)*3.5,y+Math.sin(a)*3.5,3.5,0,Math.PI*2);c.fill();}c.fillStyle='#f7e7ad';c.beginPath();c.arc(x,y,1.7,0,Math.PI*2);c.fill();}
 }else{
  for(let i=0;i<15;i++){const x=25+(i*31+variant*13)%110,y=base-i%4*3,h=22+(i*17)%47;c.strokeStyle=i%2?'#709c55':'#a3bd72';c.lineWidth=1.8;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x-3,y-h*.6,x+(i%2?11:-9),y-h);c.stroke();
   if(kind==='fern'){for(let j=0;j<5;j++)for(const side of [-1,1]){c.fillStyle=j%2?'#7fa866':'#a9c27a';c.beginPath();c.ellipse(x+side*(5+j*.4),y-7-j*7,9-j*.8,3,side*-.4,0,Math.PI*2);c.fill();}}
   if(kind==='flowers'&&i%2===0){const xx=x+(i%2?11:-9),yy=y-h;c.fillStyle=['#eed3c8','#e5c2d4','#f0dda0','#c9c0de'][(i+variant)%4];for(let k=0;k<5;k++){const a=k*Math.PI*2/5;c.beginPath();c.arc(xx+Math.cos(a)*4,yy+Math.sin(a)*4,4,0,Math.PI*2);c.fill();}c.fillStyle='#d7ae56';c.beginPath();c.arc(xx,yy,2,0,Math.PI*2);c.fill();}
   if(kind==='reeds'&&i%3===0){c.strokeStyle='#bea77b';c.lineWidth=3;c.beginPath();c.moveTo(x+(i%2?11:-9),y-h);c.lineTo(x+(i%2?11:-9),y-h-14);c.stroke();}
  }
 }
 sprites.set(key,cv);return cv;
}
function painter(ctx:CanvasRenderingContext2D,unit:number,u:number){const t=modelTransform({x:-162,z:-90},unit),m=ctx.getTransform();
 const p=(q:C,h=0)=>{const a=projectIso(t.toGame(q));return{x:a.x,y:a.y-h*unit*.8};};
 const poly=(ps:P[],fill:string,stroke?:string)=>{ctx.beginPath();ps.forEach((q,i)=>i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=u;ctx.stroke();}};
 const line=(a:P,b:P,color:string,w=1)=>{ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=color;ctx.lineWidth=w*u;ctx.stroke();};
 const rect=(r:{x0:number;x1:number;z0:number;z1:number},h=0)=>[{x:r.x0,z:r.z0},{x:r.x1,z:r.z0},{x:r.x1,z:r.z1},{x:r.x0,z:r.z1}].map(q=>p(q,h));
 const visible=(q:P,w:number,h:number)=>{const x=m.a*q.x+m.c*q.y+m.e,y=m.b*q.x+m.d*q.y+m.f,s=Math.max(Math.abs(m.a),Math.abs(m.d));return x+w*s>0&&x-w*s<ctx.canvas.width&&y+w*s>0&&y-h*s<ctx.canvas.height;};
 return{t,p,poly,line,rect,visible};
}
/** Distant scenery and creek bed are painted before campus paving; no satellite imagery is copied. */
export function surroundingsGround(ctx:CanvasRenderingContext2D,unit:number,u:number){const {p,poly,visible}=painter(ctx,unit,u);
 for(const h of S.hills){const q=p(h);if(!visible(q,h.rx*unit,(h.rz+h.height)*unit))continue;ctx.save();const g=ctx.createLinearGradient(q.x,q.y-h.height*unit,q.x,q.y+h.rz*unit*.3);g.addColorStop(0,'#a2b987');g.addColorStop(.6,'#7da074');g.addColorStop(1,'#71956d');ctx.fillStyle=g;ctx.beginPath();ctx.moveTo(q.x-h.rx*unit,q.y);ctx.bezierCurveTo(q.x-h.rx*unit*.8,q.y-h.height*unit,q.x+h.rx*unit*.65,q.y-h.height*unit*1.1,q.x+h.rx*unit,q.y);ctx.quadraticCurveTo(q.x,q.y+h.rz*unit*.5,q.x-h.rx*unit,q.y);ctx.fill();ctx.restore();}
 poly(bank.outline.map(q=>p(q)),'#b7b99a','#a7ac8a');poly(water.outline.map(q=>p(q)),'#5e9fa6');poly(shallow.outline.map(q=>p(q)),'#7ebdbc');
 for(const edge of [bank.left,bank.right])for(let i=0;i<edge.length;i+=5){const q=p(edge[i]);if(!visible(q,unit,unit))continue;ctx.fillStyle=['#9ca78d','#c2c5a4','#899780'][i%3];ctx.beginPath();ctx.ellipse(q.x,q.y-unit*.08,unit*.35,unit*.19,.2,0,Math.PI*2);ctx.fill();}
 const seconds=reduced?0:performance.now()/1000;
 for(let i=9;i<water.left.length;i+=21){const a=water.left[i],b=water.right[i],f=.35+Math.sin(seconds*.65+i)*.13,q=p({x:a.x+(b.x-a.x)*f,z:a.z+(b.z-a.z)*f});if(!visible(q,unit*2,unit))continue;ctx.strokeStyle='#d8e9d188';ctx.lineWidth=u;ctx.beginPath();ctx.ellipse(q.x,q.y,unit*.75,unit*.14,-.2,.2,Math.PI*1.4);ctx.stroke();}
}
/** The wooden deck overwrites the shared trail; raised objects then share actor foot sorting. */
export function surroundingsScene(ctx:CanvasRenderingContext2D,unit:number,u:number,player:P,cssWidth:number):BoundaryObject[]{
 const {t,p,poly,line,rect,visible}=painter(ctx,unit,u),objects:BoundaryObject[]=[],add=(q:C,draw:()=>void)=>{const g=t.toGame(q);objects.push({depth:g.x+g.y,draw});};
 const b=S.bridge;poly(rect(b),'#b49366','#806d4b');for(let x=b.x0+.25;x<b.x1;x+=.65)line(p({x,z:b.z0}),p({x,z:b.z1}),'#826e4f',1);line(p({x:b.x0,z:b.z0+.12}),p({x:b.x1,z:b.z0+.12}),'#d8bc87',1.5);line(p({x:b.x0,z:b.z1-.12}),p({x:b.x1,z:b.z1-.12}),'#d8bc87',1.5);
 for(const q of bridgePosts)add(q,()=>line(p(q),p(q,1.1),'#8b7655',3));
 if(visible(p({x:-59,z:132}),unit*12,unit*3))for(const z of [129.8,134.2])for(const h of [.5,1])for(let x=b.x0;x<b.x1;x++)add({x:x+.5,z},()=>line(p({x,z},h),p({x:Math.min(x+1,b.x1),z},h),'#b59a6d',2));
 for(const tree of S.forestTrees){const g=t.toGame(tree),q=projectIso(g),scale=tree.scale;if(!visible(q,unit*6*scale,unit*15*scale))continue;paintMeadowTreeShadow(ctx,g,tree.seed,unit*scale);add(tree,()=>{if(tree.kind==='bamboo'){const w=unit*5.8,h=unit*10.6;ctx.save();ctx.drawImage(foliage('bamboo',tree.seed%4),q.x-w/2,q.y-h*.95,w,h);ctx.restore();}else paintMeadowTree(ctx,g,player,tree.seed,unit*scale);});}
 for(const a of S.plants){const q=p(a),w=unit*(a.kind==='shrub'?4.3:3.3),h=unit*(a.kind==='shrub'?3.4:2.4);if(!visible(q,w,h))continue;add(a,()=>ctx.drawImage(foliage(a.kind,a.seed%4),q.x-w/2,q.y-h*.88,w,h));}
 for(const f of S.fixtures){const q=p(f);if(!visible(q,unit*6,unit*5))continue;add(f,()=>{ctx.save();
  if(f.kind==='bench'){for(const x of [f.x-f.width*.35,f.x+f.width*.35])line(p({x,z:f.z}),p({x,z:f.z},.6),'#607760',4);for(const h of [.62,1.1])line(p({x:f.x-f.width/2,z:f.z},h),p({x:f.x+f.width/2,z:f.z},h),h<1?'#b49a70':'#9c865f',h<1?6:5);}
  if(f.kind==='rock'){poly([{x:q.x-unit*f.width*.5,y:q.y},{x:q.x-unit*f.width*.45,y:q.y-unit*.7},{x:q.x+unit*f.width*.1,y:q.y-unit*.95},{x:q.x+unit*f.width*.55,y:q.y-unit*.35},{x:q.x+unit*f.width*.35,y:q.y+unit*.12}],'#98a48a','#738775');line({x:q.x-unit*f.width*.45,y:q.y-unit*.7},{x:q.x+unit*f.width*.1,y:q.y-unit*.95},'#d2cdb0',2);}
  if(f.kind==='sign'){line(q,p(f,2.5),'#8b7652',3);const top=p(f,2.25),text=f.id==='garden-sign'?'椰影蝶舞花園':'溪畔觀察・慢慢走';ctx.font=`bold ${11*u}px system-ui`;ctx.textAlign='center';const w=ctx.measureText(text).width+16*u;ctx.fillStyle='#f3ebd1';ctx.fillRect(top.x-w/2,top.y-12*u,w,22*u);ctx.fillStyle='#4d7256';ctx.fillText(text,top.x,top.y+3*u);}
  ctx.restore();});}
 const seconds=reduced?0:performance.now()/1000,butterflies=S.plants.filter(a=>a.kind==='flowers').filter((_,i)=>i%2===0),butterflyCap=cssWidth<=640?2:3;let butterfliesDrawn=0;
 butterflies.forEach((a,i)=>{const q={x:a.x+Math.cos(seconds*.55+i)*1.1,z:a.z+Math.sin(seconds*.45+i)*.6},base=p(q,.8);if(!visible(base,unit,unit)||butterfliesDrawn>=butterflyCap)return;butterfliesDrawn++;add(q,()=>{ctx.save();ctx.translate(base.x,base.y);const flap=reduced?.7:.35+Math.abs(Math.sin(seconds*7+i))*.65;ctx.fillStyle=['#e9c170','#c2b0d8','#e5b6b6'][i%3];for(const side of [-1,1]){ctx.beginPath();ctx.ellipse(side*3*u*flap,0,4*u*flap,3.5*u,side*.35,0,Math.PI*2);ctx.fill();}ctx.strokeStyle='#5a7350';ctx.lineWidth=u;ctx.beginPath();ctx.moveTo(0,-3*u);ctx.lineTo(0,3*u);ctx.stroke();ctx.restore();});});
 // Two small bird silhouettes over the distant forest, decorative rather than online characters.
 for(let i=0;i<2;i++){const q={x:-87+i*102+(reduced?0:Math.sin(seconds*.12+i)*4),z:-91},base=p(q,8);if(!visible(base,unit*2,unit*2))continue;add(q,()=>{const wing=(reduced?1:Math.sin(seconds*2+i))*3*u;ctx.strokeStyle='#536c55';ctx.lineWidth=1.3*u;ctx.beginPath();ctx.moveTo(base.x-6*u,base.y+wing);ctx.quadraticCurveTo(base.x-2*u,base.y-3*u,base.x,base.y);ctx.quadraticCurveTo(base.x+2*u,base.y-3*u,base.x+6*u,base.y+wing);ctx.stroke();});}
 return objects;
}
