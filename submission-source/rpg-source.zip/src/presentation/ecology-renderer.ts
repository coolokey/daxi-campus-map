import {campusEcology,ecologyVisibleCaps,ecologyInsectPose,type EcologyPlant} from './campus-ecology';
import {campusModel,modelTransform,projectIso} from './model-world';
import {terrainSeed} from './hex-terrain';
import type {MapConfig} from '../game/data/types';
import type {BoundaryObject} from './boundary-renderer';
const sprites=new Map<string,HTMLCanvasElement>();
let reduced=false;
if(typeof window!=='undefined'&&window.matchMedia){const query=window.matchMedia('(prefers-reduced-motion: reduce)');reduced=query.matches;query.addEventListener?.('change',e=>{reduced=e.matches;});}
function plantSprite(plant:EcologyPlant){
 const variant=plant.seed%4,key=plant.kind+variant,saved=sprites.get(key);if(saved)return saved;
 const cv=document.createElement('canvas');cv.width=128;cv.height=96;const c=cv.getContext('2d')!;
 c.fillStyle='#527a3423';c.beginPath();c.ellipse(64,81,48,9,0,0,Math.PI*2);c.fill();
 for(let i=0;i<16;i++){const seed=terrainSeed(i,variant+14),x=21+seed%86,y=72+(seed>>>9)%12,h=12+(seed>>>18)%24;c.strokeStyle=i%2?'#7b9e48':'#a6bc62';c.lineWidth=1.7;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x-4,y-h,x-11,y-h*.65);c.moveTo(x,y);c.quadraticCurveTo(x+2,y-h,x+8,y-h*.9);c.stroke();}
 if(plant.kind==='flowers')for(let i=0;i<8;i++){const seed=terrainSeed(i,variant+41),x=24+seed%82,y=30+(seed>>>9)%34,base=76+(seed>>>18)%8;c.strokeStyle='#628949';c.lineWidth=1.6;c.beginPath();c.moveTo(x,base);c.lineTo(x,y);c.stroke();c.fillStyle=i%2?'#789d4d':'#a0bb60';c.beginPath();c.ellipse(x-4,(base+y)/2,6,2.5,-.5,0,Math.PI*2);c.fill();c.fillStyle=['#e9b5c3','#eee3ab','#eac283','#bdb1d8'][(i+variant)%4];for(let k=0;k<5;k++){const a=k*Math.PI*2/5;c.beginPath();c.ellipse(x+Math.cos(a)*4,y+Math.sin(a)*4,3.5,3.2,a,0,Math.PI*2);c.fill();}c.fillStyle='#e3bb65';c.beginPath();c.arc(x,y,2.2,0,Math.PI*2);c.fill();}
 else if(plant.kind==='reeds')for(let i=0;i<9;i++){const seed=terrainSeed(i,variant+67),x=30+seed%72,h=37+(seed>>>8)%26;c.strokeStyle=i%2?'#6f9460':'#96ad6e';c.lineWidth=2;c.beginPath();c.moveTo(x,83);c.quadraticCurveTo(x-3,83-h*.6,x+3,83-h);c.stroke();if(i%2){c.strokeStyle='#b49a6c';c.lineWidth=3;c.beginPath();c.moveTo(x+3,83-h);c.lineTo(x+3,75-h);c.stroke();}}
 else for(let i=0;i<5;i++){const x=30+i*17,y=79-i%2*8;c.strokeStyle='#668c49';c.lineWidth=2;c.beginPath();c.moveTo(x,y);c.lineTo(x-4,y-26);c.stroke();for(let j=0;j<4;j++){c.fillStyle=j%2?'#719c54':'#93af61';c.beginPath();c.ellipse(x-4-j*1.2,y-7-j*4,8-j,2.5,.45,0,Math.PI*2);c.fill();c.beginPath();c.ellipse(x+1-j,y-9-j*4,7-j,2.5,-.4,0,Math.PI*2);c.fill();}}
 sprites.set(key,cv);return cv;
}
/** One placement cache, twelve small static sprites, bounded visible insects, no extra animation timer. */
export function ecologyScene(ctx:CanvasRenderingContext2D,map:MapConfig,unit:number,u:number,cssWidth:number):BoundaryObject[]{
 const t=modelTransform({x:-162,z:-90},unit),ecology=campusEcology(map,t,campusModel),objects:BoundaryObject[]=[],matrix=ctx.getTransform(),scale=Math.max(Math.abs(matrix.a),Math.abs(matrix.d)),time=performance.now()/1000;
 const visible=(p:{x:number;y:number},width:number,up:number)=>{const x=matrix.a*p.x+matrix.c*p.y+matrix.e,y=matrix.b*p.x+matrix.d*p.y+matrix.f;return x+width*scale>0&&x-width*scale<ctx.canvas.width&&y+width*scale>0&&y-up*scale<ctx.canvas.height;};
 for(const plant of ecology.plants){const g=t.toGame(plant),p=projectIso(g),width=unit*2.6,height=unit*(plant.kind==='reeds'?2.2:1.6);if(!visible(p,width*.55,height))continue;objects.push({depth:g.x+g.y,draw:()=>{ctx.save();ctx.imageSmoothingEnabled=true;ctx.drawImage(plantSprite(plant),p.x-width/2,p.y-height*.85,width,height);ctx.restore();}});}
 const limits=ecologyVisibleCaps(cssWidth),drawn={butterfly:0,dragonfly:0};
 for(const insect of ecology.insects){const limit=insect.kind==='butterfly'?limits.butterflies:limits.dragonflies;if(drawn[insect.kind]>=limit)continue;const pose=ecologyInsectPose(insect,time,reduced),g=t.toGame(pose),base=projectIso(g),p={x:base.x,y:base.y-pose.height*unit};if(!visible(p,u*10,u*10))continue;drawn[insect.kind]++;objects.push({depth:g.x+g.y,draw:()=>{ctx.save();ctx.translate(p.x,p.y);ctx.rotate(Math.sin(time*.3+insect.seed)*.12*(reduced?0:1));ctx.lineWidth=1.1*u;
  if(insect.kind==='butterfly'){const wing=(2.5+pose.wing*2)*u;ctx.fillStyle=['#e5b65e','#d39cac','#a8a3cb'][insect.seed%3];for(const side of [-1,1]){ctx.beginPath();ctx.ellipse(side*wing*.65,-1.5*u,wing,3.6*u,side*.45,0,Math.PI*2);ctx.fill();ctx.fillStyle=insect.seed%2?'#e5c88a':'#d8b4c5';ctx.beginPath();ctx.ellipse(side*wing*.5,2.3*u,wing*.72,2.5*u,side*-.25,0,Math.PI*2);ctx.fill();}ctx.strokeStyle='#5a6242';ctx.beginPath();ctx.moveTo(0,-3*u);ctx.lineTo(0,4*u);ctx.stroke();}
  else {ctx.fillStyle='#d5e7d9b0';for(const side of [-1,1])for(const y of [-1,2]){ctx.beginPath();ctx.ellipse(side*(3+pose.wing)*u,y*u,5*u,1.5*u,side*.2,0,Math.PI*2);ctx.fill();}ctx.strokeStyle='#4b9196';ctx.lineWidth=1.5*u;ctx.beginPath();ctx.moveTo(0,-4*u);ctx.lineTo(0,6*u);ctx.stroke();ctx.fillStyle='#537e6b';ctx.beginPath();ctx.arc(0,-4*u,1.5*u,0,Math.PI*2);ctx.fill();}
  ctx.restore();}});}
 return objects;
}
