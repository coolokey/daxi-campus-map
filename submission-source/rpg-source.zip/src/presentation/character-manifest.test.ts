import {it,expect} from 'vitest';
import original from '../../public/data/rpg-characters-v4.json';
import runtime from '../../public/data/rpg-characters-runtime-v1.json';
import {validateRegistry} from './character-runtime';
it('preserves every character identity, image, portrait and searchable field in the smaller runtime manifest',()=>{
 const checked=validateRegistry(runtime);expect(checked.anchor).toEqual(original.anchor);
 expect(checked.characters).toHaveLength(original.characters.length);
 for(let i=0;i<original.characters.length;i++)for(const key of ['id','name','role','title','destination','atlas','portrait'] as const)expect(checked.characters[i][key]).toEqual((original.characters[i] as Record<string,unknown>)[key]);
 expect(JSON.stringify(runtime).length).toBeLessThan(JSON.stringify(original).length*.5);
});
