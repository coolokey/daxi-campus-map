import textureUrl from '../assets/environment/stone-paving-v1.webp';
type Point={x:number;y:number};
const texture=new Image();texture.decoding='async';texture.src=textureUrl;
const patterns=new WeakMap<CanvasRenderingContext2D,{pattern:CanvasPattern;span:number}>();
/** Material uses the same world axes as collision and is projected exactly once. */
export function paintStonePaving(ctx:CanvasRenderingContext2D,points:Point[],worldUnit:number){
 if(points.length<3)return;
 ctx.save();ctx.transform(Math.sqrt(3)/2,.5,-Math.sqrt(3)/2,.5,0,0);
 ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.clip();
 const xs=points.map(p=>p.x),ys=points.map(p=>p.y),x=Math.min(...xs),y=Math.min(...ys),width=Math.max(...xs)-x,height=Math.max(...ys)-y;
 ctx.fillStyle='#ded6c6';ctx.fillRect(x,y,width,height);
 if(texture.complete&&texture.naturalWidth){
  let entry=patterns.get(ctx);const span=worldUnit*22;
  if(!entry){const pattern=ctx.createPattern(texture,'repeat');if(pattern){entry={pattern,span:0};patterns.set(ctx,entry);}}
  if(entry){if(entry.span!==span){entry.pattern.setTransform(new DOMMatrix().scale(span/texture.naturalWidth));entry.span=span;}ctx.fillStyle=entry.pattern;ctx.fillRect(x,y,width,height);}
 }
 ctx.restore();
}
