import { getWorldScale, safePosition } from '../game/core/world';
import type { MapConfig, SpawnPoint, NpcConfig } from '../game/data/types';
import type { WorldId } from '../game/config';
import { createPilot, loadPilot, safePilotPosition, type Pilot, type PilotId, type SharedCampus, type RuntimeCampus } from './pilot-adapter';
import * as renderer from './pilot-renderer';
import { createFloorExpansion, type FloorExpansion, planBuildings } from './floor-expansion';
import { drawExpandedFloor } from './floor-renderer';
type Host={
  maps:Partial<Record<WorldId,MapConfig>>;
  read:()=>{map:MapConfig;player:SpawnPoint;npcs:NpcConfig[];questOpen:boolean;questLoading:boolean};
  setPilot:(pilot:Pilot)=>void;
  place:(map:MapConfig,player:SpawnPoint)=>void;
  route:(visible:boolean)=>void;
  openQuest:()=>Promise<void>;
  pause:()=>void;
};
/** Loaded only when the original campus technology door is used. */
export function createPilotControls(host:Host) {
  const get=(id:string)=>document.getElementById(id)!;
  let data:{shared:SharedCampus;runtime:RuntimeCampus}|undefined,pilot:Pilot|undefined;
  let expanded:FloorExpansion|undefined;
  let saved:{map:MapConfig;player:SpawnPoint}|undefined,showRoute=true,loading=false;
  let portalLock:{mapId:WorldId;x:number;y:number;at:number}|undefined;
  const dialogue=get('dialogue');
  const accept=document.createElement('button');accept.id='pilot-accept';accept.className='primary-button';accept.textContent='接受原版 5 題任務';accept.hidden=true;
  accept.onclick=()=>{dialogue.hidden=true;accept.hidden=true;void host.openQuest();};dialogue.append(accept);
  const guide=document.createElement('button');guide.id='pilot-route';guide.textContent='隱藏巡檢路線';guide.hidden=true;
  guide.onclick=()=>{showRoute=!showRoute;guide.textContent=showRoute?'隱藏巡檢路線':'顯示巡檢路線';host.route(showRoute);};
  const note=document.createElement('p');note.id='pilot-note';note.hidden=true;note.textContent='科技館 1F → 南翼樓梯 → 2F 電腦教室二。按 E 互動。1F 出口返回校園；樓層為導覽資料示意。';
  document.querySelector('.explore-toolbar')!.append(guide);get('exploration').prepend(note);
  return {
    directoryState:()=>({pilot,expanded}),
    draw:(ctx:CanvasRenderingContext2D)=>{const state=host.read();if(state.map.id.startsWith('floor-'))drawExpandedFloor(ctx,expanded!,state.map.id,state.player,state.npcs);else renderer.drawPilotWorld(ctx,pilot!,state.map.id as PilotId,showRoute,state.player,state.npcs);},
    prompt:()=>`${host.read().map.displayName}・教室可探索，入口／樓梯按 E；建築目錄可選目的地`,
    closeDialogue:()=>{accept.hidden=true;},
    interact(npc:NpcConfig){if(!npc.id.startsWith('pilot-math-')&&!npc.id.startsWith('floor-mentor:'))return false;dialogue.querySelector('p')!.textContent=`${npc.name} · 遊戲 NPC：${npc.dialogue}`;accept.hidden=false;dialogue.hidden=false;host.pause();accept.focus();return true;},
    canPortal:()=>!portalLock,
    onPortal(){const state=host.read();portalLock={mapId:state.map.id,x:state.player.x,y:state.player.y,at:performance.now()};},
    step(now:number){const state=host.read();if(portalLock&&portalLock.mapId===state.map.id&&Math.hypot(state.player.x-portalLock.x,state.player.y-portalLock.y)>72&&now-portalLock.at>500)portalLock=undefined;},
    scale(oldWidth:number) {
      if(saved?.map.id==='campus') {const campus=host.maps.campus!;saved.player={...saved.player,...safePosition({x:saved.player.x*campus.width/oldWidth,y:saved.player.y*campus.width/oldWidth},campus)};saved.map=campus;}
      const state=host.read();if(!pilot||!data)return;
      if(state.map.id.startsWith('floor-')&&expanded){const id=state.map.id,p=expanded.transforms[id].fromGame(state.player);expanded=createFloorExpansion(data.shared,data.runtime,getWorldScale());Object.assign(host.maps,expanded.maps);host.place(expanded.maps[id],{...state.player,...safePilotPosition(expanded.transforms[id].toGame(p),expanded.maps[id])});portalLock=undefined;return;}
      if(!state.map.id.startsWith('pilot-'))return;
      const id=state.map.id as PilotId,p=pilot.transforms[id].fromGame(state.player),lock=portalLock?pilot.transforms[id].fromGame(portalLock):undefined;
      pilot=createPilot(data.shared,data.runtime,getWorldScale());host.setPilot(pilot);
      if(portalLock&&lock)portalLock={...portalLock,...pilot.transforms[id].toGame(lock)};
      host.place(pilot.maps[id],{...state.player,...safePilotPosition(pilot.transforms[id].toGame(p),pilot.maps[id])});
    },
    exit() {
      if(!saved)return;
      portalLock=undefined;guide.hidden=note.hidden=true;
      host.place(host.maps[saved.map.id]??saved.map,{...saved.player});
    },
    async enter(buildingId='tech-building') {
      const state=host.read();if(loading||state.questOpen||state.questLoading||state.map.id!=='campus')return;
      const bName=planBuildings.find(b=>b.buildingId===buildingId)?.name.split(' / ')[0]??(buildingId==='tech-building'?'科技館':'建築');
      loading=true;get('world-status').textContent=`正在載入 ${bName} 樓層……`;
      try {
        if(!data){const loaded=await loadPilot(getWorldScale());data={shared:loaded.shared,runtime:loaded.runtime};}
        const current=host.read();
        pilot=createPilot(data.shared,data.runtime,getWorldScale());expanded=createFloorExpansion(data.shared,data.runtime,getWorldScale());saved={map:current.map,player:{...current.player,...safePosition(current.player,current.map)}};
        // The source-only outdoor map remains adapter data; the playable outdoor scene is campus.
        host.setPilot(pilot);Object.assign(host.maps,expanded.maps);guide.hidden=buildingId!=='tech-building';note.hidden=false;
        note.textContent=buildingId==='tech-building'?'科技館 1F → 南翼樓梯 → 2F 電腦教室二。按 E 互動；建築目錄可巡檢其他教室。樓層為導覽資料示意。':'依 115 學年度平面圖核對樓層；室內門位與尺寸為導覽示意。入口／樓梯按 E，建築目錄可設定教室路線。';
        const next=buildingId==='tech-building'?pilot.maps['pilot-tech-1']:expanded.maps[`floor-${buildingId}-1`];if(!next)throw new Error('此建築尚待平面圖核對，暫不開放');
        const entry=next.spawns.entry;
        portalLock={mapId:next.id,x:entry.x,y:entry.y,at:performance.now()};
        host.place(next,{...entry});
        window.dispatchEvent(new CustomEvent('campus:pilot-ready',{detail:pilot}));
      }catch(error){get('world-status').textContent=`${bName} 樓層載入失敗：${error instanceof Error?error.message:String(error)}。請在入口再次按 E 重試。`;}
      finally{loading=false;}
    },
  };
}

