import { getWorldScale, safePosition } from '../game/core/world';
import type { MapConfig, SpawnPoint, NpcConfig } from '../game/data/types';
import type { WorldId } from '../game/config';
import { createPilot, loadPilot, safePilotPosition, type Pilot, type PilotId, type SharedCampus, type RuntimeCampus } from './pilot-adapter';
import * as renderer from './pilot-renderer';
type Host={
  button:HTMLButtonElement;
  maps:Partial<Record<WorldId,MapConfig>>;
  read:()=>{map:MapConfig;player:SpawnPoint;npcs:NpcConfig[];questOpen:boolean;questLoading:boolean};
  setPilot:(pilot:Pilot)=>void;
  place:(map:MapConfig,player:SpawnPoint)=>void;
  route:(visible:boolean)=>void;
  openQuest:()=>Promise<void>;
  pause:()=>void;
};
/** Loaded only after the user requests this demonstration. */
export function createPilotControls(host:Host) {
  const get=(id:string)=>document.getElementById(id)!;
  let data:{shared:SharedCampus;runtime:RuntimeCampus}|undefined,pilot:Pilot|undefined;
  let saved:{map:MapConfig;player:SpawnPoint}|undefined,showRoute=true;
  let portalLock:{mapId:WorldId;x:number;y:number;at:number}|undefined;
  const dialogue=get('dialogue');
  const accept=document.createElement('button');accept.id='pilot-accept';accept.className='primary-button';accept.textContent='接受原版 5 題任務';accept.hidden=true;
  accept.onclick=()=>{dialogue.hidden=true;accept.hidden=true;void host.openQuest();};dialogue.append(accept);
  const guide=document.createElement('button');guide.id='pilot-route';guide.textContent='隱藏巡檢路線';guide.hidden=true;
  guide.onclick=()=>{showRoute=!showRoute;guide.textContent=showRoute?'隱藏巡檢路線':'顯示巡檢路線';host.route(showRoute);};
  const note=document.createElement('p');note.id='pilot-note';note.hidden=true;note.textContent='資料平面示意，非實測實景。校門 → 科技館 1F → 南翼樓梯 → 2F 電腦教室二。沿金色路線探索，靠近入口、樓梯或導師後按 E 互動。';
  document.querySelector('.explore-toolbar')!.append(guide);get('exploration').prepend(note);
  return {
    draw:(ctx:CanvasRenderingContext2D)=>{const state=host.read();renderer.drawPilotWorld(ctx,pilot!,state.map.id as PilotId,showRoute,state.player,state.npcs);},
    prompt:()=>`${pilot!.title[host.read().map.id as PilotId]}・沿金色巡檢線手動移動，入口／樓梯按 E`,
    closeDialogue:()=>{accept.hidden=true;},
    interact(npc:NpcConfig){if(npc.id!=='pilot-math-mentor')return false;dialogue.querySelector('p')!.textContent=`${npc.name} · 遊戲 NPC：${npc.dialogue}`;accept.hidden=false;dialogue.hidden=false;host.pause();accept.focus();return true;},
    canPortal:()=>!portalLock,
    onPortal(){const state=host.read();portalLock={mapId:state.map.id,x:state.player.x,y:state.player.y,at:performance.now()};},
    step(now:number){const state=host.read();if(portalLock&&portalLock.mapId===state.map.id&&Math.hypot(state.player.x-portalLock.x,state.player.y-portalLock.y)>72&&now-portalLock.at>500)portalLock=undefined;},
    scale(oldWidth:number) {
      if(saved?.map.id==='campus') {const campus=host.maps.campus!;saved.player={...saved.player,...safePosition({x:saved.player.x*campus.width/oldWidth,y:saved.player.y*campus.width/oldWidth},campus)};saved.map=campus;}
      const state=host.read();if(!state.map.id.startsWith('pilot-')||!pilot||!data)return;
      const id=state.map.id as PilotId,p=pilot.transforms[id].fromGame(state.player),lock=portalLock?pilot.transforms[id].fromGame(portalLock):undefined;
      pilot=createPilot(data.shared,data.runtime,getWorldScale());host.setPilot(pilot);
      if(portalLock&&lock)portalLock={...portalLock,...pilot.transforms[id].toGame(lock)};
      host.place(pilot.maps[id],{...state.player,...safePilotPosition(pilot.transforms[id].toGame(p),pilot.maps[id])});
    },
    async toggle() {
      const state=host.read();if(state.questOpen||state.questLoading)return;
      if(state.map.id.startsWith('pilot-')&&saved){portalLock=undefined;host.button.textContent='科技館 2.0 示範';guide.hidden=note.hidden=true;get('quest-start').hidden=false;host.place(host.maps[saved.map.id]??saved.map,{...saved.player});return;}
      host.button.disabled=true;host.button.textContent='載入科技館示範……';
      try {
        if(!data){const loaded=await loadPilot(getWorldScale());data={shared:loaded.shared,runtime:loaded.runtime};}
        pilot=createPilot(data.shared,data.runtime,getWorldScale());saved={map:state.map,player:{...state.player}};
        portalLock=undefined;host.setPilot(pilot);host.button.textContent='返回原校園模式';guide.hidden=note.hidden=false;get('quest-start').hidden=true;
        host.place(pilot.maps['pilot-outdoor'],{...pilot.maps['pilot-outdoor'].spawns['campus-start']});
        window.dispatchEvent(new CustomEvent('campus:pilot-ready',{detail:pilot}));
      }catch(error){get('world-status').textContent=`科技館示範載入失敗：${error instanceof Error?error.message:String(error)}。可再次按鈕重試。`;host.button.textContent='重試科技館 2.0 示範';}
      finally{host.button.disabled=false;}
    },
  };
}

