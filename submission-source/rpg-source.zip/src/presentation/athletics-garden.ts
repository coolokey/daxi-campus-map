import layout from '../../public/data/athletics-garden-v1.json';
export const athleticsLayout=layout;
type Track={x:number;z:number;halfStraight:number;innerRadius:number;outerRadius:number};
export const athleticsSolids=[...layout.equipment.map(e=>e.rect),...layout.plants.filter(p=>p.kind==='shrub').map(p=>({x0:p.x-.65,x1:p.x+.65,z0:p.z-.65,z1:p.z+.65})),...[-40,-19].flatMap(z=>[-85,-73].map(x=>({x0:x-.15,x1:x+.15,z0:z-.15,z1:z+.15})))];
/** Distance along a source-sized capsule, starting at the bottom-right tangent. */
export function lanePoint(t:Track,r:number,distance:number){const straight=t.halfStraight*2,arc=Math.PI*r,total=2*straight+2*arc;let d=((distance%total)+total)%total;
 if(d<=straight)return{x:t.x+t.halfStraight-d,z:t.z+r};d-=straight;
 if(d<=arc){const a=Math.PI/2+d/r;return{x:t.x-t.halfStraight+Math.cos(a)*r,z:t.z+Math.sin(a)*r};}d-=arc;
 if(d<=straight)return{x:t.x-t.halfStraight+d,z:t.z-r};d-=straight;
 const a=-Math.PI/2+d/r;return{x:t.x+t.halfStraight+Math.cos(a)*r,z:t.z+Math.sin(a)*r};
}
export function laneStarts(t:Track){const width=(t.outerRadius-t.innerRadius)/6,first=t.innerRadius+width/2;return Array.from({length:6},(_,i)=>{const radius=first+i*width,distance=t.halfStraight*2-3+2*Math.PI*(radius-first);return{...lanePoint(t,radius,distance),lane:i+1,radius,distance};});}
