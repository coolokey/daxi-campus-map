import {terrainSeed,visibleHexRange} from './hex-terrain';
import type {Rect} from '../game/data/types';
import {projectIso} from './model-world';
import {CARTOON_CAMPUS} from './cartoon-layout';
type P={x:number;y:number};
const soften=(hex:string,amount=.24)=>{const n=parseInt(hex.slice(1),16);return '#'+[n>>16,(n>>8)&255,n&255].map(v=>Math.round(v+(246-v)*amount).toString(16).padStart(2,'0')).join('');};
const corners=(r:Rect)=>[{x:r.x,y:r.y},{x:r.x+r.width,y:r.y},{x:r.x+r.width,y:r.y+r.height},{x:r.x,y:r.y+r.height}];
export const cartoonBuildingHeight=(sourceHeight:number,unit:number)=>unit*(1.8+Math.round(sourceHeight/(unit*5.4))*.9);
export function cartoonBuildingScreenPoints(r:Rect,sourceHeight:number,unit:number){const h=cartoonBuildingHeight(sourceHeight,unit);return corners(r).flatMap(p=>{const q=projectIso(p);return [q,{x:q.x,y:q.y-h-unit*.65}];});}
export function cartoonBuildingOccludes(r:Rect,h:number,unit:number,player:P,actorUnit:number){if(player.x+player.y>=r.x+r.y+r.width+r.height)return false;const points=cartoonBuildingScreenPoints(r,h,unit),p=projectIso(player);return p.x>Math.min(...points.map(q=>q.x))-20*actorUnit&&p.x<Math.max(...points.map(q=>q.x))+20*actorUnit&&p.y>Math.min(...points.map(q=>q.y))&&p.y-50*actorUnit<Math.max(...points.map(q=>q.y));}
const visible=(ctx:CanvasRenderingContext2D,points:P[],pad=48)=>{const t=ctx.getTransform(),p=points.map(q=>({x:t.a*q.x+t.c*q.y+t.e,y:t.b*q.x+t.d*q.y+t.f}));return Math.max(...p.map(q=>q.x))>=-pad&&Math.min(...p.map(q=>q.x))<=ctx.canvas.width+pad&&Math.max(...p.map(q=>q.y))>=-pad&&Math.min(...p.map(q=>q.y))<=ctx.canvas.height+pad;};
export function paintHexTerrain(ctx:CanvasRenderingContext2D,clip:P[],width:number,height:number,unit:number){
 const radius=CARTOON_CAMPUS.hexRadius*unit,stepX=radius*1.5,stepY=Math.sqrt(3)*radius;
 ctx.save();ctx.beginPath();clip.map(projectIso).forEach((q,i)=>i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y));ctx.closePath();ctx.clip();
 const range=visibleHexRange(ctx.getTransform(),ctx.canvas.width,ctx.canvas.height,width,height,radius);
 for(let col=range.col0;col<=range.col1;col++)for(let row=range.row0;row<=range.row1;row++){
  const center={x:col*stepX,y:row*stepY+(col%2)*stepY/2},points=Array.from({length:6},(_,i)=>projectIso({x:center.x+Math.cos(i*Math.PI/3)*radius,y:center.y+Math.sin(i*Math.PI/3)*radius}));if(!visible(ctx,points,8))continue;
  ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();const seed=terrainSeed(col,row);ctx.fillStyle=CARTOON_CAMPUS.grass[seed%CARTOON_CAMPUS.grass.length];ctx.fill();ctx.strokeStyle='#f1edcf65';ctx.lineWidth=.85;ctx.stroke();
  // Sparse ground details have no collision or effect on quest locations.
  const p=projectIso(center),blade=unit*.15;
  if(seed%17===0){ctx.strokeStyle='#598b55a0';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(p.x-blade,p.y);ctx.lineTo(p.x-blade*.5,p.y-blade);ctx.lineTo(p.x,p.y);ctx.lineTo(p.x+blade,p.y-blade*.7);ctx.stroke();}
  else if(seed%43===0){ctx.strokeStyle='#679363a0';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(p.x,p.y+blade);ctx.lineTo(p.x,p.y-blade);ctx.stroke();ctx.fillStyle=seed%2?'#fff5cf':'#e8cb72';for(const dx of [-.6,.6]){ctx.beginPath();ctx.arc(p.x+dx*blade,p.y-blade,blade*.5,0,Math.PI*2);ctx.fill();}}

 }
 ctx.restore();
}
export function paintCartoonBuilding(ctx:CanvasRenderingContext2D,r:Rect,sourceHeight:number,unit:number,u:number,id:string){
 const screen=cartoonBuildingScreenPoints(r,sourceHeight,unit);if(!visible(ctx,screen))return false;
 const h=cartoonBuildingHeight(sourceHeight,unit),q=corners(r).map(projectIso),color=(CARTOON_CAMPUS.buildingColors as Record<string,string>)[id]??'#69b8db',outline='#84917b',lift=(p:P,z:number)=>({x:p.x,y:p.y-z});
 ctx.save();ctx.lineJoin='round';
 const poly=(pts:P[],fill:string|CanvasGradient,stroke=outline,width=.7)=>{ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width*u;ctx.stroke();}};
 const line=(a:P,b:P,c:string,w=2)=>{ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=c;ctx.lineWidth=w*u;ctx.stroke();};
 const wall=ctx.createLinearGradient(q[2].x,q[2].y-h,q[2].x,q[2].y);wall.addColorStop(0,'#fff6dc');wall.addColorStop(1,'#d8ddbf');
 poly([q[1],q[2],lift(q[2],h),lift(q[1],h)],wall);poly([q[2],q[3],lift(q[3],h),lift(q[2],h)],'#e3e5c9');
 const floors=Math.max(1,Math.round(sourceHeight/(unit*5.4))),rows=Math.min(2,floors);
 for(const [a,b] of [[q[1],q[2]],[q[2],q[3]]]){
  const at=(t:number,z:number)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t-z});
  line(at(0,unit*.35),at(1,unit*.35),color,3);
  const count=Math.max(2,Math.min(7,Math.round(Math.hypot(b.x-a.x,b.y-a.y)/(unit*4))));
  for(let row=0;row<rows;row++)for(let i=0;i<count;i++){const lo=(i+.22)/count,hi=(i+.78)/count,bottom=h*(.18+row*.34),top=bottom+h*.21;poly([at(lo,bottom),at(hi,bottom),at(hi,top),at(lo,top)],'#8fb9b6','#819d94',.65);line(at(lo,top-h*.025),at(hi,top-h*.025),'#d7e9d8',.8);}
 }
 // Bevels stay within the original footprint and existing roof occlusion envelope.
 const cap=q.map(p=>lift(p,h)),middle=cap.reduce((p,q)=>({x:p.x+q.x/4,y:p.y+q.y/4}),{x:0,y:0});
 const inner=cap.map(p=>({x:p.x*.88+middle.x*.12,y:p.y*.88+middle.y*.12-unit*.35}));
 poly(cap,soften(color,.28));
 poly([cap[1],cap[2],inner[2],inner[1]],soften(color,.12));poly([cap[2],cap[3],inner[3],inner[2]],soften(color,.3));
 const roof=ctx.createLinearGradient(middle.x-r.width*.3,middle.y-h*.1,middle.x+r.width*.3,middle.y+h*.1);roof.addColorStop(0,soften(color,.45));roof.addColorStop(1,soften(color,.15));poly(inner,roof,soften(color,.1),.8);
 const center=projectIso({x:r.x+r.width/2,y:r.y+r.height/2});ctx.fillStyle='#f9f4e6';ctx.strokeStyle=outline;ctx.lineWidth=.7*u;ctx.beginPath();ctx.roundRect(center.x-15*u,center.y-h-10*u,30*u,20*u,7*u);ctx.fill();ctx.stroke();ctx.fillStyle=outline;ctx.font=`900 ${11*u}px system-ui`;ctx.textAlign='center';ctx.fillText(`${floors}F`,center.x,center.y-h+4*u);
 ctx.restore();return true;
}
