import type {Rect} from '../game/data/types';
import {projectIso} from './model-world';
import {CARTOON_CAMPUS} from './cartoon-layout';
type P={x:number;y:number};
const corners=(r:Rect)=>[{x:r.x,y:r.y},{x:r.x+r.width,y:r.y},{x:r.x+r.width,y:r.y+r.height},{x:r.x,y:r.y+r.height}];
export const cartoonBuildingHeight=(sourceHeight:number,unit:number)=>unit*(1.8+Math.round(sourceHeight/(unit*5.4))*.9);
export function cartoonBuildingScreenPoints(r:Rect,sourceHeight:number,unit:number){const h=cartoonBuildingHeight(sourceHeight,unit);return corners(r).flatMap(p=>{const q=projectIso(p);return [q,{x:q.x,y:q.y-h-unit*.65}];});}
export function cartoonBuildingOccludes(r:Rect,h:number,unit:number,player:P,actorUnit:number){if(player.x+player.y>=r.x+r.y+r.width+r.height)return false;const points=cartoonBuildingScreenPoints(r,h,unit),p=projectIso(player);return p.x>Math.min(...points.map(q=>q.x))-20*actorUnit&&p.x<Math.max(...points.map(q=>q.x))+20*actorUnit&&p.y>Math.min(...points.map(q=>q.y))&&p.y-50*actorUnit<Math.max(...points.map(q=>q.y));}
const visible=(ctx:CanvasRenderingContext2D,points:P[],pad=48)=>{const t=ctx.getTransform(),p=points.map(q=>({x:t.a*q.x+t.c*q.y+t.e,y:t.b*q.x+t.d*q.y+t.f}));return Math.max(...p.map(q=>q.x))>=-pad&&Math.min(...p.map(q=>q.x))<=ctx.canvas.width+pad&&Math.max(...p.map(q=>q.y))>=-pad&&Math.min(...p.map(q=>q.y))<=ctx.canvas.height+pad;};
export function paintHexTerrain(ctx:CanvasRenderingContext2D,clip:P[],width:number,height:number,unit:number){
 const radius=CARTOON_CAMPUS.hexRadius*unit,stepX=radius*1.5,stepY=Math.sqrt(3)*radius;
 ctx.save();ctx.beginPath();clip.map(projectIso).forEach((q,i)=>i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y));ctx.closePath();ctx.clip();
 for(let col=0;col*stepX<width+radius;col++)for(let row=-1;row*stepY<height+radius;row++){
  const center={x:col*stepX,y:row*stepY+(col%2)*stepY/2},points=Array.from({length:6},(_,i)=>projectIso({x:center.x+Math.cos(i*Math.PI/3)*radius,y:center.y+Math.sin(i*Math.PI/3)*radius}));if(!visible(ctx,points,8))continue;
  ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=CARTOON_CAMPUS.grass[((col*7+row*11)%3+3)%3];ctx.fill();ctx.strokeStyle='#d6edb6';ctx.lineWidth=1.4;ctx.stroke();
  // Tiny grass tufts read as terrain details, not physical obstacles.
  if((col+row)%5===0){const p=projectIso(center);ctx.strokeStyle='#77b64e';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(p.x-4,p.y);ctx.lineTo(p.x-2,p.y-4);ctx.lineTo(p.x,p.y);ctx.lineTo(p.x+3,p.y-3);ctx.stroke();}
 }
 ctx.restore();
}
export function paintCartoonBuilding(ctx:CanvasRenderingContext2D,r:Rect,sourceHeight:number,unit:number,u:number,id:string){
 const screen=cartoonBuildingScreenPoints(r,sourceHeight,unit);if(!visible(ctx,screen))return false;
 const h=cartoonBuildingHeight(sourceHeight,unit),q=corners(r).map(projectIso),color=(CARTOON_CAMPUS.buildingColors as Record<string,string>)[id]??'#69b8db',outline='#477b81',lift=(p:P,z:number)=>({x:p.x,y:p.y-z});
 ctx.save();ctx.lineJoin='round';
 const poly=(pts:P[],fill:string,stroke=outline,width=2)=>{ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width*u;ctx.stroke();}};
 const line=(a:P,b:P,c:string,w=2)=>{ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=c;ctx.lineWidth=w*u;ctx.stroke();};
 poly([q[1],q[2],lift(q[2],h),lift(q[1],h)],'#fff7da');poly([q[2],q[3],lift(q[3],h),lift(q[2],h)],'#e7e7c8');
 const floors=Math.max(1,Math.round(sourceHeight/(unit*5.4))),rows=Math.min(2,floors);
 for(const [a,b] of [[q[1],q[2]],[q[2],q[3]]]){
  const at=(t:number,z:number)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t-z});
  line(at(0,unit*.35),at(1,unit*.35),color,3);
  const count=Math.max(2,Math.min(7,Math.round(Math.hypot(b.x-a.x,b.y-a.y)/(unit*4))));
  for(let row=0;row<rows;row++)for(let i=0;i<count;i++){const lo=(i+.22)/count,hi=(i+.78)/count,bottom=h*(.18+row*.34),top=bottom+h*.21;poly([at(lo,bottom),at(hi,bottom),at(hi,top),at(lo,top)],'#76c8dd','#5d9ba6',1.1);line(at(lo,top-h*.025),at(hi,top-h*.025),'#d7f7ff',1);}
 }
 // A broad colored toy-like roof with a white rim replaces the tall wooden roof mass.
 const cap=q.map(p=>lift(p,h));poly(cap,color,outline,2.6);const inner=cap.map(p=>({x:p.x*.88+cap.reduce((n,q)=>n+q.x,0)/4*.12,y:p.y*.88+cap.reduce((n,q)=>n+q.y,0)/4*.12}));
 ctx.beginPath();inner.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.strokeStyle='#ffffffa8';ctx.lineWidth=2*u;ctx.stroke();
 const center=projectIso({x:r.x+r.width/2,y:r.y+r.height/2});ctx.fillStyle='#fffdf3';ctx.strokeStyle=outline;ctx.lineWidth=2*u;ctx.beginPath();ctx.roundRect(center.x-15*u,center.y-h-10*u,30*u,20*u,7*u);ctx.fill();ctx.stroke();ctx.fillStyle=outline;ctx.font=`900 ${11*u}px system-ui`;ctx.textAlign='center';ctx.fillText(`${floors}F`,center.x,center.y-h+4*u);
 ctx.restore();return true;
}
