import {terrainSeed,visibleHexRange} from './hex-terrain';
import type {Rect} from '../game/data/types';
import {projectIso} from './model-world';
import {CARTOON_CAMPUS} from './cartoon-layout';
import {buildingFloorCount,buildingRoof,surfaceCoversActor} from './building-art';
type P={x:number;y:number};
const soften=(hex:string,amount=.24)=>{const n=parseInt(hex.slice(1),16);return '#'+[n>>16,(n>>8)&255,n&255].map(v=>Math.round(v+(246-v)*amount).toString(16).padStart(2,'0')).join('');};
const corners=(r:Rect)=>[{x:r.x,y:r.y},{x:r.x+r.width,y:r.y},{x:r.x+r.width,y:r.y+r.height},{x:r.x,y:r.y+r.height}];
export const cartoonBuildingHeight=(sourceHeight:number,unit:number)=>unit*(1.8+Math.round(sourceHeight/(unit*5.4))*.9);
export function cartoonBuildingScreenPoints(r:Rect,sourceHeight:number,unit:number){const h=cartoonBuildingHeight(sourceHeight,unit);return corners(r).flatMap(p=>{const q=projectIso(p);return [q,{x:q.x,y:q.y-h-unit*1.1}];});}
export function cartoonBuildingOccludes(r:Rect,h:number,unit:number,player:P,actorUnit:number){if(player.x+player.y>=r.x+r.y+r.width+r.height)return false;const points=cartoonBuildingScreenPoints(r,h,unit),p=projectIso(player);return p.x>Math.min(...points.map(q=>q.x))-20*actorUnit&&p.x<Math.max(...points.map(q=>q.x))+20*actorUnit&&p.y>Math.min(...points.map(q=>q.y))&&p.y-50*actorUnit<Math.max(...points.map(q=>q.y));}
const visible=(ctx:CanvasRenderingContext2D,points:P[],pad=48)=>{const t=ctx.getTransform(),p=points.map(q=>({x:t.a*q.x+t.c*q.y+t.e,y:t.b*q.x+t.d*q.y+t.f}));return Math.max(...p.map(q=>q.x))>=-pad&&Math.min(...p.map(q=>q.x))<=ctx.canvas.width+pad&&Math.max(...p.map(q=>q.y))>=-pad&&Math.min(...p.map(q=>q.y))<=ctx.canvas.height+pad;};
export function paintHexTerrain(ctx:CanvasRenderingContext2D,clip:P[],width:number,height:number,unit:number){
 const radius=CARTOON_CAMPUS.hexRadius*unit,stepX=radius*1.5,stepY=Math.sqrt(3)*radius;
 ctx.save();ctx.beginPath();clip.map(projectIso).forEach((q,i)=>i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y));ctx.closePath();ctx.clip();
 const range=visibleHexRange(ctx.getTransform(),ctx.canvas.width,ctx.canvas.height,width,height,radius);
 for(let col=range.col0;col<=range.col1;col++)for(let row=range.row0;row<=range.row1;row++){
  const center={x:col*stepX,y:row*stepY+(col%2)*stepY/2},points=Array.from({length:6},(_,i)=>projectIso({x:center.x+Math.cos(i*Math.PI/3)*radius,y:center.y+Math.sin(i*Math.PI/3)*radius}));if(!visible(ctx,points,8))continue;
  ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();const seed=terrainSeed(col,row);ctx.fillStyle=CARTOON_CAMPUS.grass[seed%CARTOON_CAMPUS.grass.length];ctx.fill();ctx.strokeStyle='#f1edcf65';ctx.lineWidth=.85;ctx.stroke();
  // Sparse ground details have no collision or effect on quest locations.
  const p=projectIso(center),blade=unit*.15;
  if(seed%17===0){ctx.strokeStyle='#598b55a0';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(p.x-blade,p.y);ctx.lineTo(p.x-blade*.5,p.y-blade);ctx.lineTo(p.x,p.y);ctx.lineTo(p.x+blade,p.y-blade*.7);ctx.stroke();}
  else if(seed%43===0){ctx.strokeStyle='#679363a0';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(p.x,p.y+blade);ctx.lineTo(p.x,p.y-blade);ctx.stroke();ctx.fillStyle=seed%2?'#fff5cf':'#e8cb72';for(const dx of [-.6,.6]){ctx.beginPath();ctx.arc(p.x+dx*blade,p.y-blade,blade*.5,0,Math.PI*2);ctx.fill();}}

 }
 ctx.restore();
}
export function paintCartoonBuilding(ctx:CanvasRenderingContext2D,r:Rect,sourceHeight:number,unit:number,u:number,id:string,player?:P){
 const screen=cartoonBuildingScreenPoints(r,sourceHeight,unit);if(!visible(ctx,screen))return false;
 const h=cartoonBuildingHeight(sourceHeight,unit),q=corners(r).map(projectIso),color=(CARTOON_CAMPUS.buildingColors as Record<string,string>)[id]??'#69b8db',outline='#84917b',lift=(p:P,z:number)=>({x:p.x,y:p.y-z});
 ctx.save();ctx.lineJoin='round';
 const poly=(pts:P[],fill:string|CanvasGradient,stroke=outline,width=.7)=>{ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=width*u;ctx.stroke();}};
 const line=(a:P,b:P,c:string,w=2)=>{ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=c;ctx.lineWidth=w*u;ctx.stroke();};
 const wall=ctx.createLinearGradient(q[2].x,q[2].y-h,q[2].x,q[2].y);wall.addColorStop(0,'#faf2de');wall.addColorStop(.7,'#e8e3cc');wall.addColorStop(1,'#d0d4bd');

 const floors=buildingFloorCount(sourceHeight,unit),rows=floors;
 const foot=player?projectIso(player):undefined,behind=!!player&&player.x+player.y<r.x+r.y+r.width+r.height;
 for(const [a,b] of [[q[1],q[2]],[q[2],q[3]]]){
  ctx.save();if(behind&&foot&&surfaceCoversActor([a,b,lift(b,h),lift(a,h)],foot,u))ctx.globalAlpha=.3;
  poly([a,b,lift(b,h),lift(a,h)],a===q[1]?wall:'#d1d9c5');
  const at=(t:number,z:number)=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t-z});
  // Recessed eaves and a stone plinth sit inside the old wall planes.
  poly([at(0,h),at(1,h),at(1,h-unit*.22),at(0,h-unit*.22)],'#556b5c35','');
  poly([at(0,0),at(1,0),at(1,unit*.22),at(0,unit*.22)],'#a8b39c','');
  line(at(0,unit*.35),at(1,unit*.35),color,3);
  const count=Math.max(2,Math.min(7,Math.round(Math.hypot(b.x-a.x,b.y-a.y)/(unit*4))));
  for(let row=0;row<rows;row++){
   const bottom=unit*.3+row*(h-unit*.5)/rows,top=bottom+(h-unit*.5)/rows*.60;
   // Each floor has a recessed window strip, cream slab and regular structural piers.
   poly([at(.04,bottom),at(.96,bottom),at(.96,top+unit*.07),at(.04,top+unit*.07)],'#566f6530','');
   line(at(.03,bottom-unit*.08),at(.97,bottom-unit*.08),'#fbf5e5',1.6);
   for(let i=0;i<count;i++){
    const lo=(i+.22)/count,hi=(i+.78)/count;
    poly([at(lo,bottom),at(hi,bottom),at(hi,top),at(lo,top)],a===q[1]?'#729b9b':'#60888c','#f4efde',1.2);
    poly([at(lo,top),at(hi,top),at(hi,top-h*.045),at(lo,top-h*.045)],'#3d625c50','');
    line(at((lo+hi)/2,bottom),at((lo+hi)/2,top),'#d6e2d4',.8);
    line(at(lo,top-h*.065),at(hi,top-h*.065),'#c5ded4',.8);
    line(at((i+.08)/count,bottom-unit*.05),at((i+.08)/count,top+unit*.1),'#f8f0da',1.5);
   }
  }
  for(const f of [.025,.975])line(at(f,unit*.4),at(f,h-unit*.26),'#f6efda',2);
  ctx.restore();
 }
 // Roof types follow the guide; heights remain compact for gameplay.
 const roof=buildingRoof(r,h,unit,id),screenV=(p:{x:number;y:number;z:number})=>{const q=projectIso(p);return {x:q.x,y:q.y-p.z};};
 const faces=[...roof.faces].sort((a,b)=>a.reduce((s,p)=>s+p.x+p.y,0)/a.length-b.reduce((s,p)=>s+p.x+p.y,0)/b.length);
 for(const [index,face] of faces.entries()){
  const ps=face.map(screenV);ctx.save();if(behind&&foot&&surfaceCoversActor(ps,foot,u))ctx.globalAlpha=.24;
  poly(ps,soften(color,index%2?.18:.38),soften(color,.06),.8);
  if(face.length===4){const [a,b,c,d]=ps;const count=Math.min(22,Math.max(3,Math.round(Math.hypot(b.x-a.x,b.y-a.y)/(unit*1.4))));for(let i=1;i<count;i++){const f=i/count;line({x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f},{x:d.x+(c.x-d.x)*f,y:d.y+(c.y-d.y)*f},'#f9f3df45',.7);}}
  ctx.restore();
 }
 ctx.save();if(behind&&foot&&roof.faces.some(face=>surfaceCoversActor(face.map(screenV),foot,u)))ctx.globalAlpha=.24;
 for(let i=1;i<3;i++)line(screenV(roof.corners[i]),screenV(roof.corners[i+1]),'#f4ecd5',2);
 if(roof.ridge.length)line(screenV(roof.ridge[0]),screenV(roof.ridge[1]),soften(color,.55),2.2);
 if(roof.solar&&r.width>unit*8&&r.height>unit*8){
  // Source guide places solar rows on the activity centre's large roof.
  for(let row=0;row<3;row++)for(let col=0;col<4;col++){
   const x=r.x+r.width*(.18+col*.16),y=r.y+r.height*(.2+row*.2),w=r.width*.13,d=r.height*.14;
   const ps=[{x,y},{x:x+w,y},{x:x+w,y:y+d},{x,y:y+d}].map(p=>screenV({...p,z:h+unit*.28}));
   poly(ps,'#557b8b','#b7cbd0',.7);line(ps[0],ps[2],'#9cbac180',.6);
  }
 }
 ctx.restore();
 // The shared renderer labels each building once; floor choices remain in the directory.
 ctx.restore();return true;
}
