import './photo-exhibit.css';

export interface CampusPhoto {
  id: string;
  title: string;
  group: 'sports' | 'admin' | 'overview';
  location: string;
  src: string;
  date: string;
  description: string;
  // Position on outdoor 2400x1624 campus map
  outdoorPoint?: { x: number; y: number };
}

export const CAMPUS_PHOTOS: readonly CampusPhoto[] = [
  // 操場與運動場角落 (Sports Field & Grandstand)
  {
    id: 'stage-2019',
    title: '操場司令台正面',
    group: 'sports',
    location: '西側田徑場司令台正面',
    src: './assets/photos/stage-2019.jpg',
    date: '2019 年 10 月 22 日・EXIF 拍攝紀錄',
    description: '舞台凹口、黃色收分階梯與同側三旗桿。階梯配色取自校園歷史實景照，為大溪國中朝會集會與運動典禮的核心地標。',
    outdoorPoint: { x: 490, y: 740 },
  },
  {
    id: 'lanes-2019',
    title: '田徑場直道與六道起跑線',
    group: 'sports',
    location: '操場東側直道起跑點',
    src: './assets/photos/lanes-2019.jpg',
    date: '2019 年 10 月 22 日・EXIF 拍攝紀錄',
    description: '地面清晰可見 1–6 道跑道編號及白色斜向起跑引導標記，為大溪同學體育課測驗與校慶運動會衝刺起跑點。',
    outdoorPoint: { x: 720, y: 920 },
  },
  {
    id: 'track-2019',
    title: '田徑跑道彎道與中央球場草坪',
    group: 'sports',
    location: '操場北側彎道與球場',
    src: './assets/photos/track-2019.jpg',
    date: '2019 年 10 月 22 日・EXIF 拍攝紀錄',
    description: '紅色 PU 彈性跑道與內側運動鋪面及綠茵草地，依 115 學年度平面圖校對全貌，提供體能訓練與運動休閒。',
    outdoorPoint: { x: 570, y: 460 },
  },
  {
    id: 'shade-2019',
    title: '操場南側林蔭步道與看台座位',
    group: 'sports',
    location: '田徑場南緣步道',
    src: './assets/photos/shade-2019.jpg',
    date: '2019 年 10 月 22 日・EXIF 拍攝紀錄',
    description: '低矮紅磚花台、茂密樹穴與沿跑道外緣延伸的林蔭步道，是運動會時觀眾席與平日課後學生乘涼休憩的最佳角落。',
    outdoorPoint: { x: 420, y: 950 },
  },
  {
    id: 'hill-2019',
    title: '西側後山階梯擋土牆與林木邊界',
    group: 'sports',
    location: '操場西側後山邊坡',
    src: './assets/photos/hill-2019.jpg',
    date: '2019 年 10 月 22 日・EXIF 拍攝紀錄',
    description: '依山勢構築的斜面分段擋土牆與蒼翠林木邊界，呈現大溪國中依山傍水、自然環抱的山城校園風貌。',
    outdoorPoint: { x: 190, y: 650 },
  },
  {
    id: 'stage-rear-mural',
    title: '司令台背牆彩繪藝術壁畫',
    group: 'sports',
    location: '操場司令台後方彩繪牆',
    src: './assets/photos/stage-rear-mural.jpg',
    date: '校園美育公共藝術實景紀錄',
    description: '司令台後方繪製的巨幅彩繪藝術壁畫，以自然山林與活力筆觸呈現，是大溪國中藝術美感與公共美育的重要展示角落。',
    outdoorPoint: { x: 490, y: 660 },
  },

  // 行政大樓與連廊 (Administration Building)
  {
    id: 'admin-front',
    title: '行政大樓前立面與迎賓花園',
    group: 'admin',
    location: '行政大樓正前方廣場花園',
    src: './assets/photos/admin-front.jpg',
    date: '大溪國中校園實景校對照片',
    description: '行政大樓正面優雅橫向立面與整齊修剪的花園灌木花圃，面向校門大道，為大溪國中行政核心與師長辦公處室前庭。',
    outdoorPoint: { x: 1420, y: 1360 },
  },
  {
    id: 'admin-entry',
    title: '行政大樓正門穿堂與無障礙坡道',
    group: 'admin',
    location: '行政大樓前棟 1F 正門入口',
    src: './assets/photos/admin-entry.jpg',
    date: '大溪國中校園實景校對照片',
    description: '通透明亮的玻璃大門、低平階梯、右側無障礙緩坡道與金屬安全扶手，友善迎接每一位到訪的嘉賓、家長與師生。',
    outdoorPoint: { x: 1523, y: 1367 },
  },
  {
    id: 'admin-gallery',
    title: '行政大樓 1F 穿堂長廊與藝文走廊',
    group: 'admin',
    location: '行政大樓 1F 穿堂中央展覽走廊',
    src: './assets/photos/admin-gallery.jpg',
    date: '大溪國中校園實景校對照片',
    description: '挑高的南北向中央穿堂長廊，兩側設有藝文展覽框與校務資訊公布欄，是串連前棟與後棟各大樓的核心通行走道。',
    outdoorPoint: { x: 1450, y: 1050 },
  },
  {
    id: 'admin-roof',
    title: '行政大樓屋頂斜瓦與高樓層外觀',
    group: 'admin',
    location: '行政大樓 2F/3F 展望外觀',
    src: './assets/photos/admin-roof.jpg',
    date: '大溪國中校園實景校對照片',
    description: '典雅紅色斜面屋瓦、藍綠色檐口包邊與成組明亮通風窗，兼具自然採光與山城校舍建築特色。',
  },

  // 全校空拍與平面圖 (Campus Overview)
  {
    id: 'reference-aerial',
    title: '大溪國中全校高空鳥瞰空拍實景',
    group: 'overview',
    location: '校門迎賓椰林大道全校視角',
    src: './assets/photos/reference-aerial.webp',
    date: '無人機空拍真實影像校對紀錄',
    description: '高空視角全景俯瞰大溪國中校園建築群、綠蔭操場、各教學棟與周邊山巒景致，呈現智慧校園立體架構。',
    outdoorPoint: { x: 1280, y: 1540 },
  },
  {
    id: 'campus_plan_115',
    title: '115 學年度全校平面配置總圖',
    group: 'overview',
    location: '行政大樓穿堂全校配置看板',
    src: './assets/photos/campus_plan_115.jpg',
    date: '115 學年度正式官方校園平面圖',
    description: '正式全區校園平面圖，完整標記學生活動中心、各年級教學棟、行政大樓、科技館、藝術館與各專科教室位置。',
  },
];

// Mapping each indoor floor to its relevant real photos
export function getFloorPhotos(floorId: string): CampusPhoto[] {
  if (floorId.includes('admin-front')) {
    if (floorId.endsWith('-1')) return [CAMPUS_PHOTOS[7], CAMPUS_PHOTOS[8], CAMPUS_PHOTOS[6]]; // admin-entry, admin-gallery, admin-front
    if (floorId.endsWith('-2')) return [CAMPUS_PHOTOS[9], CAMPUS_PHOTOS[6], CAMPUS_PHOTOS[11]]; // admin-roof, admin-front, plan
    return [CAMPUS_PHOTOS[9], CAMPUS_PHOTOS[10], CAMPUS_PHOTOS[11]]; // 3F: admin-roof, aerial, plan
  }
  if (floorId.includes('admin-back')) {
    return [CAMPUS_PHOTOS[8], CAMPUS_PHOTOS[6], CAMPUS_PHOTOS[11]]; // gallery, front, plan
  }
  if (floorId.includes('gym-bld')) {
    return [CAMPUS_PHOTOS[0], CAMPUS_PHOTOS[1], CAMPUS_PHOTOS[10]]; // stage, lanes, aerial
  }
  if (floorId.includes('grade8-front')) {
    return [CAMPUS_PHOTOS[3], CAMPUS_PHOTOS[10], CAMPUS_PHOTOS[11]]; // shade, aerial, plan
  }
  if (floorId.includes('grade9-back')) {
    return [CAMPUS_PHOTOS[10], CAMPUS_PHOTOS[11]]; // aerial, plan
  }
  if (floorId.includes('grade8-mid')) {
    return [CAMPUS_PHOTOS[1], CAMPUS_PHOTOS[10], CAMPUS_PHOTOS[11]]; // lanes, aerial, plan
  }
  if (floorId.includes('new-grade7')) {
    return [CAMPUS_PHOTOS[10], CAMPUS_PHOTOS[11]]; // aerial, plan
  }
  if (floorId.includes('multi-building')) {
    return [CAMPUS_PHOTOS[10], CAMPUS_PHOTOS[11]]; // aerial, plan
  }
  if (floorId.includes('tech-building') || floorId.includes('pilot-tech')) {
    return [CAMPUS_PHOTOS[10], CAMPUS_PHOTOS[11]]; // aerial, plan
  }
  if (floorId.includes('art-building')) {
    return [CAMPUS_PHOTOS[5], CAMPUS_PHOTOS[10]]; // stage-rear-mural, aerial
  }
  if (floorId.includes('health-bld')) {
    return [CAMPUS_PHOTOS[6], CAMPUS_PHOTOS[11]]; // admin-front, plan
  }
  if (floorId.includes('recycle-bld')) {
    return [CAMPUS_PHOTOS[3], CAMPUS_PHOTOS[11]]; // shade, plan
  }
  return [CAMPUS_PHOTOS[10], CAMPUS_PHOTOS[11]];
}

export function createPhotoModal() {
  const dialog = document.createElement('dialog');
  dialog.id = 'campus-photo-dialog';
  dialog.className = 'campus-photo-modal';
  dialog.setAttribute('aria-label', '大溪國中校園實景照片');

  dialog.innerHTML = `
    <header class="photo-modal-header">
      <div class="photo-modal-mast">
        <span class="photo-modal-badge">📷 實景對照</span>
        <div>
          <h2 id="photo-modal-title">大溪國中校園實景紀錄</h2>
          <small>引用自 3D 立體校園導覽真實照片資料庫</small>
        </div>
      </div>
      <button type="button" class="photo-modal-close" id="photo-modal-close" aria-label="關閉實景視窗">✕ 關閉</button>
    </header>

    <nav class="photo-modal-tabs" aria-label="照片分類">
      <button type="button" data-group="sports" class="photo-tab-btn active">操場與運動場 (6)</button>
      <button type="button" data-group="admin" class="photo-tab-btn">行政大樓 (4)</button>
      <button type="button" data-group="overview" class="photo-tab-btn">全校空拍與平面圖 (2)</button>
    </nav>

    <div class="photo-modal-content">
      <figure class="photo-modal-figure">
        <div class="photo-modal-img-wrap">
          <img id="photo-modal-img" src="" alt="" loading="eager">
        </div>
        <figcaption class="photo-modal-caption">
          <div class="photo-meta-tags">
            <span id="photo-modal-date" class="photo-tag-date"></span>
            <span id="photo-modal-loc" class="photo-tag-loc"></span>
          </div>
          <h3 id="photo-modal-caption-title"></h3>
          <p id="photo-modal-desc"></p>
        </figcaption>
      </figure>
    </div>

    <footer class="photo-modal-footer">
      <div class="photo-modal-nav">
        <button type="button" id="photo-modal-prev" class="secondary-button">← 上一張</button>
        <span id="photo-modal-count" class="photo-count-pill">1 / 12</span>
        <button type="button" id="photo-modal-next" class="secondary-button">下一張 →</button>
      </div>
      <div class="photo-modal-actions">
        <button type="button" id="photo-modal-navigate" class="primary-button">前往此校園角落 ↗</button>
      </div>
    </footer>
  `;

  document.body.append(dialog);

  let currentPhotos = [...CAMPUS_PHOTOS];
  let currentIndex = 0;

  const titleEl = dialog.querySelector<HTMLElement>('#photo-modal-caption-title')!;
  const descEl = dialog.querySelector<HTMLElement>('#photo-modal-desc')!;
  const dateEl = dialog.querySelector<HTMLElement>('#photo-modal-date')!;
  const locEl = dialog.querySelector<HTMLElement>('#photo-modal-loc')!;
  const imgEl = dialog.querySelector<HTMLImageElement>('#photo-modal-img')!;
  const countEl = dialog.querySelector<HTMLElement>('#photo-modal-count')!;
  const navBtn = dialog.querySelector<HTMLButtonElement>('#photo-modal-navigate')!;

  function renderPhoto(index: number) {
    if (!currentPhotos.length) return;
    currentIndex = (index + currentPhotos.length) % currentPhotos.length;
    const p = currentPhotos[currentIndex];
    imgEl.src = new URL(p.src, document.baseURI).href;
    imgEl.alt = p.title;
    titleEl.textContent = p.title;
    descEl.textContent = p.description;
    dateEl.textContent = p.date;
    locEl.textContent = `📍 ${p.location}`;
    countEl.textContent = `${currentIndex + 1} / ${currentPhotos.length}`;

    if (p.outdoorPoint) {
      navBtn.hidden = false;
      navBtn.textContent = `帶路前往「${p.title}」↗`;
    } else {
      navBtn.hidden = true;
    }

    // Highlight active tab
    dialog.querySelectorAll('.photo-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-group') === p.group);
    });
  }

  dialog.querySelector('#photo-modal-close')!.addEventListener('click', () => dialog.close());
  dialog.querySelector('#photo-modal-prev')!.addEventListener('click', () => renderPhoto(currentIndex - 1));
  dialog.querySelector('#photo-modal-next')!.addEventListener('click', () => renderPhoto(currentIndex + 1));
  dialog.addEventListener('close', () => {
    window.dispatchEvent(new CustomEvent('campus:map-open', { detail: false }));
  });

  dialog.querySelectorAll('.photo-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const g = btn.getAttribute('data-group');
      const filtered = CAMPUS_PHOTOS.filter(p => p.group === g);
      if (filtered.length) {
        currentPhotos = filtered;
        renderPhoto(0);
      }
    });
  });

  navBtn.addEventListener('click', () => {
    const p = currentPhotos[currentIndex];
    if (p.outdoorPoint) {
      dialog.close();
      window.dispatchEvent(new CustomEvent('campus:navigate-to-point', {
        detail: { x: p.outdoorPoint.x, y: p.outdoorPoint.y, label: p.title }
      }));
    }
  });

  dialog.addEventListener('keydown', e => {
    if (e.key === 'ArrowLeft') renderPhoto(currentIndex - 1);
    else if (e.key === 'ArrowRight') renderPhoto(currentIndex + 1);
    else if (e.key === 'Escape') dialog.close();
  });

  return {
    open(photoId?: string, photos?: CampusPhoto[]) {
      if (photos && photos.length) {
        currentPhotos = photos;
        const idx = photoId ? currentPhotos.findIndex(p => p.id === photoId) : 0;
        renderPhoto(idx >= 0 ? idx : 0);
      } else {
        currentPhotos = [...CAMPUS_PHOTOS];
        const idx = photoId ? currentPhotos.findIndex(p => p.id === photoId) : 0;
        renderPhoto(idx >= 0 ? idx : 0);
      }
      window.dispatchEvent(new CustomEvent('campus:map-open', { detail: true }));
      if (!dialog.open) dialog.showModal();
    },
    close() {
      if (dialog.open) dialog.close();
    }
  };
}

export type PhotoModal = ReturnType<typeof createPhotoModal>;

/** Draw outdoor camera photo-spots on the campus map canvas */
export function drawOutdoorPhotoSpots(
  ctx: CanvasRenderingContext2D,
  scale: number,
  unit: number,
  player: { x: number; y: number },
  now: number
) {
  const pulse = 0.8 + 0.2 * Math.sin(now / 300);

  for (const p of CAMPUS_PHOTOS) {
    if (!p.outdoorPoint) continue;
    const x = p.outdoorPoint.x * scale;
    const y = p.outdoorPoint.y * scale;
    const dist = Math.hypot(player.x - x, player.y - y);
    const isNear = dist < 65;

    ctx.save();
    // Glowing base aura
    ctx.beginPath();
    ctx.arc(x, y, 16 * unit, 0, Math.PI * 2);
    ctx.fillStyle = isNear ? `rgba(245, 158, 11, ${0.4 * pulse})` : `rgba(16, 185, 129, ${0.3 * pulse})`;
    ctx.fill();

    // Outer circle
    ctx.beginPath();
    ctx.arc(x, y, 14 * unit, 0, Math.PI * 2);
    ctx.fillStyle = isNear ? '#f59e0b' : '#059669';
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2 * unit;
    ctx.stroke();

    // Camera Icon text
    ctx.font = `${14 * unit}px system-ui`;
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('📷', x, y);

    // Floating Label
    const label = isNear ? `${p.title} [按E查看實景]` : `${p.title}`;
    ctx.font = `bold ${12 * unit}px system-ui`;
    const tw = ctx.measureText(label).width;
    const pad = 5 * unit;

    ctx.fillStyle = isNear ? '#0f172aee' : '#0f172acc';
    ctx.fillRect(x - tw / 2 - pad, y - 28 * unit, tw + pad * 2, 17 * unit);
    ctx.strokeStyle = isNear ? '#f59e0b' : '#34d399';
    ctx.lineWidth = 1 * unit;
    ctx.strokeRect(x - tw / 2 - pad, y - 28 * unit, tw + pad * 2, 17 * unit);

    ctx.fillStyle = isNear ? '#fbbf24' : '#ffffff';
    ctx.fillText(label, x, y - 19 * unit);

    ctx.restore();
  }
}

/** Check if player is near any outdoor photo hotspot */
export function nearestOutdoorPhoto(
  player: { x: number; y: number },
  scale: number,
  radius = 65
): CampusPhoto | undefined {
  return CAMPUS_PHOTOS.find(p => {
    if (!p.outdoorPoint) return false;
    const x = p.outdoorPoint.x * scale;
    const y = p.outdoorPoint.y * scale;
    return Math.hypot(player.x - x, player.y - y) <= radius;
  });
}
