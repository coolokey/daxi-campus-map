type Point={x:number;y:number};
export function nearestInRange<T extends Point&{interactionRadius:number}>(npcs:T[],player:Point):T|undefined{
  let best:T|undefined,distance=Infinity;
  for(const n of npcs){
    const d=(n.x-player.x)**2+(n.y-player.y)**2;
    if(d<=n.interactionRadius**2&&d<distance){best=n;distance=d;}
  }
  return best;
}
