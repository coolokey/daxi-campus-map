/** Camera distances are world units; backing pixels are exclusively a rendering detail. */
export function sizeViewport(cssWidth:number,cssHeight:number,dpr:number){
  const pixelRatio=Math.min(2,Math.max(1,dpr||1)),zoom=.75;
  return {cssWidth,cssHeight,pixelRatio,zoom,logicalWidth:cssWidth/zoom,logicalHeight:cssHeight/zoom,bufferWidth:Math.max(1,Math.round(cssWidth*pixelRatio)),bufferHeight:Math.max(1,Math.round(cssHeight*pixelRatio))};
}
export const viewport=sizeViewport(1280,720,1);
export function cameraOrigin(map:{width:number;height:number},player:{x:number;y:number}){
  return {x:Math.max(0,Math.min(map.width-viewport.logicalWidth,player.x-viewport.logicalWidth/2)),y:Math.max(0,Math.min(map.height-viewport.logicalHeight,player.y-viewport.logicalHeight/2))};
}
export const screenUnit=(scale:number)=>viewport.pixelRatio/scale;
