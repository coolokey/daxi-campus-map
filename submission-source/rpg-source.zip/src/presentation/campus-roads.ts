import plan from '../../public/data/campus-roads-v1.json';
import type {MapConfig} from '../game/data/types';
import {findPath} from './navigation';
export const campusRoadPlan=plan;
type C={x:number;z:number};type T={unit:number;toGame:(p:C)=>{x:number;y:number}};
/** Resolve existing portal coordinates once; rendering never invents an entrance or bypasses a collider. */
export function attachCampusEntrancePaths(map:MapConfig,t:T){
 map.outdoorPaths=plan.entranceLinks.flatMap(link=>{
  const id=link.building==='tech-building'?'technology-building-door':`building-entry:${link.building}${link.portalIndex?`:${link.portalIndex}`:''}`;
  const portal=map.portals.find(p=>p.id===id);if(!portal)throw Error(`Missing road entrance ${id}`);
  const route=findPath(t.toGame(link.anchor),{x:portal.trigger.x+22,y:portal.trigger.y+22},map);
  if(!route)throw Error(`Unreachable road entrance ${id}`);
  return [{points:route,width:plan.connectorWidth*t.unit}];
 });
}
