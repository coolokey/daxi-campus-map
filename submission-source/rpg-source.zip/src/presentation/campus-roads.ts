import plan from '../../public/data/campus-roads-v1.json';
import type {MapConfig} from '../game/data/types';
import {findPath} from './navigation';
export const campusRoadPlan=plan;
type C={x:number;z:number};type T={unit:number;toGame:(p:C)=>{x:number;y:number}};
/** Resolve existing portal coordinates once; rendering never invents an entrance or bypasses a collider. */
export function attachCampusEntrancePaths(map:MapConfig,t:T){
 map.outdoorPaths=plan.entranceLinks.flatMap(link=>{
  const id=link.building==='tech-building'?'technology-building-door':`building-entry:${link.building}${link.portalIndex?`:${link.portalIndex}`:''}`;
  const portal=map.portals.find(p=>p.id===id);if(!portal)throw Error(`Missing road entrance ${id}`);
  const route=findPath(t.toGame(link.anchor),{x:portal.trigger.x+22,y:portal.trigger.y+22},map);
  if(!route)throw Error(`Unreachable road entrance ${id}`);
  return [{points:route,width:plan.connectorWidth*t.unit}];
 });
 for(const route of plan.westPaths){
  const target=route.target,portal=target.kind==='portal'?map.portals.find(p=>p.id===target.id):undefined,landmark=target.kind==='landmark'?map.landmarks?.find(p=>p.label===target.label):undefined;
  const end=portal?{x:portal.trigger.x+22,y:portal.trigger.y+22}:landmark?{x:landmark.x,y:landmark.y}:undefined;
  if(!end)throw Error(`Missing western path destination ${route.id}`);
  const stops=[t.toGame(route.start),...route.via.map(t.toGame),end],points=[stops[0]];
  for(let i=1;i<stops.length;i++){const leg=findPath(stops[i-1],stops[i],map);if(!leg)throw Error(`Unreachable western path ${route.id} leg ${i}`);points.push(...leg.slice(1));}
  map.outdoorPaths.push({id:route.id,label:route.name,points,width:plan.westPathWidth*t.unit});
 }
}
