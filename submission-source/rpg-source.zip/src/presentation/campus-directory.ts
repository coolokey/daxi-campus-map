import plan from '../../public/data/campus-plan-115.json';
import type { MapConfig, SpawnPoint } from '../game/data/types';
import type { Pilot, SharedCampus } from './pilot-adapter';
import type { FloorExpansion } from './floor-expansion';
import { findPath, type Point } from './navigation';
import './campus-directory.css';
type State={map:MapConfig;player:SpawnPoint};
export type DirectoryState={state:State;pilot?:Pilot;expanded?:FloorExpansion};
const emit=(mapId:string,points:Point[]|null,label:string)=>window.dispatchEvent(new CustomEvent('campus:navigation-route',{detail:{mapId,points,label}}));
/** Picks a next scene doorway by breadth-first graph traversal; local routes still respect collision. */
export function nextPortal(current:MapConfig,target:string,maps:Record<string,MapConfig>){
  const queue=[current.id as string],seen=new Set(queue),first=new Map<string,MapConfig['portals'][number]>();
  for(let i=0;i<queue.length;i++){const id=queue[i];for(const p of maps[id]?.portals??[]){if(p.destinationMapId==='campus'||seen.has(p.destinationMapId))continue;seen.add(p.destinationMapId);first.set(p.destinationMapId,id===current.id?p:first.get(id)!);if(p.destinationMapId===target)return first.get(target);queue.push(p.destinationMapId);}}
  return undefined;
}
export function mountCampusDirectory(read:()=>DirectoryState){
  const button=document.createElement('button');button.textContent='校園建築';button.id='campus-directory-open';
  const dialog=document.createElement('dialog');dialog.className='campus-directory';dialog.setAttribute('aria-label','校園建築與樓層目錄');
  const title=document.createElement('h2');title.textContent='校園建築與樓層';
  const note=document.createElement('p');note.textContent='依 115 學年度平面圖核對。彩色地圖保留原風格；入口為遊戲位置，室內尺寸與門位為示意。';
  const controls=document.createElement('div');controls.className='directory-selects';
  const building=document.createElement('select');building.setAttribute('aria-label','選擇校園建築');
  for(const b of plan.buildings)building.add(new Option(b.name+(b.enabledLevels.length?'':'（待核對）'),b.buildingId));
  const level=document.createElement('select');level.setAttribute('aria-label','選擇樓層');controls.append(building,level);
  const status=document.createElement('p');status.setAttribute('role','status');
  const rooms=document.createElement('div');rooms.className='directory-rooms';
  const image=document.createElement('img');image.src=new URL('./assets/maps/campus-plan-115.jpg',document.baseURI).href;image.alt='115 學年度正式校園平面圖';image.loading='lazy';
  const details=document.createElement('details'),summary=document.createElement('summary');summary.textContent='查看正式校園平面圖';details.append(summary,image);
  const close=document.createElement('button');close.textContent='返回探索';dialog.append(title,note,controls,status,rooms,details,close);
  document.querySelector('.explore-toolbar')!.append(button);document.body.append(dialog);
  let goal:{buildingId:string;level:number;roomId?:string;name:string}|undefined,lastMap:MapConfig|undefined;
  function scene(b:string,l:number){return b==='tech-building'?`pilot-tech-${l}`:`floor-${b}-${l}`;}
  function route(){
    if(!goal)return;const {state,pilot,expanded}=read();const {map,player}=state;
    let target:Point|undefined,label=goal.name;
    if(map.id==='campus'){
      const p=map.portals.find(p=>goal!.buildingId==='tech-building'?p.id==='technology-building-door':p.id===`building-entry:${goal!.buildingId}`);
      if(p)target={x:p.trigger.x+p.trigger.width/2,y:p.trigger.y+p.trigger.height/2};
    }else if(pilot){
      const targetScene=scene(goal.buildingId,goal.level),all={...pilot.maps,...expanded?.maps};
      if(map.id===targetScene){
        const room=pilot.shared.rooms.find(r=>r.id===goal!.roomId),transform=expanded?.transforms[map.id]??pilot.transforms[map.id as keyof typeof pilot.transforms];
        target=room&&transform?transform.toGame(room.center):map.spawns.entry??map.spawns.stairs;
      }else{
        const p=nextPortal(map,targetScene,all);
        if(p){target={x:p.trigger.x+p.trigger.width/2,y:p.trigger.y+p.trigger.height/2};label=`${goal.name}・先使用${p.prompt.replace('E：','')}`;}
        else {const exit=map.portals.find(p=>p.id==='tech-exit'||p.id==='building-exit');if(exit){target={x:exit.trigger.x+18,y:exit.trigger.y+18};label='先離開目前建築，再前往'+goal.name;}
          else {const exitMap=map.id.startsWith('pilot-')?'pilot-tech-1':`floor-${expanded?.floors[map.id]?.buildingId}-1`,p=nextPortal(map,exitMap,all);if(p){target={x:p.trigger.x+18,y:p.trigger.y+18};label='先下樓返回校園，再前往'+goal.name;}}}
      }
    }
    const path=target?findPath(player,target,map):null;status.textContent=path?`${label}：沿金色避障路線手動移動，入口／樓梯按 E。`:'此目標目前無可通行路線，請重新選擇。';emit(map.id,path,label);
  }
  function selectGoal(roomId?:string,name?:string){const b=plan.buildings.find(b=>b.buildingId===building.value)!;goal={buildingId:b.buildingId,level:Number(level.value),roomId,name:name??`${b.name} ${level.value}F`};route();dialog.close();}
  function renderRooms(){
    rooms.replaceChildren();const b=plan.buildings.find(b=>b.buildingId===building.value)!;status.textContent=b.note;
    if(!b.enabledLevels.length)return;
    const entry=document.createElement('button');entry.textContent=`前往 ${b.name.split(' / ')[0]} ${level.value}F`;entry.onclick=()=>selectGoal();rooms.append(entry);
    for(const r of plan.rooms.filter(r=>r.buildingId===b.buildingId&&r.floorId===`${b.buildingId}:floor-${level.value}`&&r.enabled)){
      const name=plan.roomOverrides.find(o=>o.roomId===r.roomId)?.name??r.sourceName,button=document.createElement('button');button.textContent=name;button.onclick=()=>selectGoal(r.roomId,name);rooms.append(button);
    }
  }
  function renderLevels(){level.replaceChildren();const b=plan.buildings.find(b=>b.buildingId===building.value)!;for(const l of b.enabledLevels)level.add(new Option(`${l}F`,String(l)));level.disabled=!b.enabledLevels.length;renderRooms();}
  building.onchange=renderLevels;level.onchange=renderRooms;close.onclick=()=>dialog.close();
  button.onclick=()=>{renderLevels();dialog.showModal();window.dispatchEvent(new CustomEvent('campus:map-open',{detail:true}));building.focus();};
  dialog.onclose=()=>{window.dispatchEvent(new CustomEvent('campus:map-open',{detail:false}));button.focus();};
  window.addEventListener('campus:snapshot',()=>{const map=read().state.map;if(lastMap!==map){lastMap=map;route();}});
  window.addEventListener('campus:navigation-route',e=>{if((e as CustomEvent<{label:string}>).detail.label==='自訂目標')goal=undefined;});
}
