import {entranceLandmarks} from './entrance-landmarks';
import {CENTER_STATIONS} from '../data/three-centers';
import {modelScene,type ModelWorld} from './model-world';
import plan from './model-catalog.json';
import type { MapConfig, SpawnPoint } from '../game/data/types';
import type { Pilot, SharedCampus } from './pilot-adapter';
import type { FloorExpansion } from './floor-expansion';
import { findPath, canReach, type Point } from './navigation';
import './campus-directory.css';
type State={map:MapConfig;player:SpawnPoint};
export type DirectoryState={state:State;pilot?:Pilot;expanded?:FloorExpansion;model?:ModelWorld};
const emit=(mapId:string,points:Point[]|null,label:string)=>window.dispatchEvent(new CustomEvent('campus:navigation-route',{detail:{mapId,points,label}}));
/** Picks a next scene doorway by breadth-first graph traversal; local routes still respect collision. */
export function nextPortal(current:MapConfig,target:string,maps:Record<string,MapConfig>){
  const queue=[current.id as string],seen=new Set(queue),first=new Map<string,MapConfig['portals'][number]>();
  for(let i=0;i<queue.length;i++){const id=queue[i];for(const p of maps[id]?.portals??[]){if(p.destinationMapId==='campus'||seen.has(p.destinationMapId))continue;seen.add(p.destinationMapId);first.set(p.destinationMapId,id===current.id?p:first.get(id)!);if(p.destinationMapId===target)return first.get(target);queue.push(p.destinationMapId);}}
  return undefined;
}
export const FLOOR_PLAN_SHEETS=[
  {id:'1f-c',label:'1F 方案C（導師室＋穿堂）',src:'./floor-plans/一樓各辦公教室相對位置圖_方案C.png',alt:'一樓各辦公教室相對位置圖（方案C：西側導師室＋1F中央穿堂＋東側導師室）'},
  {id:'1f-a',label:'1F 方案A（雙導師室）',src:'./floor-plans/一樓各辦公教室相對位置圖_方案A.png',alt:'一樓各辦公教室相對位置圖（方案A：西側導師室＋東側導師室）'},
  {id:'1f-b',label:'1F 方案B（導師室＋會議室）',src:'./floor-plans/一樓各辦公教室相對位置圖_方案B.png',alt:'一樓各辦公教室相對位置圖（方案B：導師室＋會議室）'},
  {id:'2f',label:'2F 相對位置圖',src:'./floor-plans/二樓各辦公教室相對位置圖.png',alt:'二樓各辦公教室相對位置圖'},
  {id:'3f',label:'3F 相對位置圖',src:'./floor-plans/三樓各辦公教室相對位置圖.png',alt:'三樓各辦公教室相對位置圖'},
  {id:'aerial',label:'📷 全校空拍實景',src:'./assets/photos/reference-aerial.webp',alt:'大溪國中全校高空鳥瞰真實影像照片'},
  {id:'admin-photo',label:'📷 行政大樓實景',src:'./assets/photos/admin-front.jpg',alt:'大溪國中行政大樓前立面與花園實景照片'},
  {id:'sports-photo',label:'📷 操場司令台實景',src:'./assets/photos/stage-2019.jpg',alt:'大溪國中操場司令台實景照片'},
  {id:'raw',label:'115 原始平面圖',src:'./assets/maps/campus-plan-115.jpg',alt:'115 學年度正式校園平面圖'}
] as const;
export function mountCampusDirectory(read:()=>DirectoryState){
  const button=document.createElement('button');button.textContent='校園建築';button.id='campus-directory-open';
  const dialog=document.createElement('dialog');dialog.className='campus-directory';dialog.setAttribute('aria-label','校園建築與樓層目錄');
  const title=document.createElement('h2');title.textContent='校園建築與樓層';
  const note=document.createElement('p');note.textContent='依 115 學年度平面圖與一至三樓各大樓相對位置圖核對。採用最新版導覽建模的建築、入口與連通關係；室內尺寸為示意，非測量圖。';
  const controls=document.createElement('div');controls.className='directory-selects';
  const building=document.createElement('select');building.setAttribute('aria-label','選擇校園建築');
  for(const b of plan.buildings)building.add(new Option(b.name+(b.enabledLevels.length?'':'（待核對）'),b.buildingId));
  const level=document.createElement('select');level.setAttribute('aria-label','選擇樓層');controls.append(building,level);
  const status=document.createElement('p');status.setAttribute('role','status');
  const rooms=document.createElement('div');rooms.className='directory-rooms';
  const tabs=document.createElement('div');tabs.className='directory-plan-tabs';
  const image=document.createElement('img');image.loading='lazy';
  const setSheet=(sheetId:string)=>{
    const sheet=FLOOR_PLAN_SHEETS.find(s=>s.id===sheetId)??FLOOR_PLAN_SHEETS[0];
    image.src=new URL(sheet.src,document.baseURI).href;image.alt=sheet.alt;
    for(const btn of tabs.querySelectorAll('button'))btn.setAttribute('aria-pressed',String(btn.dataset.sheetId===sheet.id));
  };
  for(const sheet of FLOOR_PLAN_SHEETS){
    const tab=document.createElement('button');tab.type='button';tab.dataset.sheetId=sheet.id;tab.textContent=sheet.label;
    tab.onclick=()=>setSheet(sheet.id);tabs.append(tab);
  }
  setSheet('1f-c');
  const link=document.createElement('a');link.className='directory-plan-link';link.href=new URL('./floor-plans/各大樓一至三樓相對位置圖.html',document.baseURI).href;
  link.target='_blank';link.rel='noopener noreferrer';link.textContent='開啟完整 1F～3F 各大樓相對位置圖對照網頁 ↗';
  const details=document.createElement('details'),summary=document.createElement('summary');summary.textContent='查看 1F～3F 各大樓相對位置圖與正式平面圖';details.append(summary,tabs,link,image);
  const close=document.createElement('button');close.textContent='返回探索';dialog.append(title,note,controls,status,rooms,details,close);
  const landmarks=document.createElement('details'),heading=document.createElement('summary');heading.textContent='校門地標與椰林大道';landmarks.append(heading);
  for(const p of entranceLandmarks.targets){const b=document.createElement('button');b.textContent='前往'+p.name;b.onclick=()=>{const {state:{map,player},model}=read();if(map.id!=='campus'||!model){status.textContent='請先返回室外校園，再選擇校門地標。';return;}const points=findPath(player,model.transforms.campus.toGame(p),map);status.textContent=points?'已設定地標導航。':'目前無法前往地標。';emit(map.id,points,'實景參考區・'+p.name);dialog.close();};landmarks.append(b);}
  dialog.insertBefore(landmarks,controls);
  document.querySelector('.explore-toolbar')!.append(button);document.body.append(dialog);
  let goal:{buildingId:string;level:number;roomId?:string;name:string}|undefined,lastMap:MapConfig|undefined;
  function scene(b:string,l:number){return b==='tech-building'?`pilot-tech-${l}`:`floor-${b}-${l}`;}
  function route(){
    if(!goal)return;const {state,pilot,expanded,model}=read();const {map,player}=state;
    let target:Point|undefined,label=goal.name;
    if(model){
      const scene=modelScene(goal.buildingId,goal.level),room=model.targets[scene]?.find(r=>r.id===goal!.roomId),end=room?.point??model.maps[scene].spawns.entry;
      const components=new Map<string,Point[]>();
      const queue:{id:string;point:Point;first?:Point}[]=[{id:map.id,point:player}],seen=new Set<string>();
      for(let i=0;i<queue.length;i++){const q=queue[i],m=model.maps[q.id],visited=components.get(q.id)??[];if(visited.some(p=>canReach(p,q.point,m)))continue;visited.push(q.point);components.set(q.id,visited);if(q.id===scene&&canReach(q.point,end,m)){target=q.first??end;break;}
        for(const p of m.portals){const key=p.destinationMapId+':'+p.destinationSpawnId,point={x:p.trigger.x+p.trigger.width/2,y:p.trigger.y+p.trigger.height/2};if(seen.has(key)||!canReach(q.point,point,m))continue;seen.add(key);queue.push({id:p.destinationMapId,point:model.maps[p.destinationMapId].spawns[p.destinationSpawnId],first:q.first??point});}
      }
      if(target&&map.id!==scene)label+= '・依序使用入口／樓梯';
    }else if(map.id==='campus'){
      const p=map.portals.find(p=>goal!.buildingId==='tech-building'?p.id==='technology-building-door':p.id===`building-entry:${goal!.buildingId}`);
      if(p)target={x:p.trigger.x+p.trigger.width/2,y:p.trigger.y+p.trigger.height/2};
    }else if(pilot){
      const targetScene=scene(goal.buildingId,goal.level),all={...pilot.maps,...expanded?.maps};
      if(map.id===targetScene){
        const room=pilot.shared.rooms.find(r=>r.id===goal!.roomId),transform=expanded?.transforms[map.id]??pilot.transforms[map.id as keyof typeof pilot.transforms];
        target=room&&transform?transform.toGame(room.center):map.spawns.entry??map.spawns.stairs;
      }else{
        const p=nextPortal(map,targetScene,all);
        if(p){target={x:p.trigger.x+p.trigger.width/2,y:p.trigger.y+p.trigger.height/2};label=`${goal.name}・先使用${p.prompt.replace('E：','')}`;}
        else {const exit=map.portals.find(p=>p.id==='tech-exit'||p.id==='building-exit');if(exit){target={x:exit.trigger.x+18,y:exit.trigger.y+18};label='先離開目前建築，再前往'+goal.name;}
          else {const exitMap=map.id.startsWith('pilot-')?'pilot-tech-1':`floor-${expanded?.floors[map.id]?.buildingId}-1`,p=nextPortal(map,exitMap,all);if(p){target={x:p.trigger.x+18,y:p.trigger.y+18};label='先下樓返回校園，再前往'+goal.name;}}}
      }
    }
    const path=target?findPath(player,target,map):null;status.textContent=path?`${label}：沿金色避障路線手動移動，入口／樓梯按 E。`:'此目標目前無可通行路線，請重新選擇。';emit(map.id,path,label);
  }
  function selectGoal(roomId?:string,name?:string){const b=plan.buildings.find(b=>b.buildingId===building.value)!;goal={buildingId:b.buildingId,level:Number(level.value),roomId,name:name??`${b.name} ${level.value}F`};route();dialog.close();}
  function renderRooms(){
    rooms.replaceChildren();const b=plan.buildings.find(b=>b.buildingId===building.value)!;status.textContent=b.note;
    setSheet(level.value==='2'?'2f':level.value==='3'||level.value==='4'?'3f':'1f-c');
    if(!b.enabledLevels.length)return;
    const entry=document.createElement('button');entry.textContent=`前往 ${b.name.split(' / ')[0]} ${level.value}F`;entry.onclick=()=>selectGoal();rooms.append(entry);
    for(const r of plan.rooms.filter(r=>r.buildingId===b.buildingId&&r.floorId===`${b.buildingId}:floor-${level.value}`&&r.enabled)){
      const name=r.sourceName,button=document.createElement('button');button.textContent=name;button.onclick=()=>selectGoal(r.roomId,name);rooms.append(button);
    }
  }
  function renderLevels(){level.replaceChildren();const b=plan.buildings.find(b=>b.buildingId===building.value)!;for(const l of b.enabledLevels)level.add(new Option(`${l}F`,String(l)));level.disabled=!b.enabledLevels.length;renderRooms();}
  building.onchange=renderLevels;level.onchange=renderRooms;close.onclick=()=>dialog.close();
  button.onclick=()=>{renderLevels();dialog.showModal();window.dispatchEvent(new CustomEvent('campus:map-open',{detail:true}));building.focus();};
  dialog.onclose=()=>{window.dispatchEvent(new CustomEvent('campus:map-open',{detail:false}));button.focus();};
  window.addEventListener('campus:three-centers-navigate',e=>{const detail=(e as CustomEvent<{stationId:string}>).detail;const s=CENTER_STATIONS.find(s=>s.id===detail.stationId);if(!s)return;goal={buildingId:s.buildingId,level:s.level,roomId:s.roomId,name:s.title};route();});
  window.addEventListener('campus:snapshot',()=>{const map=read().state.map;if(lastMap!==map){lastMap=map;route();}});
  window.addEventListener('campus:navigation-route',e=>{if((e as CustomEvent<{label:string}>).detail.label==='自訂目標'||(e as CustomEvent<{label:string}>).detail.label.startsWith('實景參考區'))goal=undefined;});
}
