import plan from '../../public/data/campus-plan-115.json';
import type { MapConfig } from '../game/data/types';
import type { WorldId } from '../game/config';
import { createTransform, blocksFloor, safePilotPosition, type SharedCampus, type RuntimeCampus, type Canonical, type Volume } from './pilot-adapter';
import { auxiliaryZones } from './pilot-renderer';
export type FloorId=`floor-${string}`;
export type RoomTarget={id:string;name:string;point:{x:number;y:number};door:{x:number;y:number}};
export const floorId=(building:string,level:number):FloorId=>`floor-${building}-${level}`;
export const planBuildings=plan.buildings;
/** A separate annual register gates source-derived floor data. Originals stay unchanged. */
export function createFloorExpansion(shared:SharedCampus,runtime:RuntimeCampus,scale:number){
  shared={...shared,
    rooms:shared.rooms.map(r=>({...r,name:plan.roomOverrides.find(o=>o.roomId===r.id)?.name??r.name})),
    floors:shared.floors.map(f=>{
      if(f.buildingId==='new-grade7')return {...f,corridors:[{x0:57,x1:97.8,z0:-57,z1:-51},{x0:95,x1:97.8,z0:-65,z1:-51}]};
      if(f.buildingId==='multi-building')return {...f,corridors:[{x0:58,x1:90,z0:-35.8,z1:-33},{x0:58,x1:90,z0:-13,z1:-10.2},{x0:81.2,x1:84,z0:-35.8,z1:-10.2}]};
      if(f.id==='admin-front:floor-1')return {...f,corridors:[...f.corridors,{x0:-15.25,x1:-11.5,z0:39,z1:46.2}]};
      return f;
    })
  };
  const maps:Record<string,MapConfig>={},transforms:Record<string,ReturnType<typeof createTransform>>={},targets:Record<string,RoomTarget[]>={},floors:Record<string,SharedCampus['floors'][number]>={};
  for(const f of shared.floors){
    const registration=plan.buildings.find(b=>b.buildingId===f.buildingId);
    if(!registration?.enabledLevels.includes(f.level)||f.buildingId==='tech-building')continue;
    const b=shared.buildings.find(b=>b.id===f.buildingId)!,id=floorId(b.id,f.level),t=createTransform({x:b.bounds.x0-5,z:b.bounds.z0-5},scale);
    const floorRooms=shared.rooms.filter(r=>r.floorId===f.id);
    const doors=floorRooms.map(r=>r.door);
    const validVol=(v:Volume)=>{
      const vx0=Math.min(v.minX,v.maxX),vx1=Math.max(v.minX,v.maxX);
      const vz0=Math.min(v.minZ,v.maxZ),vz1=Math.max(v.minZ,v.maxZ);
      const vcx=(vx0+vx1)/2,vcz=(vz0+vz1)/2;
      if(doors.some(d=>Math.hypot(vcx-d.x,vcz-d.z)<0.7))return false;
      if(v.maxHeight-v.minHeight<1.2&&f.corridors.some(c=>vx1>c.x0&&vx0<c.x1&&vz1>c.z0&&vz0<c.z1))return false;
      return true;
    };
    const volumes=runtime.collisionVolumes.filter(v=>v.buildingId===b.id&&blocksFloor(v,f.elevation)&&validVol(v)).map(v=>t.rect({x0:v.minX,x1:v.maxX,z0:v.minZ,z1:v.maxZ}));
    if(f.id==='admin-front:floor-1'){
      volumes.push(
        t.rect({x0:-15.35,x1:-15.15,z0:39,z1:41.8}),
        t.rect({x0:-15.35,x1:-15.15,z0:43.4,z1:46.2}),
        t.rect({x0:-11.6,x1:-11.4,z0:39,z1:41.8}),
        t.rect({x0:-11.6,x1:-11.4,z0:43.4,z1:46.2}),
        t.rect({x0:-9.66,x1:-9.46,z0:39,z1:46.2})
      );
    }
    const map:MapConfig={id,width:(b.bounds.x1-b.bounds.x0+10)*t.unit,height:(b.bounds.z1-b.bounds.z0+10)*t.unit,displayName:`${b.name.split(' / ')[0]} ${f.level}F`,backgroundKey:'canonical-schematic',collisionZones:volumes,spawns:{},portals:[],npcs:[]};
    const xs=[...new Set([b.bounds.x0-5,b.bounds.x1+5,...f.footprints.flatMap(r=>[r.x0,r.x1])])].sort((a,b)=>a-b),zs=[...new Set([b.bounds.z0-5,b.bounds.z1+5,...f.footprints.flatMap(r=>[r.z0,r.z1])])].sort((a,b)=>a-b);
    for(let x=0;x<xs.length-1;x++)for(let z=0;z<zs.length-1;z++){const r={x0:xs[x],x1:xs[x+1],z0:zs[z],z1:zs[z+1]},cx=(r.x0+r.x1)/2,cz=(r.z0+r.z1)/2;if(!f.footprints.some(p=>cx>=p.x0&&cx<=p.x1&&cz>=p.z0&&cz<=p.z1))map.collisionZones.push(t.rect(r));}
    const entrance=shared.entrances.find(e=>e.buildingId===b.id),corridor=f.corridors[0];
    const point=f.level===1&&entrance?entrance.inside:{x:(corridor.x0+corridor.x1)/2,z:(corridor.z0+corridor.z1)/2};
    map.spawns.entry={...t.toGame(point),direction:'up'};
    targets[id]=shared.rooms.filter(r=>r.floorId===f.id).map(r=>({id:r.id,name:r.name,point:t.toGame(r.center),door:t.toGame(r.door)}));
    maps[id]=map;transforms[id]=t;floors[id]=f;
    map.floorPlan={footprints:f.footprints.map(r=>t.rect(r)),rooms:[...(f.id==='admin-front:floor-1'?[]:shared.rooms.filter(r=>r.floorId===f.id).map(r=>({rect:t.rect(r.rect),name:r.name}))),...auxiliaryZones(f.id).map(z=>({rect:t.rect(z.rect),name:z.name}))]};
  }
  type SourcePortal={id:string;fromSceneId:string;toSceneId:string;anchor:Canonical;arrival:Canonical;stairId?:string};
  const sourcePortals=(shared as SharedCampus&{portals?:SourcePortal[]}).portals??[];
  const fromScene=(scene:string)=>{const [b,f]=scene.split('/floor-');return f?floorId(b,Number(f)):undefined;};
  for(const p of sourcePortals){
    const from=fromScene(p.fromSceneId),to=fromScene(p.toSceneId);if(!from||!maps[from]||!to||!maps[to])continue;
    const a=transforms[from].toGame(p.anchor),arrival=transforms[to].toGame(p.arrival),key=`arrival:${p.id}`;
    maps[to].spawns[key]={...arrival,direction:'down'};
    maps[from].portals.push({id:p.id,mapId:from,trigger:{x:a.x-18,y:a.y-18,width:36,height:36},destinationMapId:to,destinationSpawnId:key,prompt:`E：樓梯 → ${floors[to].level}F`});
  }
  // The plan's administration building is one building; the guide splits its two wings.
  // The connecting breezeway is represented by a reversible same-level scene link.
  for(const level of [1,2,3])for(const [a,b]of[['admin-front','admin-back'],['admin-back','admin-front']]){
    const from=floorId(a,level),to=floorId(b,level);if(!maps[from]||!maps[to])continue;
    const r=floors[from].corridors[0],point=transforms[from].toGame({x:r.x1-1.4,z:(r.z0+r.z1)/2});
    const rr=floors[to].corridors[0],arrival=transforms[to].toGame({x:rr.x1-1.4,z:(rr.z0+rr.z1)/2}),key=`gallery:${a}`;
    maps[to].spawns[key]={...arrival,direction:'left'};
    maps[from].portals.push({id:`gallery:${a}:${level}`,mapId:from,trigger:{x:point.x-18,y:point.y-18,width:36,height:36},destinationMapId:to,destinationSpawnId:key,prompt:`E：行政大樓連通廊 → ${b==='admin-front'?'前棟':'後棟'} ${level}F`});
  }
  for(const [id,map]of Object.entries(maps)){
    for(const [key,spawn]of Object.entries(map.spawns))map.spawns[key]={...spawn,...safePilotPosition(spawn,map)};
    if(floors[id].level===1){const p=map.spawns.entry;map.portals.push({id:'building-exit',mapId:map.id,trigger:{x:p.x-18,y:p.y-18,width:36,height:36},destinationMapId:'campus',destinationSpawnId:'campus-start',prompt:'E：離開建築，返回校園'});}
    const target=targets[id].find(r=>!r.name.includes('待確認'))??targets[id][0];
    if(target){const p=safePilotPosition(target.point,map);map.npcs.push({id:`floor-mentor:${id}`,mapId:map.id,...p,direction:'down',name:'校園任務導師',spriteKey:'robot',portraitKey:'robot',kind:'robot',interactionRadius:62,dialogueId:'pilot-original-quest',dialogue:`歡迎來到${map.displayName}。這是依導覽資料建立的樓層示意；邀請你挑戰原版 5 題數學任務。`});}
  }
  return {maps,transforms,targets,floors,shared,scale};
}
export type FloorExpansion=ReturnType<typeof createFloorExpansion>;
