import { campusMap } from '../game/data/maps/campus';
import { presentationMap } from '../game/data/presentation';
import { movePlayer } from './movement';
import { nearestInRange } from './interaction-target';
import { viewport, sizeViewport, cameraOrigin, screenUnit } from './viewport';

import { getWorldScale, scaleMap, createResidents, stepResidents, publishWorld, safePosition } from '../game/core/world';
import { mountWorldHud } from '../game/world-hud';
import type { MapConfig } from '../game/data/types';
import type { WorldId } from '../game/config';

const get = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
const canvas = get<HTMLCanvasElement>('world'), ctx = canvas.getContext('2d')!;
const status = get('world-status'), exploration = get('exploration'), quest = get('quest'), dialogue = get('dialogue');
const makeCampus=()=>scaleMap({...presentationMap(campusMap,true),portals:campusMap.portals.map(p=>p.id==='technology-building-door'?{...p,destinationMapId:'pilot-tech-1' as const,destinationSpawnId:'entry',prompt:'E：進入科技館 1F'}:p)},getWorldScale());
const maps:Partial<Record<WorldId,MapConfig>> = { campus: makeCampus() };
let map = maps.campus!, player = { ...map.spawns['campus-start'] }, hiddenByParent = false, questOpen = false, questMounted = false, questLoading = false;
let npcs=createResidents(map), mapOpen=false;
let pilotControls:ReturnType<typeof import('./pilot-controls')['createPilotControls']>|undefined;
let characterWorld:ReturnType<typeof import('./character-world')['mountCharacterWorld']>|undefined,entering=false;
const inPilot=()=>map.id.startsWith('pilot-');
mountWorldHud(get('world-frame'));
window.addEventListener('campus:map-open',e=>{mapOpen=(e as CustomEvent<boolean>).detail;pause();resume();});
window.addEventListener('campus:scale',()=>{
  const old=maps.campus!.width;maps.campus=makeCampus();
  pilotControls?.scale(old);
  if(map.id==='campus'){player={...player,...safePosition({x:player.x*maps.campus.width/old,y:player.y*maps.campus.width/old},maps.campus)};map=maps.campus;npcs=createResidents(map);draw();}
});
let ready = false, frame = 0, last = 0, previousPrompt = '';
const keys = new Set<string>(), image = new Image();
const active = () => ready && !entering && !hiddenByParent && !document.hidden && !questOpen && !mapOpen && dialogue.hidden;
function pause() { cancelAnimationFrame(frame); frame = 0; keys.clear(); last = 0; }
function resume() { if (active() && !frame) frame = requestAnimationFrame(tick); }
function target() {
  const npc = nearestInRange(npcs,player);
  const margin=inPilot()?12:60;
  const portal = map.portals.find(p => player.x >= p.trigger.x - margin && player.x <= p.trigger.x + p.trigger.width + margin && player.y >= p.trigger.y - margin && player.y <= p.trigger.y + p.trigger.height + margin);
  return { npc, portal };
}
function draw() {
  if(!ready)return;
  characterWorld?.onMapChange();
  ctx.setTransform(viewport.pixelRatio*viewport.zoom,0,0,viewport.pixelRatio*viewport.zoom,0,0);
  ctx.fillStyle='#e4f2fa';ctx.fillRect(0,0,viewport.logicalWidth,viewport.logicalHeight);
  if(inPilot())pilotControls!.draw(ctx);
  else {
    const {x,y}=cameraOrigin(map,player),unit=screenUnit(ctx.getTransform().a);
    ctx.save();ctx.translate(-x,-y);
    ctx.drawImage(image,0,0,map.width,map.height);
    for(const portal of map.portals){const r=portal.trigger;ctx.fillStyle='#17a0aa99';ctx.fillRect(r.x,r.y,r.width,r.height);ctx.fillStyle='#092f47';ctx.font=`bold ${20*unit}px system-ui`;ctx.fillText(map.id==='campus'?'科技館入口':'返回校園',r.x,r.y-12*unit);}
    [...npcs.map(actor=>({actor,isPlayer:false})),{actor:player,isPlayer:true}].sort((a,b)=>a.actor.y-b.actor.y).forEach(({actor,isPlayer})=>{
      if(characterWorld?.draw(ctx,actor,isPlayer))return;
      ctx.fillStyle=isPlayer?'#087ba8':'#edb94d';ctx.fillRect(actor.x-12*unit,actor.y-32*unit,24*unit,32*unit);
      ctx.beginPath();ctx.arc(actor.x,actor.y-38*unit,9*unit,0,Math.PI*2);ctx.fill();
      ctx.fillStyle='#173f58';ctx.font=`bold ${18*unit}px system-ui`;ctx.textAlign='center';
      ctx.fillText(isPlayer?'玩家':('name' in actor?String(actor.name):'校園角色'),actor.x,actor.y-54*unit);ctx.textAlign='left';
    });
    ctx.restore();
  }
  publishWorld({map,player,npcs});
  const { npc, portal } = target();
  const prompt = npc ? `E／空白鍵：與 ${npc.name} 交談` : portal?.prompt ?? (inPilot()?pilotControls!.prompt() : map.id === 'campus' ? '右上方科技館入口按 E' : '靠近助教按 E 開始任務');
  const message=status.dataset.characterError||prompt;
  if (message !== previousPrompt) { status.textContent = message; previousPrompt = message; }
}
function tick(now: number) {
  frame = 0; if (!active()) return;
  const dx = Number(keys.has('ArrowRight') || keys.has('d')) - Number(keys.has('ArrowLeft') || keys.has('a'));
  const dy = Number(keys.has('ArrowDown') || keys.has('s')) - Number(keys.has('ArrowUp') || keys.has('w'));
  player = { ...player, ...movePlayer(player, dx, dy, last ? (now - last) / 1000 : 0, map) };
  pilotControls?.step(now);
  if(dx||dy)player.direction=Math.abs(dx)>Math.abs(dy)?dx>0?'right':'left':dy>0?'down':'up';
  stepResidents(npcs,map,last?(now-last)/1000:0,player,false);
  characterWorld?.step(now);
  last = now; draw(); frame = requestAnimationFrame(tick);
}
async function openQuest() {
  if (questLoading || questOpen) return;
  questLoading = true; const button = get<HTMLButtonElement>('quest-start'); button.disabled = true;
  button.textContent = '準備數學任務……';
  try {
    if (!questMounted) {
      const { mountQuest } = await import('./quest');
      mountQuest(quest, () => { questOpen = false; quest.hidden = true; exploration.hidden = false; dialogue.hidden = true; resume(); canvas.focus(); });
      questMounted = true;
    }
    questOpen = true; pause(); exploration.hidden = true; quest.hidden = false;
    quest.querySelector<HTMLElement>('h2')?.focus();
  } catch { status.textContent = '任務載入失敗，請重試。'; }
  finally { questLoading = false; button.disabled = false; button.textContent = '快速體驗數學任務'; }
}
function interact() {
  if (!dialogue.hidden) { dialogue.hidden = true;pilotControls?.closeDialogue(); resume(); canvas.focus(); return; }
  if (!active()) return;
  const { npc, portal } = target();
  if (npc) {
    if (pilotControls?.interact(npc)) return;
    else {pause();void import('./optional-ui').then(m=>m.showNpcDialogue(npc,dialogue));}
  } else if (portal) {
    if(map.id==='campus'&&portal.id==='technology-building-door'){void enterTechnology();return;}
    if(inPilot()&&!pilotControls!.canPortal())return;
    if(inPilot()&&portal.id==='tech-exit'){pilotControls!.exit();return;}
    map = maps[portal.destinationMapId]!; player = { ...map.spawns[portal.destinationSpawnId] };npcs=createResidents(map); keys.clear();
    if(inPilot())pilotControls!.onPortal();draw();
  }
}
window.addEventListener('keydown', event => {
  if (questOpen || mapOpen || hiddenByParent || event.target instanceof HTMLSelectElement || event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
  if (event.target instanceof HTMLButtonElement && (event.key === ' ' || event.key === 'Enter')) return;
  const key = event.key.length === 1 ? event.key.toLowerCase() : event.key;
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 'a', 's', 'd', 'e', ' '].includes(key)) {
    event.preventDefault(); if (key === 'e' || key === ' ') { if (!event.repeat) interact(); } else keys.add(key);
  }
});
window.addEventListener('keyup', e => keys.delete(e.key.length === 1 ? e.key.toLowerCase() : e.key));
window.addEventListener('blur', () => keys.clear());
document.addEventListener('visibilitychange', () => { pause(); resume(); });
window.addEventListener('message', event => {
  if (event.origin !== location.origin || event.source !== parent || event.data?.type !== 'proposal:visibility') return;
  hiddenByParent = !event.data.visible; pause(); resume();
});
document.querySelectorAll<HTMLButtonElement>('[data-key]').forEach(button => {
  button.addEventListener('pointerdown', event => { event.preventDefault(); button.setPointerCapture(event.pointerId); keys.add(button.dataset.key!); canvas.focus(); });
  for (const name of ['pointerup', 'pointercancel', 'lostpointercapture']) button.addEventListener(name, () => keys.delete(button.dataset.key!));
});
get('interact').onclick = interact; get('dialogue-close').onclick = interact; get('quest-start').onclick = openQuest;
async function enterTechnology(){
  if(entering)return;entering=true;pause();get<HTMLButtonElement>('interact').disabled=true;
  status.textContent='載入科技館樓層……';
  try {
  if(!pilotControls){const {createPilotControls}=await import('./pilot-controls');pilotControls=createPilotControls({maps,
    read:()=>({map,player,npcs,questOpen,questLoading}),setPilot:next=>{Object.assign(maps,next.maps);},
    place:(next,spawn)=>{pause();map=next;player=spawn;npcs=createResidents(map);dialogue.hidden=true;pilotControls?.closeDialogue();draw();resume();canvas.focus();},
    route:()=>{draw();canvas.focus();},openQuest,pause});}
  await pilotControls.enter();
  }catch{status.textContent='樓層載入失敗，請在入口按 E 重試。';}
  finally{entering=false;get<HTMLButtonElement>('interact').disabled=false;resume();}
}
image.onload = () => {
  ready = true; draw(); resume();
  if(new URLSearchParams(location.search).has('profile'))void import('./optional-ui').then(m=>m.reportStartup());
};
// Fetch characters alongside the map; drawing waits for the map's onload.
  void import('./character-world').then(({mountCharacterWorld})=>{
    characterWorld=mountCharacterWorld({read:()=>({map,player,npcs}),redraw:draw});
    draw();
  }).catch(()=>{status.dataset.characterError='角色載入失敗，請重整。';draw();});
image.onerror=()=>void import('./optional-ui').then(m=>m.showMapRetry(status,image));
image.src = new URL('./assets/maps/daxi-future-campus-rpg-v1.png', document.baseURI).href;
// Resize the camera's visible area rather than stretching or cropping a fixed canvas.
function resizeViewport(width:number,height:number) {
  if (!width || !height) return;
  Object.assign(viewport,sizeViewport(width,height,window.devicePixelRatio));
  canvas.width = viewport.bufferWidth;
  canvas.height = viewport.bufferHeight;
  window.dispatchEvent(new CustomEvent('campus:viewport',{detail:{width:viewport.logicalWidth,height:viewport.logicalHeight,pixelRatio:viewport.pixelRatio,zoom:viewport.zoom,cssWidth:width,cssHeight:height}}));
  if (ready) draw();
}
new ResizeObserver(([entry]) => resizeViewport(entry.contentRect.width,entry.contentRect.height)).observe(canvas.parentElement!);
function watchPixelRatio(){
  matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`).addEventListener('change',()=>{
    const rect=canvas.parentElement!.getBoundingClientRect();resizeViewport(rect.width,rect.height);watchPixelRatio();
  },{once:true});
}
watchPixelRatio();
