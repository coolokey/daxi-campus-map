import { campusMap } from '../game/data/maps/campus';
import { researchLabMap } from '../game/data/maps/research-lab';
import { presentationMap } from '../game/data/presentation';
import { movePlayer } from './movement';

import { getWorldScale, scaleMap, createResidents, stepResidents, publishWorld, safePosition } from '../game/core/world';
import { mountWorldHud } from '../game/world-hud';
import type { MapConfig } from '../game/data/types';
import type { WorldId } from '../game/config';

const get = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
const canvas = get<HTMLCanvasElement>('world'), ctx = canvas.getContext('2d')!;
const status = get('world-status'), exploration = get('exploration'), quest = get('quest'), dialogue = get('dialogue');
const maps:Partial<Record<WorldId,MapConfig>> = { campus: scaleMap(presentationMap(campusMap, true),getWorldScale()), 'research-lab': presentationMap(researchLabMap, true) };
let map = maps.campus!, player = { ...map.spawns['campus-start'] }, hiddenByParent = false, questOpen = false, questMounted = false, questLoading = false;
let npcs=createResidents(map), mapOpen=false;
let pilotControls:ReturnType<typeof import('./pilot-controls')['createPilotControls']>|undefined;
const inPilot=()=>map.id.startsWith('pilot-');
mountWorldHud(get('world-frame'));
window.addEventListener('campus:map-open',e=>{mapOpen=(e as CustomEvent<boolean>).detail;pause();resume();});
window.addEventListener('campus:scale',()=>{
  const old=maps.campus!.width;maps.campus=scaleMap(presentationMap(campusMap,true),getWorldScale());
  pilotControls?.scale(old);
  if(map.id==='campus'){player={...player,...safePosition({x:player.x*maps.campus.width/old,y:player.y*maps.campus.width/old},maps.campus)};map=maps.campus;npcs=createResidents(map);draw();}
});
let ready = false, frame = 0, last = 0, previousPrompt = '';
const keys = new Set<string>(), image = new Image();
const active = () => ready && !hiddenByParent && !document.hidden && !questOpen && !mapOpen && dialogue.hidden;
function pause() { cancelAnimationFrame(frame); frame = 0; keys.clear(); last = 0; }
function resume() { if (active() && !frame) frame = requestAnimationFrame(tick); }
function target() {
  const npc = npcs.find(n => Math.hypot(n.x - player.x, n.y - player.y) <= n.interactionRadius);
  const margin=inPilot()?12:60;
  const portal = map.portals.find(p => player.x >= p.trigger.x - margin && player.x <= p.trigger.x + p.trigger.width + margin && player.y >= p.trigger.y - margin && player.y <= p.trigger.y + p.trigger.height + margin);
  return { npc, portal };
}
function draw() {
  if(inPilot())pilotControls!.draw(ctx);
  else {
    const width=canvas.width,height=canvas.height;
    const x=Math.max(0,Math.min(map.width-width,player.x-width/2)),y=Math.max(0,Math.min(map.height-height,player.y-height/2));
    ctx.fillStyle='#e4f2fa';ctx.fillRect(0,0,width,height);ctx.save();ctx.translate(-x,-y);
    if(map.id==='campus')ctx.drawImage(image,0,0,map.width,map.height);
    else {
      ctx.fillStyle='#d0e1ec';ctx.fillRect(0,0,map.width,map.height);ctx.fillStyle='#f6fbff';ctx.fillRect(72,72,1456,816);
      ctx.fillStyle='#54748a';ctx.fillRect(690,350,290,150);ctx.fillStyle='#173f58';ctx.font='bold 32px system-ui';ctx.fillText('科技館・數學研究室',600,140);
    }
    for(const portal of map.portals){const r=portal.trigger;ctx.fillStyle='#17a0aa99';ctx.fillRect(r.x,r.y,r.width,r.height);ctx.fillStyle='#092f47';ctx.font='bold 20px system-ui';ctx.fillText(map.id==='campus'?'研究室入口':'返回校園',r.x,r.y-12);}
    for(const npc of npcs){ctx.fillStyle='#edb94d';ctx.fillRect(npc.x-13,npc.y-17,26,34);ctx.fillStyle='#173f58';ctx.font='bold 18px system-ui';ctx.textAlign='center';ctx.fillText(`${npc.name} · NPC`,npc.x,npc.y-26);}
    ctx.textAlign='left';ctx.fillStyle='#087ba8';ctx.fillRect(player.x-12,player.y-16,24,32);ctx.fillStyle='#fff';ctx.fillRect(player.x-8,player.y-14,16,10);ctx.restore();
  }
  publishWorld({map,player,npcs});
  const { npc, portal } = target();
  const prompt = npc ? `E／空白鍵：與 ${npc.name} 交談` : portal?.prompt ?? (inPilot()?pilotControls!.prompt() : map.id === 'campus' ? '右上方科技館入口按 E' : '靠近助教按 E 開始任務');
  if (prompt !== previousPrompt) { status.textContent = prompt; previousPrompt = prompt; }
}
function tick(now: number) {
  frame = 0; if (!active()) return;
  const dx = Number(keys.has('ArrowRight') || keys.has('d')) - Number(keys.has('ArrowLeft') || keys.has('a'));
  const dy = Number(keys.has('ArrowDown') || keys.has('s')) - Number(keys.has('ArrowUp') || keys.has('w'));
  player = { ...player, ...movePlayer(player, dx, dy, last ? (now - last) / 1000 : 0, map) };
  pilotControls?.step(now);
  if(dx||dy)player.direction=Math.abs(dx)>Math.abs(dy)?dx>0?'right':'left':dy>0?'down':'up';
  stepResidents(npcs,map,last?(now-last)/1000:0,player,false);
  last = now; draw(); frame = requestAnimationFrame(tick);
}
async function openQuest() {
  if (questLoading || questOpen) return;
  questLoading = true; const button = get<HTMLButtonElement>('quest-start'); button.disabled = true;
  button.textContent = '準備數學任務……';
  try {
    if (!questMounted) {
      const { mountQuest } = await import('./quest');
      mountQuest(quest, () => { questOpen = false; quest.hidden = true; exploration.hidden = false; dialogue.hidden = true; resume(); canvas.focus(); });
      questMounted = true;
    }
    questOpen = true; pause(); exploration.hidden = true; quest.hidden = false;
    quest.querySelector<HTMLElement>('h2')?.focus();
  } catch { status.textContent = '任務載入失敗，請重試。'; }
  finally { questLoading = false; button.disabled = false; button.textContent = '快速體驗數學任務'; }
}
function interact() {
  if (!dialogue.hidden) { dialogue.hidden = true;pilotControls?.closeDialogue(); resume(); canvas.focus(); return; }
  if (!active()) return;
  const { npc, portal } = target();
  if (npc) {
    if (pilotControls?.interact(npc)) return;
    else if (map.id === 'research-lab') void openQuest();
    else {pause();void import('./optional-ui').then(m=>m.showNpcDialogue(npc,dialogue));}
  } else if (portal) {
    if(inPilot()&&!pilotControls!.canPortal())return;
    map = maps[portal.destinationMapId]!; player = { ...map.spawns[portal.destinationSpawnId] };npcs=createResidents(map); keys.clear();
    if(inPilot())pilotControls!.onPortal();draw();
  }
}
window.addEventListener('keydown', event => {
  if (questOpen || mapOpen || hiddenByParent || event.target instanceof HTMLSelectElement || event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
  if (event.target instanceof HTMLButtonElement && (event.key === ' ' || event.key === 'Enter')) return;
  const key = event.key.length === 1 ? event.key.toLowerCase() : event.key;
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 'a', 's', 'd', 'e', ' '].includes(key)) {
    event.preventDefault(); if (key === 'e' || key === ' ') { if (!event.repeat) interact(); } else keys.add(key);
  }
});
window.addEventListener('keyup', e => keys.delete(e.key.length === 1 ? e.key.toLowerCase() : e.key));
window.addEventListener('blur', () => keys.clear());
document.addEventListener('visibilitychange', () => { pause(); resume(); });
window.addEventListener('message', event => {
  if (event.origin !== location.origin || event.source !== parent || event.data?.type !== 'proposal:visibility') return;
  hiddenByParent = !event.data.visible; pause(); resume();
});
document.querySelectorAll<HTMLButtonElement>('[data-key]').forEach(button => {
  button.addEventListener('pointerdown', event => { event.preventDefault(); button.setPointerCapture(event.pointerId); keys.add(button.dataset.key!); canvas.focus(); });
  for (const name of ['pointerup', 'pointercancel', 'lostpointercapture']) button.addEventListener(name, () => keys.delete(button.dataset.key!));
});
get('interact').onclick = interact; get('dialogue-close').onclick = interact; get('quest-start').onclick = openQuest;
const pilotButton=get<HTMLButtonElement>('pilot-mode');
pilotButton.onclick=async()=>{
  pilotButton.disabled=true;
  try {
  if(!pilotControls){const {createPilotControls}=await import('./pilot-controls');pilotControls=createPilotControls({button:pilotButton,maps,
    read:()=>({map,player,npcs,questOpen,questLoading}),setPilot:next=>{Object.assign(maps,next.maps);},
    place:(next,spawn)=>{pause();map=next;player=spawn;npcs=createResidents(map);dialogue.hidden=true;pilotControls?.closeDialogue();draw();resume();canvas.focus();},
    route:()=>{draw();canvas.focus();},openQuest,pause});}
  await pilotControls.toggle();
  }finally{pilotButton.disabled=false;}
};
image.onload = () => {
  ready = true; draw(); resume();
  if(new URLSearchParams(location.search).has('profile'))void import('./optional-ui').then(m=>m.reportStartup());
};
image.onerror=()=>void import('./optional-ui').then(m=>m.showMapRetry(status,image));
image.src = new URL('./assets/maps/daxi-future-campus-rpg-v1.webp', document.baseURI).href;
// Resize the camera's visible area rather than stretching or cropping a fixed canvas.
new ResizeObserver(([entry]) => {
  const { width, height } = entry.contentRect;
  if (!width || !height) return;
  const scale = Math.max(width / 1280, height / 720);
  canvas.width = Math.max(1, Math.round(width / scale));
  canvas.height = Math.max(1, Math.round(height / scale));
  if (ready) draw();
}).observe(canvas.parentElement!);
