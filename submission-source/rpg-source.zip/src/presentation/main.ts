import {mountThreeCenterGuide} from './three-centers-guide';
import type {CenterId} from '../data/three-centers';
import {createModelWorld,screenMotion,safeModelPoint} from './model-world';
import {drawModelWorld} from './model-renderer';
import {createModelControls} from './model-controls';

import { movePlayer } from './movement';
import { nearestInRange } from './interaction-target';
import { viewport, sizeViewport } from './viewport';

import { getWorldScale, createResidents, stepResidents, publishWorld } from '../game/core/world';
import type { MapConfig } from '../game/data/types';
import type { WorldId } from '../game/config';


import { mountCampusDirectory } from './campus-directory';
import { createPhotoModal, getFloorPhotos, CAMPUS_PHOTOS } from './photo-exhibit';
import { findPath,clearSegment } from './navigation';
import { mountCampusThemeSwitcher, getCampusThemeMode, toggleCampusThemeMode } from './realistic-campus';

const get = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
const canvas = get<HTMLCanvasElement>('world'), ctx = canvas.getContext('2d')!;
const status = get('world-status'), exploration = get('exploration'), quest = get('quest'), dialogue = get('dialogue');
const legacyQuest=document.createElement('div'),centersQuest=document.createElement('div');quest.append(legacyQuest,centersQuest);centersQuest.hidden=true;
let centerQuestController:ReturnType<typeof import('./three-centers-quest')['mountThreeCentersQuest']>|undefined;
let model=createModelWorld(getWorldScale());
const maps:Partial<Record<WorldId,MapConfig>> = model.maps;
let map = maps.campus!, player = { ...map.spawns['campus-start'] }, hiddenByParent = false, questOpen = false, questMounted = false, questLoading = false;
let npcs=createResidents(map), mapOpen=false;
let pilotControls:ReturnType<typeof createModelControls>|undefined;
let characterWorld:ReturnType<typeof import('./character-world')['mountCharacterWorld']>|undefined,entering=false;
let dialogueVersion=0,dialogueLoading=false;
mountCampusThemeSwitcher((mode) => {
  previousPrompt = '';
  status.textContent = mode === 'realistic'
    ? '已切換原版校舍配色，相同校園配置可繼續探索。'
    : '已切換大溪木藝學園，展開三心探索。';
  draw();
  canvas.focus();
});
document.getElementById('campus-floating-mode-toggle')?.remove();
window.addEventListener('campus:theme-image-loaded', () => {
  if (getCampusThemeMode() === 'realistic') {
    draw();
  }
});
mountCampusDirectory(()=>({state:{map,player},model,...pilotControls?.directoryState()}));
const photoModal = createPhotoModal();
const photoGalleryBtn = document.createElement('button');
photoGalleryBtn.type = 'button';
photoGalleryBtn.id = 'campus-photo-gallery-open';
photoGalleryBtn.className = 'secondary-button';
photoGalleryBtn.textContent = '📷 校園實景對照';
photoGalleryBtn.title = '查看 3D 立體校園導覽校對之大溪國中真實校園照片集錦';
photoGalleryBtn.addEventListener('click', () => {const photos=inPilot()?getFloorPhotos(map.id):undefined;photoModal.open(photos?.[0]?.id,photos);});
document.querySelector('.explore-toolbar')?.append(photoGalleryBtn);
window.addEventListener('campus:open-floor-photo', event => {
  const detail = (event as CustomEvent<{ floorId?: string; photoId?: string }>).detail;
  const floorId = detail?.floorId || map.id;
  const photos = getFloorPhotos(floorId);
  photoModal.open(detail?.photoId || (photos[0]?.id), photos);
});
window.addEventListener('campus:navigate-to-point', event => {
  const { label } = (event as CustomEvent<{ x: number; y: number; label: string }>).detail;
  if (map.id !== 'campus') {
    status.textContent = `請先離開大樓回到戶外校園，再前往「${label}」實景地點。`;
    return;
  }
  const photo=CAMPUS_PHOTOS.find(p=>p.title===label),outdoor=model.source.outdoor,track=outdoor.track;
  let point=outdoor.entrance.pedestrian.inside;
  if(photo?.group==='admin')point=model.source.buildings.find(b=>b.id==='admin-front')!.entrances[0].outside;
  else if(photo?.group==='sports'){
    const stage=outdoor.stage;
    point=photo.id.includes('stage')?{x:(stage.x0+stage.x1)/2,z:stage.z1+2}:photo.id.includes('hill')?{x:track.x-track.halfStraight-track.outerRadius-3,z:track.z}:{x:track.x,z:track.z};
  }
  const target=safeModelPoint(model.transforms.campus.toGame(point),map),points=findPath(player,target,map);
  window.dispatchEvent(new CustomEvent('campus:navigation-route',{detail:{mapId:map.id,points,label:`實景參考區・${label}`}}));
  status.textContent=points?'已設定最新模型的實景參考區路線。':'目前無法前往此實景參考區。';
  draw();
});
let autoWalk=false;const autoButton=document.createElement('button');autoButton.textContent='沿導航路線行走';autoButton.className='secondary-button';autoButton.onclick=()=>{if(autoWalk){autoWalk=false;}else{const end=navigation?.mapId===map.id?navigation.points?.at(-1):undefined;const points=end?findPath(player,end,map):null;if(!points){status.textContent='請先從校園建築或小地圖選擇可通行的目的地。';return;}navigation={...navigation!,points};autoWalk=true;}autoButton.textContent=autoWalk?'停止自動行走':'沿導航路線行走';canvas.focus();};document.querySelector('.explore-toolbar')?.append(autoButton);
const centerGuide=mountThreeCenterGuide({read:()=>({model,map,player}),open:openThreeCenterQuest,pause,redraw:draw});
window.addEventListener('campus:open-energy-quest',()=>{questOpen=false;void openQuest();});
let navigation:{mapId:string;points:{x:number;y:number}[]|null;label:string}|undefined;
window.addEventListener('campus:navigation-route',event=>{navigation=(event as CustomEvent<typeof navigation>).detail;draw();});
const invalidateDialogue=()=>{dialogueVersion++;dialogueLoading=false;};
const inPilot=()=>map.id.startsWith('pilot-')||map.id.startsWith('floor-');
void import('../game/world-hud').then(({mountWorldHud})=>mountWorldHud(get('world-frame'))).catch(()=>{status.dataset.hudError='小地圖載入失敗，請重整。';});
window.addEventListener('campus:map-open',e=>{mapOpen=(e as CustomEvent<boolean>).detail;if(mapOpen)invalidateDialogue();pause();resume();});
window.addEventListener('campus:scale',()=>{const previous=model,point=previous.transforms[map.id].fromGame(player),id=map.id;model=createModelWorld(getWorldScale());Object.assign(maps,model.maps);map=model.maps[id];player={...player,...safeModelPoint(model.transforms[id].toGame(point),map)};npcs=createResidents(map);pilotControls?.reset();draw();});
let ready = false, frame = 0, last = 0, previousPrompt = '';
const keys = new Set<string>();
const active = () => ready && !entering && !dialogueLoading && !hiddenByParent && !document.hidden && !questOpen && !mapOpen && dialogue.hidden;
function pause() { cancelAnimationFrame(frame); frame = 0; keys.clear(); last = 0; }
function resume() { if (active() && !frame) frame = requestAnimationFrame(tick); }
function target() {
  const npc = nearestInRange(npcs.filter(n=>clearSegment(player,n,map)),player);
  const margin=inPilot()?12:60;
  const portal = map.portals.find(p => player.x >= p.trigger.x - margin && player.x <= p.trigger.x + p.trigger.width + margin && player.y >= p.trigger.y - margin && player.y <= p.trigger.y + p.trigger.height + margin && clearSegment(player,{x:p.trigger.x+p.trigger.width/2,y:p.trigger.y+p.trigger.height/2},map));
  const photo = undefined as {id:string;title:string}|undefined;
  return { npc, portal, photo,station:centerGuide.target() };
}
function draw() {
  if(!ready)return;
  characterWorld?.onMapChange();
  const realistic = getCampusThemeMode() === 'realistic';
  ctx.setTransform(viewport.pixelRatio*viewport.zoom,0,0,viewport.pixelRatio*viewport.zoom,0,0);
  ctx.fillStyle=realistic?'#e5e0d5':'#e4f2fa';ctx.fillRect(0,0,viewport.logicalWidth,viewport.logicalHeight);
  centerGuide.syncMarkers();
  drawModelWorld(ctx,map,player,npcs,characterWorld?.draw,realistic,navigation?.mapId===map.id?navigation.points:undefined,(ctx,unit)=>centerGuide.draw(ctx,unit));
  publishWorld({map,player,npcs});
  const { npc, portal, photo,station } = target();
  const prompt = portal ? `${portal.prompt}（按 E／空白鍵／點擊下方「互動」）` : station ? `E／空白鍵：調查${station.title}` : photo ? `E／空白鍵／點擊：查看「${photo.title}」校園實景照片` : npc ? `E／空白鍵：與 ${npc.name} 交談` : centerGuide.prompt();
  const message=status.dataset.characterError||status.dataset.hudError||prompt;
  if (message !== previousPrompt) { status.textContent = message; previousPrompt = message; }
}
function tick(now: number) {
  frame = 0; if (!active()) return;
  const dx = Number(keys.has('ArrowRight') || keys.has('d')) - Number(keys.has('ArrowLeft') || keys.has('a'));
  const dy = Number(keys.has('ArrowDown') || keys.has('s')) - Number(keys.has('ArrowUp') || keys.has('w'));
  if(dx||dy){autoWalk=false;autoButton.textContent='沿導航路線行走';}
  let motion=screenMotion(dx,dy);
  if(autoWalk&&navigation?.mapId===map.id&&navigation.points){const points=navigation.points;while(points.length>1&&Math.hypot(points[0].x-player.x,points[0].y-player.y)<8)points.shift();const next=points[0];if(next&&Math.hypot(next.x-player.x,next.y-player.y)>5)motion={x:next.x-player.x,y:next.y-player.y};else{autoWalk=false;autoButton.textContent='沿導航路線行走';}}
  player = { ...player, ...movePlayer(player, motion.x, motion.y, last ? (now - last) / 1000 : 0, map,autoWalk?Math.min(220,Math.hypot(motion.x,motion.y)/Math.max(.001,last?(now-last)/1000:0)):220) };
  pilotControls?.step(now);
  if(dx||dy)player.direction=Math.abs(dx)>Math.abs(dy)?dx>0?'right':'left':dy>0?'down':'up';
  stepResidents(npcs,map,last?(now-last)/1000:0,player,false);
  characterWorld?.step(now);
  last = now; draw(); frame = requestAnimationFrame(tick);
}
async function openQuest() {
  if (questLoading || questOpen || entering) return;
  invalidateDialogue();
  questLoading = true; const button = get<HTMLButtonElement>('quest-start'); button.disabled = true;
  button.textContent = '準備數學任務……';
  try {
    if (!questMounted) {
      const { mountQuest } = await import('./quest');
      mountQuest(legacyQuest, () => { questOpen = false; quest.hidden = true; exploration.hidden = false; dialogue.hidden = true; resume(); canvas.focus(); });
      questMounted = true;
    }
    legacyQuest.hidden=false;centersQuest.hidden=true;
    questOpen = true; pause(); exploration.hidden = true; quest.hidden = false;
    legacyQuest.querySelector<HTMLElement>('h2')?.focus();
  } catch { status.textContent = '任務載入失敗，請重試。';dialogue.hidden=true;resume();canvas.focus(); }
  finally { questLoading = false; button.disabled = false; button.textContent = '原版能源任務'; }
}
async function openThreeCenterQuest(center?:CenterId){
 if(questLoading||entering)return;invalidateDialogue();questLoading=true;autoWalk=false;autoButton.textContent='沿導航路線行走';pause();
 try{if(!centerQuestController){const {mountThreeCentersQuest}=await import('./three-centers-quest');centerQuestController=mountThreeCentersQuest(centersQuest,()=>{questOpen=false;quest.hidden=true;exploration.hidden=false;dialogue.hidden=true;centerGuide.closeDialogue();resume();canvas.focus();});}
  dialogue.hidden=true;centerGuide.closeDialogue();legacyQuest.hidden=true;centersQuest.hidden=false;questOpen=true;exploration.hidden=true;quest.hidden=false;centerQuestController.open(center);
 }catch{status.textContent='三心任務載入失敗，請重試。';questOpen=false;quest.hidden=true;exploration.hidden=false;resume();}
 finally{questLoading=false;resume();}
}
function interact() {
  if(dialogueLoading){invalidateDialogue();resume();return;}
  if (!dialogue.hidden) { dialogue.hidden = true;pilotControls?.closeDialogue();centerGuide.closeDialogue(); resume(); canvas.focus(); return; }
  if (!active()) return;
  const { npc, portal, photo,station } = target();
  autoWalk=false;autoButton.textContent='沿導航路線行走';
  if (portal) {
    if (map.id === 'campus') { void enterTechnology(portal); return; }
    if (inPilot() && !pilotControls!.canPortal()) return;
    map = maps[portal.destinationMapId]!; player = { ...map.spawns[portal.destinationSpawnId] }; npcs = createResidents(map); keys.clear();
    if (inPilot()) pilotControls!.onPortal(); draw();
    return;
  }
  if(station){centerGuide.interact(station);return;}
  if (photo) {
    photoModal.open(photo.id);
    return;
  }
  if (npc) {
    if (pilotControls?.interact(npc)) return;
    else {
      const version = ++dialogueVersion, scene = map; dialogueLoading = true; pause();
      void import('./optional-ui').then(m => { if (version === dialogueVersion && map === scene && !questOpen && !questLoading && !mapOpen) m.showNpcDialogue(npc, dialogue); })
        .catch(() => { if (version === dialogueVersion) status.textContent = '對話載入失敗，請重試。'; })
        .finally(() => { if (version === dialogueVersion) { dialogueLoading = false; resume(); if (dialogue.hidden) canvas.focus(); } });
    }
  }
}
window.addEventListener('keydown', event => {
  if (questOpen || mapOpen || hiddenByParent || event.target instanceof HTMLSelectElement || event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
  if (event.target instanceof HTMLButtonElement && (event.key === ' ' || event.key === 'Enter')) return;
  const key = event.key.length === 1 ? event.key.toLowerCase() : event.key;
  if (key === 'm' && !event.repeat) {
    event.preventDefault();
    const nextMode = toggleCampusThemeMode();
    previousPrompt = '';
    status.textContent = nextMode === 'realistic'
      ? '已切換原版校舍配色，相同校園配置可繼續探索。'
      : '已切換大溪木藝學園，展開三心探索。';
    draw();
    return;
  }
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 'a', 's', 'd', 'e', ' '].includes(key)) {
    event.preventDefault(); if (key === 'e' || key === ' ') { if (!event.repeat) interact(); } else keys.add(key);
  }
});
window.addEventListener('keyup', e => keys.delete(e.key.length === 1 ? e.key.toLowerCase() : e.key));
window.addEventListener('blur', () => keys.clear());
document.addEventListener('visibilitychange', () => { pause(); resume(); });
window.addEventListener('message', event => {
  if (event.origin !== location.origin || event.source !== parent || event.data?.type !== 'proposal:visibility') return;
  hiddenByParent = !event.data.visible; pause(); resume();
});
document.querySelectorAll<HTMLButtonElement>('[data-key]').forEach(button => {
  button.addEventListener('pointerdown', event => { event.preventDefault(); button.setPointerCapture(event.pointerId); keys.add(button.dataset.key!); canvas.focus(); });
  for (const name of ['pointerup', 'pointercancel', 'lostpointercapture']) button.addEventListener(name, () => keys.delete(button.dataset.key!));
});
get('interact').onclick = interact; get('dialogue-close').onclick = interact; get('quest-start').onclick = ()=>void openQuest();
async function enterTechnology(portal:MapConfig['portals'][number]){
 if(entering)return;entering=true;pause();
 try{if(!pilotControls)pilotControls=createModelControls({read:()=>({map,player}),place:(next,spawn)=>{map=next;player=spawn;npcs=createResidents(map);dialogue.hidden=true;draw();},openQuest,pause},()=>model);pilotControls.enter(portal);}
 finally{entering=false;draw();resume();canvas.focus();}
}
ready=true;
void import('./character-world').then(({mountCharacterWorld})=>{characterWorld=mountCharacterWorld({read:()=>({map,player,npcs}),redraw:draw});draw();}).catch(()=>{status.dataset.characterError='角色載入失敗，請重整。';draw();});
queueMicrotask(()=>{draw();resume();});
// Resize the camera's visible area rather than stretching or cropping a fixed canvas.
function resizeViewport(width:number,height:number) {
  if (!width || !height) return;
  Object.assign(viewport,sizeViewport(width,height,window.devicePixelRatio));
  canvas.width = viewport.bufferWidth;
  canvas.height = viewport.bufferHeight;
  window.dispatchEvent(new CustomEvent('campus:viewport',{detail:{width:viewport.logicalWidth,height:viewport.logicalHeight,pixelRatio:viewport.pixelRatio,zoom:viewport.zoom,cssWidth:width,cssHeight:height}}));
  if (ready) draw();
}
new ResizeObserver(([entry]) => resizeViewport(entry.contentRect.width,entry.contentRect.height)).observe(canvas.parentElement!);
function watchPixelRatio(){
  matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`).addEventListener('change',()=>{
    const rect=canvas.parentElement!.getBoundingClientRect();resizeViewport(rect.width,rect.height);watchPixelRatio();
  },{once:true});
}
watchPixelRatio();
