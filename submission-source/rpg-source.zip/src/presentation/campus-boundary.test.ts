import {describe,it,expect} from 'vitest';
import {createModelWorld} from './model-world';
import {walkable,clearSegment,findPath} from './navigation';
import {campusBoundary} from './campus-boundary';
import {boundaryObjects} from './boundary-renderer';
describe('source gate and solid perimeter',()=>{
 it('retains an open student entrance and the source gate tower opening at all scales',()=>{
  for(const scale of [1,1.5,2]){const w=createModelWorld(scale),map=w.maps.campus,t=w.transforms.campus;
   const outside=t.toGame({x:-22.8,z:90}),inside=t.toGame({x:-22.8,z:80.2});
   expect(clearSegment(outside,inside,map),`wicket ${scale}`).toBe(true);
   expect(findPath(map.spawns['campus-start'],inside,map)).toBeTruthy();
   expect(walkable(t.toGame({x:-25,z:86}),map),`tower opening ${scale}`).toBe(true);
   expect(walkable(t.toGame({x:-25,z:85}),map)).toBe(false);
  }
 });
 it('blocks the visible booth, low post and retracted gates without a hidden overhead collider',()=>{
  for(const scale of [1,1.5,2]){const w=createModelWorld(scale),map=w.maps.campus,t=w.transforms.campus;
   for(const point of [{x:-47,z:86},{x:-43.5,z:86},{x:-19,z:83.5},{x:-17.4,z:86.7},{x:-21.92,z:87.8}])expect(walkable(t.toGame(point),map),JSON.stringify(point)).toBe(false);
   expect(walkable(t.toGame({x:-36,z:86}),map)).toBe(true);
  }
 });
 it('has continuous walls including joints and rejects crossing between old sparse samples',()=>{
  for(const scale of [1,1.5,2]){const w=createModelWorld(scale),map=w.maps.campus,t=w.transforms.campus;
   for(const segment of w.source.outdoor.perimeter.segments){const dx=segment.bx-segment.ax,dz=segment.bz-segment.az,length=Math.hypot(dx,dz);
    for(let i=0;i<=20;i++){const k=i/20,p={x:segment.ax+dx*k,z:segment.az+dz*k};expect(walkable(t.toGame(p),map,.1),`wall at ${scale}`).toBe(false);}
    const p={x:(segment.ax+segment.bx)/2,z:(segment.az+segment.bz)/2},n={x:-dz/length*2,z:dx/length*2};expect(clearSegment(t.toGame({x:p.x+n.x,z:p.z+n.z}),t.toGame({x:p.x-n.x,z:p.z-n.z}),map)).toBe(false);
   }
  }
 });
 it('records source provenance and preserves the open-leaf orientation',()=>{
  const b=campusBoundary();expect(b.blocks.some(p=>p.id==='tower-shaft'&&p.bottom>1.7)).toBe(true);expect(b.source.files.map(f=>f.file)).toContain('explorer.js');
  const leaf=b.blocks.find(p=>p.id==='open-wicket-leaf')!;expect(leaf.rect.z1-leaf.rect.z0).toBeGreaterThan(leaf.rect.x1-leaf.rect.x0);
 });
});

it('does not enqueue boundary drawing outside the camera viewport',()=>{
 const context={canvas:{width:1280,height:720},getTransform:()=>({a:1,b:0,c:0,d:1,e:100000,f:100000})} as unknown as CanvasRenderingContext2D;
 expect(boundaryObjects(context,16,1,{x:2200,y:2800})).toHaveLength(0);
 const near={canvas:{width:1280,height:720},getTransform:()=>({a:.55,b:0,c:0,d:.55,e:930,f:-1050})} as unknown as CanvasRenderingContext2D;
 expect(boundaryObjects(near,16,1,{x:2200,y:2800}).length).toBeGreaterThan(0);
});
