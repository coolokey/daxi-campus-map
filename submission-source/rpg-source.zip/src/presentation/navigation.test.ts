import {describe,it,expect} from 'vitest';
import {canReach,findPath,clearSegment} from './navigation';
describe('model navigation component cache',()=>{
 it('cannot cross a one-unit wall on cold or cached queries',()=>{const map={width:240,height:240,backgroundKey:'latest-model-v2',collisionZones:[{x:119,y:0,width:1,height:240}]};for(let i=0;i<3;i++)expect(canReach({x:64,y:64},{x:176,y:64},map)).toBe(false);expect(findPath({x:64,y:64},{x:176,y:64},map)).toBeNull();});
 it('routes through the real opening without clipping the wall',()=>{const map={width:240,height:240,backgroundKey:'latest-model-v2',collisionZones:[{x:119,y:0,width:1,height:110},{x:119,y:160,width:1,height:80}]},a={x:64,y:64},b={x:176,y:64};for(let i=0;i<3;i++)expect(canReach(a,b,map)).toBe(true);const path=findPath(a,b,map)!;expect(path).toBeTruthy();for(let i=1;i<path.length;i++)expect(clearSegment(path[i-1],path[i],map)).toBe(true);});
});
