import type { Pilot, PilotId, Bounds } from './pilot-adapter';
import type { Rect, NpcConfig } from '../game/data/types';
import { cameraOrigin, screenUnit } from './viewport';
import { drawRoomFurnishings, drawRoomBadgePlaque, drawArchitecturalStairs } from './room-furnishings';
export type DepthItem={depth:number;paint:()=>void};
export type AuxZone={rect:Bounds;name:string;kind:'wc'|'passage'|'office'|'special'};
const AUX_ZONES:Record<string,AuxZone[]>={
  'admin-front:floor-1':[
    {rect:{x0:-25,x1:-15.25,z0:39,z1:46.2},name:'八、九年級導師室（西側） (1F)',kind:'office'},
    {rect:{x0:-15.25,x1:-11.5,z0:39,z1:46.2},name:'1F 中央穿堂（方案 C）',kind:'passage'},
    {rect:{x0:-11.5,x1:-9.5625,z0:39,z1:46.2},name:'男女廁 (WC)',kind:'wc'},
    {rect:{x0:-9.5625,x1:1,z0:39,z1:46.2},name:'八、九年級導師室（東側） (1F)',kind:'office'},
  ],
  'admin-front:floor-2':[
    {rect:{x0:-15.25,x1:-11.5,z0:39,z1:46.2},name:'2F 中央穿堂',kind:'passage'},
    {rect:{x0:-11.5,x1:-9.5625,z0:39,z1:46.2},name:'男女廁 (WC)',kind:'wc'},
  ],
  'admin-front:floor-3':[
    {rect:{x0:-15.25,x1:-11.5,z0:39,z1:46.2},name:'3F 中央穿堂',kind:'passage'},
    {rect:{x0:-11.5,x1:-9.5625,z0:39,z1:46.2},name:'男女廁 (WC)',kind:'wc'},
  ],
  'admin-back:floor-1':[{rect:{x0:-10.5789,x1:-8.1228,z0:15,z1:22.2},name:'男女廁 (WC)',kind:'wc'}],
  'admin-back:floor-2':[
    {rect:{x0:-10.5789,x1:-8.1228,z0:15,z1:22.2},name:'男女廁 (WC)',kind:'wc'},
    {rect:{x0:-8.1228,x1:1,z0:15,z1:22.2},name:'總務・人事・會計（東區） (2F)',kind:'office'},
  ],
  'admin-back:floor-3':[{rect:{x0:-10.5789,x1:-8.1228,z0:15,z1:22.2},name:'男女廁 (WC)',kind:'wc'}],
  'health-bld:floor-1':[{rect:{x0:-2,x1:20,z0:-2.3,z1:0.5},name:'通廊 (Breezeway)',kind:'passage'}],
  'grade9-back:floor-1':[
    {rect:{x0:1.5,x1:10.7,z0:35.158,z1:38.21},name:'通廊 (Breezeway)',kind:'passage'},
    {rect:{x0:1.5,x1:10.7,z0:38.21,z1:41},name:'男女廁 (WC)',kind:'wc'},
  ],
  'grade9-back:floor-2':[
    {rect:{x0:1.5,x1:10.7,z0:35.158,z1:38.21},name:'通廊 (Breezeway)',kind:'passage'},
    {rect:{x0:1.5,x1:10.7,z0:38.21,z1:41},name:'男女廁 (WC)',kind:'wc'},
  ],
  'grade9-back:floor-3':[
    {rect:{x0:1.5,x1:10.7,z0:35.158,z1:38.21},name:'通廊 (Breezeway)',kind:'passage'},
    {rect:{x0:1.5,x1:10.7,z0:38.21,z1:41},name:'男女廁 (WC)',kind:'wc'},
  ],
  'grade8-mid:floor-1':[{rect:{x0:24.3,x1:34.5,z0:38.358,z1:41},name:'男女廁 (WC)',kind:'wc'}],
  'grade8-mid:floor-2':[{rect:{x0:24.3,x1:34.5,z0:38.358,z1:41},name:'男女廁 (WC)',kind:'wc'}],
  'grade8-mid:floor-3':[{rect:{x0:24.3,x1:34.5,z0:38.358,z1:41},name:'男女廁 (WC)',kind:'wc'}],
  'new-grade7:floor-1':[
    {rect:{x0:63,x1:73.667,z0:-65,z1:-57},name:'A11 廣場（挑空穿堂）',kind:'passage'},
    {rect:{x0:95,x1:97.8,z0:-65,z1:-57},name:'配電室／男女廁 (WC)',kind:'wc'},
  ],
  'new-grade7:floor-2':[
    {rect:{x0:57,x1:63,z0:-57,z1:-51},name:'視聽中心 (2F)',kind:'special'},
    {rect:{x0:95,x1:97.8,z0:-65,z1:-57},name:'男女廁 (WC)',kind:'wc'},
  ],
  'new-grade7:floor-3':[
    {rect:{x0:57,x1:63,z0:-57,z1:-51},name:'視聽中心 (3F)',kind:'special'},
    {rect:{x0:95,x1:97.8,z0:-65,z1:-57},name:'男女廁 (WC)',kind:'wc'},
  ],
  'multi-building:floor-1':[
    {rect:{x0:84,x1:90,z0:-10.2,z1:-6},name:'男女廁 (WC)',kind:'wc'},
    {rect:{x0:62,x1:78,z0:-29,z1:-17},name:'🅿 中庭停車場',kind:'passage'},
  ],
  'multi-building:floor-2':[{rect:{x0:84,x1:90,z0:-10.2,z1:-6},name:'男女廁 (WC)',kind:'wc'}],
  'tech-building:floor-1':[
    {rect:{x0:74.2,x1:80.2,z0:19.8,z1:23},name:'男女廁 (WC)',kind:'wc'},
    {rect:{x0:64,x1:78,z0:9,z1:15},name:'1F 中央通廊',kind:'passage'},
  ],
  'tech-building:floor-2':[
    {rect:{x0:74.2,x1:80.2,z0:19.8,z1:23},name:'男女廁 (WC)',kind:'wc'},
    {rect:{x0:64,x1:78,z0:9,z1:15},name:'2F 連通廊',kind:'passage'},
  ],
  'gym-bld:floor-1':[{rect:{x0:-74,x1:-65.8,z0:46,z1:51},name:'男女廁 (WC)',kind:'wc'}],
};
export const auxiliaryZones=(floorId:string):AuxZone[]=>AUX_ZONES[floorId]??[];
export function roomPalette(name:string,kind?:AuxZone['kind']){
  if(kind==='wc'||name.includes('廁'))return{bg:'#fce7f3',border:'#be185d',text:'#9d174d'};
  if(kind==='passage'||/(穿堂|通廊|連通廊|廣場|停車場)/.test(name))return{bg:'#e2e8f0',border:'#475569',text:'#1e293b'};
  if(kind==='office'||/(校長室|教務處|學務處|總務|人事|會計|輔導室|導師室|辦公室|健康中心|合作社|檔案室|會客室|教練室|油印室|研習中心|機房|會議室|器材室|訓練室|回收室)/.test(name))return{bg:'#dbeafe',border:'#1d4ed8',text:'#1e3a8a'};
  if(/([789]0[1-9]|幼兒園)/.test(name))return{bg:'#fef9c3',border:'#b45309',text:'#78350f'};
  return{bg:'#dcfce7',border:'#15803d',text:'#14532d'};
}
type Actor={x:number;y:number;direction?:string};
let actorPainter:((ctx:CanvasRenderingContext2D,actor:Actor,isPlayer?:boolean)=>boolean)|undefined;
export function setActorPainter(painter:typeof actorPainter){actorPainter=painter;}
export function paintActor(ctx:CanvasRenderingContext2D,actor:Actor,isPlayer=false){if(actorPainter?.(ctx,actor,isPlayer))return;ctx.fillStyle=isPlayer?'#087ba8':'#edb94d';ctx.fillRect(actor.x-12,actor.y-32,24,32);}
export function drawPilotWorld(ctx:CanvasRenderingContext2D,pilot:Pilot,id:PilotId,showRoute:boolean,player:{x:number;y:number},npcs:NpcConfig[]) {
  const map=pilot.maps[id],unit=screenUnit(ctx.getTransform().a);
  const {x,y}=cameraOrigin(map,player);
  ctx.save();ctx.translate(-x,-y);const depth=drawPilot(ctx,pilot,id,showRoute);
  for(const portal of map.portals){const r=portal.trigger;ctx.fillStyle='#17a0aa99';ctx.fillRect(r.x,r.y,r.width,r.height);ctx.fillStyle='#092f47';ctx.font=`bold ${20*unit}px system-ui`;ctx.fillText(portal.prompt,r.x,r.y-12*unit);}
  for(const npc of npcs)depth.push({depth:npc.y,paint:()=>{if(actorPainter?.(ctx,npc,false))return;ctx.fillStyle='#edb94d';ctx.fillRect(npc.x-12*unit,npc.y-32*unit,24*unit,32*unit);ctx.fillStyle='#173f58';ctx.font=`bold ${18*unit}px system-ui`;ctx.textAlign='center';ctx.fillText(`${npc.name} · 遊戲 NPC`,npc.x,npc.y-42*unit);ctx.textAlign='left';}});
  depth.push({depth:player.y,paint:()=>{if(actorPainter?.(ctx,player,true))return;ctx.fillStyle='#087ba8';ctx.fillRect(player.x-12*unit,player.y-32*unit,24*unit,32*unit);ctx.fillStyle='#fff';ctx.fillRect(player.x-8*unit,player.y-30*unit,16*unit,10*unit);}});
  depth.sort((a,b)=>a.depth-b.depth).forEach(item=>item.paint());ctx.restore();
}
/** Source geometry rendered as a schematic cutaway, never claimed to be a surveyed likeness. */
export function drawPilot(ctx:CanvasRenderingContext2D,pilot:Pilot,id:PilotId,showRoute:boolean):DepthItem[] {
  const t=pilot.transforms[id],map=pilot.maps[id],outdoor=id==='pilot-outdoor',level=id==='pilot-tech-2'?2:1;
  const depth:DepthItem[]=[];
  ctx.fillStyle=outdoor?'#c5d9be':'#aec7b5';ctx.fillRect(0,0,map.width,map.height);
  const floor=(r:Rect,color:string)=>{ctx.fillStyle=color;ctx.fillRect(r.x,r.y,r.width,r.height);};
  if(outdoor) {
    const route=pilot.routes[id];ctx.strokeStyle='#e4dcc9';ctx.lineWidth=t.unit*1.6;ctx.lineJoin='round';ctx.beginPath();route.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();
    for(const b of pilot.shared.buildings){const r=t.rect(b.bounds);floor(r,'#9eaec0');depth.push({depth:r.y+r.height,paint:()=>{
      ctx.fillStyle=b.id==='tech-building'?'#358b9b':'#63829b';ctx.fillRect(r.x,r.y+r.height-16,r.width,34);
      ctx.fillStyle=b.id==='tech-building'?'#d2e9ed':'#d9e1eb';ctx.fillRect(r.x+5,r.y+5,r.width-10,r.height-10);
      ctx.strokeStyle='#536f82';ctx.lineWidth=3;ctx.strokeRect(r.x,r.y,r.width,r.height);
      ctx.fillStyle='#17384a';ctx.font='bold 25px system-ui';ctx.textAlign='center';
      b.name.split(' / ').forEach((line,i)=>ctx.fillText(line,r.x+r.width/2,r.y+r.height/2+i*32,Math.max(50,r.width-18)));ctx.textAlign='left';
    }});}
    const gate=t.toGame(pilot.canonicalRoutes[id][0].position);ctx.fillStyle='#153e51';ctx.font='bold 26px system-ui';ctx.fillText('校門・示範起點',gate.x-90,gate.y+55);
  } else {
    const data=pilot.shared.floors.find(f=>f.buildingId==='tech-building'&&f.level===level)!;
    data.footprints.forEach(b=>floor(t.rect(b),'#e7e8dc'));
    data.corridors.forEach(b=>floor(t.rect(b),'#d5e6e8'));
    for(const z of auxiliaryZones(data.id)){
      const r=t.rect(z.rect),pal=roomPalette(z.name,z.kind);floor(r,pal.bg);
      ctx.strokeStyle=pal.border;ctx.lineWidth=2;ctx.strokeRect(r.x,r.y,r.width,r.height);
      ctx.fillStyle=pal.text;ctx.font='bold 18px system-ui';ctx.textAlign='center';
      ctx.fillText(z.name,r.x+r.width/2,r.y+28,Math.max(40,r.width-14));ctx.textAlign='left';
    }
    for(const room of pilot.shared.rooms.filter(r=>r.floorId===data.id)){
      const r=t.rect(room.rect),pal=roomPalette(room.name),door=t.toGame(room.door);floor(r,pal.bg);
      ctx.strokeStyle=pal.border;ctx.lineWidth=2;ctx.strokeRect(r.x,r.y,r.width,r.height);
      drawRoomFurnishings(ctx, r, door, room.name, 1);
      drawRoomBadgePlaque(ctx, r, room.name, 1, (room as any).spaceCode);
      ctx.fillStyle='#0284c7';ctx.fillRect(door.x-15,door.y-4,30,8);
      ctx.fillStyle='#e0f2fe';ctx.fillRect(door.x-12,door.y-2,24,4);
    }
    const stair=t.rect(pilot.stair.rect);
    drawArchitecturalStairs(ctx, stair, pilot.stair.id, `科技館南翼樓梯 ${level}F`, 'tech-building', 1);
    for(const r of map.collisionZones){if(r.width>t.unit*10&&r.height>t.unit*4)continue;depth.push({depth:r.y+r.height,paint:()=>{
      ctx.fillStyle='#607d8d';ctx.fillRect(r.x,r.y-12,r.width,r.height+12);ctx.fillStyle='#9fb4bb';ctx.fillRect(r.x,r.y-12,r.width,Math.min(9,r.height));
    }});}
    ctx.fillStyle='#204b62';ctx.font='bold 26px system-ui';ctx.fillText(`科技館 ${level}F・平面剖視示意`,40,45);
  }
  if(showRoute){
    const route=pilot.routes[id];ctx.strokeStyle='#df9c21';ctx.lineWidth=5;ctx.setLineDash([12,12]);ctx.beginPath();route.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();ctx.setLineDash([]);
    let distance=0;for(let i=1;i<route.length;i++) {const a=route[i-1],b=route[i];distance+=Math.hypot(b.x-a.x,b.y-a.y);if(distance<100)continue;distance=0;ctx.save();ctx.translate(b.x,b.y);ctx.rotate(Math.atan2(b.y-a.y,b.x-a.x));ctx.fillStyle='#a26000';ctx.beginPath();ctx.moveTo(8,0);ctx.lineTo(-5,-5);ctx.lineTo(-5,5);ctx.closePath();ctx.fill();ctx.restore();}
  }
  return depth;
}

