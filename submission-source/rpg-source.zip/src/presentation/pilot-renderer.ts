import type { Pilot, PilotId } from './pilot-adapter';
import type { Rect, NpcConfig } from '../game/data/types';
import { cameraOrigin, screenUnit } from './viewport';
export type DepthItem={depth:number;paint:()=>void};
type Actor={x:number;y:number;direction?:string};
let actorPainter:((ctx:CanvasRenderingContext2D,actor:Actor,isPlayer?:boolean)=>boolean)|undefined;
export function setActorPainter(painter:typeof actorPainter){actorPainter=painter;}
export function paintActor(ctx:CanvasRenderingContext2D,actor:Actor,isPlayer=false){if(actorPainter?.(ctx,actor,isPlayer))return;ctx.fillStyle=isPlayer?'#087ba8':'#edb94d';ctx.fillRect(actor.x-12,actor.y-32,24,32);}
export function drawPilotWorld(ctx:CanvasRenderingContext2D,pilot:Pilot,id:PilotId,showRoute:boolean,player:{x:number;y:number},npcs:NpcConfig[]) {
  const map=pilot.maps[id],unit=screenUnit(ctx.getTransform().a);
  const {x,y}=cameraOrigin(map,player);
  ctx.save();ctx.translate(-x,-y);const depth=drawPilot(ctx,pilot,id,showRoute);
  for(const portal of map.portals){const r=portal.trigger;ctx.fillStyle='#17a0aa99';ctx.fillRect(r.x,r.y,r.width,r.height);ctx.fillStyle='#092f47';ctx.font=`bold ${20*unit}px system-ui`;ctx.fillText(portal.prompt,r.x,r.y-12*unit);}
  for(const npc of npcs)depth.push({depth:npc.y,paint:()=>{if(actorPainter?.(ctx,npc,false))return;ctx.fillStyle='#edb94d';ctx.fillRect(npc.x-12*unit,npc.y-32*unit,24*unit,32*unit);ctx.fillStyle='#173f58';ctx.font=`bold ${18*unit}px system-ui`;ctx.textAlign='center';ctx.fillText(`${npc.name} · 遊戲 NPC`,npc.x,npc.y-42*unit);ctx.textAlign='left';}});
  depth.push({depth:player.y,paint:()=>{if(actorPainter?.(ctx,player,true))return;ctx.fillStyle='#087ba8';ctx.fillRect(player.x-12*unit,player.y-32*unit,24*unit,32*unit);ctx.fillStyle='#fff';ctx.fillRect(player.x-8*unit,player.y-30*unit,16*unit,10*unit);}});
  depth.sort((a,b)=>a.depth-b.depth).forEach(item=>item.paint());ctx.restore();
}
/** Source geometry rendered as a schematic cutaway, never claimed to be a surveyed likeness. */
export function drawPilot(ctx:CanvasRenderingContext2D,pilot:Pilot,id:PilotId,showRoute:boolean):DepthItem[] {
  const t=pilot.transforms[id],map=pilot.maps[id],outdoor=id==='pilot-outdoor',level=id==='pilot-tech-2'?2:1;
  const depth:DepthItem[]=[];
  ctx.fillStyle=outdoor?'#c5d9be':'#aec7b5';ctx.fillRect(0,0,map.width,map.height);
  const floor=(r:Rect,color:string)=>{ctx.fillStyle=color;ctx.fillRect(r.x,r.y,r.width,r.height);};
  if(outdoor) {
    const route=pilot.routes[id];ctx.strokeStyle='#e4dcc9';ctx.lineWidth=t.unit*1.6;ctx.lineJoin='round';ctx.beginPath();route.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();
    for(const b of pilot.shared.buildings){const r=t.rect(b.bounds);floor(r,'#9eaec0');depth.push({depth:r.y+r.height,paint:()=>{
      ctx.fillStyle=b.id==='tech-building'?'#358b9b':'#63829b';ctx.fillRect(r.x,r.y+r.height-16,r.width,34);
      ctx.fillStyle=b.id==='tech-building'?'#d2e9ed':'#d9e1eb';ctx.fillRect(r.x+5,r.y+5,r.width-10,r.height-10);
      ctx.strokeStyle='#536f82';ctx.lineWidth=3;ctx.strokeRect(r.x,r.y,r.width,r.height);
      ctx.fillStyle='#17384a';ctx.font='bold 25px system-ui';ctx.textAlign='center';
      b.name.split(' / ').forEach((line,i)=>ctx.fillText(line,r.x+r.width/2,r.y+r.height/2+i*32,Math.max(50,r.width-18)));ctx.textAlign='left';
    }});}
    const gate=t.toGame(pilot.canonicalRoutes[id][0].position);ctx.fillStyle='#153e51';ctx.font='bold 26px system-ui';ctx.fillText('校門・示範起點',gate.x-90,gate.y+55);
  } else {
    const data=pilot.shared.floors.find(f=>f.buildingId==='tech-building'&&f.level===level)!;
    data.footprints.forEach(b=>floor(t.rect(b),'#e7e8dc'));
    data.corridors.forEach(b=>floor(t.rect(b),'#d5e6e8'));
    for(const room of pilot.shared.rooms.filter(r=>r.floorId===data.id)){
      const r=t.rect(room.rect);floor(r,room.id===pilot.room.id?'#dae9f4':'#f1eadb');
      ctx.strokeStyle='#c2bba8';ctx.lineWidth=2;ctx.strokeRect(r.x,r.y,r.width,r.height);
      ctx.fillStyle='#274e62';ctx.font='bold 22px system-ui';ctx.textAlign='center';
      ctx.fillText(room.name,r.x+r.width/2,r.y+30,Math.max(50,r.width-22));ctx.textAlign='left';
      const door=t.toGame(room.door);ctx.fillStyle='#0b8f99';ctx.fillRect(door.x-15,door.y-5,30,10);
    }
    const stair=t.rect(pilot.stair.rect);floor(stair,'#cdd5d5');
    ctx.strokeStyle='#7d939c';ctx.lineWidth=2;for(let i=1;i<9;i++){const y=stair.y+stair.height*i/9;ctx.beginPath();ctx.moveTo(stair.x+8,y);ctx.lineTo(stair.x+stair.width-8,y);ctx.stroke();}
    ctx.fillStyle='#254657';ctx.font='bold 23px system-ui';ctx.fillText(`南翼樓梯 ${level}F`,stair.x+8,stair.y+30);
    for(const r of map.collisionZones){if(r.width>t.unit*10&&r.height>t.unit*4)continue;depth.push({depth:r.y+r.height,paint:()=>{
      ctx.fillStyle='#607d8d';ctx.fillRect(r.x,r.y-12,r.width,r.height+12);ctx.fillStyle='#9fb4bb';ctx.fillRect(r.x,r.y-12,r.width,Math.min(9,r.height));
    }});}
    ctx.fillStyle='#204b62';ctx.font='bold 26px system-ui';ctx.fillText(`科技館 ${level}F・平面剖視示意`,40,45);
  }
  if(showRoute){
    const route=pilot.routes[id];ctx.strokeStyle='#df9c21';ctx.lineWidth=5;ctx.setLineDash([12,12]);ctx.beginPath();route.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();ctx.setLineDash([]);
    let distance=0;for(let i=1;i<route.length;i++) {const a=route[i-1],b=route[i];distance+=Math.hypot(b.x-a.x,b.y-a.y);if(distance<100)continue;distance=0;ctx.save();ctx.translate(b.x,b.y);ctx.rotate(Math.atan2(b.y-a.y,b.x-a.x));ctx.fillStyle='#a26000';ctx.beginPath();ctx.moveTo(8,0);ctx.lineTo(-5,-5);ctx.lineTo(-5,5);ctx.closePath();ctx.fill();ctx.restore();}
  }
  return depth;
}
