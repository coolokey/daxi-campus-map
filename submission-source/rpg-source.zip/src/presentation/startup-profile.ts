export function reportStartup() {
  console.info('RPG_STARTUP',JSON.stringify({readyMs:Math.round(performance.now()),resources:performance.getEntriesByType('resource').map(entry=>({name:entry.name.split('/').pop(),ms:Math.round(entry.duration),bytes:(entry as PerformanceResourceTiming).transferSize}))}));
}
