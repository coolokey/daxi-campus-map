import {projectIso} from './model-world';
import {terrainSeed} from './hex-terrain';
type P={x:number;y:number};
let brick:HTMLCanvasElement|undefined;
const patterns=new WeakMap<CanvasRenderingContext2D,CanvasPattern>();
function brickTexture(){
 if(brick)return brick;
 brick=document.createElement('canvas');brick.width=256;brick.height=256;
 const c=brick.getContext('2d')!;c.fillStyle='#c6bea8';c.fillRect(0,0,256,256);
 const colors=['#d8ceb5','#dfd5bc','#d4cbb4','#dcd3bb','#d1c9b3','#e1d7bf'];
 for(let row=0;row<16;row++)for(let col=-1;col<9;col++){
  const x=col*32+(row%2)*16,y=row*16,n=terrainSeed((col+8)%8,row);
  c.fillStyle=colors[n%colors.length];c.fillRect(x+1,y+1,30,14);
  c.fillStyle='#fff9e64a';c.fillRect(x+2,y+1,28,1);
  c.fillStyle='#786d5514';c.fillRect(x+2,y+13,28,1);
 }
 return brick;
}
/** Fine masonry only on existing paved polygons; same world origin at every scale. */
export function paintStoryPaving(ctx:CanvasRenderingContext2D,points:P[],unit:number){
 if(points.length<3)return;
 const screen=points.map(projectIso),m=ctx.getTransform(),xs=screen.map(p=>m.a*p.x+m.c*p.y+m.e),ys=screen.map(p=>m.b*p.x+m.d*p.y+m.f);
 if(Math.max(...xs)<-8||Math.min(...xs)>ctx.canvas.width+8||Math.max(...ys)<-8||Math.min(...ys)>ctx.canvas.height+8)return;
 ctx.save();ctx.transform(Math.sqrt(3)/2,.5,-Math.sqrt(3)/2,.5,0,0);
 ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();
 ctx.fillStyle='#d9cfb5';ctx.fill();ctx.strokeStyle='#f0e5c9';ctx.lineWidth=unit*.2;ctx.stroke();ctx.clip();
 let pattern=patterns.get(ctx);if(!pattern){pattern=ctx.createPattern(brickTexture(),'repeat')!;patterns.set(ctx,pattern);}
 pattern.setTransform(new DOMMatrix().scale(unit/32));ctx.fillStyle=pattern;
 const x=Math.min(...points.map(p=>p.x)),y=Math.min(...points.map(p=>p.y));
 ctx.fillRect(x,y,Math.max(...points.map(p=>p.x))-x,Math.max(...points.map(p=>p.y))-y);ctx.restore();
}
/** Ground inlay, not a new object or destination. Radius fits inside the existing avenue. */
export function paintWelcomeInlay(ctx:CanvasRenderingContext2D,point:P,unit:number){
 const p=projectIso(point);ctx.save();ctx.translate(p.x,p.y);ctx.scale(1,.57735);
 const r=unit*2.6;ctx.strokeStyle='#a8ae8c';ctx.lineWidth=unit*.08;
 ctx.beginPath();ctx.arc(0,0,r,0,Math.PI*2);ctx.stroke();
 for(let i=0;i<8;i++){ctx.save();ctx.rotate(i*Math.PI/4);ctx.fillStyle=i%2?'#c6b58f':'#91a78c';ctx.beginPath();ctx.moveTo(0,-r*.86);ctx.lineTo(r*.16,0);ctx.lineTo(0,r*.14);ctx.lineTo(-r*.16,0);ctx.closePath();ctx.fill();ctx.restore();}
 ctx.fillStyle='#efe3be';ctx.beginPath();ctx.arc(0,0,r*.22,0,Math.PI*2);ctx.fill();ctx.restore();
}
/** Shared sunlight falls toward screen bottom-right. Ground-only shadow cannot hide an actor. */
export function paintBuildingShadow(ctx:CanvasRenderingContext2D,r:{x:number;y:number;width:number;height:number},height:number,unit:number){
 const base=[{x:r.x,y:r.y},{x:r.x+r.width,y:r.y},{x:r.x+r.width,y:r.y+r.height},{x:r.x,y:r.y+r.height}].map(projectIso);
 const dx=height*.48,dy=height*.28;
 ctx.save();ctx.fillStyle='#34574718';ctx.beginPath();[base[0],{x:base[0].x+dx,y:base[0].y+dy},{x:base[1].x+dx,y:base[1].y+dy},{x:base[2].x+dx,y:base[2].y+dy},{x:base[3].x+dx,y:base[3].y+dy},base[3]].forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();ctx.fill();
 ctx.strokeStyle='#405a4025';ctx.lineWidth=unit*.22;ctx.beginPath();ctx.moveTo(base[1].x,base[1].y);ctx.lineTo(base[2].x,base[2].y);ctx.lineTo(base[3].x,base[3].y);ctx.stroke();ctx.restore();
}
