import { beforeEach, describe, expect, it, vi } from 'vitest';
import shared from '../../public/data/campus.shared.json';
import runtime from '../../public/data/technology-demo-runtime.json';
import { campusMap } from '../game/data/maps/campus';
import { getWorldScale, scaleMap, setWorldScale } from '../game/core/world';
import { createPilotControls } from './pilot-controls';
import { isBlocked } from '../game/core/collision';
import type { MapConfig, SpawnPoint } from '../game/data/types';
import type { WorldId } from '../game/config';
import type { Pilot } from './pilot-adapter';

describe('original campus technology entrance',()=>{
  beforeEach(()=>{
    setWorldScale(1);
    document.body.innerHTML='<div class="explore-toolbar"></div><section id="exploration"><p id="world-status"></p><div id="dialogue" hidden><p></p></div></section><button id="quest-start"></button>';
    vi.stubGlobal('fetch',vi.fn(async (url:URL)=>({ok:true,json:async()=>String(url).includes('campus.shared')?shared:runtime})));
  });
  function setup(){
    const maps:Partial<Record<WorldId,MapConfig>>={campus:scaleMap(campusMap,getWorldScale())};
    let map=maps.campus!,player:SpawnPoint={x:1930,y:850,direction:'up'};
    const visited:WorldId[]=[];
    const host={maps,read:()=>({map,player,npcs:[],questOpen:false,questLoading:false}),setPilot:(p:Pilot)=>Object.assign(maps,p.maps),place:(m:MapConfig,p:SpawnPoint)=>{map=m;player=p;visited.push(m.id);},route:vi.fn(),openQuest:vi.fn(async()=>{}),pause:vi.fn()};
    return {controls:createPilotControls(host),host,visited,state:()=>({map,player}),move:(p:SpawnPoint)=>{player=p;}};
  }
  it('enters source 1F without visiting a replacement outdoor map and keeps quick quest available',async()=>{
    const t=setup();await t.controls.enter();
    expect(t.visited).toEqual(['pilot-tech-1']);
    expect(t.state().player).toEqual(t.state().map.spawns.entry);
    expect(document.getElementById('quest-start')!.hidden).toBe(false);
    expect(t.controls.canPortal()).toBe(false);
    t.move({...t.state().player,x:t.state().player.x+80});t.controls.step(performance.now()+1000);
    expect(t.controls.canPortal()).toBe(true);
    expect(t.state().map.portals.find(p=>p.id==='tech-up')?.destinationMapId).toBe('pilot-tech-2');
  });
  it('returns to the pre-entry original campus position after changing scale indoors',async()=>{
    const t=setup();await t.controls.enter();
    setWorldScale(2);t.host.maps.campus=scaleMap(campusMap,2);t.controls.scale(2400);
    expect(t.controls.canPortal()).toBe(false);
    t.controls.exit();
    expect(t.state().map).toBe(t.host.maps.campus);
    expect(t.state().player).toEqual({x:3860,y:1700,direction:'up'});
    expect(t.visited).not.toContain('pilot-outdoor');
  });
  it('recovers an obsolete entry position that now lies inside a verified building footprint',async()=>{
    const t=setup();t.move({x:2000,y:850,direction:'up'});await t.controls.enter();t.controls.exit();
    const {map,player}=t.state();expect(isBlocked({x:player.x-16,y:player.y-16,width:32,height:40},map.collisionZones)).toBe(false);
    expect(Math.hypot(player.x-2000,player.y-850)).toBeLessThan(160);
  });
  it('keeps the player on campus after a load failure and allows retry',async()=>{
    const t=setup();vi.mocked(fetch).mockRejectedValueOnce(new Error('offline'));
    await t.controls.enter();expect(t.state().map.id).toBe('campus');
    await t.controls.enter();expect(t.state().map.id).toBe('pilot-tech-1');
  });
  it('keeps the upper-floor mentor linked to the original quest without moving the player',async()=>{
    const t=setup();await t.controls.enter();
    const upper=t.host.maps['pilot-tech-2']!;t.host.place(upper,{...upper.spawns.stairs});t.controls.onPortal();
    const position={...t.state().player};
    expect(t.controls.canPortal()).toBe(false);
    expect(t.controls.interact(upper.npcs[0])).toBe(true);
    expect(document.getElementById('dialogue')!.hidden).toBe(false);
    document.getElementById('pilot-accept')!.click();
    expect(t.host.openQuest).toHaveBeenCalledOnce();
    expect(t.state().player).toEqual(position);
    expect(document.getElementById('quest-start')!.hidden).toBe(false);
  });
});
