import roofTypes from '../../public/data/building-art-v1.json';
import type {Rect} from '../game/data/types';
type P={x:number;y:number};type V=P&{z:number};
export const buildingFloorCount=(height:number,unit:number)=>Math.max(1,Math.round(height/(unit*5.4)));
export function buildingRoof(r:Rect,h:number,unit:number,id:string){
 const c:V[]=[{x:r.x,y:r.y,z:h},{x:r.x+r.width,y:r.y,z:h},{x:r.x+r.width,y:r.y+r.height,z:h},{x:r.x,y:r.y+r.height,z:h}];
 const pitched=roofTypes.pitchedBuildings.includes(id);
 if(pitched){
  const alongX=r.width>=r.height,rise=Math.min(unit*1.05,Math.min(r.width,r.height)*.18);
  const a:V=alongX?{x:r.x,y:r.y+r.height/2,z:h+rise}:{x:r.x+r.width/2,y:r.y,z:h+rise};
  const b:V=alongX?{x:r.x+r.width,y:a.y,z:a.z}:{x:a.x,y:r.y+r.height,z:a.z};
  return {pitched,solar:false,corners:c,ridge:[a,b],faces:alongX?[[c[0],c[1],b,a],[c[3],c[2],b,a],[c[1],c[2],b],[c[0],c[3],a]]:[[c[0],c[3],b,a],[c[1],c[2],b,a],[c[2],c[3],b],[c[0],c[1],a]]};
 }
 const inset=Math.min(unit*.45,r.width*.1,r.height*.1);
 const inner:V[]=[{x:r.x+inset,y:r.y+inset,z:h+unit*.14},{x:r.x+r.width-inset,y:r.y+inset,z:h+unit*.14},{x:r.x+r.width-inset,y:r.y+r.height-inset,z:h+unit*.14},{x:r.x+inset,y:r.y+r.height-inset,z:h+unit*.14}];
 return {pitched,solar:id===roofTypes.solarBuilding,corners:c,ridge:[],faces:[inner,...c.map((p,i)=>[p,c[(i+1)%4],inner[(i+1)%4],inner[i]])]};
}
export function polygonContains(points:P[],p:P){let inside=false;for(let i=0,j=points.length-1;i<points.length;j=i++){const a=points[i],b=points[j];if((a.y>p.y)!==(b.y>p.y)&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x)inside=!inside;}return inside;}
/** Only the surface overlapping the actor silhouette fades. */
export function surfaceCoversActor(points:P[],foot:P,actorUnit:number){
 // The atlas is drawn at 48 x 66 CSS units, with its foot anchor about 58 above the top.
 const left=foot.x-24*actorUnit,right=foot.x+24*actorUnit,top=foot.y-58*actorUnit,bottom=foot.y+9*actorUnit;
 if(!points.length||Math.max(...points.map(p=>p.x))<left||Math.min(...points.map(p=>p.x))>right||Math.max(...points.map(p=>p.y))<top||Math.min(...points.map(p=>p.y))>bottom)return false;
 const rect=[{x:left,y:top},{x:right,y:top},{x:right,y:bottom},{x:left,y:bottom}];
 if(points.some(p=>p.x>=left&&p.x<=right&&p.y>=top&&p.y<=bottom)||rect.some(p=>polygonContains(points,p)))return true;
 const cross=(a:P,b:P,c:P)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
 const intersects=(a:P,b:P,c:P,d:P)=>Math.max(a.x,b.x)>=Math.min(c.x,d.x)&&Math.max(c.x,d.x)>=Math.min(a.x,b.x)&&Math.max(a.y,b.y)>=Math.min(c.y,d.y)&&Math.max(c.y,d.y)>=Math.min(a.y,b.y)&&cross(a,b,c)*cross(a,b,d)<=0&&cross(c,d,a)*cross(c,d,b)<=0;
 return points.some((p,i)=>rect.some((q,j)=>intersects(p,points[(i+1)%points.length],q,rect[(j+1)%4])));
}
