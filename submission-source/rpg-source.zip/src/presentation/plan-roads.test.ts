import {describe,it,expect} from 'vitest';
import {createModelWorld} from './model-world';
import {walkable,clearSegment} from './navigation';

describe('plan-aligned outdoor roads',()=>{
 it('shows the missing north-south road and joins the south road at every scale',()=>{for(const scale of [1,1.5,2]){const w=createModelWorld(scale),map=w.maps.campus,t=w.transforms.campus;for(const z of [-61,-38,14.5,54.5,86]){const p=t.toGame({x:52,z});expect(map.outdoorPaving?.some(r=>p.x>=r.x&&p.x<=r.x+r.width&&p.y>=r.y&&p.y<=r.y+r.height),`L road missing at ${z}, scale ${scale}`).toBe(true);expect(walkable(p,map)).toBe(true);}}});
 it('connects four eastern building portals with collision-checked access paths',()=>{for(const scale of [1,1.5,2]){const w=createModelWorld(scale),map=w.maps.campus;expect(map.outdoorPaths).toHaveLength(4);for(const link of map.outdoorPaths??[]){expect(link.points.length).toBeGreaterThanOrEqual(2);for(let i=1;i<link.points.length;i++)expect(clearSegment(link.points[i-1],link.points[i],map)).toBe(true);const end=link.points.at(-1)!;expect(map.portals.some(p=>Math.abs(end.x-p.trigger.x-22)<.01&&Math.abs(end.y-p.trigger.y-22)<.01)).toBe(true);}}});
});
