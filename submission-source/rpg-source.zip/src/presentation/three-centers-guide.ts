import type {MapConfig,SpawnPoint} from '../game/data/types';
import {CENTER_STATIONS,loadCenterProgress,saveCenterProgress,advanceCenterProgress,type CenterId} from '../data/three-centers';
import {modelScene,projectIso,safeModelPoint,type ModelWorld} from './model-world';
import {clearSegment} from './navigation';
export function centerPoints(model:ModelWorld,map:MapConfig){return CENTER_STATIONS.filter(s=>modelScene(s.buildingId,s.level)===map.id).map(station=>{const room=model.targets[map.id]?.find(r=>r.id===station.roomId);if(!room)return undefined;return {...station,point:safeModelPoint({x:room.point.x-64,y:room.point.y},map)};}).filter((s):s is NonNullable<typeof s>=>!!s);}
export function findCenterTarget(model:ModelWorld,map:MapConfig,player:{x:number;y:number}){return centerPoints(model,map).filter(s=>Math.hypot(s.point.x-player.x,s.point.y-player.y)<=88&&clearSegment(player,s.point,map)).sort((a,b)=>Math.hypot(a.point.x-player.x,a.point.y-player.y)-Math.hypot(b.point.x-player.x,b.point.y-player.y))[0];}
export function mountThreeCenterGuide(host:{read:()=>{model:ModelWorld;map:MapConfig;player:SpawnPoint};open:(center?:CenterId)=>Promise<void>;pause:()=>void;redraw:()=>void}){
 let progress=loadCenterProgress();
 const button=document.createElement('button');button.textContent=`三心闖關 ${progress.completed.length}／3`;button.id='three-centers-open';button.className='primary-button';button.onclick=()=>void host.open();document.querySelector('.explore-toolbar')?.insertBefore(button,document.getElementById('quest-start'));
 const accept=document.createElement('button');accept.id='three-centers-accept';accept.className='primary-button';accept.hidden=true;document.getElementById('dialogue')!.append(accept);
 const update=()=>{progress=loadCenterProgress();button.textContent=`三心闖關 ${progress.completed.length}／3`;host.redraw();};window.addEventListener('campus:three-centers-progress',update);
 function next(){return CENTER_STATIONS.find(s=>!progress.completed.includes(s.id));}
 const mark=(ctx:CanvasRenderingContext2D,point:{x:number;y:number},color:string,text:string,symbol:string,unit:number)=>{
  const q=projectIso(point);ctx.save();ctx.translate(q.x,q.y);ctx.fillStyle='#fffdf5f5';ctx.strokeStyle=color;ctx.lineWidth=3*unit;ctx.beginPath();ctx.ellipse(0,0,19*unit,11*unit,0,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle=color;ctx.font=`bold ${14*unit}px system-ui`;ctx.textAlign='center';ctx.fillText(symbol,0,-14*unit);
  ctx.font=`600 ${11*unit}px system-ui`;const width=ctx.measureText(text).width+16*unit;ctx.fillStyle='#fffdf5ee';if(text){ctx.fillRect(-width/2,-40*unit,width,18*unit);ctx.fillStyle=color;ctx.fillText(text,0,-27*unit);}ctx.restore();
 };
 return {next,prompt:()=>{const s=next();return s?`三心探索：${s.location}・按「三心闖關」查看線索與導航`:'三心探索已完成！可以重訪各站，或體驗原版能源任務。';},
  target:()=>{const s=host.read();return findCenterTarget(s.model,s.map,s.player);},
  syncMarkers(){const {model,map}=host.read();map.questMarkers=centerPoints(model,map).map(s=>({...s.point,label:s.title,color:s.color,symbol:({incenter:'內',centroid:'重',circumcenter:'外'} as const)[s.id],completed:progress.completed.includes(s.id)}));if(map.id==='campus'&&next()){const p=map.portals.find(p=>p.id==='technology-building-door');if(p)map.questMarkers.push({x:p.trigger.x+22,y:p.trigger.y+22,label:'三心探索起點',color:'#b85a22',symbol:'心',completed:false});}},
  draw(ctx:CanvasRenderingContext2D,unit:number){const {map,player}=host.read();for(const m of map.questMarkers??[]){const near=Math.hypot(m.x-player.x,m.y-player.y)<350;mark(ctx,m,m.color,near?m.label+(m.completed?'・已完成':map.id==='campus'?'・E 進入':'・E 調查'):'',m.completed?'✓':m.symbol,unit);}},
  interact(station:NonNullable<ReturnType<typeof findCenterTarget>>){const i=CENTER_STATIONS.findIndex(s=>s.id===station.id),unlocked=i===0||progress.completed.includes(CENTER_STATIONS[i-1].id);progress=advanceCenterProgress(progress,station.id,'discover');saveCenterProgress(progress);const dialogue=document.getElementById('dialogue')!;dialogue.querySelector('p')!.textContent=`${station.title}｜${station.intro} 線索：${station.hints[0]}${unlocked?'':' 請先完成上一站，再啟動本站挑戰。'}`;accept.textContent=progress.completed.includes(station.id)?'複習本站三心觀念':unlocked?'查看圖形與開始本站挑戰':'查看本站線索';accept.hidden=false;accept.onclick=()=>{dialogue.hidden=true;accept.hidden=true;void host.open(station.id);};dialogue.hidden=false;host.pause();accept.focus();},
  closeDialogue:()=>{accept.hidden=true;}
 };
}
