import type {MapConfig,SpawnPoint} from '../game/data/types';
import {CENTER_STATIONS,loadCenterProgress,saveCenterProgress,advanceCenterProgress,type CenterId} from '../data/three-centers';
import {modelScene,projectIso,safeModelPoint,type ModelWorld} from './model-world';
import {clearSegment} from './navigation';
import {centerStageView} from './center-stage';
export function centerPoints(model:ModelWorld,map:MapConfig){return CENTER_STATIONS.filter(s=>modelScene(s.buildingId,s.level)===map.id).map(station=>{const room=model.targets[map.id]?.find(r=>r.id===station.roomId);if(!room)return undefined;return {...station,point:safeModelPoint({x:room.point.x-64,y:room.point.y},map)};}).filter((s):s is NonNullable<typeof s>=>!!s);}
export function findCenterTarget(model:ModelWorld,map:MapConfig,player:{x:number;y:number}){return centerPoints(model,map).filter(s=>Math.hypot(s.point.x-player.x,s.point.y-player.y)<=88&&clearSegment(player,s.point,map)).sort((a,b)=>Math.hypot(a.point.x-player.x,a.point.y-player.y)-Math.hypot(b.point.x-player.x,b.point.y-player.y))[0];}
export function mountThreeCenterGuide(host:{read:()=>{model:ModelWorld;map:MapConfig;player:SpawnPoint};open:(center?:CenterId)=>Promise<void>;pause:()=>void;redraw:()=>void}){
 let progress=loadCenterProgress();
 const button=document.createElement('button');button.textContent=`三心闖關 ${progress.completed.length}／3`;button.id='three-centers-open';button.className='primary-button';button.onclick=()=>void host.open();document.querySelector('.explore-toolbar')?.insertBefore(button,document.getElementById('quest-start'));
 const accept=document.createElement('button');accept.id='three-centers-accept';accept.className='primary-button';accept.hidden=true;document.getElementById('dialogue')!.append(accept);
 const tracker=document.createElement('aside');tracker.id='center-stage-tracker';tracker.setAttribute('aria-label','三心闖關階段');
 const heading=document.createElement('strong');const steps=document.createElement('ol');const instruction=document.createElement('p');instruction.setAttribute('aria-live','polite');
 const stageNodes=CENTER_STATIONS.map((station,i)=>{const li=document.createElement('li');li.textContent=`${i+1} ${station.short}`;steps.append(li);return li;});
 const action=document.createElement('button');action.type='button';action.className='primary-button';
 tracker.append(heading,steps,instruction,action);document.getElementById('exploration')!.append(tracker);
 const toolbar=document.querySelector('.explore-toolbar');
 if(toolbar&&typeof ResizeObserver!=='undefined')new ResizeObserver(()=>{tracker.style.setProperty('--toolbar-bottom',`${Math.ceil(toolbar.getBoundingClientRect().bottom)+12}px`);}).observe(toolbar);
 let stageSignature='';
 function syncTracker(){
  const state=host.read(),near=findCenterTarget(state.model,state.map,state.player)?.id,view=centerStageView(progress,near);
  const signature=JSON.stringify([view.index,view.action,view.states]);if(signature===stageSignature)return;stageSignature=signature;
  heading.textContent=view.station?`三心闖關｜第 ${view.index+1} 階段／3`:'三心闖關｜全部完成';
  stageNodes.forEach((li,i)=>{li.dataset.state=view.states[i];li.textContent=`${view.states[i]==='done'?'✓':i+1} ${CENTER_STATIONS[i].short}${view.states[i]==='locked'?'・未解鎖':view.states[i]==='current'?'・進行中':'・完成'}`;if(view.states[i]==='current')li.setAttribute('aria-current','step');else li.removeAttribute('aria-current');});
  instruction.textContent=view.station?`${view.station.location}｜${view.action==='discover'?'已抵達，按 E 或「互動」調查線索':view.action==='challenge'?'線索已找到，完成兩道題目即可過關':'跟隨導航前往本站，抵達後調查線索'}`:'內心、重心、外心均已完成，可以回顧圖形與解題觀念。';
  action.textContent=view.action==='review'?'回顧三心':view.action==='discover'?'調查本站線索':view.action==='challenge'?'開始／繼續本站挑戰':`導航至第 ${view.index+1} 站`;
  action.onclick=()=>{if(view.action==='navigate'&&view.station)window.dispatchEvent(new CustomEvent('campus:three-centers-navigate',{detail:{stationId:view.station.id}}));else if(view.action==='discover'){const current=host.read();const station=findCenterTarget(current.model,current.map,current.player);if(station?.id===view.station?.id)interactStation(station);}else void host.open(view.station?.id);};
 }
 function interactStation(station:NonNullable<ReturnType<typeof findCenterTarget>>){const i=CENTER_STATIONS.findIndex(s=>s.id===station.id),unlocked=i===0||progress.completed.includes(CENTER_STATIONS[i-1].id);progress=advanceCenterProgress(progress,station.id,'discover');saveCenterProgress(progress);const dialogue=document.getElementById('dialogue')!;dialogue.querySelector('p')!.textContent=`${station.title}｜${station.intro} 線索：${station.hints[0]}${unlocked?'':' 請先完成上一站，再啟動本站挑戰。'}`;accept.textContent=progress.completed.includes(station.id)?'複習本站三心觀念':unlocked?'查看圖形與開始本站挑戰':'查看本站線索';accept.hidden=false;accept.onclick=()=>{dialogue.hidden=true;accept.hidden=true;void host.open(station.id);};dialogue.hidden=false;host.pause();accept.focus();}
 const update=()=>{progress=loadCenterProgress();button.textContent=`三心闖關 ${progress.completed.length}／3`;host.redraw();};window.addEventListener('campus:three-centers-progress',update);
 function next(){return CENTER_STATIONS.find(s=>!progress.completed.includes(s.id));}
 const mark=(ctx:CanvasRenderingContext2D,point:{x:number;y:number},color:string,text:string,symbol:string,unit:number)=>{
  const q=projectIso(point);ctx.save();ctx.translate(q.x,q.y);ctx.fillStyle='#fffdf5f5';ctx.strokeStyle=color;ctx.lineWidth=3*unit;ctx.beginPath();ctx.ellipse(0,0,19*unit,11*unit,0,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle=color;ctx.font=`bold ${14*unit}px system-ui`;ctx.textAlign='center';ctx.fillText(symbol,0,-14*unit);
  ctx.font=`600 ${11*unit}px system-ui`;const width=ctx.measureText(text).width+16*unit;ctx.fillStyle='#fffdf5ee';if(text){ctx.fillRect(-width/2,-40*unit,width,18*unit);ctx.fillStyle=color;ctx.fillText(text,0,-27*unit);}ctx.restore();
 };
 return {next,prompt:()=>{const s=next();return s?`三心探索：${s.location}・按「三心闖關」查看線索與導航`:'三心探索已完成！可以重訪各站，或體驗原版能源任務。';},
  target:()=>{const s=host.read();return findCenterTarget(s.model,s.map,s.player);},
  syncMarkers(){syncTracker();const {model,map}=host.read();map.questMarkers=centerPoints(model,map).map(s=>({...s.point,label:s.title,color:s.color,symbol:({incenter:'內',centroid:'重',circumcenter:'外'} as const)[s.id],completed:progress.completed.includes(s.id)}));if(map.id==='campus'&&next()){const p=map.portals.find(p=>p.id==='technology-building-door');if(p)map.questMarkers.push({x:p.trigger.x+22,y:p.trigger.y+22,label:'三心探索起點',color:'#b85a22',symbol:'心',completed:false});}},
  draw(ctx:CanvasRenderingContext2D,unit:number){const {map,player}=host.read();for(const m of map.questMarkers??[]){const near=Math.hypot(m.x-player.x,m.y-player.y)<350;mark(ctx,m,m.color,near?m.label+(m.completed?'・已完成':map.id==='campus'?'・E 進入':'・E 調查'):'',m.completed?'✓':m.symbol,unit);}},
  interact:interactStation,
  closeDialogue:()=>{accept.hidden=true;}
 };
}
