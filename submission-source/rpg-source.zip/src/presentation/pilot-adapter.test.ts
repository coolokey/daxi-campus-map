import { describe, expect, it } from 'vitest';
import sharedData from '../../public/data/campus.shared.json';
import runtimeData from '../../public/data/technology-demo-runtime.json';
import { createPilot, createTransform, blocksFloor, safePilotPosition, type SharedCampus, type RuntimeCampus } from './pilot-adapter';
import { movePlayer } from './movement';
const shared = sharedData as SharedCampus;
const runtime = runtimeData as RuntimeCampus;
describe('canonical campus adapter',()=>{
  it('unembeds a fixed-size foot collider after shrinking a room doorway',()=>{
    const p=createPilot(shared,runtime,1),map=p.maps['pilot-tech-1'];
    const stuck={x:522.45,y:393.6};const safe=safePilotPosition(stuck,map);
    expect(Math.hypot(safe.x-stuck.x,safe.y-stuck.y)).toBeLessThan(30);
    expect(map.collisionZones.some(r=>safe.x+11>r.x&&safe.x-11<r.x+r.width&&safe.y+11>r.y&&safe.y-11<r.y+r.height)).toBe(false);
    expect(safePilotPosition(map.spawns.entry,map)).toEqual(map.spawns.entry);
  });
  it('round trips canonical x/z at every world scale without scaling the character',()=>{
    for(const scale of [1,1.5,2]) { const t=createTransform({x:-110,z:-90},scale);const p={x:85.5,z:14.5,height:3.6};expect(t.fromGame(t.toGame(p),3.6)).toEqual(p); }
  });
  it('filters door lintels and other floors while retaining ground furniture',()=>{
    const v={buildingId:'tech-building',minX:0,maxX:1,minZ:0,maxZ:1,minHeight:2.3,maxHeight:3.6};
    expect(blocksFloor(v,0)).toBe(false);expect(blocksFloor({...v,minHeight:0.72,maxHeight:0.8},0)).toBe(true);
    expect(blocksFloor({...v,minHeight:0,maxHeight:3.6},3.6)).toBe(false);
    expect(blocksFloor({...v,minHeight:3.6,maxHeight:7.2},3.6)).toBe(true);
  });
  it('uses the actual runtime entrance, stair landings and source room for symmetric portals',()=>{
    const p=createPilot(shared,runtime,1);
    expect(p.entrance.id).toBe('tech-building:entrance-0');expect(p.room.id).toBe('tech-building:TC-SE-2');
    expect(p.landings.lower.position.height).toBe(0);expect(p.landings.upper.position.height).toBe(3.6);
    expect(p.maps['pilot-outdoor'].portals[0].destinationMapId).toBe('pilot-tech-1');
    for(const m of Object.values(p.maps)) for(const portal of m.portals){const dest=p.maps[portal.destinationMapId as keyof typeof p.maps];expect(dest.spawns[portal.destinationSpawnId]).toBeDefined();}
    expect(p.maps['pilot-tech-2'].npcs[0].x).toBe(p.transforms['pilot-tech-2'].toGame(p.room.center).x);
  });
  it('keeps the full checked manual route passable at 1, 1.5 and 2 scales',()=>{
    for(const scale of [1,1.5,2]) {
      const p=createPilot(shared,runtime,scale);
      for(const id of Object.keys(p.maps) as (keyof typeof p.maps)[]) {
        const route=p.routes[id],map=p.maps[id];expect(route.length).toBeGreaterThan(2);
        for(let i=1;i<route.length;i++) {
          let position={...route[i-1]};const dest=route[i];
          for(let step=0;step<100 && Math.hypot(dest.x-position.x,dest.y-position.y)>0.01;step++) {
            const dx=dest.x-position.x,dy=dest.y-position.y;
            position=movePlayer(position,dx,dy,0.05,map,Math.min(220,Math.hypot(dx,dy)/0.05));
          }
          expect(Math.hypot(dest.x-position.x,dest.y-position.y),`${id} segment ${i} scale ${scale}`).toBeLessThan(0.01);
        }
      }
    }
  });
});
