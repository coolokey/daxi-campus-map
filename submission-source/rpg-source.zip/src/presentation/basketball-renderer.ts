import {basketballConfig as B,basketballCourts,basketballHoops} from './basketball-courts';
import {modelTransform,projectIso} from './model-world';
import type {BoundaryObject} from './boundary-renderer';
type C={x:number;z:number};type P={x:number;y:number};
/** Ground is painted now; raised hoops join the shared actor depth queue. */
export function basketballScene(ctx:CanvasRenderingContext2D,unit:number,u:number,player:P):BoundaryObject[]{
 const t=modelTransform({x:-162,z:-90},unit),objects:BoundaryObject[]=[],v=unit*.85;
 const p=(c:C,h=0)=>{const q=projectIso(t.toGame(c));return {x:q.x,y:q.y-h*v};};
 const poly=(ps:P[],fill:string,stroke?:string)=>{ctx.beginPath();ps.forEach((q,i)=>i?ctx.lineTo(q.x,q.y):ctx.moveTo(q.x,q.y));ctx.closePath();ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1.6*u;ctx.stroke();}};
 const rect=(x:number,z:number,w:number,d:number,fill:string,stroke?:string)=>poly([{x:x-w/2,z:z-d/2},{x:x+w/2,z:z-d/2},{x:x+w/2,z:z+d/2},{x:x-w/2,z:z+d/2}].map(q=>p(q)),fill,stroke);
 const line=(a:P,b:P,color='#fff6e1',width=1.6)=>{ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.strokeStyle=color;ctx.lineWidth=width*u;ctx.stroke();};
 const circle=(x:number,z:number,r:number,fill:string,stroke?:string)=>poly(Array.from({length:48},(_,i)=>p({x:x+Math.cos(i*Math.PI/24)*r,z:z+Math.sin(i*Math.PI/24)*r})),fill,stroke);
 rect(B.center.x,B.center.z,B.bufferWidth,B.bufferDepth,'#80ba55','#b1d384');
 for(const c of basketballCourts){rect(c.x,c.z,B.width,B.depth,'#389cc7','#fff5df');for(const side of [-1,1]){const x=c.x+side*B.keyCenterX;rect(x,c.z,B.keyWidth,B.keyDepth,'#dc7360','#fff5df');circle(x-side*B.keyWidth/2,c.z,B.circleRadius,'#dc7360','#fff5df');}circle(c.x,c.z,B.circleRadius,'#dc7360','#fff5df');line(p({x:c.x,z:c.z-B.depth/2}),p({x:c.x,z:c.z+B.depth/2}));}
 const camera=ctx.getTransform();
 for(const hoop of basketballHoops){const q=p(hoop),top=p(hoop,B.postHeight),bx=hoop.x-hoop.side,board=[p({x:bx,z:hoop.z-.9},B.boardHeight-.6),p({x:bx,z:hoop.z+.9},B.boardHeight-.6),p({x:bx,z:hoop.z+.9},B.boardHeight+.6),p({x:bx,z:hoop.z-.9},B.boardHeight+.6)];
 const ps=[q,top,...board],screen=ps.map(q=>({x:camera.a*q.x+camera.c*q.y+camera.e,y:camera.b*q.x+camera.d*q.y+camera.f}));if(Math.max(...screen.map(q=>q.x))<-40||Math.min(...screen.map(q=>q.x))>ctx.canvas.width+40||Math.max(...screen.map(q=>q.y))<-40||Math.min(...screen.map(q=>q.y))>ctx.canvas.height+40)continue;
 const foot=t.toGame(hoop);objects.push({depth:foot.x+foot.y,draw:()=>{ctx.save();const playerFoot=projectIso(player);if(player.x+player.y<foot.x+foot.y&&Math.abs(playerFoot.x-q.x)<unit*2&&playerFoot.y>top.y&&playerFoot.y-45*u<q.y)ctx.globalAlpha=.35;
 line(q,top,'#94b6c9',5);line(q,p(hoop,1.9),'#266fba',9);line(p(hoop,3.8),p({x:bx,z:hoop.z},3.8),'#b4cfda',4);poly(board,'#fffdfa','#5e8598');line(p({x:bx,z:hoop.z-.4},3.55),p({x:bx,z:hoop.z+.4},3.55),'#b94f46',2);
 const rim={x:hoop.x-hoop.side*1.3,z:hoop.z};poly(Array.from({length:25},(_,i)=>p({x:rim.x+Math.cos(i*Math.PI/12)*.3,z:rim.z+Math.sin(i*Math.PI/12)*.3},B.rimHeight)),'#ffffff33','#eb7250');for(const dz of [-.25,0,.25])line(p({x:rim.x,z:rim.z+dz},B.rimHeight),p({x:rim.x,z:rim.z+dz*.55},B.rimHeight-.55),'#fff9e8',1);ctx.restore();}});
 }
 const label=p({x:B.center.x,z:B.center.z+B.bufferDepth/2+1});ctx.save();ctx.font=`bold ${12*u}px system-ui`;ctx.textAlign='center';const text='籃球場群・三面全場',width=ctx.measureText(text).width+14*u;ctx.fillStyle='#f8f3e1ef';ctx.fillRect(label.x-width/2,label.y-14*u,width,21*u);ctx.fillStyle='#36583b';ctx.fillText(text,label.x,label.y);ctx.restore();
 return objects;
}
