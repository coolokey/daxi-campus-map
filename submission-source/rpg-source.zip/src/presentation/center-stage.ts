import {CENTER_STATIONS,type CenterId,type CenterProgress} from '../data/three-centers';
export function centerStageView(progress:CenterProgress,near?:CenterId){
 const found=CENTER_STATIONS.findIndex(s=>!progress.completed.includes(s.id));
 const index=found<0?3:found;
 const station=CENTER_STATIONS[index];
 const states=CENTER_STATIONS.map((s,i)=>progress.completed.includes(s.id)?'done':i===index?'current':'locked');
 const action=!station?'review':near!==station.id?'navigate':!progress.discovered.includes(station.id)?'discover':'challenge';
 return {index,station,states,action} as const;
}
