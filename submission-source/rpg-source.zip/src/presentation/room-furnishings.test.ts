import { describe, it, expect } from 'vitest';
import {
  getRoomCategory,
  getCategoryPalette,
  getRoomKind,
  getAuthenticStairName,
  drawRoomFurnishings,
  drawRoomBadgePlaque,
  drawArchitecturalStairs,
} from './room-furnishings';

describe('room-furnishings', () => {
  it('classifies room categories correctly matching CampusRoomLayout', () => {
    expect(getRoomCategory('701 教室 (1F)')).toBe('grade7');
    expect(getRoomCategory('805 教室 (2F)')).toBe('grade8');
    expect(getRoomCategory('902 教室 (3F)')).toBe('grade9');
    expect(getRoomCategory('教務處 (2F)')).toBe('admin');
    expect(getRoomCategory('校長室 (2F)')).toBe('admin');
    expect(getRoomCategory('八、九年級導師室 (1F)')).toBe('admin');
    expect(getRoomCategory('健康中心 (1F)')).toBe('admin');
    expect(getRoomCategory('第一電腦教室 (2F)')).toBe('special');
    expect(getRoomCategory('大溪木藝教室 (1F)')).toBe('special');
    expect(getRoomCategory('第一音樂教室 (2F)')).toBe('special');
    expect(getRoomCategory('中央圖書室 Library (1F)')).toBe('special');
    expect(getRoomCategory('活動中心大禮堂 (1F)')).toBe('sports');
    expect(getRoomCategory('活動中心入口大廳／桌球區 (1F)')).toBe('sports');
    expect(getRoomCategory('體適能教室 (1F)')).toBe('sports');
  });

  it('provides official category palettes', () => {
    expect(getCategoryPalette('grade7').badge).toBe('#63b54f');
    expect(getCategoryPalette('grade8').badge).toBe('#409ed1');
    expect(getCategoryPalette('grade9').badge).toBe('#e86482');
    expect(getCategoryPalette('admin').badge).toBe('#8470dc');
    expect(getCategoryPalette('special').badge).toBe('#b95bc2');
  });

  it('determines room kinds accurately', () => {
    expect(getRoomKind('801 教室 (2F)')).toBe('classroom');
    expect(getRoomKind('第一電腦教室 (2F)')).toBe('computer');
    expect(getRoomKind('理化第一實驗室 (2F)')).toBe('lab');
    expect(getRoomKind('生物實驗室 (1F)')).toBe('lab');
    expect(getRoomKind('大溪木藝教室 (1F)')).toBe('workshop');
    expect(getRoomKind('生活科技教室一 (1F)')).toBe('workshop');
    expect(getRoomKind('第一音樂教室 (2F)')).toBe('music');
    expect(getRoomKind('教務處 (2F)')).toBe('office');
    expect(getRoomKind('會客室 (1F)')).toBe('meeting');
    expect(getRoomKind('健康中心 (1F)')).toBe('health');
    expect(getRoomKind('中央圖書室 Library (1F)')).toBe('library');
    expect(getRoomKind('活動中心大禮堂 (1F)')).toBe('sports');
    expect(getRoomKind('校史室 (1F)')).toBe('exhibit');
    expect(getRoomKind('全校資訊機房 (2F)')).toBe('utility');
    expect(getRoomKind('空間 315（名稱待確認） (1F)')).toBe('unconfirmed');
  });

  it('maps stair names to authentic architectural designations from campus-explorer', () => {
    expect(getAuthenticStairName('grade8-front-west', '西側半圓梯')).toBe('八年級西側半圓樓梯塔');
    expect(getAuthenticStairName('grade8-front-east', '東側共用樓梯')).toBe('八年級東側樓梯');
    expect(getAuthenticStairName('gym-bld-south', '活動中心南側梯')).toBe('活動中心南側雙圓柱梯');
    expect(getAuthenticStairName('gym-bld-north', '活動中心北側梯')).toBe('活動中心北側雙圓柱梯');
    expect(getAuthenticStairName('admin-back-central', '中段折返梯')).toBe('行政大樓中段折返梯');
    expect(getAuthenticStairName('art-building-main', '藝術館樓梯')).toBe('藝術館主樓梯間');
  });

  it('renders furnishings and plaques without throwing errors on canvas mock', () => {
    const mockCtx = {
      save: () => {},
      restore: () => {},
      fillRect: () => {},
      strokeRect: () => {},
      rect: () => {},
      beginPath: () => {},
      arc: () => {},
      arcTo: () => {},
      moveTo: () => {},
      lineTo: () => {},
      closePath: () => {},
      fill: () => {},
      stroke: () => {},
      fillText: () => {},
      fillStyle: '',
      strokeStyle: '',
      lineWidth: 1,
      font: '',
      textAlign: 'left',
    } as unknown as CanvasRenderingContext2D;

    const rect = { x: 50, y: 50, width: 120, height: 100 };
    const door = { x: 110, y: 150 };

    expect(() => drawRoomFurnishings(mockCtx, rect, door, '801 教室 (2F)', 1)).not.toThrow();
    expect(() => drawRoomFurnishings(mockCtx, rect, door, '第一電腦教室 (2F)', 1)).not.toThrow();
    expect(() => drawRoomFurnishings(mockCtx, rect, door, '理化第一實驗室 (2F)', 1)).not.toThrow();
    expect(() => drawRoomFurnishings(mockCtx, rect, door, '第一音樂教室 (2F)', 1)).not.toThrow();
    expect(() => drawRoomFurnishings(mockCtx, rect, door, '健康中心 (1F)', 1)).not.toThrow();
    expect(() => drawRoomBadgePlaque(mockCtx, rect, '801 教室 (2F)', 1, '422')).not.toThrow();
    expect(() => drawArchitecturalStairs(mockCtx, rect, 'grade8-front-west', '西側半圓梯', 'grade8-front', 1)).not.toThrow();
  });
});
