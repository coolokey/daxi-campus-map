import {woodlandTheme} from './campus-materials';
import type {CampusModel,modelTransform} from './model-world';
import type {MapConfig,Rect} from '../game/data/types';
export type WoodFurniture={id:string;rect:Rect;axis:string};
export function placeWoodFurniture(map:MapConfig,t:ReturnType<typeof modelTransform>,model:CampusModel){
 const result:WoodFurniture[]=[];
 for(const item of woodlandTheme.furniture){
  const anchor=model.forecourt[item.anchor as 'planting'|'southTreeRow'],x=anchor.x0+item.dx,z=anchor.z0+item.dz,r=t.rect({x0:x-item.width/2,x1:x+item.width/2,z0:z-item.depth/2,z1:z+item.depth/2});
  const padding=12,blocked=map.collisionZones.some(b=>r.x-padding<b.x+b.width&&r.x+r.width+padding>b.x&&r.y-padding<b.y+b.height&&r.y+r.height+padding>b.y);
  const byDoor=model.buildings.some(b=>b.entrances.some(e=>e.floor===1&&Math.hypot(e.outside.x-x,e.outside.z-z)<4));
  if(blocked||byDoor)continue;result.push({id:item.id,rect:r,axis:item.axis});map.collisionZones.push(r);
 }
 return result;
}
