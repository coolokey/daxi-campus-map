import type { MapConfig } from '../game/data/types';
export type Point={x:number;y:number};
type World=Pick<MapConfig,'width'|'height'|'collisionZones'>;
export function walkable(p:Point,map:World){return p.x>=11&&p.y>=11&&p.x<=map.width-11&&p.y<=map.height-11&&!map.collisionZones.some(r=>p.x+11>r.x&&p.x-11<r.x+r.width&&p.y+11>r.y&&p.y-11<r.y+r.height);}
export function clearSegment(a:Point,b:Point,map:World){const count=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/5));for(let i=0;i<=count;i++)if(!walkable({x:a.x+(b.x-a.x)*i/count,y:a.y+(b.y-a.y)*i/count},map))return false;return true;}
const cache=new WeakMap<World,{step:number;cols:number;rows:number;valid:Uint8Array}>();
/** Four-neighbour BFS uses the same fixed foot box as movement; no diagonal corner cutting. */
export function findPath(start:Point,end:Point,map:World):Point[]|null{
  if(!walkable(start,map)||!walkable(end,map))return null;
  const connect=(a:Point,b:Point):Point[]|null=>{if((a.x===b.x||a.y===b.y)&&clearSegment(a,b,map))return [a,b];for(const corner of [{x:a.x,y:b.y},{x:b.x,y:a.y}])if(clearSegment(a,corner,map)&&clearSegment(corner,b,map))return [a,corner,b];return null;};
  const direct=connect(start,end);if(direct)return direct;
  let grid=cache.get(map);
  if(!grid){const step=12,cols=Math.floor(map.width/step)+1,rows=Math.floor(map.height/step)+1,valid=new Uint8Array(cols*rows);for(let y=0;y<rows;y++)for(let x=0;x<cols;x++)valid[y*cols+x]=Number(walkable({x:x*step,y:y*step},map));grid={step,cols,rows,valid};cache.set(map,grid);}
  const {step,cols,rows,valid}=grid,point=(i:number)=>({x:i%cols*step,y:Math.floor(i/cols)*step});
  function nearby(p:Point){const list:number[]=[];for(let y=Math.max(0,Math.round(p.y/step)-2);y<=Math.min(rows-1,Math.round(p.y/step)+2);y++)for(let x=Math.max(0,Math.round(p.x/step)-2);x<=Math.min(cols-1,Math.round(p.x/step)+2);x++){const i=y*cols+x;if(valid[i]&&connect(p,point(i)))list.push(i);}return list;}
  const starts=nearby(start),goals=new Set(nearby(end));if(!starts.length||!goals.size)return null;
  const parent=new Int32Array(valid.length).fill(-2),queue=new Int32Array(valid.length);let head=0,tail=0;
  for(const i of starts){parent[i]=-1;queue[tail++]=i;}
  let found=-1;
  while(head<tail){const i=queue[head++];if(goals.has(i)){found=i;break;}const x=i%cols,y=Math.floor(i/cols);for(const n of [x>0?i-1:-1,x<cols-1?i+1:-1,y>0?i-cols:-1,y<rows-1?i+cols:-1])if(n>=0&&valid[n]&&parent[n]===-2&&clearSegment(point(i),point(n),map)){parent[n]=i;queue[tail++]=n;}}
  if(found<0)return null;
  const indices:number[]=[];for(let i=found;i>=0;i=parent[i])indices.push(i);indices.reverse();
  const path:Point[]=[...connect(start,point(indices[0]))!,...indices.slice(1).map(point),...connect(point(found),end)!.slice(1)];
  const compact=[path[0]];for(let i=1;i<path.length-1;i++){const a=compact[compact.length-1],b=path[i],c=path[i+1];if((b.x-a.x)*(c.y-b.y)!==(b.y-a.y)*(c.x-b.x))compact.push(b);}compact.push(end);return compact;
}
