import type { MapConfig } from '../game/data/types';
export type Point={x:number;y:number};
type World=Pick<MapConfig,'width'|'height'|'collisionZones'> & {backgroundKey?:string};
const collisionIndex=new WeakMap<World,Map<string,World['collisionZones']>>();
export function walkable(p:Point,map:World,radius=11){
 if(p.x<radius||p.y<radius||p.x>map.width-radius||p.y>map.height-radius)return false;
 let zones=map.collisionZones;
 if(map.backgroundKey==='latest-model-v2'){
  let index=collisionIndex.get(map);if(!index){index=new Map();for(const r of zones)for(let x=Math.floor(r.x/64);x<=Math.floor((r.x+r.width)/64);x++)for(let y=Math.floor(r.y/64);y<=Math.floor((r.y+r.height)/64);y++){const key=x+','+y,list=index.get(key)??[];list.push(r);index.set(key,list);}collisionIndex.set(map,index);}
  zones=[];for(let x=Math.floor((p.x-radius)/64);x<=Math.floor((p.x+radius)/64);x++)for(let y=Math.floor((p.y-radius)/64);y<=Math.floor((p.y+radius)/64);y++)zones.push(...(index.get(x+','+y)??[]));
 }
 return !zones.some(r=>p.x+radius>r.x&&p.x-radius<r.x+r.width&&p.y+radius>r.y&&p.y-radius<r.y+r.height);
}
export function clearSegment(a:Point,b:Point,map:World,radius=11){const count=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/5));for(let i=0;i<=count;i++)if(!walkable({x:a.x+(b.x-a.x)*i/count,y:a.y+(b.y-a.y)*i/count},map,radius))return false;return true;}
type Grid={step:number;cols:number;rows:number;valid:Uint8Array;components?:Int32Array};
const cache=new WeakMap<World,Grid>();
function gridFor(map:World){let grid=cache.get(map);if(!grid){const step=map.backgroundKey==='latest-model-v2'?8:12,cols=Math.floor(map.width/step)+1,rows=Math.floor(map.height/step)+1,valid=new Uint8Array(cols*rows),radius=map.backgroundKey==='latest-model-v2'?11:16;for(let y=0;y<rows;y++)for(let x=0;x<cols;x++)valid[y*cols+x]=Number(walkable({x:x*step,y:y*step},map,radius));grid={step,cols,rows,valid};cache.set(map,grid);}return grid;}
/** Reachability labels are reused by the cross-scene planner instead of computing a full path for every edge. */
export function canReach(a:Point,b:Point,map:World){
 if(!walkable(a,map)||!walkable(b,map))return false;
 if(clearSegment(a,b,map))return true;
 const grid=gridFor(map),{cols,rows,valid,step}=grid;
 if(!grid.components){const labels=new Int32Array(valid.length),queue=new Int32Array(valid.length);let label=0;for(let i=0;i<valid.length;i++){if(!valid[i]||labels[i])continue;let head=0,tail=0;labels[i]=++label;queue[tail++]=i;while(head<tail){const k=queue[head++],x=k%cols,y=Math.floor(k/cols);for(const n of [x>0?k-1:-1,x<cols-1?k+1:-1,y>0?k-cols:-1,y<rows-1?k+cols:-1])if(n>=0&&valid[n]&&!labels[n]){labels[n]=label;queue[tail++]=n;}}}grid.components=labels;}
 const nearby=(p:Point)=>{const ids=new Set<number>();for(let y=Math.max(0,Math.round(p.y/step)-2);y<=Math.min(rows-1,Math.round(p.y/step)+2);y++)for(let x=Math.max(0,Math.round(p.x/step)-2);x<=Math.min(cols-1,Math.round(p.x/step)+2);x++){const i=y*cols+x;if(valid[i]&&clearSegment(p,{x:x*step,y:y*step},map))ids.add(grid.components![i]);}return ids;};
 const starts=nearby(a),ends=nearby(b);return [...starts].some(id=>ends.has(id));
}
/** Four-neighbour BFS uses the same fixed foot box as movement; no diagonal corner cutting. */
export function findPath(start:Point,end:Point,map:World):Point[]|null{
  if(!walkable(start,map)||!walkable(end,map))return null;
  const clearance=map.backgroundKey==='latest-model-v2'?11:16;
  const connect=(a:Point,b:Point,radius=clearance):Point[]|null=>{if((a.x===b.x||a.y===b.y)&&clearSegment(a,b,map,radius))return [a,b];for(const corner of [{x:a.x,y:b.y},{x:b.x,y:a.y}])if(clearSegment(a,corner,map,radius)&&clearSegment(corner,b,map,radius))return [a,corner,b];return null;};
  const direct=connect(start,end);if(direct)return direct;
  const grid=gridFor(map);
  const {step,cols,rows,valid}=grid,point=(i:number)=>({x:i%cols*step,y:Math.floor(i/cols)*step});
  function nearby(p:Point){const list:number[]=[];for(let y=Math.max(0,Math.round(p.y/step)-2);y<=Math.min(rows-1,Math.round(p.y/step)+2);y++)for(let x=Math.max(0,Math.round(p.x/step)-2);x<=Math.min(cols-1,Math.round(p.x/step)+2);x++){const i=y*cols+x;if(valid[i]&&connect(p,point(i),11))list.push(i);}return list;}
  const starts=nearby(start),goals=new Set(nearby(end));if(!starts.length||!goals.size)return null;
  const parent=new Int32Array(valid.length).fill(-2),queue=new Int32Array(valid.length);let head=0,tail=0;
  for(const i of starts){parent[i]=-1;queue[tail++]=i;}
  let found=-1;
  while(head<tail){const i=queue[head++];if(goals.has(i)){found=i;break;}const x=i%cols,y=Math.floor(i/cols);for(const n of [x>0?i-1:-1,x<cols-1?i+1:-1,y>0?i-cols:-1,y<rows-1?i+cols:-1])if(n>=0&&valid[n]&&parent[n]===-2&&clearSegment(point(i),point(n),map)){parent[n]=i;queue[tail++]=n;}}
  if(found<0)return null;
  const indices:number[]=[];for(let i=found;i>=0;i=parent[i])indices.push(i);indices.reverse();
  const path:Point[]=[...connect(start,point(indices[0]),11)!,...indices.slice(1).map(point),...connect(point(found),end,11)!.slice(1)];
  const compact=[path[0]];for(let i=1;i<path.length-1;i++){const a=compact[compact.length-1],b=path[i],c=path[i+1];if((b.x-a.x)*(c.y-b.y)!==(b.y-a.y)*(c.x-b.x))compact.push(b);}compact.push(end);return compact;
}
