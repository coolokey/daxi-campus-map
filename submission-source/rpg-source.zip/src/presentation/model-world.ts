import {pavilion,pavilionSolids} from './lan-pavilion';
import {athleticsLayout,athleticsSolids} from './athletics-garden';
import {farmLayout,farmSolids,attachFarmApproach} from './campus-farm';
import {parkingSolids,parkingAreas,parkingTargets} from './parking-layout';
import {campusRoadPlan,attachCampusEntrancePaths} from './campus-roads';
import {pondWaterFootprints} from './pond-collision';
import meadowTheme from '../../public/data/meadow-theme-v1.json';
import {basketballCourts,basketballHoops,basketballTarget} from './basketball-courts';
import {entranceLandmarks,landmarkSolids} from './entrance-landmarks';
import raw from '../../public/data/campus-model-v2.json';
import type { MapConfig,Rect,SpawnPoint } from '../game/data/types';
import type { WorldId } from '../game/config';
import { walkable,findPath } from './navigation';
import { boundaryColliders } from './campus-boundary';
import {placeWoodFurniture,type WoodFurniture} from './woodland-furniture';
import {outdoorBuildingPoint,outdoorBuildingRect} from './cartoon-layout';
type P={x:number;y:number};type C={x:number;z:number;y?:number};
type B={x0:number;x1:number;z0:number;z1:number};
export type ModelRoom={id:string;sourceId:string;spaceCode:string;name:string;floor:number;rect:B;center:C;door:C;corridor:C};
export type ModelBuilding={id:string;name:string;floors:number;bounds:B;footprints:{floor:number;rect:B}[];corridors:{floor:number;rect:B}[];rooms:ModelRoom[];stairs:{id:string;name:string;rect:B}[];ramps:{floor:number;stairId:string;h0:number;h1:number;start:C;end:C}[];entrances:{floor:number;inside:C;outside:C;kind?:string}[]};
export type CampusModel={version:number;source:{commit:string;files:{file:string;sha256:string}[]};forecourt:{planting:B;southTreeRow:B;driveway:B;parking:B};buildings:ModelBuilding[];junctions:{floor:number;a:string;b:string;start:C;end:C}[];outdoor:{entrance:{spawn:C;gate:C;target:C;pedestrian:{inside:C}};track:{x:number;z:number;halfStraight:number;outerRadius:number;innerRadius:number};courts:B[];outerCourts:B[];stage:B&{height:number;stairs:B};pond:{x:number;z:number;radius:number};perimeter:{height:number;thickness:number;outline:number[][];segments:{ax:number;az:number;bx:number;bz:number;thickness?:number}[]}}};
export const campusModel=raw as unknown as CampusModel;
export const projectIso=(p:P):P=>({x:(p.x-p.y)*Math.sqrt(3)/2,y:(p.x+p.y)/2});
export const unprojectIso=(p:P):P=>({x:p.y+p.x/Math.sqrt(3),y:p.y-p.x/Math.sqrt(3)});
export const screenMotion=(x:number,y:number):P=>unprojectIso({x,y});
export const modelScene=(b:string,l:number):WorldId=>`floor-model-${b}-${l}`;
export function modelTransform(origin:{x:number;z:number},unit:number){return{origin,unit,toGame:(p:C):P=>({x:(p.x-origin.x)*unit,y:(p.z-origin.z)*unit}),fromGame:(p:P,height=0)=>({x:p.x/unit+origin.x,z:p.y/unit+origin.z,height}),rect:(b:B):Rect=>({x:(b.x0-origin.x)*unit,y:(b.z0-origin.z)*unit,width:(b.x1-b.x0)*unit,height:(b.z1-b.z0)*unit})};}
export type ModelInfo={furniture:WoodFurniture[];unit:number;outdoor:boolean;building?:ModelBuilding;level:number;surfaces:Rect[];structures:{rect:Rect;height:number;name:string;id:string}[];rooms:{id:string;name:string;point:P;door:P;rect:Rect}[];roamingRoutes:P[][]};
const metadata=new WeakMap<MapConfig,ModelInfo>();
export const modelMapInfo=(map:MapConfig)=>metadata.get(map);
export function safeModelPoint(p:P,map:MapConfig):P{
  if(walkable(p,map))return {...p};
  for(let r=2;r<=192;r+=2)for(let i=0;i<32;i++){const q={x:p.x+Math.cos(i*Math.PI/16)*r,y:p.y+Math.sin(i*Math.PI/16)*r};if(walkable(q,map))return q;}
  throw Error(`No safe model position in ${map.id}`);
}
function roomWalls(room:ModelRoom,t:ReturnType<typeof modelTransform>,doors:C[]):Rect[]{
  const r=t.rect(room.rect),result:Rect[]=[],thickness=5,gap=Math.max(54,t.unit*1.8),points=doors.map(d=>t.toGame(d));
  const edge=(from:number,to:number,line:number,horizontal:boolean)=>{
    let spans=[[from,to]];
    for(const d of points){const along=horizontal?d.x:d.y,across=horizontal?d.y:d.x;if(Math.abs(across-line)>1||along<from-1||along>to+1)continue;
      spans=spans.flatMap(([a,b])=>{const lo=along-gap/2,hi=along+gap/2;if(hi<=a||lo>=b)return [[a,b]];const next:number[][]=[];if(lo>a)next.push([a,lo]);if(hi<b)next.push([hi,b]);return next;});
    }
    for(const[a,b]of spans)if(b>a)result.push(horizontal?{x:a,y:line-thickness/2,width:b-a,height:thickness}:{x:line-thickness/2,y:a,width:thickness,height:b-a});
  };
  edge(r.x,r.x+r.width,r.y,true);edge(r.x,r.x+r.width,r.y+r.height,true);edge(r.y,r.y+r.height,r.x,false);edge(r.y,r.y+r.height,r.x+r.width,false);return result;
}
/** The compiler's footprints, doors and stair landings share one reversible transform. */
export function createModelWorld(scale:number){
  const maps:Record<string,MapConfig>={},transforms:Record<string,ReturnType<typeof modelTransform>>={},targets:Record<string,ModelInfo['rooms']>={},floors:Record<string,{id:string;buildingId:string;level:number}>={};
  const t=modelTransform({x:-162,z:-90},16*scale),campus:MapConfig={id:'campus',displayName:'大溪校園・晴日草甸',width:286*t.unit,height:272*t.unit,backgroundKey:'latest-model-v2',collisionZones:[],spawns:{},npcs:[],portals:[]};maps.campus=campus;transforms.campus=t;
  const info:ModelInfo={furniture:[],unit:t.unit,outdoor:true,level:0,surfaces:[],structures:[],rooms:[],roamingRoutes:[]};metadata.set(campus,info);
  for(const b of campusModel.buildings){
    for(const f of b.footprints.filter(f=>f.floor===1)){const rect=t.rect(outdoorBuildingRect(b,f.rect));campus.collisionZones.push(rect);info.structures.push({rect,height:b.floors*3.6*24*scale,name:b.name,id:b.id});}
    for(let level=1;level<=b.floors;level++){
      const id=modelScene(b.id,level),tr=modelTransform({x:b.bounds.x0-4,z:b.bounds.z0-4},32*scale),surfaces=b.footprints.filter(f=>f.floor===level).map(f=>tr.rect(f.rect)),roomData=b.rooms.filter(r=>r.floor===level);
      if(!surfaces.length)throw Error(`Missing source floor ${id}`);
      const map:MapConfig={id,displayName:`${b.name.split(' / ')[0]} ${level}F`,width:(b.bounds.x1-b.bounds.x0+8)*tr.unit,height:(b.bounds.z1-b.bounds.z0+8)*tr.unit,backgroundKey:'latest-model-v2',collisionZones:roomData.flatMap(r=>roomWalls(r,tr,roomData.map(r=>r.door))),spawns:{},portals:[],npcs:[]};
      const xs=[...new Set([0,map.width,...surfaces.flatMap(r=>[r.x,r.x+r.width])])].sort((a,b)=>a-b),ys=[...new Set([0,map.height,...surfaces.flatMap(r=>[r.y,r.y+r.height])])].sort((a,b)=>a-b);
      for(let x=0;x<xs.length-1;x++)for(let y=0;y<ys.length-1;y++){const r={x:xs[x],y:ys[y],width:xs[x+1]-xs[x],height:ys[y+1]-ys[y]},cx=r.x+r.width/2,cy=r.y+r.height/2;if(!surfaces.some(s=>cx>=s.x&&cx<=s.x+s.width&&cy>=s.y&&cy<=s.y+s.height))map.collisionZones.push(r);}
      const rooms=roomData.map(r=>({id:r.id,name:r.name,point:tr.toGame(r.center),door:tr.toGame(r.door),rect:tr.rect(r.rect)}));
      metadata.set(map,{furniture:[],unit:tr.unit,outdoor:false,building:b,level,surfaces,structures:[],rooms,roamingRoutes:[]});targets[id]=rooms;maps[id]=map;transforms[id]=tr;floors[id]={id:`${b.id}:floor-${level}`,buildingId:b.id,level};
      map.floorPlan={footprints:surfaces,rooms:rooms.map(r=>({rect:r.rect,name:r.name}))};
      const c=b.corridors.find(c=>c.floor===level)?.rect??b.bounds,entry=b.entrances.find(e=>e.floor===level)?.inside??{x:(c.x0+c.x1)/2,z:(c.z0+c.z1)/2};
      map.spawns.entry={...safeModelPoint(tr.toGame(entry),map),direction:'down'};
    }
  }
  campus.collisionZones.push(...boundaryColliders(campusModel,t.rect));
  for(const p of modelTrees()){const q=t.toGame({x:p.x,z:p.z});campus.collisionZones.push({x:q.x-t.unit*.3,y:q.y-t.unit*.3,width:t.unit*.6,height:t.unit*.6});}
  campus.collisionZones.push(...landmarkSolids().map(s=>t.rect(s.rect)));
  campus.collisionZones.push(...parkingSolids.map(t.rect),...farmSolids.map(t.rect),...athleticsSolids.map(t.rect),...pavilionSolids.map(t.rect));
  campus.farmArea=t.rect(farmLayout.bounds);campus.farmBeds=farmLayout.beds.map(b=>t.rect(b.rect));
  campus.parkingAreas=parkingAreas.map(t.rect);
  const avenue=entranceLandmarks.plan;campus.outdoorPaving=[t.rect({x0:avenue.x-avenue.width/2,x1:avenue.x+avenue.width/2,z0:avenue.z0,z1:avenue.z1}),t.rect(campusModel.forecourt.driveway),...campusRoadPlan.roads.map(r=>t.rect(r.rect)),t.rect(farmLayout.path)];
  campus.collisionZones.push(...basketballHoops.map(h=>t.rect(h.rect)));
  campus.sportsCourts=basketballCourts.map(c=>t.rect(c));
  campus.landmarks=[...entranceLandmarks.targets,basketballTarget,...parkingTargets,farmLayout.target,athleticsLayout.target,pavilion.target].map(p=>({...t.toGame(p),label:p.name}));
  info.furniture=placeWoodFurniture(campus,t,campusModel);
  const pond=campusModel.outdoor.pond;if(pond)for(let i=0;i<24;i++){const a=i*Math.PI/12,p=t.toGame({x:pond.x+Math.cos(a)*pond.radius,z:pond.z+Math.sin(a)*pond.radius});campus.collisionZones.push({x:p.x-t.unit*.55,y:p.y-t.unit*.55,width:t.unit*1.1,height:t.unit*1.1});}
  if(pond)campus.collisionZones.push(...pondWaterFootprints(pond).map(t.rect));
  campus.spawns['campus-start']={...safeModelPoint(t.toGame(campusModel.outdoor.entrance.spawn),campus),direction:'up'};
  const addPortal=(from:WorldId,id:string,p:P,to:WorldId,arrival:P,prompt:string)=>{const key=`arrival:${from}:${id}`;maps[to].spawns[key]={...safeModelPoint(arrival,maps[to]),direction:'down'};const safe=safeModelPoint(p,maps[from]);maps[from].portals.push({id,mapId:from,trigger:{x:safe.x-22,y:safe.y-22,width:44,height:44},destinationMapId:to,destinationSpawnId:key,prompt});};
  for(const b of campusModel.buildings){
    const dest=modelScene(b.id,1),entry=maps[dest].spawns.entry;
    const candidates=b.entrances.filter(e=>e.floor===1);if(!candidates.length)throw Error(`No source entrance ${b.id}`);
    candidates.forEach((entrance,index)=>{
      const dx=entrance.outside.x-entrance.inside.x,dz=entrance.outside.z-entrance.inside.z,len=Math.hypot(dx,dz)||1;
      const point=outdoorBuildingPoint(b,entrance.outside);
      const outside=safeModelPoint(t.toGame({x:point.x+dx/len*2,z:point.z+dz/len*2}),campus),inside=safeModelPoint(transforms[dest].toGame(entrance.inside),maps[dest]);
      const id=index===0?(b.id==='tech-building'?'technology-building-door':`building-entry:${b.id}`):`building-entry:${b.id}:${index}`;
      addPortal('campus',id,outside,dest,inside,`E：進入${b.name.split(' / ')[0]}${index?'・獨立入口':''} 1F`);
      addPortal(dest,`building-exit:${index}`,inside,'campus',outside,'E：離開建築，返回校園');
    });    for(const stair of b.stairs)for(let f=1;f<b.floors;f++){
      const rs=b.ramps.filter(r=>r.floor===f&&r.stairId===stair.id),lower=rs.find(r=>Math.abs(r.h0-(f-1)*3.6)<.01)?.start,upper=rs.find(r=>Math.abs(r.h1-f*3.6)<.01)?.end;
      if(!lower||!upper)throw Error(`Missing source stair landing ${stair.id} ${f}`);
      const from=modelScene(b.id,f),to=modelScene(b.id,f+1),a=safeModelPoint(transforms[from].toGame(lower),maps[from]),z=safeModelPoint(transforms[to].toGame(upper),maps[to]);
      addPortal(from,`${stair.id}:${f}:up`,a,to,z,`E：${stair.name} → ${f+1}F`);addPortal(to,`${stair.id}:${f+1}:down`,z,from,a,`E：${stair.name} → ${f}F`);
    }
  }
  for(const j of campusModel.junctions??[]){const a=modelScene(j.a,j.floor),b=modelScene(j.b,j.floor);if(!maps[a]||!maps[b])continue;const p=transforms[a].toGame(j.start),q=transforms[b].toGame(j.end);addPortal(a,`junction:${j.a}:${j.b}`,p,b,q,'E：通過同層連通廊');addPortal(b,`junction:${j.b}:${j.a}`,q,a,p,'E：通過同層連通廊');}
  attachCampusEntrancePaths(campus,t);
  attachFarmApproach(campus,t);
  for(const map of Object.values(maps)){
    const data=metadata.get(map)!;if(data.outdoor)continue;
    const target=data.rooms.find(r=>data.building!.id==='tech-building'&&data.level===2?/理化實驗/.test(r.name):!r.name.includes('待確認'))??data.rooms[0];
    if(target){const teacher=data.building!.id==='tech-building'&&data.level===2;map.npcs.push({id:teacher?'pilot-math-teacher':`floor-mentor:${map.id}`,mapId:map.id,...safeModelPoint(target.point,map),direction:'down',name:teacher?'陳小鈴老師':'校園任務導師',spriteKey:teacher?'staff-014':'robot',portraitKey:teacher?'staff-014':'robot',kind:teacher?'teacher':'robot',interactionRadius:68,dialogueId:'energy-core',dialogue:'歡迎來到未來學園！這是遊戲任務位置，邀請你完成原版 5 題數學挑戰。'});}
  }
  return {maps,transforms,targets,floors,source:campusModel,scale};
}
export type ModelWorld=ReturnType<typeof createModelWorld>;
export function modelRoamingRoutes(map:MapConfig){const info=metadata.get(map);if(!info?.outdoor)return [];if(info.roamingRoutes.length)return info.roamingRoutes;
  const start=map.spawns['campus-start'];for(const portal of map.portals){const route=findPath(start,{x:portal.trigger.x+22,y:portal.trigger.y+22},map);if(route&&route.length>2){const part=route;if(part.length>1)info.roamingRoutes.push([...part,...part.slice(1,-1).reverse()]);}if(info.roamingRoutes.length===3)break;}return info.roamingRoutes;
}


export function modelTrees(){const b=campusModel.forecourt.planting,cx=(b.x0+b.x1)/2,cz=(b.z0+b.z1)/2,trees:{x:number;z:number}[]=[];for(const z of [cz-4.5,cz,cz+4.5])for(const x of [cx-2,cx+2])trees.push({x,z});for(let x=0;x<=36;x+=6)trees.push({x,z:70});
 for(const p of meadowTheme.sourceTrees){const blocked=campusModel.buildings.some(b=>b.footprints.filter(f=>f.floor===1).some(f=>{const r=outdoorBuildingRect(b,f.rect);return p.x>r.x0-1&&p.x<r.x1+1&&p.z>r.z0-1&&p.z<r.z1+1;}));if(!blocked&&!trees.some(q=>Math.hypot(q.x-p.x,q.z-p.z)<2))trees.push(p);}
 return trees;}

export function modelGuardPoint(map:MapConfig){return safeModelPoint(modelTransform({x:-162,z:-90},modelMapInfo(map)!.unit).toGame(campusModel.outdoor.entrance.pedestrian.inside),map);}
