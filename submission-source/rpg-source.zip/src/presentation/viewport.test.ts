import { describe, expect, it } from 'vitest';
import { viewport, sizeViewport, cameraOrigin, screenUnit } from './viewport';

describe('CSS viewport and physical backing pixels', () => {
  it.each([[1440,900,1],[1440,900,2],[390,844,3],[844,390,2]])('keeps %s × %s CSS pixels sharp at DPR %s', (w,h,dpr) => {
    const size=sizeViewport(w,h,dpr);
    expect(size.pixelRatio).toBe(Math.min(dpr,2));
    expect(size.bufferWidth).toBe(Math.round(w*Math.min(dpr,2)));
    expect(size.bufferHeight).toBe(Math.round(h*Math.min(dpr,2)));
    expect(size.logicalWidth).toBe(w/.75);
    expect(size.logicalHeight).toBe(h/.75);
  });
  it('clamps camera bounds in logical world units, including a map smaller than the view', () => {
    Object.assign(viewport,sizeViewport(1440,900,2));
    expect(cameraOrigin({width:3600,height:2436},{x:3590,y:2430})).toEqual({x:1680,y:1236});
    expect(cameraOrigin({width:800,height:600},{x:400,y:300})).toEqual({x:0,y:0});
  });
  it.each([1,2])('keeps a 48 × 66 actor and its anchor fixed in CSS pixels at DPR %s', dpr => {
    Object.assign(viewport,sizeViewport(390,844,dpr));
    const transformScale=dpr*viewport.zoom,unit=screenUnit(transformScale);
    expect(48*unit*transformScale/dpr).toBeCloseTo(48);
    expect(66*unit*transformScale/dpr).toBeCloseTo(66);
    expect(77.0177039725223*.75*unit*transformScale/dpr).toBeCloseTo(57.76327797939172);
  });
});
