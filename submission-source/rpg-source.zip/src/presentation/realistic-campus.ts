import './realistic-campus.css';
import type { MapConfig } from '../game/data/types';

export type CampusThemeMode = 'future' | 'realistic';

let currentThemeMode: CampusThemeMode = 'future';

export function getCampusThemeMode(): CampusThemeMode {
  return currentThemeMode;
}

export function setCampusThemeMode(mode: CampusThemeMode): void {
  if (currentThemeMode === mode) return;
  currentThemeMode = mode;
  updateThemeHeaderDom(mode);
  window.dispatchEvent(new CustomEvent<CampusThemeMode>('campus:theme-mode', { detail: mode }));
}

export function toggleCampusThemeMode(): CampusThemeMode {
  const next: CampusThemeMode = currentThemeMode === 'future' ? 'realistic' : 'future';
  setCampusThemeMode(next);
  return next;
}

function updateThemeHeaderDom(mode: CampusThemeMode) {
  const header = document.querySelector('.app-header');
  if (!header) return;
  const eyebrow = header.querySelector('.eyebrow');
  const h1 = header.querySelector('h1');
  const desc = header.querySelector('p:not(.eyebrow)');
  if (mode === 'realistic') {
    if (eyebrow) eyebrow.textContent = 'TAOYUAN DAXI JUNIOR HIGH · 115 學年度真實校園導覽';
    if (h1) h1.textContent = '大溪國中現實版校園 RPG';
    if (desc) desc.textContent = '還原紅瓦斜頂校舍、PU 跑道、司令台與真實處室配置，自由穿梭校園各角落。';
  } else {
    if (eyebrow) eyebrow.textContent = 'DAXI FUTURE CAMPUS · 校園探索雛型';
    if (h1) h1.textContent = '未來科技校園 RPG';
    if (desc) desc.textContent = '走進熟悉的校園，展開能源核心修復任務。';
  }
}

export function mountCampusThemeSwitcher(onChange?: (mode: CampusThemeMode) => void) {
  const toolbar = document.querySelector('.explore-toolbar');
  const switcher = document.createElement('div');
  switcher.className = 'campus-mode-switcher';
  switcher.setAttribute('role', 'group');
  switcher.setAttribute('aria-label', '切換校園版本模式');

  const futureBtn = document.createElement('button');
  futureBtn.type = 'button';
  futureBtn.className = 'campus-mode-btn';
  futureBtn.dataset.mode = 'future';
  futureBtn.textContent = '木藝學園';
  futureBtn.title = '木博館木藝風與大溪老街入口元素；遊戲美術詮釋（快捷鍵 M）';

  const realisticBtn = document.createElement('button');
  realisticBtn.type = 'button';
  realisticBtn.className = 'campus-mode-btn';
  realisticBtn.dataset.mode = 'realistic';
  realisticBtn.textContent = '原版校舍';
  realisticBtn.title = '對照原本校舍配色；沿用相同校園配置（快捷鍵 M）';

  switcher.append(futureBtn, realisticBtn);
  if (toolbar) {
    toolbar.prepend(switcher);
  }

  // Also mount a prominent floating quick-switch pill on #world-frame
  const worldFrame = document.getElementById('world-frame');
  const floatingBtn = document.createElement('button');
  floatingBtn.type = 'button';
  floatingBtn.id = 'campus-floating-mode-toggle';
  floatingBtn.className = 'campus-floating-mode-toggle';
  if (worldFrame) {
    worldFrame.append(floatingBtn);
  }

  const syncButtons = (mode: CampusThemeMode) => {
    futureBtn.setAttribute('aria-pressed', String(mode === 'future'));
    realisticBtn.setAttribute('aria-pressed', String(mode === 'realistic'));
    if (mode === 'future') {
      floatingBtn.innerHTML = `<span class="mode-pill-tag">目前：未來科技版</span> 🏫 切換為「現實版校園 RPG」 (按 M)`;
    } else {
      floatingBtn.innerHTML = `<span class="mode-pill-tag">目前：現實校園版</span> 🚀 切換為「未來科技校園 RPG」 (按 M)`;
    }
  };

  syncButtons(currentThemeMode);

  const applyMode = (mode: CampusThemeMode) => {
    setCampusThemeMode(mode);
    syncButtons(mode);
    onChange?.(mode);
  };

  futureBtn.addEventListener('click', () => applyMode('future'));
  realisticBtn.addEventListener('click', () => applyMode('realistic'));
  floatingBtn.addEventListener('click', () => {
    applyMode(currentThemeMode === 'future' ? 'realistic' : 'future');
  });

  window.addEventListener('campus:theme-mode', (e) => {
    const mode = (e as CustomEvent<CampusThemeMode>).detail;
    syncButtons(mode);
  });

  return {
    setMode: applyMode,
    getMode: getCampusThemeMode,
  };
}

interface BuildingSpec {
  id: string;
  title: string;
  subtitle: string;
  x: number;
  y: number;
  w: number;
  h: number;
  roofStyle: 'red-tile' | 'gym-dome' | 'modern-brick' | 'pavilion';
  stories: string;
  photoKey?: string;
}

// Coordinates in 2400x1624 base world matching campus-obstacles.ts 100%
const REALISTIC_BUILDINGS: readonly BuildingSpec[] = [
  {
    id: 'gym-bld',
    title: '學生活動中心',
    subtitle: '體育館・1F 大禮堂 / 2F 看台',
    x: 395,
    y: 1032,
    w: 360,
    h: 252,
    roofStyle: 'gym-dome',
    stories: '1F–2F',
    photoKey: 'stage',
  },
  {
    id: 'recycle-bld',
    title: '資源回收室',
    subtitle: '環保分類站',
    x: 285,
    y: 1047,
    w: 57,
    h: 165,
    roofStyle: 'modern-brick',
    stories: '1F',
  },
  {
    id: 'admin-front',
    title: '行政大樓（前棟）',
    subtitle: '導師室・健康中心・校長室・輔導室',
    x: 1393,
    y: 1224,
    w: 261,
    h: 126,
    roofStyle: 'red-tile',
    stories: '1F–3F',
    photoKey: 'adminFront',
  },
  {
    id: 'admin-back',
    title: '行政大樓（後棟）',
    subtitle: '教務處・學務處・總務處・會議室',
    x: 1168,
    y: 835,
    w: 274,
    h: 185,
    roofStyle: 'red-tile',
    stories: '1F–3F',
    photoKey: 'adminGallery',
  },
  {
    id: 'grade8-front',
    title: '八年級教學棟（南棟）',
    subtitle: '801–806 教室・專科教室',
    x: 1168,
    y: 1025,
    w: 274,
    h: 188,
    roofStyle: 'red-tile',
    stories: '1F–3F',
  },
  {
    id: 'grade9-back',
    title: '九年級教學棟',
    subtitle: '901–909 教室・物理化學實驗室',
    x: 1671,
    y: 835,
    w: 233,
    h: 185,
    roofStyle: 'red-tile',
    stories: '1F–3F',
  },
  {
    id: 'grade8-mid',
    title: '八年級中棟／專科棟',
    subtitle: '807–810・生物地科實驗室',
    x: 1671,
    y: 1025,
    w: 233,
    h: 188,
    roofStyle: 'red-tile',
    stories: '1F–3F',
  },
  {
    id: 'health-bld',
    title: '健康中心／員生社棟',
    subtitle: '合作社・護理站・通廊',
    x: 1465,
    y: 684,
    w: 131,
    h: 82,
    roofStyle: 'red-tile',
    stories: '1F–2F',
  },
  {
    id: 'new-grade7',
    title: '七年級新大樓與特教園地',
    subtitle: '701–709・家長會・教師會・視聽中心',
    x: 1944,
    y: 129,
    w: 263,
    h: 276,
    roofStyle: 'modern-brick',
    stories: '1F–3F',
  },
  {
    id: 'new-grade7-east',
    title: '七年級東側翼樓',
    subtitle: '電梯與配電室・專科空間',
    x: 2208,
    y: 180,
    w: 107,
    h: 230,
    roofStyle: 'modern-brick',
    stories: '1F–3F',
  },
  {
    id: 'multi-building',
    title: '綜合大樓／圖書館',
    subtitle: '圖書館・童軍家政・視聽館',
    x: 1951,
    y: 425,
    w: 238,
    h: 225,
    roofStyle: 'red-tile',
    stories: '1F–2F',
  },
  {
    id: 'multi-east-wing',
    title: '綜合大樓東側長廊',
    subtitle: '多功能活動空間',
    x: 2208,
    y: 474,
    w: 101,
    h: 397,
    roofStyle: 'red-tile',
    stories: '1F–2F',
  },
  {
    id: 'tech-building',
    title: '科技館',
    subtitle: '生科教室・電腦教室一／二・數學研究室',
    x: 1950,
    y: 669,
    w: 257,
    h: 214,
    roofStyle: 'red-tile',
    stories: '1F–2F',
  },
  {
    id: 'art-building',
    title: '藝術館',
    subtitle: '音樂・視覺藝術・表演藝術教室',
    x: 1951,
    y: 914,
    w: 205,
    h: 432,
    roofStyle: 'red-tile',
    stories: '1F–4F',
  },
  {
    id: 'art-south-wing',
    title: '東南側門樓與藝文廊',
    subtitle: '校園東側端景建築',
    x: 1956,
    y: 1362,
    w: 195,
    h: 146,
    roofStyle: 'red-tile',
    stories: '1F–2F',
  },
];

const photoCache: Record<string, HTMLImageElement> = {};
function getPhotoAsset(key: string, relPath: string): HTMLImageElement | undefined {
  if (typeof Image === 'undefined') return undefined;
  if (!photoCache[key]) {
    try {
      const img = new Image();
      img.src = new URL(relPath, document.baseURI).href;
      photoCache[key] = img;
    } catch {
      return undefined;
    }
  }
  const img = photoCache[key];
  return img && img.complete && img.naturalWidth > 0 ? img : undefined;
}

let realisticMapImage: HTMLImageElement | undefined;
let isImageLoading = false;

export function getRealisticMapImage(): HTMLImageElement | undefined {
  if (typeof Image === 'undefined') return undefined;
  if (!realisticMapImage && !isImageLoading) {
    isImageLoading = true;
    try {
      const img = new Image();
      img.onload = () => {
        realisticMapImage = img;
        window.dispatchEvent(new CustomEvent('campus:theme-image-loaded'));
      };
      img.onerror = () => {
        // Fallback to png if webp fails
        if (img.src.endsWith('.webp')) {
          img.src = new URL('./assets/maps/daxi-realistic-campus-rpg-v1.png', document.baseURI).href;
        }
      };
      img.src = new URL('./assets/maps/daxi-realistic-campus-rpg-v1.webp', document.baseURI).href;
    } catch {
      return undefined;
    }
  }
  return realisticMapImage;
}

// Eagerly initiate image load in browser
if (typeof window !== 'undefined' && typeof Image !== 'undefined') {
  getRealisticMapImage();
}

/**
 * Renders the Realistic Daxi Junior High School Campus Map (現實版大溪國中實景校園地圖)
 * on the 2400x1624 scaled coordinate system.
 */
export function drawRealisticOutdoorCampus(
  ctx: CanvasRenderingContext2D,
  map: MapConfig,
  scale: number,
  unit: number
): void {
  const img = getRealisticMapImage();
  const s = (v: number) => v * scale;

  ctx.save();

  // If the authentic pixel-art isometric illustration is loaded, render it directly
  if (img && img.complete && img.naturalWidth > 0) {
    ctx.drawImage(img, 0, 0, map.width, map.height);

    // Celebratory landmark banner badge at top-center for atmosphere
    ctx.save();
    ctx.fillStyle = 'rgba(15, 23, 42, 0.82)';
    const bannerW = Math.min(map.width - s(40), s(460));
    const bannerH = s(34);
    const bannerX = (map.width - bannerW) / 2;
    const bannerY = s(16);
    ctx.fillRect(bannerX, bannerY, bannerW, bannerH);
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = Math.max(1, 1.5 * scale);
    ctx.strokeRect(bannerX, bannerY, bannerW, bannerH);
    ctx.fillStyle = '#fef08a';
    ctx.font = `bold ${14 * unit}px system-ui`;
    ctx.textAlign = 'center';
    ctx.fillText('🏫 大溪國中 80 週年校慶之夜・現實版校園 RPG（按 M 可自由切換）', map.width / 2, bannerY + s(23));
    ctx.restore();

    ctx.restore();
    return;
  }

  // Fallback: If image is still loading or running in test environments (e.g. Vitest jsdom)
  // 1. Base Campus Ground (Warm natural concrete & stone paving)
  ctx.fillStyle = '#e5e0d5';
  ctx.fillRect(0, 0, map.width, map.height);

  // Subtle architectural tile grid across the campus ground
  ctx.strokeStyle = 'rgba(120, 113, 108, 0.14)';
  ctx.lineWidth = Math.max(1, 1 * scale);
  const gridStep = s(48);
  if (gridStep > 8) {
    ctx.beginPath();
    for (let x = 0; x < map.width; x += gridStep) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, map.height);
    }
    for (let y = 0; y < map.height; y += gridStep) {
      ctx.moveTo(0, y);
      ctx.lineTo(map.width, y);
    }
    ctx.stroke();
  }

  // 2. Surrounding Daxi Mountain Slope & Perimeter Woods (大溪山城翠綠林木邊界)
  ctx.fillStyle = '#4a7846';
  // North mountain border
  ctx.fillRect(0, 0, map.width, s(65));
  // West hillside slope
  ctx.fillRect(0, 0, s(195), map.height);
  // East perimeter greenery
  ctx.fillRect(s(2270), 0, map.width - s(2270), map.height);
  // South exterior street & wall border
  ctx.fillStyle = '#475569';
  ctx.fillRect(0, s(1530), map.width, map.height - s(1530));
  // Dashed street center line outside main gate
  ctx.strokeStyle = '#fbbf24';
  ctx.lineWidth = s(3);
  ctx.setLineDash?.([s(24), s(18)]);
  ctx.beginPath();
  ctx.moveTo(s(100), s(1585));
  ctx.lineTo(s(2300), s(1585));
  ctx.stroke();
  ctx.setLineDash?.([]);

  // West Stepped Retaining Wall (後山階梯擋土牆 - hill-2019.jpg)
  for (let tier = 0; tier < 4; tier++) {
    const tx = s(95 + tier * 24);
    ctx.fillStyle = tier % 2 === 0 ? '#94a3b8' : '#788799';
    ctx.fillRect(tx, s(180), s(20), s(740));
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = s(1.5);
    ctx.strokeRect(tx, s(180), s(20), s(740));
  }
  ctx.fillStyle = '#f8fafc';
  ctx.font = `bold ${13 * unit}px system-ui`;
  ctx.fillText('⛰️ 西側後山階梯擋土牆', s(75), s(560));

  // 3. Campus Asphalt Roads & Red-Brick Pedestrian Boulevards (校園柏油車道與紅磚林蔭步道)
  const drawRoad = (x: number, y: number, w: number, h: number, color = '#94a3b8') => {
    ctx.fillStyle = color;
    ctx.fillRect(s(x), s(y), s(w), s(h));
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = s(2);
    ctx.strokeRect(s(x), s(y), s(w), s(h));
  };

  // Main Gate Welcome Boulevard (校門迎賓椰林大道)
  drawRoad(1150, 1340, 235, 210, '#64748b');
  // Crosswalk at main gate
  ctx.fillStyle = '#f8fafc';
  for (let cx = 1168; cx < 1370; cx += 24) {
    ctx.fillRect(s(cx), s(1465), s(14), s(38));
  }
  // South Main East-West Boulevard (前庭東西向幹道)
  drawRoad(755, 1345, 1200, 68, '#788696');
  // West Gym Boulevard (體育館前南北大道)
  drawRoad(760, 935, 395, 415, '#c9b99b');
  // Central North-South Walkway West (中央林蔭道西側)
  drawRoad(1065, 810, 98, 540, '#c87d65');
  // Track South Shaded Red-Brick Walkway (操場南側紅磚林蔭步道 - shade-2019.jpg)
  drawRoad(380, 830, 765, 135, '#c27860');
  // East Teaching Boulevard (東側科技與教學林蔭道)
  drawRoad(1902, 140, 46, 1220, '#c87d65');
  // North Courts South Walkway
  drawRoad(1180, 632, 725, 48, '#b8b0a2');

  // Central Courtyard & Confucius Statue Garden (中央中庭與至聖先師銅像花園)
  drawRoad(1442, 835, 229, 389, '#d6cfc2');
  // Green garden beds inside central courtyard
  ctx.fillStyle = '#4d8b46';
  ctx.fillRect(s(1456), s(855), s(40), s(180));
  ctx.fillRect(s(1616), s(855), s(40), s(180));
  // Central Fountain & Confucius Statue Base ([954,591,55,62] -> x:1501, y:931, w:87, h:98)
  ctx.fillStyle = '#0ea5e9';
  ctx.beginPath();
  ctx.arc(s(1544), s(980), s(44), 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = s(5);
  ctx.stroke();
  ctx.fillStyle = '#475569';
  ctx.fillRect(s(1526), s(962), s(36), s(36));
  ctx.fillStyle = '#fef08a';
  ctx.font = `bold ${11 * unit}px system-ui`;
  ctx.textAlign = 'center';
  ctx.fillText('至聖先師像', s(1544), s(984));
  ctx.textAlign = 'left';

  // West Plaza Fountain ([563,653,49,49] -> x:886, y:1028, w:77, h:77)
  ctx.fillStyle = '#38bdf8';
  ctx.beginPath();
  ctx.arc(s(924), s(1066), s(36), 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#f1f5f9';
  ctx.lineWidth = s(4);
  ctx.stroke();

  // Garden beds matching campus-obstacles.ts
  const drawGardenBed = (gx: number, gy: number, gw: number, gh: number, label?: string) => {
    ctx.fillStyle = '#3f7d3c';
    ctx.fillRect(s(gx), s(gy), s(gw), s(gh));
    ctx.strokeStyle = '#9a5b42';
    ctx.lineWidth = s(3);
    ctx.strokeRect(s(gx), s(gy), s(gw), s(gh));
    if (label) {
      ctx.fillStyle = '#dcfce7';
      ctx.font = `bold ${11 * unit}px system-ui`;
      ctx.textAlign = 'center';
      ctx.fillText(label, s(gx + gw / 2), s(gy + gh / 2 + 4));
      ctx.textAlign = 'left';
    }
  };
  // Entrance gardens south of track ([275,558,144,31], [523,558,145,31])
  drawGardenBed(433, 879, 226, 49, '🌳 操場南側紅磚花台');
  drawGardenBed(823, 879, 228, 49, '🌳 林蔭看台花圃');
  // Gym gardens & side wings
  drawGardenBed(419, 994, 329, 38, '🌺 活動中心前花圃');
  drawGardenBed(795, 1261, 47, 101);
  drawGardenBed(947, 1246, 101, 116);
  // Southwest planting bed ([704,779,144,59])
  drawGardenBed(1108, 1227, 226, 93, '🌿 迎賓庭園花圃');
  // Gardens south of north courts ([765,414,135,68], [1028,429,150,53])
  drawGardenBed(1204, 652, 212, 107, '🌲 北苑西花園');
  drawGardenBed(1618, 676, 236, 83, '🌲 北苑東花園');

  // 4. West Sports Field & 6-Lane Red PU Running Track (西側大操場與 PU 跑道)
  const trackX = 250, trackY = 165, trackW = 560, trackH = 610, trackR = 250;
  const drawStadiumPath = (inset: number) => {
    const x = s(trackX + inset), y = s(trackY + inset);
    const w = s(trackW - inset * 2), h = s(trackH - inset * 2);
    const r = Math.min(w / 2, h / 2, s(trackR - inset));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.arcTo(x + w, y, x + w, y + r, r);
    ctx.lineTo(x + w, y + h - r);
    ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
    ctx.lineTo(x + r, y + h);
    ctx.arcTo(x, y + h, x, y + h - r, r);
    ctx.lineTo(x, y + r);
    ctx.arcTo(x, y, x + r, y, r);
    ctx.closePath();
  };

  // Outer red PU running track surface
  drawStadiumPath(0);
  ctx.fillStyle = '#c24136';
  ctx.fill();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = s(2.5);
  ctx.stroke();

  // 6 White lane lines on the PU track
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.78)';
  ctx.lineWidth = s(1.2);
  for (let lane = 1; lane <= 6; lane++) {
    drawStadiumPath(lane * 13);
    ctx.stroke();
  }

  // Inner Green Grass Turf Field
  drawStadiumPath(82);
  ctx.fillStyle = '#3f8f42';
  ctx.fill();
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = s(2);
  ctx.stroke();

  // Soccer field markings inside turf
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.8)';
  ctx.lineWidth = s(1.8);
  ctx.strokeRect(s(365), s(285), s(330), s(370));
  ctx.beginPath();
  ctx.moveTo(s(365), s(470));
  ctx.lineTo(s(695), s(470));
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(s(530), s(470), s(45), 0, Math.PI * 2);
  ctx.stroke();

  // East Straightaway 6-Lane Starting Line & Numbers (lanes-2019.jpg)
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold ${10 * unit}px system-ui`;
  ctx.textAlign = 'center';
  for (let lane = 1; lane <= 6; lane++) {
    const lx = s(trackX + trackW - 82 + (lane - 0.5) * 13);
    ctx.fillRect(lx - s(5), s(650), s(10), s(2));
    ctx.fillText(String(lane), lx, s(668));
  }
  ctx.font = `bold ${15 * unit}px system-ui`;
  ctx.fillStyle = '#fef9c3';
  ctx.fillText('🏃 大溪國中 200M 六道 PU 田徑運動場（真實跑道配置）', s(530), s(465));
  ctx.textAlign = 'left';

  // Field Equipment & Net on North-East of Track ([574,200,22,28], [608,220,73,32])
  ctx.fillStyle = '#64748b';
  ctx.fillRect(s(903), s(315), s(35), s(44));
  ctx.fillStyle = '#334155';
  ctx.fillRect(s(956), s(346), s(115), s(50));
  ctx.strokeStyle = '#e2e8f0';
  ctx.strokeRect(s(956), s(346), s(115), s(50));

  // Grandstand / 司令台 & Rear Mural ([270,500,177,25], [500,500,139,25], flagpole [466,508,12,27])
  // West Grandstand Wing & Stage
  ctx.fillStyle = '#eab308'; // Authentic yellow steps from stage-2019.jpg
  ctx.fillRect(s(425), s(787), s(278), s(40));
  ctx.fillStyle = '#fef08a';
  ctx.fillRect(s(435), s(792), s(258), s(16));
  // Rear Mural Strip (stage-rear-mural.jpg)
  ctx.fillStyle = '#0284c7';
  ctx.fillRect(s(425), s(818), s(278), s(9));
  ctx.strokeStyle = '#ca8a04';
  ctx.lineWidth = s(2);
  ctx.strokeRect(s(425), s(787), s(278), s(40));
  ctx.fillStyle = '#0f172a';
  ctx.font = `bold ${13 * unit}px system-ui`;
  ctx.textAlign = 'center';
  ctx.fillText('🎤 操場司令台（黃階梯與背牆彩繪）', s(564), s(809));

  // Flagpole Base (三旗桿座)
  ctx.fillStyle = '#e2e8f0';
  ctx.fillRect(s(733), s(795), s(19), s(42));
  ctx.strokeStyle = '#475569';
  ctx.strokeRect(s(733), s(795), s(19), s(42));

  // East Spectator Stand
  ctx.fillStyle = '#d97706';
  ctx.fillRect(s(787), s(787), s(219), s(40));
  ctx.strokeStyle = '#92400e';
  ctx.strokeRect(s(787), s(787), s(219), s(40));
  ctx.fillStyle = '#ffffff';
  ctx.fillText('觀眾看台區', s(896), s(811));
  ctx.textAlign = 'left';

  // 5. North Octagonal Pavilion & Volleyball / Basketball Courts (北側八角涼亭、排球場與雙座籃球場)
  // North Octagonal Pavilion ([808,76,56,58] -> x:1272, y:120, w:88, h:91)
  ctx.fillStyle = '#b84a39';
  ctx.fillRect(s(1272), s(120), s(88), s(91));
  ctx.strokeStyle = '#fef3c7';
  ctx.lineWidth = s(2.5);
  ctx.strokeRect(s(1272), s(120), s(88), s(91));
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold ${12 * unit}px system-ui`;
  ctx.textAlign = 'center';
  ctx.fillText('八角涼亭', s(1316), s(170));
  // Circular flower beds flanking pavilion ([746,102,38,38], [880,102,38,38])
  for (const fx of [1204, 1414]) {
    ctx.fillStyle = '#15803d';
    ctx.beginPath();
    ctx.arc(s(fx), s(190), s(28), 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#d97706';
    ctx.lineWidth = s(3);
    ctx.stroke();
  }

  // Green Volleyball Court ([800,158,125,244] -> x:1259, y:249, w:197, h:384)
  ctx.fillStyle = '#2e7d32';
  ctx.fillRect(s(1259), s(249), s(197), s(384));
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = s(2);
  ctx.strokeRect(s(1280), s(275), s(155), s(330));
  ctx.beginPath();
  ctx.moveTo(s(1280), s(440));
  ctx.lineTo(s(1435), s(440));
  ctx.stroke();
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold ${13 * unit}px system-ui`;
  ctx.fillText('🏐 排球場', s(1357), s(432));

  // Dual Basketball Courts ([924,155,266,249] -> x:1454, y:244, w:419, h:392)
  ctx.fillStyle = '#1e6091';
  ctx.fillRect(s(1454), s(244), s(419), s(392));
  for (const bx of [1480, 1675]) {
    // Court boundary
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = s(2);
    ctx.strokeRect(s(bx), s(275), s(170), s(330));
    // Red painted keys (禁區)
    ctx.fillStyle = '#c24136';
    ctx.fillRect(s(bx + 55), s(275), s(60), s(65));
    ctx.fillRect(s(bx + 55), s(540), s(60), s(65));
    ctx.strokeRect(s(bx + 55), s(275), s(60), s(65));
    ctx.strokeRect(s(bx + 55), s(540), s(60), s(65));
    // Center line & circle
    ctx.beginPath();
    ctx.moveTo(s(bx), s(440));
    ctx.lineTo(s(bx + 170), s(440));
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(s(bx + 85), s(440), s(26), 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.fillStyle = '#fef08a';
  ctx.font = `bold ${14 * unit}px system-ui`;
  ctx.fillText('🏀 北側戶外籃球場（雙全場）', s(1663), s(445));
  ctx.textAlign = 'left';

  // 6. All Authentic Daxi Junior High School Buildings (大溪國中真實校舍建築群)
  const photoAssets: Record<string, HTMLImageElement | undefined> = {
    stage: getPhotoAsset('stage', './assets/photos/stage-2019.jpg'),
    adminFront: getPhotoAsset('adminFront', './assets/photos/admin-front.jpg'),
    adminGallery: getPhotoAsset('adminGallery', './assets/photos/admin-gallery.jpg'),
  };

  for (const b of REALISTIC_BUILDINGS) {
    const bx = s(b.x), by = s(b.y), bw = s(b.w), bh = s(b.h);

    // Building Ground Drop Shadow
    ctx.fillStyle = 'rgba(15, 23, 42, 0.22)';
    ctx.fillRect(bx + s(6), by + s(8), bw, bh);

    // Building Lower Wall / Cream Washed-Stone Facade
    ctx.fillStyle = '#f5efe6';
    ctx.fillRect(bx, by, bw, bh);

    // Blue-green Eaves Trim Band (藍綠色檐口包邊 from admin-roof.jpg)
    ctx.fillStyle = '#2b7a78';
    ctx.fillRect(bx, by + bh - s(16), bw, s(16));

    // Rhythmic Classroom Windows along south elevation
    ctx.fillStyle = '#bae6fd';
    const winW = s(14), winH = s(8), winY = by + bh - s(12);
    for (let wx = bx + s(12); wx < bx + bw - s(20); wx += s(24)) {
      ctx.fillRect(wx, winY, winW, winH);
    }

    // Sloped Roof Surface
    const roofMargin = s(5);
    const rx = bx + roofMargin, ry = by + roofMargin, rw = bw - roofMargin * 2, rh = bh - s(20);
    if (b.roofStyle === 'gym-dome') {
      // Steel-ribbed gymnasium roof with skylights
      ctx.fillStyle = '#64748b';
      ctx.fillRect(rx, ry, rw, rh);
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = s(2);
      for (let gx = rx + s(24); gx < rx + rw; gx += s(28)) {
        ctx.beginPath();
        ctx.moveTo(gx, ry);
        ctx.lineTo(gx, ry + rh);
        ctx.stroke();
      }
      // Red brick trim on gym roof edge
      ctx.strokeStyle = '#b84a39';
      ctx.lineWidth = s(4);
      ctx.strokeRect(rx, ry, rw, rh);
    } else if (b.roofStyle === 'modern-brick') {
      ctx.fillStyle = '#c2593f';
      ctx.fillRect(rx, ry, rw, rh);
    } else {
      // Classic Daxi Terracotta Red Sloped Tile Roof (紅瓦斜屋頂)
      ctx.fillStyle = '#b84a39';
      ctx.fillRect(rx, ry, rw, rh);
      // Horizontal tile course lines
      ctx.strokeStyle = 'rgba(127, 29, 29, 0.35)';
      ctx.lineWidth = s(1);
      for (let ty = ry + s(12); ty < ry + rh; ty += s(12)) {
        ctx.beginPath();
        ctx.moveTo(rx, ty);
        ctx.lineTo(rx + rw, ty);
        ctx.stroke();
      }
      // Central roof ridge line (屋脊線)
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = s(2.5);
      ctx.beginPath();
      if (rw >= rh) {
        ctx.moveTo(rx + s(14), ry + rh / 2);
        ctx.lineTo(rx + rw - s(14), ry + rh / 2);
      } else {
        ctx.moveTo(rx + rw / 2, ry + s(14));
        ctx.lineTo(rx + rw / 2, ry + rh - s(14));
      }
      ctx.stroke();
    }

    // Outer architectural border
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = s(2.5);
    ctx.strokeRect(bx, by, bw, bh);

    // Optional embedded real photo vignette on large key buildings
    const photoImg = b.photoKey ? photoAssets[b.photoKey] : undefined;
    if (photoImg && bw > s(220) && bh > s(110)) {
      const pw = Math.min(s(96), bw * 0.34);
      const ph = Math.min(s(58), bh * 0.45);
      const px = bx + bw - pw - s(10);
      const py = by + s(10);
      ctx.drawImage(photoImg, px, py, pw, ph);
      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = s(2);
      ctx.strokeRect(px, py, pw, ph);
    }

    // Building Nameplate Badge (真實校舍銘牌)
    if (bw >= s(90)) {
      const cx = bx + bw / 2;
      const cy = by + bh / 2 - s(6);
      const tagW = Math.min(bw - s(12), s(210));
      const tagH = s(44);
      ctx.fillStyle = 'rgba(15, 23, 42, 0.86)';
      ctx.fillRect(cx - tagW / 2, cy - tagH / 2, tagW, tagH);
      ctx.strokeStyle = '#fbbf24';
      ctx.lineWidth = s(1.5);
      ctx.strokeRect(cx - tagW / 2, cy - tagH / 2, tagW, tagH);

      ctx.textAlign = 'center';
      ctx.fillStyle = '#ffffff';
      ctx.font = `bold ${14 * unit}px system-ui`;
      ctx.fillText(`🏫 ${b.title} (${b.stories})`, cx, cy - s(3), tagW - s(8));
      ctx.fillStyle = '#fde68a';
      ctx.font = `${11 * unit}px system-ui`;
      ctx.fillText(b.subtitle, cx, cy + s(14), tagW - s(8));
      ctx.textAlign = 'left';
    }
  }

  // 7. Main School Gate, Guardhouse & Perimeter Wall (大溪國中正門、警衛室與南側圍牆)
  // South Perimeter Walls ([365,915,354,50], [917,915,326,50])
  ctx.fillStyle = '#b45309';
  ctx.fillRect(s(574), s(1441), s(557), s(79));
  ctx.fillRect(s(1443), s(1441), s(513), s(79));
  ctx.strokeStyle = '#78350f';
  ctx.lineWidth = s(3);
  ctx.strokeRect(s(574), s(1441), s(557), s(79));
  ctx.strokeRect(s(1443), s(1441), s(513), s(79));

  // West Gate Pillar ([719,895,20,78] -> x:1131, y:1410, w:32, h:123)
  ctx.fillStyle = '#d97706';
  ctx.fillRect(s(1131), s(1410), s(32), s(123));
  ctx.strokeStyle = '#fef3c7';
  ctx.strokeRect(s(1131), s(1410), s(32), s(123));

  // East Gate Pillar & Guardhouse ([881,895,36,78] -> x:1386, y:1410, w:57, h:123)
  ctx.fillStyle = '#d97706';
  ctx.fillRect(s(1386), s(1410), s(57), s(123));
  ctx.strokeStyle = '#fef3c7';
  ctx.strokeRect(s(1386), s(1410), s(57), s(123));
  ctx.fillStyle = '#ffffff';
  ctx.font = `bold ${12 * unit}px system-ui`;
  ctx.textAlign = 'center';
  ctx.fillText('警衛室', s(1414), s(1475));

  // Main School Gate Banner Title (佇立於校門大道上方橫幅標示，不阻擋通行)
  ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
  ctx.fillRect(s(1155), s(1415), s(225), s(32));
  ctx.strokeStyle = '#f59e0b';
  ctx.lineWidth = s(2);
  ctx.strokeRect(s(1155), s(1415), s(225), s(32));
  ctx.fillStyle = '#fef08a';
  ctx.font = `bold ${15 * unit}px system-ui`;
  ctx.fillText('桃園市立大溪國民中學・正門', s(1267), s(1436));
  ctx.textAlign = 'left';

  // 8. Coconut Palm Trees along Main Boulevard & Shade Trees (校園椰林與綠樹美化)
  const treePositions = [
    [1145, 1365], [1145, 1395], [1392, 1365], [1392, 1395],
    [450, 895], [530, 895], [610, 895], [850, 895], [950, 895],
    [1055, 920], [1055, 1020], [1055, 1120], [1055, 1220],
    [1895, 300], [1895, 500], [1895, 750], [1895, 1050],
  ];
  for (const [tx, ty] of treePositions) {
    ctx.fillStyle = '#166534';
    ctx.beginPath();
    ctx.arc(s(tx), s(ty), s(14), 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#22c55e';
    ctx.beginPath();
    ctx.arc(s(tx - 3), s(ty - 3), s(9), 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}
