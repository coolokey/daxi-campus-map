import { expect,it } from 'vitest';
import { nearestInRange } from './interaction-target';
it('selects the nearest eligible NPC even when it is later in the array',()=>{
  const far={x:25,y:0,interactionRadius:40},near={x:10,y:0,interactionRadius:20},outside={x:5,y:0,interactionRadius:4};
  expect(nearestInRange([far,outside,near],{x:0,y:0})).toBe(near);
  expect(nearestInRange([outside],{x:0,y:0})).toBeUndefined();
  expect(nearestInRange([],{x:0,y:0})).toBeUndefined();
});
it('includes the radius boundary and retains first actor on equal distance',()=>{
  const first={x:3,y:4,interactionRadius:5},second={...first};
  expect(nearestInRange([first,second],{x:0,y:0})).toBe(first);
});
