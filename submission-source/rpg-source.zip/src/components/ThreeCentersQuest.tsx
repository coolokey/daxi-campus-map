import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { CENTER_STATIONS, advanceCenterProgress, loadCenterProgress, saveCenterProgress, type CenterId, type CenterProgress } from '../data/three-centers';
import { ThreeCentersDiagram } from './ThreeCentersDiagram';
import './three-centers.css';
type Attempt = { index: number; correct: boolean; feedback: string; hintLevel: number; mistakes: number };
const freshAttempt = (): Attempt => ({ index: 0, correct: false, feedback: '', hintLevel: 0, mistakes: 0 });
type Props = { onClose: () => void; openRequest: { center?: CenterId; serial: number } };
export function ThreeCentersQuest({ onClose, openRequest }: Props) {
  const [progress, setProgress] = useState<CenterProgress>(loadCenterProgress);
  const [selected, setSelected] = useState<CenterId>();
  const [attempts, setAttempts] = useState<Record<CenterId, Attempt>>({ incenter: freshAttempt(), centroid: freshAttempt(), circumcenter: freshAttempt() });
  const heading = useRef<HTMLHeadingElement>(null);
  useEffect(() => { setProgress(loadCenterProgress()); setSelected(openRequest.center); heading.current?.focus(); }, [openRequest]);
  useEffect(() => { const refresh = (event: Event) => { const detail = (event as CustomEvent<CenterProgress>).detail; setProgress(detail ?? loadCenterProgress()); }; window.addEventListener('campus:three-centers-progress', refresh); return () => window.removeEventListener('campus:three-centers-progress', refresh); }, []);
  useEffect(() => { heading.current?.focus(); }, [selected]);
  const station = CENTER_STATIONS.find(s => s.id === selected);
  const attempt = selected ? attempts[selected] : undefined;
  const eligible = (id: CenterId) => { const index = CENTER_STATIONS.findIndex(s => s.id === id); return progress.discovered.includes(id) && (index === 0 || progress.completed.includes(CENTER_STATIONS[index - 1].id)); };
  const update = (change: Partial<Attempt>) => { if (selected) setAttempts(prev => ({ ...prev, [selected]: { ...prev[selected], ...change } })); };
  const navigate = (id: CenterId) => { window.dispatchEvent(new CustomEvent('campus:three-centers-navigate', { detail: { stationId: id } })); onClose(); };
  const finish = () => { if (!station || !attempt?.correct || attempt.index !== station.questions.length - 1 || !eligible(station.id)) return; const next = advanceCenterProgress(progress, station.id, 'complete'); setProgress(next); saveCenterProgress(next); setSelected(undefined); };
  const question = station && attempt ? station.questions[attempt.index] : undefined;
  const allDone = progress.completed.length === 3;
  return <section className="three-centers-quest" aria-label="三心探索任務">
    <header className="centers-heading"><div><p className="centers-eyebrow">國中數學・三角形的三心</p><h2 tabIndex={-1} ref={heading}>{station ? station.title : allDone ? '三心校準完成' : '三心探索任務'}</h2></div><button type="button" className="secondary-button" onClick={onClose}>返回校園探索</button></header>
    <p className="centers-progress" role="status">已完成 {progress.completed.length}／3 站・內心 → 重心 → 外心</p>
    {!station && <>
      <p>{allDone ? '獲得「三心觀測員徽章」！你已走訪科技館兩層，完成六項數學校準。' : '沿科技館現有走廊與樓梯探索，在房間內靠近任務標記互動。每站先觀察提示，再挑戰兩題。'}</p>
      <div className="centers-stations">{CENTER_STATIONS.map((s, index) => { const done = progress.completed.includes(s.id), found = progress.discovered.includes(s.id), unlocked = index === 0 || progress.completed.includes(CENTER_STATIONS[index - 1].id); return <article className="centers-station" key={s.id} style={{ '--center-color': s.color } as CSSProperties}><span className="centers-badge">{index + 1}</span><h3>{s.title}</h3><p>{s.location}</p><p className="centers-station-status">{done ? '已完成・可複習' : !unlocked ? '待解鎖・先完成上一站' : found ? '已發現・可挑戰' : '待探索・到房間內互動'}</p><div className="centers-actions"><button type="button" className="secondary-button" onClick={() => navigate(s.id)}>導航至本站</button><button type="button" className="primary-button" disabled={!eligible(s.id)} onClick={() => setSelected(s.id)}>{done ? '複習本站' : '進入本站'}</button></div></article>; })}</div>
      <button type="button" className="secondary-button" onClick={() => window.dispatchEvent(new Event('campus:open-energy-quest'))}>原版能源修復任務</button>
      {allDone && <aside className="centers-summary"><h3>帶走三個觀念</h3><p>內心：內角平分線交點，到三邊的垂直距離相等。</p><p>重心：三條中線交點，頂點到重心：重心到邊中點＝2：1。</p><p>外心：三邊垂直平分線交點，到三頂點等距；鈍角三角形的外心在外。</p><button type="button" className="secondary-button" onClick={() => { const next: CenterProgress = { discovered: [], completed: [] }; setProgress(next); setAttempts({ incenter: freshAttempt(), centroid: freshAttempt(), circumcenter: freshAttempt() }); saveCenterProgress(next); }}>重新探索三心</button></aside>}
    </>}
    {station && attempt && <div style={{ '--center-color': station.color } as CSSProperties}>
      <button type="button" className="secondary-button centers-back" onClick={() => setSelected(undefined)}>查看三站進度</button><p className="centers-location">{station.location}</p>
      <div className="centers-lesson"><div><p className="centers-dialogue">{progress.completed.includes(station.id) ? station.outro : station.intro}</p><div className="centers-hints"><button type="button" className="secondary-button" disabled={attempt.hintLevel >= 2} onClick={() => update({ hintLevel: Math.min(2, attempt.hintLevel + 1) })}>{attempt.hintLevel === 0 ? '提示一：找觀念' : attempt.hintLevel === 1 ? '提示二：看關鍵性質' : '兩層提示已展開'}</button>{station.hints.slice(0, attempt.hintLevel).map((hint, i) => <p key={hint}><strong>提示 {i + 1}：</strong>{hint}</p>)}</div></div><ThreeCentersDiagram center={station.id} /></div>
      {!eligible(station.id) ? <aside className="centers-feedback"><p>{!progress.discovered.includes(station.id) ? '請先在目的地房間內靠近任務標記並互動，發現本站。' : '本站已發現，請先完成上一站，再開始挑戰。'}</p><button type="button" className="primary-button" onClick={() => navigate(station.id)}>導航至本站</button></aside>
        : progress.completed.includes(station.id) ? <aside className="centers-feedback"><h3>本站已完成</h3>{station.questions.map(q => <div key={q.id}><p><strong>{q.prompt}</strong></p><p>{q.explanation}</p></div>)}</aside>
        : question && <section className="centers-challenge" aria-label={`${station.short}兩題挑戰`}><p className="centers-eyebrow">本站第 {attempt.index + 1}／2 題</p><h3>{question.prompt}</h3><div className="centers-choices">{question.choices.map((choice, index) => <button type="button" key={choice} disabled={attempt.correct} className={attempt.correct && index === question.answer ? 'centers-choice correct' : 'centers-choice'} onClick={() => { const correct = index === question.answer; update({ correct, feedback: correct ? question.explanation : `再試一次：${question.hint}`, mistakes: attempt.mistakes + Number(!correct) }); }}>{String.fromCharCode(65 + index)}．{choice}</button>)}</div>{attempt.feedback && <div className="centers-feedback" role="status"><strong>{attempt.correct ? '答對了・詳解' : '觀念提醒'}</strong><p>{attempt.feedback}</p></div>}{attempt.correct && <button type="button" className="primary-button centers-next" onClick={attempt.index === station.questions.length - 1 ? finish : () => update({ index: attempt.index + 1, correct: false, feedback: '' })}>{attempt.index === station.questions.length - 1 ? '完成本站並儲存進度' : '閱讀完畢，下一題'}</button>}</section>}
    </div>}
    <p className="centers-local-note">進度只存於此瀏覽器，不含姓名，未上傳。提示與判題皆為本機規則。瀏覽器限制儲存時，請在本次開啟中完成體驗。</p>
  </section>;
}
