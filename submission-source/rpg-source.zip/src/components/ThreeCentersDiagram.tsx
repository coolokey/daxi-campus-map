import type { CenterId } from '../data/three-centers';
type Point = { x: number; y: number };
const distance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y);
const midpoint = (a: Point, b: Point): Point => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });
const foot = (p: Point, a: Point, b: Point): Point => { const dx = b.x - a.x, dy = b.y - a.y, t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy); return { x: a.x + t * dx, y: a.y + t * dy }; };
const line = (a: Point, b: Point, dashed = false) => <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="currentColor" strokeWidth="2" strokeDasharray={dashed ? '5 4' : undefined} />;
const point = (p: Point, label: string, dx = 8, dy = -8) => <g><circle cx={p.x} cy={p.y} r="3.5" fill="currentColor" /><text x={p.x + dx} y={p.y + dy}>{label}</text></g>;
function rightMark(p: Point, edge: Point, center: Point) { const l = distance(p, edge), n = distance(p, center), size = 9, u = { x: (edge.x - p.x) / l * size, y: (edge.y - p.y) / l * size }, v = { x: (center.x - p.x) / n * size, y: (center.y - p.y) / n * size }; return <polyline points={`${p.x + u.x},${p.y + u.y} ${p.x + u.x + v.x},${p.y + u.y + v.y} ${p.x + v.x},${p.y + v.y}`} fill="none" stroke="currentColor" strokeWidth="1.5" />; }
export function ThreeCentersDiagram({ center }: { center: CenterId }) {
  const a = { x: 80, y: 30 }, b = { x: 40, y: 180 }, c = { x: 260, y: 180 };
  const ab = distance(a, b), bc = distance(b, c), ca = distance(c, a), perimeter = ab + bc + ca;
  const i = { x: (bc * a.x + ca * b.x + ab * c.x) / perimeter, y: (bc * a.y + ca * b.y + ab * c.y) / perimeter };
  const d = foot(i, a, b), e = foot(i, b, c), f = foot(i, c, a);
  const g = { x: (a.x + b.x + c.x) / 3, y: (a.y + b.y + c.y) / 3 }, m = midpoint(b, c);
  const oa = { x: 140, y: 120 }, ob = { x: 80, y: 180 }, oc = { x: 240, y: 180 }, o = { x: 160, y: 200 };
  const label = center === 'incenter' ? '內心：內切圓與到三邊的垂線' : center === 'centroid' ? '重心：三條中線與頂點端 2：1' : '外心：鈍角三角形的外接圓與等長半徑';
  return <figure className="centers-diagram"><svg viewBox={center === 'circumcenter' ? '0 0 320 310' : '0 0 320 230'} role="img" aria-label={label}>
    <title>{label}</title>
    {center !== 'circumcenter' && <polygon points={`${a.x},${a.y} ${b.x},${b.y} ${c.x},${c.y}`} fill="#fff6db" stroke="currentColor" strokeWidth="2.5" />}
    {center === 'incenter' && <>
      <circle cx={i.x} cy={i.y} r={distance(i, e)} fill="#ffce7b" fillOpacity="0.35" stroke="currentColor" strokeWidth="2" />
      {line(a, i, true)}{line(b, i, true)}{line(c, i, true)}
      {line(i, d)}{line(i, e)}{line(i, f)}{rightMark(d, a, i)}{rightMark(e, b, i)}{rightMark(f, c, i)}
      {point(i, 'I', 5, -12)}{point(d, 'D', -20, 0)}{point(e, 'E', 2, 22)}{point(f, 'F', 10, 0)}
    </>}
    {center === 'centroid' && <>
      {line(a, m)}{line(b, midpoint(a, c), true)}{line(c, midpoint(a, b), true)}
      <path d="M 92 176 l 0 8 M 96 176 l 0 8 M 202 176 l 0 8 M 206 176 l 0 8" stroke="currentColor" fill="none" strokeWidth="2" />
      {point(g, 'G', 8, -8)}{point(m, 'D', 0, 23)}
      <text x="170" y="76">AG：GD＝2：1</text><text x="170" y="98">長段靠頂點 A</text>
    </>}
    {center !== 'circumcenter' && <>{point(a, 'A', -3, -13)}{point(b, 'B', -20, 18)}{point(c, 'C', 8, 18)}</>}
    {center === 'circumcenter' && <>
      <circle cx={o.x} cy={o.y} r={distance(o, oa)} fill="#e9e0fa" fillOpacity="0.35" stroke="currentColor" strokeWidth="2" />
      <polygon points="140,120 80,180 240,180" fill="#fff6db" stroke="currentColor" strokeWidth="2.5" />
      {line(o, oa)}{line(o, ob)}{line(o, oc)}
      {line({ x: 160, y: 90 }, { x: 160, y: 280 }, true)}
      {line({ x: 90, y: 130 }, { x: 205, y: 245 }, true)}
      {rightMark(midpoint(ob, oc), oc, o)}
      {point(oa, 'A', -8, -13)}{point(ob, 'B', -20, 0)}{point(oc, 'C', 8, 0)}{point(o, 'O', 8, 17)}
      <text x="65" y="302">OA＝OB＝OC；O 在三角形外</text>
    </>}
  </svg><figcaption>{label}。圖形為性質示意，非題目尺寸圖。</figcaption></figure>;
}
