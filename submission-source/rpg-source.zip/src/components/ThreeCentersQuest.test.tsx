import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, expect, it, vi } from 'vitest';
import { ThreeCentersQuest } from './ThreeCentersQuest';
import { advanceCenterProgress, CENTER_STATIONS, loadCenterProgress, saveCenterProgress } from '../data/three-centers';
afterEach(cleanup);
it('keeps explanation and question position across reopening, and saves only after explicit station completion', async () => {
  const user = userEvent.setup();
  let progress = advanceCenterProgress(loadCenterProgress({ getItem: () => null }), 'incenter', 'discover');
  saveCenterProgress(progress);
  const view = render(<ThreeCentersQuest onClose={vi.fn()} openRequest={{ center: 'incenter', serial: 1 }} />);
  await user.click(screen.getByRole('button', { name: '提示一：找觀念' }));
  await user.click(screen.getByRole('button', { name: '提示二：看關鍵性質' }));
  await user.click(screen.getByRole('button', { name: 'B．IE＝4，IF＝8' }));
  expect(screen.getByText(/再試一次：內心到三邊/)).toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: 'A．IE＝4，IF＝4' }));
  expect(screen.getByText('答對了・詳解')).toBeInTheDocument();
  expect(loadCenterProgress().completed).toEqual([]);
  view.rerender(<ThreeCentersQuest onClose={vi.fn()} openRequest={{ center: 'incenter', serial: 2 }} />);
  expect(screen.getByText('答對了・詳解')).toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: '閱讀完畢，下一題' }));
  await user.click(screen.getByRole('button', { name: 'B．36°' }));
  expect(loadCenterProgress().completed).toEqual([]);
  await user.click(screen.getByRole('button', { name: '完成本站並儲存進度' }));
  progress = loadCenterProgress();
  expect(progress.completed).toEqual(['incenter']);
  expect(screen.getByRole('button', { name: '原版能源修復任務' })).toBeInTheDocument();
});
it('rejects invalid persisted progress and sends completion only when all three stations newly finish', () => {
  expect(loadCenterProgress({ getItem: () => JSON.stringify({ discovered: ['unknown'], completed: [] }) })).toEqual({ discovered: [], completed: [] });
  expect(loadCenterProgress({ getItem: () => JSON.stringify({ discovered: ['circumcenter'], completed: ['circumcenter'] }) })).toEqual({ discovered: [], completed: [] });
  const map = new Map<string, string>();
  const storage = { getItem: (k: string) => map.get(k) ?? null, setItem: (k: string, v: string) => { map.set(k, v); } };
  const completed = vi.fn();
  window.addEventListener('campus:quest-complete', completed);
  let p = loadCenterProgress(storage);
  for (const station of CENTER_STATIONS) { p = advanceCenterProgress(p, station.id, 'discover'); p = advanceCenterProgress(p, station.id, 'complete'); saveCenterProgress(p, storage); }
  saveCenterProgress(p, storage);
  expect(completed).toHaveBeenCalledTimes(1);
  expect((completed.mock.calls[0][0] as CustomEvent).detail).toEqual({ questId: 'three-centers' });
  window.removeEventListener('campus:quest-complete', completed);
});
it('restarts only three-center progress and preserves the player choice', async () => {
  localStorage.setItem('campus:rpg-player', 'player-female-uniform');
  let p = loadCenterProgress({ getItem: () => null });
  for (const s of CENTER_STATIONS) { p = advanceCenterProgress(p, s.id, 'discover'); p = advanceCenterProgress(p, s.id, 'complete'); }
  saveCenterProgress(p);
  render(<ThreeCentersQuest onClose={vi.fn()} openRequest={{ serial: 1 }} />);
  expect(screen.getByRole('heading', { name: '三心校準完成' })).toBeInTheDocument();
  await userEvent.click(screen.getByRole('button', { name: '重新探索三心' }));
  expect(loadCenterProgress()).toEqual({ discovered: [], completed: [] });
  expect(localStorage.getItem('campus:rpg-player')).toBe('player-female-uniform');
  expect(screen.getByRole('heading', { name: '三心探索任務' })).toBeInTheDocument();
});
