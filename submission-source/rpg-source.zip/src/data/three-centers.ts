export type CenterId = 'incenter' | 'centroid' | 'circumcenter';
export type CenterQuestion = { id: string; prompt: string; choices: string[]; answer: number; hint: string; explanation: string };
export type CenterStation = { id: CenterId; title: string; short: string; buildingId: string; level: number; roomId: string; location: string; hints: [string, string]; intro: string; outro: string; color: string; questions: CenterQuestion[] };
export type CenterProgress = { discovered: CenterId[]; completed: CenterId[] };
export const CENTER_STORAGE_KEY = 'campus-rpg:three-centers:v1';
export const CENTER_STATIONS: CenterStation[] = [
  { id: 'incenter', title: '內心・等距觀測站', short: '內心', buildingId: 'tech-building', level: 1, roomId: 'tech-building:1:TC-N-1:life-tech-1', location: '科技館 1F・生科教室一', color: '#b85314',
    intro: '我是內心觀測員。要讓圓恰好碰到三角形的三邊，先觀察圓心到三邊的垂線，再完成兩項校準。',
    outro: '內心校準成功！角平分線交會，到三邊等距。下一站在科技館 2F 理化實驗室，請走現有樓梯上樓。',
    hints: ['找找三個角的角平分線，它們在三角形內相遇。觀察交點到三條邊的距離。', '內心是三條內角平分線的交點，到三邊的垂直距離相等。角平分線把同一個角分成相等的兩部分。'],
    questions: [
      { id: 'centers-in-01', prompt: '三角形 ABC 的內心為 I。從 I 向 AB、BC、CA 作垂線，垂足為 D、E、F。若 ID＝4 公分，則 IE、IF 各為多少公分？', choices: ['IE＝4，IF＝4', 'IE＝4，IF＝8', 'IE＝8，IF＝4', '資料不足，無法判斷'], answer: 0, hint: '內心到三邊的垂直距離相等；不要和到頂點的距離混淆。', explanation: '內心到三邊的垂直距離相等，因此 ID＝IE＝IF。已知 ID＝4 公分，所以 IE、IF 都是 4 公分。' },
      { id: 'centers-in-02', prompt: '在三角形 ABC 中，I 是內心，∠BAC＝72°。∠BAI 是多少度？', choices: ['18°', '36°', '72°', '144°'], answer: 1, hint: 'AI 是∠BAC 的角平分線，把 72° 分成相等的兩個角。', explanation: '因為 I 是內心，AI 平分∠BAC，所以∠BAI＝72°÷2＝36°。角平分線平分角度，不一定通過對邊中點。' },
    ] },
  { id: 'centroid', title: '重心・平衡校準站', short: '重心', buildingId: 'tech-building', level: 2, roomId: 'tech-building:2:TC-N-2:physics-lab', location: '科技館 2F・理化實驗室', color: '#176eaf',
    intro: '我是平衡校準員。這裡用均勻三角形薄板研究平衡。先確認頂點與對邊中點，再判斷 2：1 的方向。',
    outro: '重心校準成功！中線較長的那一段靠頂點。下一站是同層科技創作教室，沿走廊前往即可。',
    hints: ['找一條邊的中點，把它連到對面的頂點，得到的線段叫作中線。', '三條中線交於重心 G。中線 AD 上，A 是頂點、D 是對邊中點，AG：GD＝2：1；AG 占全長三分之二，GD 占三分之一。'],
    questions: [
      { id: 'centers-gr-01', prompt: '在三角形 ABC 中，D 是 BC 的中點，G 是重心。若中線 AD＝18 公分，則 AG 是多少公分？', choices: ['6', '9', '12', '18'], answer: 2, hint: '從頂點 A 到重心 G 是較長段，占整條中線的三分之二。', explanation: 'AG：GD＝2：1，中線 AD 共三份。AG＝18×2／3＝12 公分。6 公分是 GD，不是 AG。' },
      { id: 'centers-gr-02', prompt: '在三角形 ABC 中，D 是 BC 的中點，G 是重心。若 GD＝5 公分，則整條中線 AD 是多少公分？', choices: ['5', '10', '15', '20'], answer: 2, hint: 'GD 是一份，AG 是兩份；整條 AD 是三份。', explanation: 'GD 是一份，AG 是兩份，因此 AG＝10 公分。整條 AD＝AG＋GD＝10＋5＝15 公分。10 公分只代表 AG。' },
    ] },
  { id: 'circumcenter', title: '外心・訊號等距站', short: '外心', buildingId: 'tech-building', level: 2, roomId: 'tech-building:2:TC-NE-2:tech-smart', location: '科技館 2F・科技創作教室', color: '#7550a3',
    intro: '我是訊號定位員。要讓中心到三個頂點一樣遠，應找外心。外心的位置不一定在外面，要依三角形種類判斷。',
    outro: '三心校準完成！內心看三邊，外心看三頂點，重心看中線與 2：1。你已取得三心觀測員徽章。',
    hints: ['這次觀察的是到三個頂點的距離。試著找三邊的垂直平分線。', '三邊垂直平分線交於外心 O，OA＝OB＝OC。直角三角形的外心是斜邊中點；鈍角三角形的外心在三角形外部。'],
    questions: [
      { id: 'centers-out-01', prompt: '直角三角形 ABC 的∠A＝90°，AB＝6 公分，AC＝8 公分。其外心 O 到頂點 A 的距離是多少公分？', choices: ['3', '4', '5', '10'], answer: 2, hint: '先用畢氏定理求斜邊。直角三角形的外心在斜邊中點，半徑為斜邊的一半。', explanation: '斜邊 BC＝√（6²＋8²）＝10 公分。外心在斜邊中點，外接圓半徑是斜邊的一半，因此 OA＝5 公分。' },
      { id: 'centers-out-02', prompt: '三角形 ABC 是鈍角三角形，O 是其外心。下列何者正確？', choices: ['O 必在三角形內，且到三邊等距', 'O 在三角形外，且 OA＝OB＝OC', 'O 在最長邊的中點，且 OA＝OB＝OC', 'O 在三角形外，且到三邊的垂直距離相等'], answer: 1, hint: '鈍角三角形的外心在外部。外心到三頂點等距，到三邊等距則是內心。', explanation: '鈍角三角形的外心位於三角形外部。外心是三邊垂直平分線的交點，因此 OA＝OB＝OC。直角三角形才以斜邊中點為外心。' },
    ] },
];
const empty = (): CenterProgress => ({ discovered: [], completed: [] });
const ids = CENTER_STATIONS.map(s => s.id);
function validated(value: unknown): CenterProgress {
  if (!value || typeof value !== 'object') return empty();
  const p = value as CenterProgress;
  if (!Array.isArray(p.discovered) || !Array.isArray(p.completed)) return empty();
  if ([...p.discovered, ...p.completed].some(id => !ids.includes(id)) || new Set(p.discovered).size !== p.discovered.length || new Set(p.completed).size !== p.completed.length) return empty();
  if (p.completed.some((id, i) => id !== ids[i] || !p.discovered.includes(id))) return empty();
  return { discovered: [...p.discovered], completed: [...p.completed] };
}
const pageMemory = new Map<string, string>();
let storageWriteFailed = false;
function defaultStorage(): Pick<Storage, 'getItem' | 'setItem'> {
  return {
    getItem(key) { if (storageWriteFailed && pageMemory.has(key)) return pageMemory.get(key)!; try { const stored = typeof window === 'undefined' ? null : window.localStorage.getItem(key); return stored ?? pageMemory.get(key) ?? null; } catch { return pageMemory.get(key) ?? null; } },
    setItem(key, value) { pageMemory.set(key, value); try { if (typeof window !== 'undefined') window.localStorage.setItem(key, value); } catch { storageWriteFailed = true; /* Prefer this page's newer progress over stale readable storage after a failed write. */ } },
  };
}
export function loadCenterProgress(storage: Pick<Storage, 'getItem'> | undefined = defaultStorage()): CenterProgress {
  try { const raw = storage?.getItem(CENTER_STORAGE_KEY); return raw ? validated(JSON.parse(raw)) : empty(); } catch { return empty(); }
}
export function advanceCenterProgress(progress: CenterProgress, id: CenterId, action: 'discover' | 'complete'): CenterProgress {
  const p = validated(progress), index = ids.indexOf(id);
  if (index < 0) return p;
  if (action === 'discover' && !p.discovered.includes(id)) p.discovered.push(id);
  if (action === 'complete' && p.discovered.includes(id) && !p.completed.includes(id) && (index === 0 || p.completed.includes(ids[index - 1]))) p.completed.push(id);
  return p;
}
export function saveCenterProgress(progress: CenterProgress, storage: Pick<Storage, 'getItem' | 'setItem'> | undefined = defaultStorage()): void {
  const previous = loadCenterProgress(storage), next = validated(progress);
  try { storage?.setItem(CENTER_STORAGE_KEY, JSON.stringify(next)); } catch { /* The current page remains playable when browser storage is unavailable. */ }
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('campus:three-centers-progress', { detail: next }));
    if (next.completed.length === 3 && previous.completed.length < 3) window.dispatchEvent(new CustomEvent('campus:quest-complete', { detail: { questId: 'three-centers' } }));
  }
}
