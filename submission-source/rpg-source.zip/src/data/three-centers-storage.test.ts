import { afterEach, expect, it, vi } from 'vitest';

afterEach(() => { vi.restoreAllMocks(); vi.resetModules(); });

it('keeps newly saved progress when old storage remains readable but every write throws', async () => {
  vi.resetModules();
  const quest = await import('./three-centers');
  const oldValue = JSON.stringify({ discovered: [], completed: [] });
  vi.spyOn(Storage.prototype, 'getItem').mockImplementation(key => key === quest.CENTER_STORAGE_KEY ? oldValue : null);
  vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => { throw new DOMException('Storage is full', 'QuotaExceededError'); });
  const complete = vi.fn();
  window.addEventListener('campus:quest-complete', complete);
  try {
    for (const station of quest.CENTER_STATIONS) {
      let progress = quest.advanceCenterProgress(quest.loadCenterProgress(), station.id, 'discover');
      quest.saveCenterProgress(progress);
      expect(quest.loadCenterProgress()).toEqual(progress);
      progress = quest.advanceCenterProgress(quest.loadCenterProgress(), station.id, 'complete');
      quest.saveCenterProgress(progress);
      expect(quest.loadCenterProgress()).toEqual(progress);
    }
    expect(quest.loadCenterProgress().completed).toEqual(['incenter', 'centroid', 'circumcenter']);
    quest.saveCenterProgress(quest.loadCenterProgress());
    expect(complete).toHaveBeenCalledTimes(1);
    expect((complete.mock.calls[0][0] as CustomEvent).detail).toEqual({ questId: 'three-centers' });
  } finally { window.removeEventListener('campus:quest-complete', complete); }
});

it('continues to honor persisted values before a storage write has failed', async () => {
  vi.resetModules();
  const quest = await import('./three-centers');
  let stored = JSON.stringify({ discovered: [], completed: [] });
  vi.spyOn(Storage.prototype, 'getItem').mockImplementation(() => stored);
  vi.spyOn(Storage.prototype, 'setItem').mockImplementation((_key, value) => { stored = value; });
  quest.saveCenterProgress(quest.advanceCenterProgress(quest.loadCenterProgress(), 'incenter', 'discover'));
  stored = JSON.stringify({ discovered: [], completed: [] });
  expect(quest.loadCenterProgress()).toEqual({ discovered: [], completed: [] });
});
