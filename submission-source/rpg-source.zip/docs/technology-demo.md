# 科技館 2.0 示範

範圍為既有 `presentation.html` 的 Canvas 示範模式。既有導覽、原校園模式與 React `DemoQuest` 保留。Phaser 開發入口仍能編譯，尚未接入本示範資料。未使用教師照片或名冊。

## 操作

1. 執行 `pnpm exec vite --host 127.0.0.1 --port 8771`，開啟 `http://127.0.0.1:8771/presentation.html`。
2. 按「科技館 2.0 示範」，由校門出發。方向鍵或 WASD 手動沿金色巡檢線移動。巡檢線取自已檢查路線，不提供穿牆直線帶路。
3. 到科技館北翼西端入口，按 E 進入 1F；循走廊到南翼樓梯，按 E 上 2F。
4. 沿線到電腦教室二，靠近「數學任務導師・遊戲 NPC」按 E，按「接受原版 5 題任務」。
5. 原題目完成後按「返回校園探索」，回到同一個人物位置；沿路返回南翼樓梯，按 E 下樓，再回原入口出館。
6. 「返回原校園模式」恢復原校園探索位置。示範模式隱藏快速任務按鈕，讓入口、樓梯與 NPC 任務形成完整流程。

切換入口或樓層後，需要離開出生點至少 72 像素並經過 500 毫秒，互動才重新啟用，避免立即反向傳送。所有 portal 為手動 E 互動，不自動切換。

## 資料與驗證 API

`src/presentation/pilot-adapter.ts` 匯出 `createPilot(shared,runtime,scale)`。場景 ID 為 `pilot-outdoor`、`pilot-tech-1`、`pilot-tech-2`。

- `pilot.routes[id]`：該場景的遊戲座標巡檢線。
- `pilot.canonicalRoutes[id]`：帶 x／z／height 的來源節點。
- `pilot.transforms[id].toGame(point)`：來源 x／z 轉遊戲 x／y。
- `pilot.transforms[id].fromGame(point,height)`：可逆轉回來源座標。
- `pilot.maps[id]`：沿用原移動引擎的 MapConfig。
- `pilot.entrance`：路線實際使用的 shared 入口，並非任選 candidate。
- `pilot.landings`：高度 0／3.6 對應的實際路線 landing。
- `pilot.room`：來源 `computer-lab-2` 對應空間。

在點擊模式前監聽 `campus:pilot-ready`，其 detail 為完整 factory 結果。原 `campus:snapshot` 每幀維持 map／player／npcs，供只讀測試與小地圖更新；比例切換後以 snapshot 的新 map 為準。

示範按需載入 shared JSON 與 `technology-demo-runtime.json`，不載入完整 graph。使用 `node scripts/compile-technology-demo.mjs` 可由完整 runtime 重建 440 節點、1237 高度碰撞體的子集，並附完整來源 SHA-256。

## 呈現界線

12 棟建築的位置、名稱與輪廓來自來源資料，為示意而非實測實景。室內以樓層平面剖視呈現，碰撞取該樓面上人物高度 0.08 至 1.65 範圍，避開高處門楣並保留家具。空白庭院以 footprint 補集禁止走入；樓梯洞口屬視覺語意，離散上下樓使用 landing portal，不把斜坡或洞口扁平化為阻擋牆。

角色維持固定 24×32 像素矩形、原速度 220 與 8 向移動，狀態只有 4 朝向；比例只縮放世界資料。建築／牆體／人物依腳底深度排序。

驗證：先建立失敗測試，再實作 adapter。核心測試涵蓋三比例可逆座標、高度過濾、入口／樓梯／房間引用、對稱 portal，以及整條路線用原 movePlayer 逐段行走。瀏覽器端全流程另由主代理驗證。
