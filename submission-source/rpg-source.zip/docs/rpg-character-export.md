# 校園導覽角色離線轉製

生成檔案：`public/data/rpg-characters.json` 與 `public/assets/characters/guide-rpg/*.png`。

共 109 位：來源 91 位教職員（ID 原樣保留）、12 位示意學生、警衛、男女 × 制服／便服四種玩家、巡邏機器人。全部圖集為 512 × 264 PNG；每格 64 × 88；橫向依序為 down、down-left、left、up-left、up、up-right、right、down-right；縱向為 idle、leftstep、rightstep。模型原正面 +Z 對應 down，各欄旋轉角為 −欄號 × π/4。Canvas 以腳底排序時，使用每格共同底部錨點；不可逐角色裁切後重新放大。

腳本唯讀來源導覽的 staff-data.js、campus-people.js、explorer.js。使用來源 window.campusExplorer.createCharacter，保留 appearance、gender、ID 衍生的 blazer/cardigan/shirt/polo 與 pantsColor 規則。老師資料包含來源 appearance 時標記 source；其餘 generic 代表一般示意造型，並非依照片還原。沒有複製或匯出照片、portrait 路徑。robot 以 Three.js 基本球體、圓柱及方塊製作。

頭部乘上 1.18；成人／學生保留來源 .72／.65 模型比例。先遍歷全部角色、方向及步態的 Box3，再設定共同正交相機，保留 10% 安全邊界。渲染使用透明 alpha、2 倍內部解析度縮至目標格、來源 ACES/.88 曝光與相近光源，避免外觀色彩被過曝洗白。所有素材只於製作時使用 Three.js，遊戲執行時可直接 Canvas drawImage。

重製：啟動來源導覽唯讀伺服器於 http://127.0.0.1:8770/campus-explorer/，於本專案執行 `node scripts/export-rpg-characters.cjs`。可用 RPG_GUIDE_URL 與 RPG_GUIDE_SOURCE 指定其他來源位置。需要已安裝 Edge 與 Codex bundled Playwright。

驗證：`node --test scripts/verify-rpg-characters.node-check.cjs`。先確認「Character manifest must be generated」失敗後才實作匯出；完成後檢查完整 ID、角色分類、source hash、appearance 保留、無照片引用、109 張圖尺寸、全部 2,616 格非空／透明邊界／未裁切及 idle 與 walking 有差異。另目視檢查 staff-001、玩家制服與 robot 的八方向及兩種步態。

來源 SHA-256：

- staff-data.js：286f6b86feddfc762e9d04353fb6929afcb88854beb67f208c37ffccefaebd54
- campus-people.js：514499a0049ab3b1ea96d37843d1249ae8528ebd830c50f0016da84466a08256
- explorer.js：d12c7af8370c71f167d9ac404d68f203139700bacbda0954f128d26d04231faf

這些角色的姓名與職稱沿用來源名冊；RPG 活動位置與對話不屬於來源外觀資料。圖集呈現既有程式化示意模型，不能推論真實人物肖像授權或真實位置。

