# 校園導覽角色離線轉製

生成檔案：`public/data/rpg-characters.json`、`public/data/rpg-characters-v3.json`、`public/assets/characters/guide-rpg/style-v3/*.png` 及同目錄 `portraits/*.png`。舊版圖片保留；新路徑避免瀏覽器沿用舊圖快取。

共 109 位：來源 91 位教職員（ID 原樣保留）、12 位示意學生、警衛、男女 × 制服／便服四種玩家、巡邏機器人。全部圖集為 512 × 264 PNG；每格 64 × 88；橫向依序為 down、down-left、left、up-left、up、up-right、right、down-right；縱向為 idle、leftstep、rightstep。模型原正面 +Z 對應 down，各欄旋轉角為 −欄號 × π/4。Canvas 以腳底排序時，使用每格共同底部錨點；不可逐角色裁切後重新放大。

腳本唯讀來源導覽的 staff-data.js、campus-people.js、explorer.js。使用來源 window.campusExplorer.createCharacter，保留 ID、姓名、gender 與來源髮型／髮色，並於 sourceAppearance 完整保存來源外觀欄位。遊戲衣著由 ID 的 SHA-256 決定，不受名冊排序影響；使用 16 種成熟柔和上衣色、8 種褲色與 blazer/cardigan/shirt/polo 四種基底，搭配領帶、圍巾、背心、胸針、背包與裙／褲款。來源已有眼鏡者保留，其他角色可由遊戲創意規則補上眼鏡。衣著配色不限定性別。91 位教師的 styleSignature 均唯一。styleOrigin=creative-rpg 明確表示創意遊戲造型，非真實穿著紀錄；appearanceStatus 保留既有 source/generic 相容契約。老師資料包含來源 appearance 時標記 source；其餘 generic 代表一般示意造型，並非依照片還原。沒有複製或匯出照片、portrait 路徑。robot 以 Three.js 基本球體、圓柱及方塊製作。

世界 Q 版頭部乘上 1.65；非頭部放入同一身體群組並縮放為 (.88,.68,.88)，頭部重新移至頸部上方。成人／學生保留來源根節點 .72／.65 比例。可見幾何量測的頭高占全身高為 59.7%～64.6%，平均 64.2%；包含髮型輪廓，記錄於 proportions.headBodyRatio。新增 RPG 配件後，先遍歷全部角色、方向及步態（包含配件）的 Box3，再設定共同正交相機，保留 10% 安全邊界。渲染使用透明 alpha、2 倍內部解析度縮至目標格、來源 ACES/.88 曝光與相近光源，避免外觀色彩被過曝洗白。所有素材只於製作時使用 Three.js，遊戲執行時可直接 Canvas drawImage。

重製：啟動來源導覽唯讀伺服器於 http://127.0.0.1:8770/campus-explorer/，於本專案執行 `node scripts/export-rpg-characters.cjs`。可用 RPG_GUIDE_URL 與 RPG_GUIDE_SOURCE 指定其他來源位置。需要已安裝 Edge 與 Codex bundled Playwright。

驗證：`node --test scripts/deterministic-style.node-check.cjs scripts/verify-rpg-characters.node-check.cjs`。先確認「Character manifest must be generated」失敗後才實作匯出；完成後檢查完整 ID、角色分類、source hash、sourceAppearance 與來源髮型／髮色保留、無照片引用、109 張圖尺寸、全部 2,616 格非空／透明邊界／未裁切及 idle 與 walking 有差異。另目視檢查 staff-001、玩家制服與 robot 的八方向及兩種步態。

來源 SHA-256：

- staff-data.js：286f6b86feddfc762e9d04353fb6929afcb88854beb67f208c37ffccefaebd54
- campus-people.js：514499a0049ab3b1ea96d37843d1249ae8528ebd830c50f0016da84466a08256
- explorer.js：d12c7af8370c71f167d9ac404d68f203139700bacbda0954f128d26d04231faf

這些角色的姓名與職稱沿用來源名冊；RPG 活動位置與對話不屬於來源外觀資料。圖集呈現既有程式化示意模型，不能推論真實人物肖像授權或真實位置。


2026-10-13 造型驗證：新增多樣性測試先因褲色不足失敗，再實作 ID 雜湊造型。重新匯出 109 張圖集後，91 種衣著組合、16 上衣色、8 褲色、四種基底、眼鏡有／無均通過；2,616 格透明邊界檢查涵蓋新增配件。目視比較 staff-011、staff-005、staff-002、staff-014 的前／後方向，可辨識紫色外套、棕色針織衫、橘紅上衣、酒紅 Polo、背心／領帶、眼鏡與背包差異，所有角色共用腳底錨點。驗證圖：output/qa/teacher-style-variety.png。

2026-10-13 半身立繪：每角色再建立一份相同服裝、髮色、髮型、眼鏡與配件模型，使用原身體比例與 1.18 頭部縮放，正交鏡頭專門框取頭至腰部，輸出透明 512 × 640 PNG。不是把全身縮小，也沒有使用新人物照片。manifest 的 portrait 指向 style-v3/portraits/角色ID.png。全部 109 張立繪已驗證尺寸、透明上／側安全邊界、非空面積與上下構圖；世界 109 圖集的 2,616 格同樣完成裁切檢查。測試共 4 項通過。目視對照 output/qa/teacher-q-portrait-v3.png 上排 Q 世界角色、下排真正半身立繪，四位老師衣著與眼鏡一致。

半身像直接輸出 WebGL 的 512 × 640 實際渲染像素（256 × 320 邏輯畫布、2 倍像素密度），不經縮圖或插值放大；維持 0.8 寬高比與相同頭至腰構圖，足供桌面 180 × 230 CSS 在 DPR 2 顯示。世界圖集格尺寸維持 64 × 88。
