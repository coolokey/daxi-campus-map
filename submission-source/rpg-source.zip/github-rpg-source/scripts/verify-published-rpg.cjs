const path=require('node:path'),fs=require('node:fs'),assert=require('node:assert/strict');
const {chromium}=require(process.env.CAMPUS_PLAYWRIGHT_MODULE||path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));
const url=process.env.CAMPUS_QA_URL||'https://coolokey.github.io/daxi-campus-map/proposal/rpg/';
(async()=>{
  const browser=await chromium.launch({channel:'msedge',headless:true}),errors=[],failed=[],results=[];
  const out='output/published-rpg-qa';fs.mkdirSync(out,{recursive:true});
  try {
    const page=await browser.newPage({viewport:{width:1440,height:1100},hasTouch:true});
    page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)failed.push({url:r.url(),status:r.status()});});
    await page.addInitScript(()=>window.addEventListener('campus:snapshot',e=>window.testWorld=e.detail));
    await page.goto(url,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.testWorld?.map.width===3600);
    const start=await page.evaluate(()=>testWorld.npcs.map(n=>({x:n.x,y:n.y})));
    await page.waitForFunction(start=>testWorld.npcs.some((n,i)=>Math.hypot(n.x-start[i].x,n.y-start[i].y)>8),start);
    results.push('published world renders and NPCs move');
    for(const scale of [1,2,1.5]){await page.getByLabel('校園世界比例').selectOption(String(scale));await page.waitForFunction(w=>testWorld.map.width===w,2400*scale);}
    await page.locator('.world-minimap').click();await page.locator('dialog canvas').click({position:{x:300,y:200}});await page.waitForSelector('dialog[open]',{state:'hidden'});
    const y=await page.evaluate(()=>testWorld.player.y);await page.keyboard.down('ArrowUp');await page.waitForTimeout(250);await page.keyboard.up('ArrowUp');assert.ok(await page.evaluate(y=>testWorld.player.y<y-10,y));
    results.push('three scales, map navigation and keyboard after map close');
    await page.evaluate(()=>{const n=testWorld.npcs.find(n=>n.kind==='student');n.route=undefined;n.x=testWorld.player.x+40;n.y=testWorld.player.y;});await page.waitForTimeout(120);await page.keyboard.press('e');await page.waitForSelector('#dialogue:not([hidden])');await page.getByRole('button',{name:'繼續探索',exact:true}).click();
    await page.getByRole('button',{name:'快速體驗數學任務',exact:true}).click();await page.waitForSelector('.question-runner');await page.getByRole('button',{name:/返回校園/}).first().click();
    results.push('NPC dialogue and existing mathematics task');
    await page.screenshot({path:out+'/desktop.png',fullPage:true});
    await page.setViewportSize({width:390,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.locator('.world-minimap').tap();await page.getByRole('button',{name:'返回探索',exact:true}).tap();await page.screenshot({path:out+'/mobile.png',fullPage:true});
    results.push('mobile layout and touch full map');
    assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);
    const report={url,results,errors,failed};fs.writeFileSync(out+'/results.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
