import {readdirSync,readFileSync,statSync} from 'node:fs';
import {strict as assert} from 'node:assert';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const dist=fileURLToPath(new URL('../dist/',import.meta.url));
const js=readdirSync(path.join(dist,'assets')).filter(name=>name.endsWith('.js'));
const bytes=js.reduce((sum,name)=>sum+statSync(path.join(dist,'assets',name)).size,0);
assert.ok(bytes<900000,`Startup JavaScript budget exceeded: ${bytes} bytes (limit 900000)`);
const html=readFileSync(path.join(dist,'index.html'),'utf8');
assert.match(html,/rel="modulepreload"/,'Engine download must start from HTML, before React effects');
assert.match(html,/rel="preload"[^>]+campus[^>]+webp/,'Map download must start from HTML');
console.log(JSON.stringify({javascriptBytes:bytes,maximumBytes:900000,parallelEngineAndMap:true}));
const presentation=readFileSync(path.join(dist,'presentation.html'),'utf8');
const entries=[...presentation.matchAll(/(?:src|href)="\.\/(assets\/[^"?]+\.js)"/g)].map(match=>match[1]);
const visited=new Set();
function visit(file) {
  if(visited.has(file)) return; visited.add(file);
  const source=readFileSync(path.join(dist,file),'utf8');
  assert.ok(!/phaser-lite|react-dom|DemoQuest/.test(path.basename(file)),`Heavy module in initial graph: ${file}`);
  for(const match of source.matchAll(/(?:\bfrom\s*|\bimport\s*)["'](\.\/[^"']+\.js)["']/g)) visit(path.posix.join(path.posix.dirname(file),match[1]));
}
assert.ok(entries.length,'Presentation entry scripts are required'); entries.forEach(visit);
const initialBytes=[...visited].reduce((sum,file)=>sum+statSync(path.join(dist,file)).size,0);
assert.ok(initialBytes<20000,`Presentation startup exceeded 20 KB: ${initialBytes}`);
assert.ok(!/phaser-lite|DemoQuest/.test(presentation),'HTML must not preload engine or questions');
console.log(JSON.stringify({presentationInitialBytes:initialBytes,initialChunks:[...visited],questions:'on demand'}));
