import { GameShell } from './game/GameShell';
import { useEffect, useState } from 'react';
import { DemoQuest } from './components/DemoQuest';
export default function App() {
  const [questOpen, setQuestOpen] = useState(false);
  useEffect(() => {
    const openQuest = () => setQuestOpen(true);
    window.addEventListener('campus:quest-start', openQuest);
    return () => window.removeEventListener('campus:quest-start', openQuest);
  }, []);
  return <main><header className="app-header"><p className="eyebrow">大溪國中 × 數學學習任務雛型</p><h1>未來科技校園 RPG</h1><p>探索校園，走進科技館研究室，挑戰能源核心修復。</p></header>
    <div className="explore-toolbar"><p>方向鍵或 WASD 移動，E／空白鍵互動；手機可使用畫面搖桿。</p><button className="primary-button" onClick={() => setQuestOpen(true)}>快速體驗數學任務</button></div>
    <div hidden={questOpen}><GameShell paused={questOpen} /></div>
    {questOpen && <DemoQuest onClose={() => setQuestOpen(false)} />}
  </main>;
}
