import { render, screen } from '@testing-library/react';
import { expect, it } from 'vitest';
import { GameShell } from './GameShell';

it('provides a labelled game mount', () => {
  render(<GameShell />);
  expect(screen.getByLabelText('未來科技校園 RPG 遊戲畫面')).toBeInTheDocument();
});
