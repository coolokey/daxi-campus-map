import { act, cleanup, render, screen } from '@testing-library/react';
import { afterEach, expect, it } from 'vitest';
import { GameShell } from './GameShell';
afterEach(cleanup);

it('provides a labelled game mount', () => {
  render(<GameShell />);
  expect(screen.getByLabelText('未來科技校園 RPG 遊戲畫面')).toBeInTheDocument();
});

it('keeps a loading message until the campus has rendered', () => {
  render(<GameShell />);
  expect(screen.getByRole('status')).toHaveTextContent('正在載入校園');
  act(() => window.dispatchEvent(new Event('campus:world-ready')));
  expect(screen.queryByRole('status')).not.toBeInTheDocument();
});

it('shows a retryable error when a required scene asset cannot load', () => {
  render(<GameShell />);
  act(() => window.dispatchEvent(new Event('campus:world-error')));
  expect(screen.getByRole('alert')).toHaveTextContent('校園場景未能載入');
  expect(screen.queryByRole('status')).not.toBeInTheDocument();
});
