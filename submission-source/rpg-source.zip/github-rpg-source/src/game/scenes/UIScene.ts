import Phaser from 'phaser';
import { GAME_HEIGHT, GAME_WIDTH } from '../config';

type DialoguePayload = { name: string; text: string; portraitKey?: string };

/** A screen-space scene shared by every map: prompts, dialogue, and touch controls. */
export class UIScene extends Phaser.Scene {
  private prompt!: Phaser.GameObjects.Text;
  private dialogue!: Phaser.GameObjects.Container;
  private dialogueParts: Phaser.GameObjects.Components.Visible[] = [];
  private joystickKnob!: Phaser.GameObjects.Arc;
  private dialogueOpen = false;

  constructor() { super({ key: 'ui', active: false, visible: true }); }

  create() {
    this.prompt = this.add.text(GAME_WIDTH / 2, GAME_HEIGHT - 42, '', {
      fontFamily: 'Arial, "Microsoft JhengHei", sans-serif', fontSize: '22px', color: '#ffffff',
      backgroundColor: '#173652cc', padding: { left: 16, right: 16, top: 8, bottom: 8 },
    }).setOrigin(0.5).setDepth(20).setVisible(false);

    this.dialogue = this.createDialogue();
    this.dialogue.setAlpha(0);
    this.createTouchControls();
    const interact = () => this.dialogueOpen ? this.closeDialogue() : this.game.events.emit('interaction:action');
    this.input.keyboard?.on('keydown-E', interact);
    this.input.keyboard?.on('keydown-SPACE', interact);
    this.input.keyboard?.on('keydown-ENTER', interact);
    this.game.events.on('interaction:prompt', this.setPrompt, this);
    this.game.events.on('dialogue:open', this.openDialogue, this);
    this.game.events.on('dialogue:close', this.closeDialogue, this);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      this.game.events.off('interaction:prompt', this.setPrompt, this);
      this.game.events.off('dialogue:open', this.openDialogue, this);
      this.game.events.off('dialogue:close', this.closeDialogue, this);
    });
  }

  private createDialogue() {
    const shade = this.add.rectangle(GAME_WIDTH / 2, GAME_HEIGHT / 2, GAME_WIDTH, GAME_HEIGHT, 0x071421, 0.66)
      .setInteractive().on('pointerdown', () => this.game.events.emit('dialogue:close'));
    const panel = this.add.rectangle(GAME_WIDTH / 2, GAME_HEIGHT - 146, 1100, 190, 0x102b45, 0.96)
      .setStrokeStyle(3, 0x8ee8ff);
    const avatar = this.add.image(164, GAME_HEIGHT - 148, 'npc-placeholder').setDisplaySize(108, 130);
    const name = this.add.text(248, GAME_HEIGHT - 222, '', { fontFamily: 'Arial, "Microsoft JhengHei", sans-serif', fontSize: '25px', color: '#98efff', fontStyle: 'bold' });
    const text = this.add.text(248, GAME_HEIGHT - 178, '', { fontFamily: 'Arial, "Microsoft JhengHei", sans-serif', fontSize: '24px', color: '#ffffff', wordWrap: { width: 820 }, lineSpacing: 7 });
    const hint = this.add.text(GAME_WIDTH - 120, GAME_HEIGHT - 82, 'E ／空白鍵　繼續', { fontFamily: 'Arial, "Microsoft JhengHei", sans-serif', fontSize: '16px', color: '#c9f8ff' }).setOrigin(1);
    this.dialogueParts = [shade, panel, avatar, name, text, hint];
    return this.add.container(0, 0, this.dialogueParts as unknown as Phaser.GameObjects.GameObject[]).setDepth(30).setData({ name, text, avatar });
  }

  private createTouchControls() {
    const baseX = 105; const baseY = GAME_HEIGHT - 105;
    const base = this.add.circle(baseX, baseY, 58, 0x0c2842, 0.45).setStrokeStyle(2, 0xb7eeff, 0.65).setDepth(21);
    this.joystickKnob = this.add.circle(baseX, baseY, 25, 0x92edff, 0.7).setDepth(22);
    const action = this.add.circle(GAME_WIDTH - 102, GAME_HEIGHT - 102, 52, 0x1f8ec2, 0.82).setStrokeStyle(3, 0xd7fbff).setDepth(22).setInteractive({ useHandCursor: true });
    this.add.text(GAME_WIDTH - 102, GAME_HEIGHT - 102, '互動', { fontFamily: 'Arial, "Microsoft JhengHei", sans-serif', fontSize: '19px', color: '#ffffff', fontStyle: 'bold' }).setOrigin(0.5).setDepth(23);
    action.on('pointerdown', () => this.dialogueOpen ? this.closeDialogue() : this.game.events.emit('interaction:action'));
    this.input.on('pointermove', (pointer: Phaser.Input.Pointer) => {
      if (!pointer.isDown || this.dialogueOpen) return;
      const dx = pointer.x - baseX; const dy = pointer.y - baseY;
      if (Math.hypot(dx, dy) > 86) return;
      const length = Math.max(1, Math.hypot(dx, dy)); const amount = Math.min(1, length / 45);
      this.joystickKnob.setPosition(baseX + (dx / length) * Math.min(34, length), baseY + (dy / length) * Math.min(34, length));
      this.game.events.emit('input:virtual-direction', { x: (dx / length) * amount, y: (dy / length) * amount });
    });
    this.input.on('pointerup', () => this.resetJoystick());
    base.setInteractive();
  }

  private resetJoystick() { this.joystickKnob.setPosition(105, GAME_HEIGHT - 105); this.game.events.emit('input:virtual-direction', { x: 0, y: 0 }); }
  private setPrompt(text?: string) { if (this.dialogueOpen) return; this.prompt.setText(text ?? '').setVisible(Boolean(text)); }
  private openDialogue(payload: DialoguePayload) {
    const data = this.dialogue.data; (data.get('name') as Phaser.GameObjects.Text).setText(payload.name); (data.get('text') as Phaser.GameObjects.Text).setText(payload.text);
    const avatar = data.get('avatar') as Phaser.GameObjects.Image; if (payload.portraitKey && this.textures.exists(payload.portraitKey)) avatar.setTexture(payload.portraitKey);
    this.dialogueOpen = true; this.prompt.setVisible(false); this.dialogue.setAlpha(1); this.resetJoystick();
  }
  private closeDialogue() { if (!this.dialogueOpen) return; this.dialogueOpen = false; this.dialogue.setAlpha(0); this.game.events.emit('dialogue:closed'); }
}
