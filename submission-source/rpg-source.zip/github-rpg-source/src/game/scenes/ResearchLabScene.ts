import Phaser from 'phaser';
import { PlayerController } from '../entities/PlayerController';
import { researchLabMap as sourceResearchLabMap } from '../data/maps/research-lab';
import { presentationMap } from '../data/presentation';
import { nearestInteractable } from '../core/interaction';
import type { NpcConfig, PortalConfig } from '../data/types';

type Target = { type: 'npc'; value: NpcConfig } | { type: 'portal'; value: PortalConfig };
const researchLabMap = presentationMap(sourceResearchLabMap);

export class ResearchLabScene extends Phaser.Scene {
  private player!: PlayerController;
  private cursors!: Phaser.Types.Input.Keyboard.CursorKeys;
  private wasd!: Record<'W' | 'A' | 'S' | 'D', Phaser.Input.Keyboard.Key>;
  private virtualDirection = { x: 0, y: 0 };
  private target?: Target;
  constructor() { super({ key: 'research-lab', active: false, visible: true }); }
  create({ spawnId = 'lab-entry' }: { spawnId?: string } = {}) {
    this.cameras.main.setBackgroundColor('#153654'); this.cameras.main.fadeIn(180, 8, 28, 45);
    this.add.rectangle(800, 480, 1500, 860, 0xeaf9ff).setStrokeStyle(12, 0x86d7ff); this.add.rectangle(840, 425, 290, 150, 0x5b7c93).setStrokeStyle(6, 0xc1edff);
    const collisions = this.physics.add.staticGroup(); researchLabMap.collisionZones.forEach((zone) => collisions.create(zone.x + zone.width / 2, zone.y + zone.height / 2, undefined).setDisplaySize(zone.width, zone.height).setVisible(false).refreshBody());
    const spawn = researchLabMap.spawns[spawnId] ?? researchLabMap.spawns['lab-entry']; const sprite = this.physics.add.sprite(spawn.x, spawn.y, `player-${spawn.direction}-idle`).setCollideWorldBounds(true).setDepth(3);
    sprite.setSize(22, 24).setOffset(9, 22); this.player = new PlayerController(sprite); this.physics.add.collider(sprite, collisions);
    this.physics.world.setBounds(0, 0, researchLabMap.width, researchLabMap.height); this.cameras.main.setBounds(0, 0, researchLabMap.width, researchLabMap.height); this.cameras.main.startFollow(sprite, true, 0.12, 0.12);
    this.cursors = this.input.keyboard!.createCursorKeys(); this.wasd = this.input.keyboard!.addKeys('W,A,S,D') as Record<'W' | 'A' | 'S' | 'D', Phaser.Input.Keyboard.Key>; researchLabMap.npcs.forEach((npc) => this.add.sprite(npc.x, npc.y, npc.spriteKey).setDepth(2));
    this.game.events.on('input:virtual-direction', this.setVirtualDirection, this); this.game.events.on('interaction:action', this.activateTarget, this); this.game.events.on('dialogue:closed', this.resumePlayer, this); this.events.once(Phaser.Scenes.Events.SHUTDOWN, this.removeListeners, this);
  }
  update() { const x = Number(this.cursors.right.isDown || this.wasd.D.isDown) - Number(this.cursors.left.isDown || this.wasd.A.isDown) || this.virtualDirection.x; const y = Number(this.cursors.down.isDown || this.wasd.S.isDown) - Number(this.cursors.up.isDown || this.wasd.W.isDown) || this.virtualDirection.y; this.player.move({ x, y }); this.refreshTarget(); }
  private refreshTarget() { const position = this.player.sprite; const npc = nearestInteractable(position, researchLabMap.npcs); const portal = researchLabMap.portals.find((item) => Phaser.Geom.Rectangle.Contains(new Phaser.Geom.Rectangle(item.trigger.x - 60, item.trigger.y - 60, item.trigger.width + 120, item.trigger.height + 120), position.x, position.y)); this.target = npc ? { type: 'npc', value: npc } : portal ? { type: 'portal', value: portal } : undefined; this.game.events.emit('interaction:prompt', this.target?.type === 'npc' ? `E ／空白鍵　與 ${this.target.value.name} 交談` : this.target?.type === 'portal' ? this.target.value.prompt : undefined); }
  private activateTarget() { if (!this.target) return; if (this.target.type === 'portal') { const portal = this.target.value; this.player.enabled = false; this.player.sprite.setVelocity(0, 0); this.game.events.emit('interaction:prompt'); this.cameras.main.fadeOut(220, 8, 28, 45); this.cameras.main.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => this.scene.start(portal.destinationMapId, { spawnId: portal.destinationSpawnId })); return; } this.player.enabled = false; this.player.sprite.setVelocity(0, 0); this.game.events.emit('dialogue:open', { name: this.target.value.name, portraitKey: this.target.value.portraitKey, text: '這裡是數學研究室。一起修復能源核心吧！' }); this.game.events.emit('dialogue:close'); window.dispatchEvent(new CustomEvent('campus:quest-start'));  }
  private setVirtualDirection(direction: { x: number; y: number }) { this.virtualDirection = direction; }
  private resumePlayer() { this.player.enabled = true; }
  private removeListeners() { this.game.events.off('input:virtual-direction', this.setVirtualDirection, this); this.game.events.off('interaction:action', this.activateTarget, this); this.game.events.off('dialogue:closed', this.resumePlayer, this); }
}
