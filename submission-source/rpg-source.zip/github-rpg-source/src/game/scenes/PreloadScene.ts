import Phaser from 'phaser';
import { mathematicsTeacherAssets } from '../data/teacher-assets';
import { assetUrl, isPresentation } from '../data/presentation';

const directions = ['down', 'up', 'left', 'right'] as const;

export class PreloadScene extends Phaser.Scene {
  constructor() { super('preload'); }
  preload() {
    this.load.once('loaderror', () => window.dispatchEvent(new Event('campus:world-error')));
    this.load.image('campus-background', assetUrl('/assets/maps/daxi-future-campus-rpg-v1.webp'));
    if (!isPresentation()) mathematicsTeacherAssets.forEach((teacher) => {
      this.load.image(teacher.id, assetUrl(teacher.worldSprite));
      this.load.image(`${teacher.id}-portrait`, assetUrl(teacher.portrait));
    });
  }
  create() {
    directions.forEach((direction, index) => {
      const createFrame = (key: string, walking: boolean) => {
        const graphics = this.add.graphics();
        const tint = [0x4fb3e7, 0x638fd6, 0x5dbb9a, 0xb071cc][index];
        graphics.fillStyle(tint, 1); graphics.fillRoundedRect(7, walking ? 5 : 7, 26, 30, 8);
        graphics.fillStyle(0xffffff, 1); graphics.fillCircle(20, 11, 9);
        graphics.fillStyle(0x17324d, 1); graphics.fillRect(walking ? 4 : 8, 34, 10, walking ? 9 : 7); graphics.fillRect(walking ? 22 : 24, 34, 10, walking ? 7 : 9);
        graphics.generateTexture(key, 40, 48); graphics.destroy();
      };
      createFrame(`player-${direction}-idle`, false); createFrame(`player-${direction}-walk`, true);
      this.anims.create({ key: `idle-${direction}`, frames: [{ key: `player-${direction}-idle` }], frameRate: 1, repeat: -1 });
      this.anims.create({ key: `walk-${direction}`, frames: [{ key: `player-${direction}-idle` }, { key: `player-${direction}-walk` }], frameRate: 8, repeat: -1 });
    });
    const npc = this.add.graphics(); npc.fillStyle(0xf2b646, 1); npc.fillRoundedRect(6, 5, 28, 32, 8); npc.fillStyle(0xffffff, 1); npc.fillCircle(20, 11, 8); npc.generateTexture('npc-placeholder', 40, 48); npc.destroy();
    this.scene.launch('ui');
    this.scene.start('campus', { spawnId: 'campus-start' });
  }
}
