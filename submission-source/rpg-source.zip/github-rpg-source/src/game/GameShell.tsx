import { useEffect, useRef, useState } from 'react';

export function GameShell({ paused = false }: { paused?: boolean }) {
  const [portalHidden, setPortalHidden] = useState(false);
  const suspended = paused || portalHidden;
  const mountRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<import('phaser').Game | null>(null);
  const pausedRef = useRef(suspended);
  const [error, setError] = useState(false);
  useEffect(() => {
    pausedRef.current = suspended;
    const game = gameRef.current;
    if (!game) return;
    if (suspended) { game.loop.sleep(); if (game.input.keyboard) game.input.keyboard.enabled = false; }
    else { game.scene.getScenes(false).forEach(scene => scene.input.keyboard?.resetKeys()); game.loop.wake(); if (game.input.keyboard) game.input.keyboard.enabled = true; }
  }, [suspended]);
  useEffect(() => {
    const receive = (event: MessageEvent) => {
      if (event.source !== window.parent || event.origin !== location.origin) return;
      if (event.data?.type === 'proposal:visibility' && typeof event.data.visible === 'boolean') setPortalHidden(!event.data.visible);
    };
    window.addEventListener('message', receive);
    return () => window.removeEventListener('message', receive);
  }, []);
  useEffect(() => {
    if (!mountRef.current || navigator.userAgent.includes('jsdom')) return;
    let destroyed = false;
    let destroy: (() => void) | undefined;
    void Promise.all([import('phaser'), import('./game-config')]).then(([phaserModule, configModule]) => {
      if (destroyed || !mountRef.current) return;
      const game = new phaserModule.default.Game(configModule.createGameConfig(mountRef.current));
      gameRef.current = game;
      if (pausedRef.current) { game.loop.sleep(); if (game.input.keyboard) game.input.keyboard.enabled = false; }
      destroy = () => { gameRef.current = null; game.destroy(true); };
    }).catch(() => { if (!destroyed) setError(true); });
    return () => { destroyed = true; destroy?.(); };
  }, []);
  return <>{error && <p role="alert">校園場景未能載入。請重新整理，或先使用上方的數學任務體驗。</p>}<div className="game-shell" aria-label="未來科技校園 RPG 遊戲畫面" ref={mountRef} /></>;
}
