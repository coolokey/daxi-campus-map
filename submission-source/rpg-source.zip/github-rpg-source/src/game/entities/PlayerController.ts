import Phaser from 'phaser';
import { PLAYER_SPEED } from '../config';
import { normalizeVelocity } from '../core/vector';
import type { Direction } from '../data/types';

export function directionFromVelocity(x: number, y: number, fallback: Direction): Direction {
  if (x === 0 && y === 0) return fallback;
  return Math.abs(x) >= Math.abs(y) ? (x > 0 ? 'right' : 'left') : (y > 0 ? 'down' : 'up');
}

export class PlayerController {
  enabled = true;
  lastDirection: Direction = 'down';

  constructor(readonly sprite: Phaser.Physics.Arcade.Sprite) {}

  move(input: { x: number; y: number }) {
    if (!this.enabled) {
      this.sprite.setVelocity(0, 0);
      return;
    }
    const velocity = normalizeVelocity(input, PLAYER_SPEED);
    this.sprite.setVelocity(velocity.x, velocity.y);
    this.lastDirection = directionFromVelocity(velocity.x, velocity.y, this.lastDirection);
    this.sprite.anims.play(velocity.x === 0 && velocity.y === 0 ? `idle-${this.lastDirection}` : `walk-${this.lastDirection}`, true);
  }
}
