// Phaser 3.90 official core + the modules used by this 2D campus game.
// Phaser copyright 2013-2025 Phaser Studio Inc.; MIT license.
const Phaser = require('phaser/src/phaser-core.js');
Phaser.Geom = { Rectangle: require('phaser/src/geom/rectangle/Rectangle.js') };
Phaser.Geom.Rectangle.Contains = require('phaser/src/geom/rectangle/Contains.js');
Phaser.Physics = { Arcade: require('phaser/src/physics/arcade/index.js') };
require('phaser/src/gameobjects/container/ContainerFactory.js');
require('phaser/src/gameobjects/shape/rectangle/RectangleFactory.js');
require('phaser/src/gameobjects/shape/arc/ArcFactory.js');
module.exports = Phaser;
