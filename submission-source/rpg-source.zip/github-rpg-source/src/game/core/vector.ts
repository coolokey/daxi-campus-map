export type Vector = { x: number; y: number };

export function normalizeVelocity(input: Vector, speed: number): Vector {
  const length = Math.hypot(input.x, input.y);
  return length === 0
    ? { x: 0, y: 0 }
    : { x: (input.x / length) * speed, y: (input.y / length) * speed };
}
