import { describe, expect, it } from 'vitest';
import { normalizeVelocity } from './vector';

describe('normalizeVelocity', () => {
  it('keeps diagonal speed equal to straight speed', () => {
    const velocity = normalizeVelocity({ x: 1, y: 1 }, 220);
    expect(Math.hypot(velocity.x, velocity.y)).toBeCloseTo(220, 6);
  });

  it('keeps no input stationary', () => {
    expect(normalizeVelocity({ x: 0, y: 0 }, 220)).toEqual({ x: 0, y: 0 });
  });
});
