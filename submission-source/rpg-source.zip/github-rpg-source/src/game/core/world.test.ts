import { expect, it } from 'vitest';
import { campusMap } from '../data/maps/campus';
import { scaleMap, createResidents, stepResidents, safePosition } from './world';
import { isBlocked } from './collision';

it('recovers fixed-size characters near a building after shrinking',()=>{
  const p=safePosition({x:1115,y:400},campusMap);
  expect(isBlocked({x:p.x-16,y:p.y-16,width:32,height:40},campusMap.collisionZones)).toBe(false);
  expect(Math.hypot(p.x-1115,p.y-400)).toBeLessThan(160);
});

it.each([1, 1.5, 2])('scales every spatial layer at %s without mutating source', scale => {
  const original = JSON.stringify(campusMap), map = scaleMap(campusMap, scale);
  expect(map.width).toBe(2400 * scale);
  expect(map.spawns['campus-start'].x).toBe(1180 * scale);
  expect(map.portals[0].trigger.x).toBe(1945 * scale);
  expect(map.collisionZones[0].width).toBe(1040 * scale);
  expect(map.npcs[0].interactionRadius).toBe(campusMap.npcs[0].interactionRadius);
  expect(JSON.stringify(campusMap)).toBe(original);
});

it.each([1, 1.5, 2])('residents patrol without entering walls at scale %s', scale => {
  const map = scaleMap(campusMap, scale), npcs = createResidents(map);
  const start = npcs.map(n => ({ x:n.x, y:n.y }));
  let distance = 0;
  for (let i = 0; i < 6000; i++) {
    const old = npcs.map(n => ({ x:n.x, y:n.y }));
    stepResidents(npcs, map, 0.1, {x:0,y:0}, false);
    npcs.forEach((n,j) => {
      distance += Math.hypot(n.x-old[j].x,n.y-old[j].y);
      expect(isBlocked({x:n.x-11,y:n.y-11,width:22,height:22},map.collisionZones)).toBe(false);
    });
  }
  expect(distance).toBeGreaterThan(5000);
  expect(npcs.some((n,i)=>Math.hypot(n.x-start[i].x,n.y-start[i].y)>20)).toBe(true);
  const before = JSON.stringify(npcs);
  stepResidents(npcs,map,0.1,{x:0,y:0},true);
  expect(JSON.stringify(npcs)).toBe(before);
});
