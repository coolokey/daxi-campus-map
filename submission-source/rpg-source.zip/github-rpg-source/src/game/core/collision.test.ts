import { expect, it } from 'vitest';
import { isBlocked } from './collision';

it('blocks a player rectangle that overlaps a wall', () => {
  expect(isBlocked({ x: 40, y: 40, width: 24, height: 24 }, [{ x: 50, y: 0, width: 80, height: 80 }])).toBe(true);
});

it('allows a player rectangle away from every wall', () => {
  expect(isBlocked({ x: 0, y: 100, width: 24, height: 24 }, [{ x: 50, y: 0, width: 80, height: 80 }])).toBe(false);
});
