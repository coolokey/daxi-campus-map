import type { MapConfig } from '../data/types';
import type { WorldId } from '../config';

export function resolvePortal(map: MapConfig, portalId: string): { mapId: WorldId; spawnId: string } {
  const portal = map.portals.find((item) => item.id === portalId);
  if (!portal) throw new Error(`Unknown portal ${portalId} on ${map.id}`);
  return { mapId: portal.destinationMapId, spawnId: portal.destinationSpawnId };
}
