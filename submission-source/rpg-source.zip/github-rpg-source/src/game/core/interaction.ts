export type InteractionPoint = { id: string; x: number; y: number; interactionRadius: number };
export type Point = { x: number; y: number };

export function nearestInteractable<T extends InteractionPoint>(point: Point, items: T[]): T | undefined {
  return items
    .filter((item) => Math.hypot(item.x - point.x, item.y - point.y) <= item.interactionRadius)
    .sort((a, b) => Math.hypot(a.x - point.x, a.y - point.y) - Math.hypot(b.x - point.x, b.y - point.y))[0];
}
