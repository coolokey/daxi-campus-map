import type { Rect } from '../data/types';

export function isBlocked(player: Rect, zones: Rect[]): boolean {
  return zones.some((zone) => (
    player.x < zone.x + zone.width
    && player.x + player.width > zone.x
    && player.y < zone.y + zone.height
    && player.y + player.height > zone.y
  ));
}
