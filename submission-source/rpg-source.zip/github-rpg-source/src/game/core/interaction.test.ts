import { expect, it } from 'vitest';
import { nearestInteractable } from './interaction';

it('only finds an NPC inside its interaction radius', () => {
  const npc = { id: 'n', x: 100, y: 100, interactionRadius: 76 };
  expect(nearestInteractable({ x: 150, y: 100 }, [npc])).toEqual(npc);
  expect(nearestInteractable({ x: 177, y: 100 }, [npc])).toBeUndefined();
});
