import { expect, it } from 'vitest';
import { getMapConfig } from '../data/maps';
import { resolvePortal } from './portal';

it('resolves the campus technology door to the lab entry spawn', () => {
  expect(resolvePortal(getMapConfig('campus'), 'technology-building-door')).toEqual({ mapId: 'research-lab', spawnId: 'lab-entry' });
});
