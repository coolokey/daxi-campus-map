import { INTERACTION_RADIUS } from '../../config';
import type { MapConfig } from '../types';

export const campusMap: MapConfig = {
  id: 'campus',
  width: 2400,
  height: 1624,
  backgroundKey: 'campus-background',
  spawns: {
    'campus-start': { x: 1180, y: 1360, direction: 'up' },
    'technology-door-return': { x: 1880, y: 900, direction: 'down' },
  },
  collisionZones: [
    { x: 70, y: 160, width: 1040, height: 720 },
    { x: 1700, y: 260, width: 500, height: 520 },
    { x: 1360, y: 950, width: 300, height: 260 },
    { x: 250, y: 1060, width: 470, height: 330 },
  ],
  npcs: [{
    id: 'math-researcher', mapId: 'campus', x: 1810, y: 1030, direction: 'down',
    spriteKey: 'math-陳小鈴', portraitKey: 'math-陳小鈴-portrait',
    interactionRadius: INTERACTION_RADIUS, dialogueId: 'campus-researcher', name: '陳小鈴老師',
  }],
  portals: [{
    id: 'technology-building-door', mapId: 'campus', trigger: { x: 1945, y: 750, width: 120, height: 80 },
    destinationMapId: 'research-lab', destinationSpawnId: 'lab-entry', prompt: 'E 進入科技館數學研究室',
  }],
};
