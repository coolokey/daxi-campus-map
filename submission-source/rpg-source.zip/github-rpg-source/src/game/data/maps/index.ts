import type { WorldId } from '../../config';
import type { MapConfig, Rect } from '../types';
import { campusMap } from './campus';
import { researchLabMap } from './research-lab';

export const maps: Record<WorldId, MapConfig> = { campus: campusMap, 'research-lab': researchLabMap };
export function getMapConfig(id: WorldId): MapConfig { return maps[id]; }

function isInside(rect: Rect, map: MapConfig): boolean {
  return rect.x >= 0 && rect.y >= 0 && rect.x + rect.width <= map.width && rect.y + rect.height <= map.height;
}

export function validateMapConfigs(): string[] {
  const errors: string[] = [];
  for (const map of Object.values(maps)) {
    for (const npc of map.npcs) {
      if (npc.mapId !== map.id) errors.push(`${npc.id}: map mismatch`);
      if (npc.x < 0 || npc.y < 0 || npc.x > map.width || npc.y > map.height) errors.push(`${npc.id}: out of bounds`);
    }
    for (const portal of map.portals) {
      if (!isInside(portal.trigger, map)) errors.push(`${portal.id}: trigger out of bounds`);
      const destination = maps[portal.destinationMapId];
      if (!destination) errors.push(`${portal.id}: unknown destination map`);
      else if (!destination.spawns[portal.destinationSpawnId]) errors.push(`${portal.id}: unknown destination spawn`);
    }
  }
  return errors;
}
