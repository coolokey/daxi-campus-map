import { INTERACTION_RADIUS } from '../../config';
import type { MapConfig } from '../types';

export const researchLabMap: MapConfig = {
  id: 'research-lab', width: 1600, height: 960, backgroundKey: 'research-lab-background',
  spawns: { 'lab-entry': { x: 260, y: 760, direction: 'up' } },
  collisionZones: [
    { x: 0, y: 0, width: 1600, height: 72 }, { x: 0, y: 888, width: 1600, height: 72 },
    { x: 0, y: 0, width: 72, height: 960 }, { x: 1528, y: 0, width: 72, height: 960 },
    { x: 690, y: 350, width: 290, height: 150 },
  ],
  npcs: [
    { id: 'math-蔡之民', mapId: 'research-lab', x: 250, y: 210, direction: 'down', spriteKey: 'math-蔡之民', portraitKey: 'math-蔡之民-portrait', interactionRadius: INTERACTION_RADIUS, dialogueId: 'math-蔡之民', name: '蔡之民老師' },
    { id: 'math-游家興', mapId: 'research-lab', x: 510, y: 220, direction: 'down', spriteKey: 'math-游家興', portraitKey: 'math-游家興-portrait', interactionRadius: INTERACTION_RADIUS, dialogueId: 'math-游家興', name: '游家興老師' },
    { id: 'math-張秀萍', mapId: 'research-lab', x: 1100, y: 220, direction: 'down', spriteKey: 'math-張秀萍', portraitKey: 'math-張秀萍-portrait', interactionRadius: INTERACTION_RADIUS, dialogueId: 'math-張秀萍', name: '張秀萍老師' },
    { id: 'math-張雅琪', mapId: 'research-lab', x: 1370, y: 230, direction: 'down', spriteKey: 'math-張雅琪', portraitKey: 'math-張雅琪-portrait', interactionRadius: INTERACTION_RADIUS, dialogueId: 'math-張雅琪', name: '張雅琪老師' },
    { id: 'math-游貿仁', mapId: 'research-lab', x: 250, y: 510, direction: 'right', spriteKey: 'math-游貿仁', portraitKey: 'math-游貿仁-portrait', interactionRadius: INTERACTION_RADIUS, dialogueId: 'math-游貿仁', name: '游貿仁老師' },
    { id: 'math-方廷榕', mapId: 'research-lab', x: 500, y: 700, direction: 'up', spriteKey: 'math-方廷榕', portraitKey: 'math-方廷榕-portrait', interactionRadius: INTERACTION_RADIUS, dialogueId: 'math-方廷榕', name: '方廷榕老師' },
    { id: 'math-康嘉玲', mapId: 'research-lab', x: 760, y: 700, direction: 'up', spriteKey: 'math-康嘉玲', portraitKey: 'math-康嘉玲-portrait', interactionRadius: INTERACTION_RADIUS, dialogueId: 'math-康嘉玲', name: '康嘉玲老師' },
    { id: 'math-潘建銘', mapId: 'research-lab', x: 1030, y: 700, direction: 'up', spriteKey: 'math-潘建銘', portraitKey: 'math-潘建銘-portrait', interactionRadius: INTERACTION_RADIUS, dialogueId: 'math-潘建銘', name: '潘建銘老師' },
    { id: 'math-徐君萍', mapId: 'research-lab', x: 1280, y: 700, direction: 'up', spriteKey: 'math-徐君萍', portraitKey: 'math-徐君萍-portrait', interactionRadius: INTERACTION_RADIUS, dialogueId: 'math-徐君萍', name: '徐君萍老師' },
    { id: 'math-何昶毅', mapId: 'research-lab', x: 1360, y: 500, direction: 'left', spriteKey: 'math-何昶毅', portraitKey: 'math-何昶毅-portrait', interactionRadius: INTERACTION_RADIUS, dialogueId: 'math-何昶毅', name: '何昶毅老師' },
  ],
  portals: [{
    id: 'research-lab-exit', mapId: 'research-lab', trigger: { x: 180, y: 780, width: 160, height: 90 },
    destinationMapId: 'campus', destinationSpawnId: 'technology-door-return', prompt: 'E 返回校園',
  }],
};
