import { expect, it } from 'vitest';
import { getMapConfig, validateMapConfigs } from './index';

it('has valid campus and research-lab maps', () => {
  expect(validateMapConfigs()).toEqual([]);
  expect(getMapConfig('campus').portals).toHaveLength(1);
  expect(getMapConfig('research-lab').portals).toHaveLength(1);
});
