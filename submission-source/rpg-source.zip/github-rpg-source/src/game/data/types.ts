import type { WorldId } from '../config';

export type Rect = { x: number; y: number; width: number; height: number };
export type Direction = 'up' | 'down' | 'left' | 'right';
export type SpawnPoint = { x: number; y: number; direction: Direction };
export type NpcConfig = {
  id: string;
  mapId: WorldId;
  x: number;
  y: number;
  direction: Direction;
  spriteKey: string;
  portraitKey: string;
  interactionRadius: number;
  dialogueId: string;
  name: string;
};
export type PortalConfig = {
  id: string;
  mapId: WorldId;
  trigger: Rect;
  destinationMapId: WorldId;
  destinationSpawnId: string;
  prompt: string;
};
export type MapConfig = {
  id: WorldId;
  width: number;
  height: number;
  backgroundKey: string;
  collisionZones: Rect[];
  npcs: NpcConfig[];
  portals: PortalConfig[];
  spawns: Record<string, SpawnPoint>;
};
