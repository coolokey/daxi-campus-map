/**
 * Current mathematics-domain roster.  Portrait references stay unassigned until
 * each current teacher is matched to a supplied, approved source photograph.
 * This prevents an RPG likeness from being attached to the wrong person.
 */
export const mathematicsTeacherAssets = [
  '蔡之民', '游家興', '張秀萍', '張雅琪', '陳小鈴', '游貿仁',
  '方廷榕', '康嘉玲', '潘建銘', '徐君萍', '何昶毅',
].map((name) => ({
  id: `math-${name}`,
  name,
  fullBody: `/assets/rpg/teachers/math-${name}-full.png`,
  portrait: `/assets/rpg/teachers/math-${name}-portrait.png`,
  worldSprite: `/assets/rpg/teachers/math-${name}-sprite.png`,
  sourceStatus: ['陳小鈴', '游貿仁', '方廷榕', '康嘉玲', '張秀萍', '潘建銘'].includes(name) ? 'photo-matched' as const : 'provisional-non-likeness' as const,
}));
