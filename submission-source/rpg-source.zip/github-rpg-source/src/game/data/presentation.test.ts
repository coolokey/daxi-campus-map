import { expect, it } from 'vitest';
import { campusMap } from './maps/campus';
import { presentationMap, assetUrl } from './presentation';

it('uses fictional NPCs without mutating the original teacher map', () => {
  const result = presentationMap(campusMap, true);
  expect(result.npcs[0].spriteKey).toBe('npc-placeholder');
  expect(result.npcs[0].name).toBe('數字研究員');
  expect(campusMap.npcs[0].name).toBe('陳小鈴老師');
  expect(result.portals).toEqual(campusMap.portals);
});

it('keeps assets relative to a nested deployment directory', () => {
  expect(assetUrl('/assets/maps/campus.png', './')).toBe('./assets/maps/campus.png');
  expect(assetUrl('/assets/maps/campus.png', '/demo/rpg/')).toBe('/demo/rpg/assets/maps/campus.png');
});
