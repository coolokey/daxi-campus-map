import type { MapConfig } from './types';

export const isPresentation = () => new URLSearchParams(window.location.search).get('presentation') === '1';

export function assetUrl(path: string, base = import.meta.env.BASE_URL) {
  return `${base.replace(/\/?$/, '/')}${path.replace(/^\//, '')}`;
}

export function presentationMap(map: MapConfig, enabled = isPresentation()): MapConfig {
  if (!enabled) return map;
  return { ...map, npcs: map.npcs.map((npc, index) => ({ ...npc,
    name: map.id === 'campus' ? '數字研究員' : `研究室助教 ${index + 1}`,
    spriteKey: 'npc-placeholder', portraitKey: 'npc-placeholder',
  })) };
}
