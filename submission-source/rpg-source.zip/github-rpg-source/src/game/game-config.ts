import Phaser from 'phaser';
import { GAME_HEIGHT, GAME_WIDTH } from './config';
import { BootScene } from './scenes/BootScene';
import { CampusScene } from './scenes/CampusScene';
import { PreloadScene } from './scenes/PreloadScene';
import { ResearchLabScene } from './scenes/ResearchLabScene';
import { UIScene } from './scenes/UIScene';

export function createGameConfig(parent: HTMLElement): Phaser.Types.Core.GameConfig {
  return {
    type: Phaser.AUTO, parent, width: GAME_WIDTH, height: GAME_HEIGHT, backgroundColor: '#eaf9ff',
    physics: { default: 'arcade', arcade: { debug: false } },
    scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH, width: GAME_WIDTH, height: GAME_HEIGHT },
    scene: [BootScene, PreloadScene, CampusScene, ResearchLabScene, UIScene],
  };
}
