export const GAME_WIDTH = 1280;
export const GAME_HEIGHT = 720;
export const PLAYER_SPEED = 220;
export const INTERACTION_RADIUS = 76;
export const WORLD_IDS = ['campus', 'research-lab'] as const;
export type WorldId = (typeof WORLD_IDS)[number];
