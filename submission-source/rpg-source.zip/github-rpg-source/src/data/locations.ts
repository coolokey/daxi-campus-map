import type { Location } from '../types/game';

export const locations: Location[] = [
  { id: 'main-gate', name: '正門', x: 47, y: 89 },
  { id: 'technology-building', name: '科技館', x: 84, y: 52, npcId: 'teacher-001' },
  { id: 'library', name: '圖書館', x: 79, y: 40 },
];
