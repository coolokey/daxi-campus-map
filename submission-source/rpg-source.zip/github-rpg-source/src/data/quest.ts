export const firstQuest = {
  id: 'energy-core-01',
  title: '能源核心修復',
  npcId: 'teacher-001',
  reward: '數字研究員徽章',
  dialogue: '校園能源核心失去平衡。完成五個數學校準任務，一起修復它吧。',
};
