import { summarizeByConcept } from './progress';
import type { Concept, LearningEvent } from '../types/game';

const conceptNames: Record<Concept, string> = {
  integer: '整數運算',
  exponent: '指數記法',
  factor: '因數與倍數',
};

export type Recommendation =
  | { kind: 'review'; concept: Concept; title: string }
  | { kind: 'advance'; title: string };

export function recommendNextStep(events: LearningEvent[]): Recommendation {
  const review = summarizeByConcept(events).find((item) => item.correct < item.attempts || item.hintUses > 0);
  if (review) {
    return { kind: 'review', concept: review.concept, title: `建議先複習${conceptNames[review.concept]}` };
  }
  return { kind: 'advance', title: '可以挑戰下一個數學任務' };
}
