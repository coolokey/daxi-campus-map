import { cleanup, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { afterEach, expect, it, vi } from 'vitest';
import { DemoQuest } from './DemoQuest';
afterEach(cleanup);

it('completes five questions, preserves hint evidence and resets a new attempt', async () => {
  const user = userEvent.setup();
  render(<DemoQuest onClose={vi.fn()} />);
  await user.click(screen.getByRole('button', { name: '2' }));
  expect(screen.getByRole('status')).toHaveTextContent('以數線想像');
  for (const answer of ['8', '5', '16', '3 × 3 × 3', '6']) {
    await user.click(screen.getByRole('button', { name: answer }));
  }
  expect(screen.getByRole('heading', { name: '能源核心修復成功' })).toBeInTheDocument();
  expect(screen.getByRole('heading', { name: '教師摘要' })).toBeInTheDocument();
  expect(screen.getByText('建議先複習整數運算')).toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: '重新挑戰' }));
  expect(screen.getByText('1 / 5')).toBeInTheDocument();
  expect(screen.queryByRole('heading', { name: '教師摘要' })).not.toBeInTheDocument();
});

it('returns to exploration without completing a task', async () => {
  const onClose = vi.fn();
  render(<DemoQuest onClose={onClose} />);
  await userEvent.click(screen.getByRole('button', { name: '返回校園探索' }));
  expect(onClose).toHaveBeenCalledOnce();
});
