import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { expect, it, vi } from 'vitest';
import { CampusMap } from './CampusMap';

it('starts a conversation when the technology building is selected', async () => {
  const user = userEvent.setup();
  const onInteract = vi.fn();
  render(<CampusMap onInteract={onInteract} />);
  await user.click(screen.getByRole('button', { name: '科技館 數字研究員' }));
  expect(onInteract).toHaveBeenCalledWith('teacher-001');
});
