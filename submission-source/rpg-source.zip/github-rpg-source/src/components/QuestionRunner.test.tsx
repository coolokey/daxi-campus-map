import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { expect, it, vi } from 'vitest';
import { QuestionRunner } from './QuestionRunner';

it('shows a hint after a wrong answer and advances after a correct answer', async () => {
  const user = userEvent.setup();
  render(<QuestionRunner onComplete={vi.fn()} onEvent={vi.fn()} />);
  await user.click(screen.getByRole('button', { name: '2' }));
  expect(screen.getByText('以數線想像從 -3 走到 5。')).toBeInTheDocument();
  await user.click(screen.getByRole('button', { name: '8' }));
  expect(screen.getByText('2 / 5')).toBeInTheDocument();
});
