import { useEffect, useRef, useState } from 'react';
import { QuestionRunner } from './QuestionRunner';
import { TeacherSummary } from './TeacherSummary';
import { LearningRecommendation } from './LearningRecommendation';
import type { LearningEvent } from '../types/game';

export function DemoQuest({ onClose }: { onClose: () => void }) {
  const [events, setEvents] = useState<LearningEvent[]>([]);
  const [complete, setComplete] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const headingRef = useRef<HTMLHeadingElement>(null);
  useEffect(() => { headingRef.current?.focus(); }, [complete, attempt]);
  return <section className="demo-quest" aria-label="數學闖關體驗">
    <div className="quest-heading"><div><p className="eyebrow">CHAPTER 01 · 七年級數學</p><h2 ref={headingRef} tabIndex={-1}>{complete ? '能源核心修復成功' : '能源核心修復'}</h2></div><button className="secondary-button" onClick={onClose}>返回校園探索</button></div>
    {complete ? <>
      <p className="quest-reward">獲得「數字研究員徽章」。五個校準任務已完成，看看這次的概念回饋。</p>
      <TeacherSummary events={events} /><LearningRecommendation events={events} />
      <button className="primary-button return-button" onClick={() => { setEvents([]); setComplete(false); setAttempt(value => value + 1); }}>重新挑戰</button>
    </> : <><p>校園能源核心失去平衡。完成五個校準任務，一起修復它吧。答錯時可閱讀提示，再試一次。</p><QuestionRunner key={attempt} onEvent={event => setEvents(previous => [...previous, event])} onComplete={() => setComplete(true)} /></>}
    <p className="prototype-note">作答紀錄僅保留在本次體驗中。提示與建議採本機規則，生成式 AI 功能仍在規劃中。</p>
  </section>;
}
