import { useState } from 'react';
import { firstQuestQuestions } from '../data/questions';
import { gradeChoice } from '../domain/grading';
import type { LearningEvent } from '../types/game';

type Props = { onComplete: () => void; onEvent: (event: LearningEvent) => void };
export function QuestionRunner({ onComplete, onEvent }: Props) {
  const [index, setIndex] = useState(0); const [feedback, setFeedback] = useState(''); const [usedHint, setUsedHint] = useState(false); const question = firstQuestQuestions[index];
  const choose = (choice: number) => { const result = gradeChoice(question, choice); const eventUsedHint = usedHint || !result.correct; onEvent({ questionId: question.id, concept: question.concept, correct: result.correct, usedHint: eventUsedHint }); setFeedback(result.feedback); if (!result.correct) { setUsedHint(true); return; } if (index + 1 === firstQuestQuestions.length) { onComplete(); return; } setIndex((current) => current + 1); setFeedback(''); setUsedHint(false); };
  return <section aria-label="能源核心任務" className="question-runner"><p className="progress-label">{index + 1} / {firstQuestQuestions.length}</p><p className="concept-label">七年級數學校準任務</p><h2>{question.prompt}</h2><div className="choice-grid">{question.choices.map((choice, choiceIndex) => <button key={`${question.id}-${choice}`} className="choice-button" onClick={() => choose(choiceIndex)}>{choice}</button>)}</div>{feedback && <p role="status" className="feedback">{feedback}</p>}</section>;
}
