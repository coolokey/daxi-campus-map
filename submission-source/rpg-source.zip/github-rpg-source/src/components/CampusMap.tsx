import { locations } from '../data/locations';

export function CampusMap({ onInteract }: { onInteract: (npcId: string) => void }) {
  return <section aria-label="校園地圖" className="campus-map"><img src="/assets/maps/daxi-future-campus-rpg-v1.png" alt="大溪國中未來科技校園 RPG 地圖" />
    {locations.map((location) => <button key={location.id} className={`landmark ${location.npcId ? 'landmark--active' : ''}`} style={{ left: `${location.x}%`, top: `${location.y}%` }} onClick={() => location.npcId && onInteract(location.npcId)} disabled={!location.npcId} aria-label={location.npcId ? `${location.name} 數字研究員` : location.name}>{location.npcId ? '✦ ' : ''}{location.name}</button>)}
  </section>;
}
