import { createRoot } from 'react-dom/client';
import { DemoQuest } from '../components/DemoQuest';
export function mountQuest(container: HTMLElement, onClose: () => void) {
  createRoot(container).render(<DemoQuest onClose={onClose} />);
}
