import { describe, expect, it } from 'vitest';
import { movePlayer } from './movement';
describe('lightweight campus movement', () => {
  const world = { width: 1000, height: 1000, collisionZones: [{ x: 100, y: 0, width: 40, height: 300 }] };
  it('cannot cross a wall even after a delayed frame', () => {
    expect(movePlayer({ x: 80, y: 80 }, 1, 0, 2, world).x).toBeLessThanOrEqual(89);
  });
  it('normalizes diagonal movement', () => {
    const result = movePlayer({ x: 500, y: 500 }, 1, 1, 0.1, world);
    expect(Math.hypot(result.x - 500, result.y - 500)).toBeCloseTo(22);
  });
  it('slides along a wall and stays inside world bounds', () => {
    const result = movePlayer({ x: 88, y: 80 }, 1, 1, 0.1, world);
    expect(result.x).toBeLessThan(90); expect(result.y).toBeGreaterThan(80);
    expect(movePlayer({ x: 12, y: 12 }, -1, -1, 0.1, world).x).toBe(11);
  });
});
