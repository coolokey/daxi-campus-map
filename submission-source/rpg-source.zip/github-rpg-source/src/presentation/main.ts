import { campusMap } from '../game/data/maps/campus';
import { researchLabMap } from '../game/data/maps/research-lab';
import { presentationMap } from '../game/data/presentation';
import { movePlayer } from './movement';

const get = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
const canvas = get<HTMLCanvasElement>('world'), ctx = canvas.getContext('2d')!;
const status = get('world-status'), exploration = get('exploration'), quest = get('quest'), dialogue = get('dialogue');
const maps = { campus: presentationMap(campusMap, true), 'research-lab': presentationMap(researchLabMap, true) };
let map = maps.campus, player = { ...map.spawns['campus-start'] }, hiddenByParent = false, questOpen = false, questMounted = false, questLoading = false;
let ready = false, frame = 0, last = 0, previousPrompt = '';
const keys = new Set<string>(), image = new Image();
const active = () => ready && !hiddenByParent && !document.hidden && !questOpen && dialogue.hidden;
function pause() { cancelAnimationFrame(frame); frame = 0; keys.clear(); last = 0; }
function resume() { if (active() && !frame) frame = requestAnimationFrame(tick); }
function target() {
  const npc = map.npcs.find(n => Math.hypot(n.x - player.x, n.y - player.y) <= n.interactionRadius);
  const portal = map.portals.find(p => player.x >= p.trigger.x - 60 && player.x <= p.trigger.x + p.trigger.width + 60 && player.y >= p.trigger.y - 60 && player.y <= p.trigger.y + p.trigger.height + 60);
  return { npc, portal };
}
function draw() {
  const x = Math.max(0, Math.min(map.width - 1280, player.x - 640)), y = Math.max(0, Math.min(map.height - 720, player.y - 360));
  ctx.fillStyle = '#e4f2fa'; ctx.fillRect(0, 0, 1280, 720); ctx.save(); ctx.translate(-x, -y);
  if (map.id === 'campus') ctx.drawImage(image, 0, 0, map.width, map.height);
  else {
    ctx.fillStyle = '#d0e1ec'; ctx.fillRect(0, 0, map.width, map.height);
    ctx.fillStyle = '#f6fbff'; ctx.fillRect(72, 72, 1456, 816);
    ctx.fillStyle = '#54748a'; ctx.fillRect(690, 350, 290, 150);
    ctx.fillStyle = '#173f58'; ctx.font = 'bold 32px system-ui'; ctx.fillText('科技館・數學研究室', 600, 140);
  }
  for (const portal of map.portals) {
    const r = portal.trigger; ctx.fillStyle = '#17a0aa99'; ctx.fillRect(r.x, r.y, r.width, r.height);
    ctx.fillStyle = '#092f47'; ctx.font = 'bold 20px system-ui'; ctx.fillText(map.id === 'campus' ? '研究室入口' : '返回校園', r.x, r.y - 12);
  }
  for (const npc of map.npcs) {
    ctx.fillStyle = '#edb94d'; ctx.fillRect(npc.x - 13, npc.y - 17, 26, 34);
    ctx.fillStyle = '#173f58'; ctx.font = 'bold 18px system-ui'; ctx.textAlign = 'center'; ctx.fillText(npc.name, npc.x, npc.y - 26);
  }
  ctx.textAlign = 'left'; ctx.fillStyle = '#087ba8'; ctx.fillRect(player.x - 12, player.y - 16, 24, 32);
  ctx.fillStyle = '#fff'; ctx.fillRect(player.x - 8, player.y - 14, 16, 10); ctx.restore();
  const { npc, portal } = target();
  const prompt = npc ? `E／空白鍵：與 ${npc.name} 交談` : portal?.prompt ?? (map.id === 'campus' ? '校園探索中・右上方科技館可進入研究室' : '數學研究室・靠近助教後按 E 開始任務');
  if (prompt !== previousPrompt) { status.textContent = prompt; previousPrompt = prompt; }
}
function tick(now: number) {
  frame = 0; if (!active()) return;
  const dx = Number(keys.has('ArrowRight') || keys.has('d')) - Number(keys.has('ArrowLeft') || keys.has('a'));
  const dy = Number(keys.has('ArrowDown') || keys.has('s')) - Number(keys.has('ArrowUp') || keys.has('w'));
  player = { ...player, ...movePlayer(player, dx, dy, last ? (now - last) / 1000 : 0, map) };
  last = now; draw(); frame = requestAnimationFrame(tick);
}
async function openQuest() {
  if (questLoading || questOpen) return;
  questLoading = true; const button = get<HTMLButtonElement>('quest-start'); button.disabled = true;
  button.textContent = '正在準備數學任務……';
  try {
    if (!questMounted) {
      const { mountQuest } = await import('./quest');
      mountQuest(quest, () => { questOpen = false; quest.hidden = true; exploration.hidden = false; dialogue.hidden = true; resume(); canvas.focus(); });
      questMounted = true;
    }
    questOpen = true; pause(); exploration.hidden = true; quest.hidden = false;
    quest.querySelector<HTMLElement>('h2')?.focus();
  } catch { status.textContent = '任務下載失敗，請再按一次重試。'; }
  finally { questLoading = false; button.disabled = false; button.textContent = '快速體驗數學任務'; }
}
function interact() {
  if (!dialogue.hidden) { dialogue.hidden = true; resume(); canvas.focus(); return; }
  if (!active()) return;
  const { npc, portal } = target();
  if (npc) {
    if (map.id === 'research-lab') void openQuest();
    else { dialogue.hidden = false; pause(); get('dialogue-close').focus(); }
  } else if (portal) {
    map = maps[portal.destinationMapId]; player = { ...map.spawns[portal.destinationSpawnId] }; keys.clear(); draw();
  }
}
window.addEventListener('keydown', event => {
  if (questOpen || hiddenByParent || event.target instanceof HTMLButtonElement) return;
  const key = event.key.length === 1 ? event.key.toLowerCase() : event.key;
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'w', 'a', 's', 'd', 'e', ' '].includes(key)) {
    event.preventDefault(); if (key === 'e' || key === ' ') { if (!event.repeat) interact(); } else keys.add(key);
  }
});
window.addEventListener('keyup', e => keys.delete(e.key.length === 1 ? e.key.toLowerCase() : e.key));
window.addEventListener('blur', () => keys.clear());
document.addEventListener('visibilitychange', () => { pause(); resume(); });
window.addEventListener('message', event => {
  if (event.origin !== location.origin || event.source !== parent || event.data?.type !== 'proposal:visibility') return;
  hiddenByParent = !event.data.visible; pause(); resume();
});
document.querySelectorAll<HTMLButtonElement>('[data-key]').forEach(button => {
  button.addEventListener('pointerdown', event => { event.preventDefault(); button.setPointerCapture(event.pointerId); keys.add(button.dataset.key!); canvas.focus(); });
  for (const name of ['pointerup', 'pointercancel', 'lostpointercapture']) button.addEventListener(name, () => keys.delete(button.dataset.key!));
});
get('interact').onclick = interact; get('dialogue-close').onclick = interact; get('quest-start').onclick = () => void openQuest();
image.onload = () => {
  ready = true; draw(); resume();
  if (new URLSearchParams(location.search).has('profile')) console.info('RPG_STARTUP', JSON.stringify({ readyMs: Math.round(performance.now()), resources: performance.getEntriesByType('resource').map(entry => ({ name: entry.name.split('/').pop(), ms: Math.round(entry.duration), bytes: (entry as PerformanceResourceTiming).transferSize })) }));
};
image.onerror = () => { status.textContent = '地圖暫時下載失敗，可先體驗數學任務，或按重新載入。'; const retry = document.createElement('button'); retry.textContent = '重新載入地圖'; retry.onclick = () => { retry.remove(); image.src = `${image.src.split('?')[0]}?retry=${Date.now()}`; }; status.append(retry); };
image.src = new URL('./assets/maps/daxi-future-campus-rpg-v1.webp', document.baseURI).href;
