import type { MapConfig } from '../game/data/types';
export function movePlayer(position: { x: number; y: number }, dx: number, dy: number, seconds: number, world: Pick<MapConfig, 'width' | 'height' | 'collisionZones'>) {
  const result = { ...position }, length = Math.hypot(dx, dy);
  if (!length) return result;
  const distance = 220 * Math.min(Math.max(seconds, 0), 0.1), steps = Math.max(1, Math.ceil(distance / 5));
  const blocked = (x: number, y: number) => world.collisionZones.some(r => x + 11 > r.x && x - 11 < r.x + r.width && y + 11 > r.y && y - 11 < r.y + r.height);
  for (let i = 0; i < steps; i++) {
    const x = Math.max(11, Math.min(world.width - 11, result.x + dx / length * distance / steps));
    if (!blocked(x, result.y)) result.x = x;
    const y = Math.max(11, Math.min(world.height - 11, result.y + dy / length * distance / steps));
    if (!blocked(result.x, y)) result.y = y;
  }
  return result;
}
