export type Concept = 'integer' | 'exponent' | 'factor';

export type ChoiceQuestion = {
  id: string;
  grade: 7;
  concept: Concept;
  prompt: string;
  choices: string[];
  answer: number;
  hint: string;
  explanation: string;
};

export type Location = {
  id: string;
  name: string;
  x: number;
  y: number;
  npcId?: string;
};

export type LearningEvent = {
  questionId: string;
  concept: Concept;
  correct: boolean;
  usedHint: boolean;
};
