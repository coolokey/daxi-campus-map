import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

export default defineConfig(({ command }) => ({
  resolve: { alias: command === 'build' ? [{ find: /^phaser$/, replacement: fileURLToPath(new URL('./src/game/phaser-lite.cjs', import.meta.url)) }] : [] },
  define: { global: 'globalThis' },
  build: { rollupOptions: { input: { main: fileURLToPath(new URL('./index.html', import.meta.url)), presentation: fileURLToPath(new URL('./presentation.html', import.meta.url)) } } },
  plugins: [react(), {
    name: 'campus-phaser-features', enforce: 'pre',
    transform(code, id) {
      if (command !== 'build' || !id.replace(/\\/g, '/').includes('/phaser/src/')) return;
      // Same feature switches as Phaser's official webpack build, for this Canvas-only game.
      return code.replace(/typeof (CANVAS_RENDERER|WEBGL_RENDERER|WEBGL_DEBUG|EXPERIMENTAL|PLUGIN_3D|PLUGIN_CAMERA3D|PLUGIN_FBINSTANT|FEATURE_SOUND)\b/g,
        (_, feature) => feature === 'CANVAS_RENDERER' ? 'true' : 'false');
    },
  }, {
    name: 'campus-startup-preloads',
    generateBundle: { order: 'post', handler(_, bundle) {
      const html = bundle['index.html'];
      if (html?.type !== 'asset') return;
      const chunks = Object.values(bundle).filter(item => item.type === 'chunk' && /phaser-lite|game-config/.test(item.fileName));
      const links = chunks.map(chunk => `<link rel="modulepreload" href="./${chunk.fileName}">`).join('');
      html.source = String(html.source).replace('</head>', `${links}<link rel="preload" as="image" href="./assets/maps/daxi-future-campus-rpg-v1.webp" fetchpriority="high"></head>`);
    } },
  }],
  test: { environment: 'jsdom', setupFiles: './src/test/setup.ts' },
}));
