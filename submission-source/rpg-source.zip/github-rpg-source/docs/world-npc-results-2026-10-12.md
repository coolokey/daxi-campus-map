# 未來科技校園 RPG 升級驗收

日期：2026-10-12。正確專案：F:\1151005---創意教學\future-campus-rpg。
預覽：http://127.0.0.1:8766/；輕量展示入口：http://127.0.0.1:8766/presentation.html。
原 8765 為另一個專案，未撤銷其修改。本輪未部署至公開網站。

## 完成行為

- 校園比例 1／1.5／2 倍，預設 1.5，分別為 2400 × 1624／3600 × 2436／4800 × 3248。保持原背景長寬比、碰撞區／NPC／出生點／科技館入口的相對位置。人物速度維持 220 單位／秒，尺寸不隨地圖放大。縮小邊界時校正安全位置。
- Phaser 主鏡頭持續跟隨；Canvas 展示入口亦沿用跟隨鏡頭。研究室保留 1600 × 960，返回校園套用選定比例。
- 桌機小地圖固定在遊戲左下方、搖桿上方；窄螢幕改為遊戲下方左側以維持可讀性。標示玩家位置／面向、NPC、建築碰撞輪廓與入口。進入研究室切換室內平面示意。全圖支援點選導航、鍵盤調整目標；提供方向及距離，沒有自動尋路或避障導航。
- 校園保留原教師 NPC，加入 2 位虛構學生與 1 台巡邏機器人，共 4 位；教師與新增角色均可巡邏。學生／機器人為原創簡易角色，標示 NPC。巡邏依共用資料路線、防穿牆、接近人物時停下；對話、全圖與數學任務暫停探索。按 E／空白鍵或互動按鈕交談。研究室原有角色與能源核心題目保留。
- Phaser 小螢幕增加 48px 觸控移動與互動按鈕，與小地圖分開。展示頁保留既有原生觸控按鈕。

## 驗證

1. 修改前原有 20 個測試檔／30 項測試通過。最終 21 個測試檔／37 項測試通過：`pnpm exec vitest run --maxWorkers=1`。
2. 新增核心測試對三種比例各模擬 10 分鐘巡邏，逐步檢查 NPC 與碰撞區不重疊、移動與暫停；另測所有地圖座標層同步、來源未變與縮小安全位置。
3. `pnpm run build` 通過 TypeScript 與 Vite 生產建置。既有 Phaser 引擎 chunk 仍有超過 500 KB 提示，不是建置失敗。
4. `node scripts/verify-startup.mjs` 通過：全部 JS 約 868 KB，低於既有 900 KB 預算；展示入口初始模組約 19.3 KB，低於 20 KB 預算；數學題目按需載入。
5. `node scripts/verify-world-npc.cjs` 在生產預覽驗證兩入口：NPC 真實移動、三種比例、全圖暫停／導航、NPC 對話凍結人物、切換比例關閉對話後正常移動、沿道路走到原門口／研究室／返回、原數學任務開啟與返回。另驗證桌機 1440 × 1100、平板 820 × 1180、手機 390 × 844 與 320 × 568，無水平溢出，小地圖與操作區不重疊；CDP 觸控按住能移動人物。
6. 主入口另檢查既有教師素材正常載入。結果 JSON 與截圖在 `output/world-npc-qa/`；瀏覽器執行錯誤為 0。
7. `public` 全部素材與備份逐檔雜湊比對：0 項變更。未更動原地圖、人物肖像或其他素材。
8. 獨立程式審查發現並修正兩項操作回歸：展示頁按鈕焦點吞掉方向鍵，以及 Phaser 對話中切換比例殘留對話卻解除暫停。

瀏覽器測試為 Edge／Chromium 與觸控／尺寸模擬，尚未使用實體 iPad、iPhone 或 Safari。沒有測量每秒影格或 20～30 人線上負載，不將功能測試當作效能數據。現有單圖與 4 個校園矩形碰撞保持沿用，尚未逐棟重新核對官方平面圖。

## 修改清單

新增：

- `src/game/core/world.ts`：座標縮放、安全位置、NPC 巡邏與共用快照。
- `src/game/core/world.test.ts`：比例、來源保護、巡邏碰撞、暫停、安全位置。
- `src/game/data/residents.ts`：虛構學生／機器人路線與對話。
- `src/game/entities/WorldActors.ts`：Phaser NPC 呈現與更新。
- `src/game/world-hud.ts`：兩入口共用小地圖／全圖／導航與手機按鈕。
- `scripts/verify-world-npc.cjs`：生產瀏覽器驗收。
- `docs/world-npc-upgrade-2026-10-12.md`、本報告與 `output/world-npc-qa/`。

修改：

- `src/game/data/types.ts`、`src/game/data/maps/campus.ts`：可選巡邏設定、原教師路線。
- `src/game/GameShell.tsx`：HUD 與觸控事件生命週期。
- `src/game/scenes/CampusScene.ts`：縮放、NPC、快照、暫停。
- `src/game/scenes/ResearchLabScene.ts`：室內快照與全圖暫停。
- `src/game/scenes/UIScene.ts`：外部互動按鈕事件。
- `src/presentation/main.ts`、`src/presentation/movement.ts`：展示入口共用世界與巡邏。
- `src/styles.css`、`presentation.html`：地圖與觸控版面。
- `vite.config.ts`：測試搜尋限制為現行 src，避免掃入備份。
- `scripts/verify-startup.mjs`：相容 Vite 預設絕對資源 URL 的檢查。
- `dist/`、`tsconfig.tsbuildinfo`：建置產物重新產生。

## 備份與後續範圍

備份：`backups/before-world-npc-20261012-133614/`，包含 src、public、docs、scripts、入口與設定。還原時關閉預覽／開發伺服器，複製備份覆蓋對應檔案，移除上述新增檔案，再執行建置。

現有資料只有 campus／research-lab，沒有樓梯、完整樓層／教室、多年級題庫匯入、探索彩蛋狀態或校慶隱藏任務。這些並未宣稱完成。後續先補資料階層與任務結構，再做真正多人後端。現場沒有登入／資料庫／即時服務；所有 NPC 都是本機模擬，不顯示虛構在線人數、不收集學生個資。多人伺服器、隱私協定與房間負載測試另階段實作。
