"""Read-only source register. Never overwrites the guide or original plan."""
import hashlib, json, pathlib, shutil
root=pathlib.Path(__file__).resolve().parent.parent
plan=root.parent/'大溪國中平面圖-115學年.jpg'
shared=json.loads((root/'public/data/campus.shared.json').read_text(encoding='utf-8'))
# Bounds are visual reference crops on the supplied 1612 x 1092 plan, not survey measurements.
specs=[
 ('gym-bld',[298,797,554,998],[1],[520,855]),
 ('recycle-bld',[197,801,251,881],[1],[300,805]),
 ('admin-front',[771,788,940,864],[1,2,3],[900,740]),
 ('admin-back',[772,692,939,769],[1,2,3],[900,515]),
 ('health-bld',[992,570,1101,630],[1,2],[1015,490]),
 ('grade8-front',[986,893,1130,981],[1,2,3],[1030,870]),
 ('grade9-back',[992,722,1101,831],[1,2,3],[1030,720]),
 ('grade8-mid',[1128,723,1238,892],[1,2,3],[1205,750]),
 ('new-grade7',[1286,237,1539,351],[1,2,3],[1205,170]),
 ('multi-building',[1287,360,1526,544],[1,2],[1205,360]),
 ('tech-building',[1287,607,1463,754],[1,2],[1268,542]),
 ('art-building',[1287,798,1379,935],[1,2,3,4],[1210,825]),
]
rows=[]
for bid,bounds,levels,anchor in specs:
 b=next(b for b in shared['buildings'] if b['id']==bid)
 reason='已放大核對側翼橫向 1F／2F／3F 標示：704 在 2F、708 在 3F，與導覽資料一致。' if bid=='new-grade7' else '活動中心僅開放正式圖可確認的 1F；2F／3F 保留待核對。' if bid=='gym-bld' else '樓層可由正式圖核對；室內尺寸、門與梯段沿用導覽示意，非實測。'
 rows.append({'buildingId':bid,'name':b['name'],'planBounds':bounds,'enabledLevels':levels,'artAnchor':anchor,'geometryStatus':'schematic','note':reason})
data={'version':1,'schoolYear':115,'plan':{'file':'assets/maps/campus-plan-115.jpg','sha256':hashlib.sha256(plan.read_bytes()).hexdigest(),'width':1612,'height':1092},'buildings':rows,'roomOverrides':[{'roomId':next(r['id'] for r in shared['rooms'] if r['buildingId']=='new-grade7' and r['name'].startswith('706')),'name':'706 教室 (3F)','evidence':'正式圖 A32 標示 706；取消來源中的遊戲主題別名'},{'roomId':'tech-building:TC-NE-2','name':'科技創作教室 (2F)','evidence':'正式圖科技館右上方 2F 標示'}],'rooms':[{'roomId':r['id'],'buildingId':r['buildingId'],'floorId':r['floorId'],'sourceName':r['name'],'nameStatus':'pending' if '待確認' in r['name'] else 'guide-source-needs-room-check','geometryStatus':'schematic','enabled':int(r['floorId'].split('-')[-1]) in next(b['enabledLevels'] for b in rows if b['buildingId']==r['buildingId'])} for r in shared['rooms']]}
data['mentors']=[{'roomId':'tech-building:TC-N-2','characterId':'staff-014','name':'陳小鈴老師','questId':'energy-core','placementStatus':'game-placement-not-actual-office'}]
(root/'public/data/campus-plan-115.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copyfile(plan,root/'public/assets/maps/campus-plan-115.jpg')
lines=['# 115 學年度正式平面圖對照表','','原始圖 SHA-256：'+data['plan']['sha256'],'','室外彩色圖入口為遊戲錨點；正式圖區域為對照裁切範圍。兩者不可當成相同投影或實測座標。','','| 共用 ID | 建築 | 開放樓層 | 核對說明 |','|---|---|---|---|']
for b in rows:lines.append('| '+b['buildingId']+' | '+b['name']+' | '+('、'.join(str(v)+'F' for v in b['enabledLevels']) or '暫緩')+' | '+b['note']+' |')
lines+=['','## 教室逐項登錄','','| 教室 ID | 來源名稱 | 樓層 ID | 狀態 |','|---|---|---|---|']
for r in data['rooms']:lines.append('| '+r['roomId']+' | '+r['sourceName']+' | '+r['floorId']+' | '+('開放示意' if r['enabled'] else '暫緩')+'／'+r['nameStatus']+' |')
lines+=['','已核對修正：TC-NE-2 為科技創作教室。其他待確認名稱保留，不依模糊文字猜測。']
(root/'docs/115-plan-crosswalk.md').write_text('\n'.join(lines),encoding='utf-8')
print(f'{len(rows)} building records, {sum(len(b["enabledLevels"]) for b in rows)} open floors, {len(data["rooms"])} room records')
