"""Read-only source register. Never overwrites the guide or original plan."""
import hashlib, json, pathlib, shutil
root=pathlib.Path(__file__).resolve().parent.parent
plan=root.parent/'大溪國中平面圖-115學年.jpg'
shared=json.loads((root/'public/data/campus.shared.json').read_text(encoding='utf-8'))
# Bounds are visual reference crops on the supplied 1612 x 1092 plan, not survey measurements.
specs=[
 ('gym-bld',[298,797,554,998],[1],[520,855]),
 ('recycle-bld',[197,801,251,881],[1],[300,805]),
 ('admin-front',[771,788,940,864],[1,2,3],[900,740]),
 ('admin-back',[772,692,939,769],[1,2,3],[900,515]),
 ('health-bld',[992,570,1101,630],[1,2],[1015,490]),
 ('grade8-front',[986,893,1130,981],[1,2,3],[1030,870]),
 ('grade9-back',[992,722,1101,831],[1,2,3],[1030,720]),
 ('grade8-mid',[1128,723,1238,892],[1,2,3],[1205,750]),
 ('new-grade7',[1286,237,1539,351],[1,2,3],[1205,170]),
 ('multi-building',[1287,360,1526,544],[1,2],[1205,360]),
 ('tech-building',[1287,607,1463,754],[1,2],[1268,542]),
 ('art-building',[1287,798,1379,935],[1,2,3,4],[1210,825]),
]
rows=[]
for bid,bounds,levels,anchor in specs:
 b=next(b for b in shared['buildings'] if b['id']==bid)
 reason='已放大核對側翼橫向 1F／2F／3F 標示：704 在 2F、708 在 3F，A21 家長會、A31 教師會已正名。' if bid=='new-grade7' else '活動中心開放 1F 大禮堂、消防機房與男女廁；2F 看台區為挑空看台。' if bid=='gym-bld' else '依 115 學年度平面圖與空拍實景完成 1F–3F 處室、教室、專科教室、廁所與樓梯相對位置核對。'
 rows.append({'buildingId':bid,'name':b['name'],'planBounds':bounds,'enabledLevels':levels,'artAnchor':anchor,'geometryStatus':'schematic','note':reason})
overrides=[
 {'roomId':'admin-front:ADM-F-1','name':'八、九年級導師室 (1F)','evidence':'行政大樓前棟 1F 為八、九年級導師室（含中央穿堂方案 C 對照）'},
 {'roomId':'admin-front:ADM-F-2C','name':'油印室 (2F)','evidence':'115 平面圖行政大樓前棟 2F 校長室與穿堂間為油印室'},
 {'roomId':'admin-back:ADM-B-1W','name':'學務處 (1F)','evidence':'行政大樓後棟 1F 西側為學務處'},
 {'roomId':'admin-back:ADM-B-1C','name':'學務處（西側辦公區） (1F)','evidence':'方案 C 行政大樓後棟 1F 西側完整大格為學務處'},
 {'roomId':'admin-back:ADM-B-1E1','name':'會客室 (1F)','evidence':'方案 C 行政大樓後棟 1F 東側上方為會客室'},
 {'roomId':'admin-back:ADM-B-1E2','name':'教練室 (1F)','evidence':'方案 C 行政大樓後棟 1F 東側下方為教練室'},
 {'roomId':'health-bld:511','name':'511 健康中心 (1F)','evidence':'115 平面圖 511 為健康中心'},
 {'roomId':'health-bld:512','name':'512 員生合作社 (1F)','evidence':'115 平面圖 512 為員生合作社'},
 {'roomId':'health-bld:521','name':'521 檔案室 (2F)','evidence':'115 平面圖健康中心棟 2F 521 為檔案室'},
 {'roomId':'health-bld:522','name':'522 檔案室 (2F)','evidence':'115 平面圖健康中心棟 2F 522 為檔案室'},
 {'roomId':'grade9-back:223','name':'社團教室一 (2F)','evidence':'115 平面圖九年級棟 2F 223 為社團教室一'},
 {'roomId':'grade8-mid:315','name':'體育器材室 (1F)','evidence':'115 平面圖八年級中棟 1F 315 為體育器材室'},
 {'roomId':'grade8-mid:314','name':'輕艇隊訓練室 (1F)','evidence':'115 平面圖八年級中棟 1F 314 為輕艇隊訓練室'},
 {'roomId':'grade8-mid:325','name':'志工／校友辦公室 (2F)','evidence':'115 平面圖八年級中棟 2F 325 為志工辦公室／校友辦公室'},
 {'roomId':'grade8-mid:324','name':'訓育設備及器材室 (2F)','evidence':'115 平面圖八年級中棟 2F 324 為訓育設備及器材室'},
 {'roomId':'grade8-mid:323','name':'教學設備器材室 (2F)','evidence':'115 平面圖八年級中棟 2F 323 為教學設備器材室'},
 {'roomId':'grade8-mid:335','name':'生涯發展教室 (3F)','evidence':'115 平面圖八年級中棟 3F 335 為生涯發展教室'},
 {'roomId':'grade8-mid:332','name':'教材製作室 (3F)','evidence':'115 平面圖八年級中棟 3F 332 為教材製作室'},
 {'roomId':'grade8-front:431','name':'本土語教室 (3F)','evidence':'115 平面圖八年級南棟 3F 431 為本土語教室'},
 {'roomId':'new-grade7:A14','name':'資源班 3／4 教室 (1F)','evidence':'115 平面圖七年級棟 1F A14 為資源班 4／資源班 3'},
 {'roomId':'new-grade7:A15','name':'特教教室 2 (1F)','evidence':'115 平面圖七年級棟 1F A15 為特教教室 2'},
 {'roomId':'new-grade7:A21','name':'家長會辦公室 (2F)','evidence':'115 平面圖七年級棟 2F A21 為家長會辦公室'},
 {'roomId':'new-grade7:A31','name':'教師會辦公室 (3F)','evidence':'115 平面圖七年級棟 3F A31 為教師會辦公室'},
 {'roomId':'new-grade7:A32','name':'706 教室 (3F)','evidence':'正式圖 A32 標示 706；取消來源中的遊戲主題別名'},
 {'roomId':'new-grade7:A35','name':'七年級導師室 (3F)','evidence':'115 平面圖七年級棟 3F A35 為導師室'},
 {'roomId':'multi-building:614','name':'特教班 (1F)','evidence':'115 平面圖綜合大樓 1F 614 為特教班'},
 {'roomId':'multi-building:612','name':'資源班 1／2 教室 (1F)','evidence':'115 平面圖綜合大樓 1F 612 為資源班 2／1'},
 {'roomId':'multi-building:622','name':'資訊機房 (2F)','evidence':'115 平面圖綜合大樓 2F 622 為資訊機房'},
 {'roomId':'multi-building:623','name':'諮商會議室 (2F)','evidence':'115 平面圖綜合大樓 2F 623 為諮商會議室'},
 {'roomId':'tech-building:TC-SW-1','name':'生物實驗室 (1F)','evidence':'115 平面圖科技館 1F 西南側為生物實驗室'},
 {'roomId':'tech-building:TC-NW-2','name':'科中辦公室 (2F)','evidence':'115 平面圖科技館 2F 西北側為科中辦公室（自造中心辦公室）'},
 {'roomId':'tech-building:TC-SW-2','name':'科技智慧教室 (2F)','evidence':'115 平面圖科技館 2F 西南側為科技智慧教室'},
 {'roomId':'tech-building:TC-NE-2','name':'科技創作教室 (2F)','evidence':'正式圖科技館右上方 2F 標示'},
 {'roomId':'art-building:ART-2','name':'音樂教室（第一音樂教室） (2F)','evidence':'115 平面圖藝術館 2F 為第一音樂教室'},
 {'roomId':'art-building:ART-3','name':'音樂教室（第二音樂教室） (3F)','evidence':'115 平面圖藝術館 3F 為第二音樂教室'},
 {'roomId':'gym-bld:GYM-2','name':'活動中心看台區 (2F)','evidence':'實景與平面圖確認活動中心 2F 為看台區'}
]
override_map={o['roomId']:o['name'] for o in overrides}
data={'version':1,'schoolYear':115,'plan':{'file':'assets/maps/campus-plan-115.jpg','sha256':hashlib.sha256(plan.read_bytes()).hexdigest(),'width':1612,'height':1092},'buildings':rows,'roomOverrides':overrides,'rooms':[{'roomId':r['id'],'buildingId':r['buildingId'],'floorId':r['floorId'],'sourceName':override_map.get(r['id'],r['name']),'nameStatus':'plan-checked','geometryStatus':'schematic','enabled':int(r['floorId'].split('-')[-1]) in next(b['enabledLevels'] for b in rows if b['buildingId']==r['buildingId'])} for r in shared['rooms']]}
data['mentors']=[{'roomId':'tech-building:TC-N-2','characterId':'staff-014','name':'陳小鈴老師','questId':'energy-core','placementStatus':'game-placement-not-actual-office'}]
(root/'public/data/campus-plan-115.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
shutil.copyfile(plan,root/'public/assets/maps/campus-plan-115.jpg')
lines=['# 115 學年度正式平面圖對照表','','原始圖 SHA-256：'+data['plan']['sha256'],'','室外彩色圖入口為遊戲錨點；正式圖區域為對照裁切範圍。兩者不可當成相同投影或實測座標。','','| 共用 ID | 建築 | 開放樓層 | 核對說明 |','|---|---|---|---|']
for b in rows:lines.append('| '+b['buildingId']+' | '+b['name']+' | '+('、'.join(str(v)+'F' for v in b['enabledLevels']) or '暫緩')+' | '+b['note']+' |')
lines+=['','## 教室逐項登錄','','| 教室 ID | 核對後名稱 | 樓層 ID | 狀態 |','|---|---|---|---|']
for r in data['rooms']:lines.append('| '+r['roomId']+' | '+r['sourceName']+' | '+r['floorId']+' | '+('開放示意' if r['enabled'] else '暫緩')+'／'+r['nameStatus']+' |')
lines+=['','已依據 115 學年度各大樓一至三樓相對位置圖完成全校處室、班級、專科教室與行政大樓 1F 方案 C 名稱核對。']
(root/'docs/115-plan-crosswalk.md').write_text('\n'.join(lines),encoding='utf-8')
print(f'{len(rows)} building records, {sum(len(b["enabledLevels"]) for b in rows)} open floors, {len(data["rooms"])} room records, {len(overrides)} overrides')

