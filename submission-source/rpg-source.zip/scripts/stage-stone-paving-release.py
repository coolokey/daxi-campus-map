from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-color-stages-release.py'),run_name='__main__')
release=source.parent/'rpg2-release'
f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='stone-paving-numbered-three-centers'
m['visualTheme']['ground']='imagegen stone paver texture in world coordinates; source sports fields, planting and roadway retained'
m['visualTheme']['groundTexture']={'file':'assets/'+next((source/'dist/assets').glob('stone-paving-v1-*.webp')).name,'bytes':177876,'generation':'built-in imagegen; source PNG retained in source archive','projection':'world-space isometric repeated material'}
m['threeCenters']['stageTracker']='01-03 numbered badges, current/locked/completed text, clue-question-next flow and world marker numbers'
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/stone-paving';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/stone-paving-release.md',source/'output/stone-paving-qa/results.json',source/'output/stone-paving-qa/imagegen-prompt.txt']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
