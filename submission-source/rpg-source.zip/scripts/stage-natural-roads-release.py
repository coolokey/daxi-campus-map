from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-meadow-reference-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='natural-meadow-roads'
m['meadowTheme']['roads']={'surfaces':['gate forecourt driveway','palm avenue','ecological trail approach','building entrance aprons'],'material':'warm earth with irregular inward edges, gravel and grass fringe','defaultGrayCarriagewayRemoved':True,'geometryChanged':False,'collisionChanged':False,'offscreenCulling':True,'aerialReferencesReviewed':11,'photoDerivedSurvey':False}
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/natural-roads';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/natural-roads-release.md',source/'docs/superpowers/plans/2026-10-31-natural-roads.md',source/'output/natural-roads-qa/results.json']:shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
