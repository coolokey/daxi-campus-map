from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-natural-roads-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='official-plan-road-network'
m['roadNetwork']={'file':'campus-roads-v1.json','pavingRects':6,'entrancePaths':4,'source':'official plan topology with existing guide schematic coordinates','minimapSharedData':True,'newRoads':['east north-south driveway','north teaching breezeway','south teaching breezeway','health-center breezeway'],'collisionChanged':False,'portalsChanged':False,'surveyedGeometry':False,'testsPassed':164}
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/plan-roads';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/plan-roads-release.md',source/'docs/superpowers/plans/2026-10-31-plan-roads.md',source/'output/plan-roads-qa/results.json']:shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
