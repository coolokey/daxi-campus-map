from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-sunny-release.py'),run_name='__main__')
release=source.parent/'rpg2-release'
f=release/'public/proposal/rpg/data/manifest.json'
m=json.loads(f.read_text(encoding='utf-8'));m['stage']='building-colors-three-center-stages'
m['visualTheme']['buildings']='11 distinct coordinated facade, side and roof palettes by building ID'
m['visualTheme']['ground']='meadow ribbons, flower flecks, entrance promenade and tiled building aprons'
m['threeCenters']['stageTracker']='persistent ordered steps with navigation, discovery, challenge and completion actions'
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/color-stages';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/color-stages-release.md',source/'output/color-stages-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
