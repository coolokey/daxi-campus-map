const path=require('node:path'),fs=require('node:fs'),assert=require('node:assert/strict');
const {chromium}=require(process.env.CAMPUS_PLAYWRIGHT_MODULE||path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));
(async()=>{
  const out='output/world-npc-qa';fs.mkdirSync(out,{recursive:true});
  const browser=await chromium.launch({channel:'msedge',headless:true});const results=[],errors=[];
  try {
    for(const entry of ['/?presentation=1','/presentation.html']) {
      const page=await browser.newPage({viewport:{width:1440,height:1100},hasTouch:true});
      page.on('pageerror',e=>errors.push(entry+': '+e.message));
      await page.addInitScript(()=>window.addEventListener('campus:snapshot',e=>{window.testWorld=e.detail;window.snapshotCount=(window.snapshotCount||0)+1;}));
      await page.goto('http://127.0.0.1:8766'+entry);await page.waitForFunction(()=>window.testWorld?.map.width===3600);
      const before=await page.evaluate(()=>testWorld.npcs.map(n=>({x:n.x,y:n.y})));
      await page.waitForFunction(before=>testWorld.npcs.some((n,i)=>n.kind&&Math.hypot(n.x-before[i].x,n.y-before[i].y)>10),before);
      results.push(entry+' autonomous NPC movement PASS');
      for(const scale of [1,2,1.5,1]){
        await page.getByLabel('校園世界比例').selectOption(String(scale));
        await page.waitForFunction(w=>testWorld.map.width===w,2400*scale);
        assert.equal(await page.evaluate(()=>testWorld.map.portals[0].trigger.x),1945*scale);
        assert.equal(await page.evaluate(()=>testWorld.map.width/testWorld.map.height),2400/1624);
      }
      results.push(entry+' all scales, portals, aspect ratio PASS');
      await page.getByLabel('開啟校園全圖與導航').click();await page.waitForSelector('dialog[open]');
      const paused=await page.evaluate(()=>testWorld.npcs.map(n=>({x:n.x,y:n.y})));
      await page.waitForTimeout(350);assert.deepEqual(await page.evaluate(()=>testWorld.npcs.map(n=>({x:n.x,y:n.y}))),paused);
      await page.locator('dialog canvas').click({position:{x:260,y:180}});await page.waitForSelector('dialog[open]',{state:'hidden'});
      await page.waitForFunction(()=>document.querySelector('.world-minimap span').textContent.includes('目標'));
      results.push(entry+' full map pauses NPCs, click navigation PASS');
      // Position only the test NPC alongside the actual player to exercise the real dialogue path.
      await page.evaluate(()=>{const n=testWorld.npcs.find(n=>n.kind==='student');n.route=undefined;n.x=testWorld.player.x+40;n.y=testWorld.player.y;});
      await page.waitForTimeout(150);
      const canvas=page.locator('.game-shell > canvas');await canvas.click({position:{x:400,y:200}});
      await page.keyboard.press('e');await page.waitForTimeout(180);
      if(entry.startsWith('/?')) await page.waitForFunction(()=>testWorld.npcs.find(n=>n.kind==='student')&&testWorld.player);
      else await page.waitForSelector('#dialogue:not([hidden])');
      const pos=await page.evaluate(()=>({x:testWorld.player.x,y:testWorld.player.y}));
      await page.keyboard.down('ArrowRight');await page.waitForTimeout(300);await page.keyboard.up('ArrowRight');
      assert.deepEqual(await page.evaluate(()=>({x:testWorld.player.x,y:testWorld.player.y})),pos);
      if(entry.startsWith('/?')) {
        await page.getByLabel('校園世界比例').selectOption('2');await page.waitForFunction(()=>testWorld.map.width===4800);await page.waitForTimeout(150);
        const x=await page.evaluate(()=>testWorld.player.x);await page.keyboard.down('ArrowRight');await page.waitForTimeout(200);await page.keyboard.up('ArrowRight');assert.ok(await page.evaluate(x=>testWorld.player.x>x+10,x));
        await page.getByLabel('校園世界比例').selectOption('1');await page.waitForFunction(()=>testWorld.map.width===2400);await page.waitForTimeout(150);
        results.push(entry+' scaling closes dialogue and resumes safely PASS');
      } else await page.keyboard.press('e');
      results.push(entry+' NPC interaction freezes player PASS');
      // Walk through the original campus door along existing open roads.
      async function drive(key,axis,dest) {
        await page.keyboard.down(key);
        try {await page.waitForFunction(({axis,dest,key})=>key==='ArrowUp'||key==='ArrowLeft'?testWorld.player[axis]<=dest:testWorld.player[axis]>=dest,{axis,dest,key},{timeout:12000});}
        finally{await page.keyboard.up(key);}
      }
      await drive('ArrowUp','y',890);await drive('ArrowRight','x',1990);
      await page.keyboard.press('e');await page.waitForFunction(()=>testWorld.map.id==='research-lab');
      assert.equal(await page.evaluate(()=>testWorld.map.width),1600);
      await page.waitForFunction(()=>document.querySelector('.world-minimap span').textContent.includes('研究室'));
      await page.keyboard.press('e');await page.waitForFunction(()=>testWorld.map.id==='campus');
      assert.equal(await page.evaluate(()=>testWorld.map.width),2400);
      results.push(entry+' real door indoor minimap and return PASS');
      await page.getByRole('button',{name:'快速體驗數學任務'}).click();await page.waitForSelector('.demo-quest');
      assert.ok(await page.getByText('能源核心修復',{exact:false}).count());
      const ret=page.getByRole('button',{name:/返回校園/});await ret.first().click();
      results.push(entry+' existing math task opens and returns PASS');
      for(const [name,width,height] of [['desktop',1440,1100],['ipad',820,1180],['mobile',390,844],['mobile-small',320,568]]) {
        await page.setViewportSize({width,height});await page.waitForTimeout(180);
        assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
        const mini=await page.locator('.world-minimap').boundingBox();assert.ok(mini.width>=170);
        if(width<=760){const world=await canvas.boundingBox();assert.ok(mini.y>=world.y+world.height-2);}
        await page.locator('.world-minimap').tap();await page.waitForSelector('dialog[open]');
        await page.getByRole('button',{name:'返回探索',exact:true}).tap();
        if(width===390 && entry.startsWith('/?')) {
          const button=page.locator('.world-touch-controls button').filter({hasText:'→ 右'}),r=await button.boundingBox(),x=await page.evaluate(()=>testWorld.player.x);
          assert.ok(r.width>=44&&r.height>=44);
          const cdp=await page.context().newCDPSession(page);
          await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:r.x+r.width/2,y:r.y+r.height/2}]});await page.waitForTimeout(250);await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});await page.waitForTimeout(100);
          assert.ok(await page.evaluate(x=>testWorld.player.x>x+15,x));await cdp.detach();results.push(entry+' mobile held touch button moves player PASS');
        }
        await page.screenshot({path:`${out}/${entry.startsWith('/?')?'phaser':'presentation'}-${name}.png`,fullPage:true});
      }
      results.push(entry+' desktop iPad 390px 320px no overlap, touch map PASS');
      await page.close();
    }
    const main=await browser.newPage({viewport:{width:1440,height:1100}});main.on('pageerror',e=>errors.push('main: '+e.message));
    await main.addInitScript(()=>window.addEventListener('campus:snapshot',e=>window.testWorld=e.detail));await main.goto('http://127.0.0.1:8766/');await main.waitForFunction(()=>window.testWorld?.npcs[0]?.name==='陳小鈴老師');await main.screenshot({path:`${out}/main-original-teachers.png`,fullPage:true});await main.close();results.push('main entry original teacher assets render PASS');
    assert.deepEqual(errors,[]);fs.writeFileSync(`${out}/results.json`,JSON.stringify({results,errors},null,2));console.log(JSON.stringify({results,errors},null,2));
  } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exitCode=1;});
