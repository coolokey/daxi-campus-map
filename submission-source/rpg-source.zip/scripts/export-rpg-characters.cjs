/* Offline export only: source guide files are read and never modified. */
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),vm=require('node:vm');
const {chromium}=require(process.env.USERPROFILE+'/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root=path.resolve(__dirname,'..');
const sourceDirectory=process.env.RPG_GUIDE_SOURCE||'F:/1151005---創意教學/daxi-campus-map/public/campus-explorer';
const sourceFiles=['staff-data.js','campus-people.js','explorer.js'];
const sha256=Object.fromEntries(sourceFiles.map(f=>[f,crypto.createHash('sha256').update(fs.readFileSync(path.join(sourceDirectory,f))).digest('hex')]));
const context={window:{}};vm.runInNewContext(fs.readFileSync(path.join(sourceDirectory,'staff-data.js'),'utf8'),context);
const characters=Array.from(context.window.CampusStaffData.people,p=>{
 const look=Array.from(p.id).reduce((n,c)=>n+c.charCodeAt(0),0);
 return {id:p.id,name:p.name,role:'teacher',title:p.title,destination:p.destination,appearance:{...(p.appearance||{}),gender:p.appearance?.gender||p.gender||'male',role:'teacher',clothingStyle:['blazer','cardigan','shirt','polo'][look%4],pantsColor:[0x514b48,0x49545c,0x716755,0x535c51][look%4]},appearanceStatus:p.appearance?'source':'generic'};
});
for(let i=0;i<12;i++)characters.push({id:'student-'+i,name:'示意學生 '+(i+1),role:'student',appearance:{gender:i%2?'female':'male',outfit:'uniform',role:'student'},appearanceStatus:'generic'});
characters.push({id:'gate-guard',name:'警衛先生',role:'guard',appearance:{role:'guard',gender:'male',hairStyle:'short',outfit:'casual',shirtColor:0x465e76,hairColor:0x45403b},appearanceStatus:'generic'});
for(const gender of ['male','female'])for(const outfit of ['uniform','casual'])characters.push({id:`player-${gender}-${outfit}`,name:`${gender==='male'?'男':'女'}學生（${outfit==='uniform'?'制服':'便服'}）`,role:'player',appearance:{gender,outfit,role:'player'},appearanceStatus:'generic'});
characters.push({id:'robot-patrol',name:'校園巡邏機器人',role:'robot',appearance:{role:'robot',bodyColor:0x82c6c8,accentColor:0x304d66},appearanceStatus:'generic'});
for(const c of characters)c.atlas='assets/characters/guide-rpg/'+c.id+'.png';
const directions=['down','down-left','left','up-left','up','up-right','right','down-right'];
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true,args:['--enable-webgl','--ignore-gpu-blocklist']});
 try{
  const page=await browser.newPage({viewport:{width:1024,height:768}});
  await page.goto(process.env.RPG_GUIDE_URL||'http://127.0.0.1:8770/campus-explorer/',{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>window.THREE&&window.campusExplorer?.createCharacter,{timeout:60000});
  const servedSources=await page.evaluate(async files=>Promise.all(files.map(async name=>({name,text:await (await fetch(name)).text()}))),sourceFiles);
  for(const source of servedSources){
   const expected=fs.readFileSync(path.join(sourceDirectory,source.name),'utf8').replace(/\r\n/g,'\n');
   if(source.text.replace(/\r\n/g,'\n')!==expected)throw new Error('Served source differs from recorded source: '+source.name);
  }
  const result=await page.evaluate(({characters})=>{
   const T=window.THREE,scene=new T.Scene();scene.add(new T.HemisphereLight(0xdbe2e5,0x686b5e,.72));scene.add(new T.AmbientLight(0xf2eee5,.25));
   const light=new T.DirectionalLight(0xfff3e3,1.05);light.position.set(-3,6,7);scene.add(light);
   const renderer=new T.WebGLRenderer({alpha:true,antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(2);renderer.setSize(64,88);renderer.setClearColor(0,0);
   renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=.88;if(T.SRGBColorSpace)renderer.outputColorSpace=T.SRGBColorSpace;else renderer.outputEncoding=T.sRGBEncoding;
   const camera=new T.OrthographicCamera(-1,1,1,-1,.1,50);camera.position.set(0,4,10);camera.lookAt(0,1,0);camera.updateMatrixWorld();
   const robot=spec=>{
    const r=new T.Group();r.scale.setScalar(.72);
    const mat=new T.MeshStandardMaterial({color:spec.bodyColor,roughness:.6}),dark=new T.MeshStandardMaterial({color:spec.accentColor,roughness:.7}),white=new T.MeshStandardMaterial({color:0xf0f9f6});
    function mesh(geo,m,x,y,z,parent=r){const n=new T.Mesh(geo,m);n.position.set(x,y,z);parent.add(n);return n;}
    mesh(new T.SphereGeometry(.43,24,16),mat,0,1.4,0).scale.set(1,1.2,.7);
    const head=new T.Group();head.name='avatar-head';head.position.y=2.25;r.add(head);
    mesh(new T.SphereGeometry(.49,24,16),mat,0,0,0,head).scale.set(1,.9,.8);
    for(const x of [-.17,.17])mesh(new T.SphereGeometry(.085,12,8),dark,x,.04,.36,head);
    mesh(new T.BoxGeometry(.21,.04,.04),white,0,-.16,.38,head);
    mesh(new T.CylinderGeometry(.025,.025,.22,8),dark,0,.51,0,head);mesh(new T.SphereGeometry(.065,12,8),white,0,.64,0,head);
    for(const side of ['left','right']){const sign=side==='left'?-1:1;
     const arm=new T.Group();arm.name='avatar-arm-'+side;arm.position.set(sign*.49,1.7,0);r.add(arm);mesh(new T.CylinderGeometry(.12,.12,.64,12),dark,0,-.31,0,arm);
     const leg=new T.Group();leg.name='avatar-leg-'+side;leg.position.set(sign*.2,.96,0);r.add(leg);mesh(new T.CylinderGeometry(.14,.14,.78,12),dark,0,-.37,0,leg);mesh(new T.SphereGeometry(.19,16,10),white,0,-.77,.08,leg).scale.set(1,.55,1.5);
    }return r;
   };
   const models=characters.map(c=>{const r=c.role==='robot'?robot(c.appearance):window.campusExplorer.createCharacter(c.appearance);r.getObjectByName('avatar-head').scale.multiplyScalar(1.18);r.traverse(n=>{if(n.material?.transparent&&n.name!=='avatar-glasses')n.visible=false;});scene.add(r);r.visible=false;return r;});
   const pose=(r,row,col)=>{r.rotation.y=-col*Math.PI/4;const step=[0,.48,-.48][row];for(const [name,sign]of [['arm-left',-1],['arm-right',1],['leg-left',1],['leg-right',-1]])r.getObjectByName('avatar-'+name).rotation.x=step*sign;r.updateMatrixWorld(true);};
   // Capture bounds across EVERY model, direction and pose before fixing a shared camera scale.
   let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
   for(const r of models)for(let row=0;row<3;row++)for(let col=0;col<8;col++){pose(r,row,col);const b=new T.Box3().setFromObject(r);for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z]){const v=new T.Vector3(x,y,z).applyMatrix4(camera.matrixWorldInverse);minX=Math.min(minX,v.x);maxX=Math.max(maxX,v.x);minY=Math.min(minY,v.y);maxY=Math.max(maxY,v.y);}}
   const centerY=(minY+maxY)/2,halfHeight=Math.max((maxY-minY)/2,(maxX-minX)/2*88/64)*1.10,halfWidth=halfHeight*64/88;
   camera.left=-halfWidth;camera.right=halfWidth;camera.top=centerY+halfHeight;camera.bottom=centerY-halfHeight;camera.updateProjectionMatrix();
   const groundAnchor=new T.Vector3(0,0,0).project(camera);const anchor={x:(groundAnchor.x+1)*32,y:(1-groundAnchor.y)*44};
   const atlases=[];
   for(let i=0;i<models.length;i++){const r=models[i];r.visible=true;const canvas=document.createElement('canvas');canvas.width=512;canvas.height=264;const ctx=canvas.getContext('2d');
    for(let row=0;row<3;row++)for(let col=0;col<8;col++){pose(r,row,col);renderer.render(scene,camera);ctx.drawImage(renderer.domElement,col*64,row*88,64,88);}
    r.visible=false;atlases.push(canvas.toDataURL('image/png').split(',')[1]);
   }
   renderer.dispose();return {atlases,anchor,camera:{halfHeight,centerY,view:'front +Z, elevated camera, orthographic'}};
  },{characters});
  const directory=path.join(root,'public/assets/characters/guide-rpg');fs.mkdirSync(directory,{recursive:true});
  result.atlases.forEach((base64,i)=>fs.writeFileSync(path.join(directory,characters[i].id+'.png'),Buffer.from(base64,'base64')));
  const manifest={version:1,source:{directory:'campus-explorer',sha256,model:'window.campusExplorer.createCharacter',exportedAt:new Date().toISOString()},tile:{width:64,height:88,columns:8,rows:3},directions,poses:['idle','leftstep','rightstep'],anchor:result.anchor,headScale:1.18,rotationRadians:directions.map((_,i)=>-i*Math.PI/4),camera:result.camera,characters};
  fs.mkdirSync(path.join(root,'public/data'),{recursive:true});fs.writeFileSync(path.join(root,'public/data/rpg-characters.json'),JSON.stringify(manifest,null,2)+'\n');
  console.log(JSON.stringify({characters:characters.length,sourceSha256:sha256,camera:result.camera}));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1)});





