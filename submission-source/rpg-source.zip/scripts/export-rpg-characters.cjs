/* Offline export only: source guide files are read and never modified. */
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),vm=require('node:vm');
const {chromium}=require(process.env.USERPROFILE+'/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const root=path.resolve(__dirname,'..');
const {teacherStyle}=require('./deterministic-style.cjs');
const sourceDirectory=process.env.RPG_GUIDE_SOURCE||'F:/1151005---創意教學/daxi-campus-map/public/campus-explorer';
const sourceFiles=['staff-data.js','campus-people.js','explorer.js'];
const sha256=Object.fromEntries(sourceFiles.map(f=>[f,crypto.createHash('sha256').update(fs.readFileSync(path.join(sourceDirectory,f))).digest('hex')]));
const context={window:{}};vm.runInNewContext(fs.readFileSync(path.join(sourceDirectory,'staff-data.js'),'utf8'),context);
const characters=Array.from(context.window.CampusStaffData.people,p=>{
 return {id:p.id,name:p.name,role:'teacher',title:p.title,destination:p.destination,...teacherStyle(p),appearanceStatus:p.appearance?'source':'generic'};
});
for(let i=0;i<12;i++)characters.push({id:'student-'+i,name:'示意學生 '+(i+1),role:'student',appearance:{gender:i%2?'female':'male',outfit:'uniform',role:'student'},appearanceStatus:'generic'});
characters.push({id:'gate-guard',name:'警衛先生',role:'guard',appearance:{role:'guard',gender:'male',hairStyle:'short',outfit:'casual',shirtColor:0x465e76,hairColor:0x45403b},appearanceStatus:'generic'});
for(const gender of ['male','female'])for(const outfit of ['uniform','casual'])characters.push({id:`player-${gender}-${outfit}`,name:`${gender==='male'?'男':'女'}學生（${outfit==='uniform'?'制服':'便服'}）`,role:'player',appearance:{gender,outfit,role:'player'},appearanceStatus:'generic'});
characters.push({id:'robot-patrol',name:'校園巡邏機器人',role:'robot',appearance:{role:'robot',bodyColor:0x82c6c8,accentColor:0x304d66},appearanceStatus:'generic'});
for(const c of characters){c.atlas='assets/characters/guide-rpg/style-v3/'+c.id+'.png';c.portrait='assets/characters/guide-rpg/style-v3/portraits/'+c.id+'.png';}
const directions=['down','down-left','left','up-left','up','up-right','right','down-right'];
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true,args:['--enable-webgl','--ignore-gpu-blocklist']});
 try{
  const page=await browser.newPage({viewport:{width:1024,height:768}});
  await page.goto(process.env.RPG_GUIDE_URL||'http://127.0.0.1:8770/campus-explorer/',{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>window.THREE&&window.campusExplorer?.createCharacter,{timeout:60000});
  const servedSources=await page.evaluate(async files=>Promise.all(files.map(async name=>({name,text:await (await fetch(name)).text()}))),sourceFiles);
  for(const source of servedSources){
   const expected=fs.readFileSync(path.join(sourceDirectory,source.name),'utf8').replace(/\r\n/g,'\n');
   if(source.text.replace(/\r\n/g,'\n')!==expected)throw new Error('Served source differs from recorded source: '+source.name);
  }
  const result=await page.evaluate(({characters})=>{
   const T=window.THREE,scene=new T.Scene();scene.add(new T.HemisphereLight(0xdbe2e5,0x686b5e,.72));scene.add(new T.AmbientLight(0xf2eee5,.25));
   const light=new T.DirectionalLight(0xfff3e3,1.05);light.position.set(-3,6,7);scene.add(light);
   const renderer=new T.WebGLRenderer({alpha:true,antialias:true,preserveDrawingBuffer:true});renderer.setPixelRatio(2);renderer.setSize(64,88);renderer.setClearColor(0,0);
   renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=.88;if(T.SRGBColorSpace)renderer.outputColorSpace=T.SRGBColorSpace;else renderer.outputEncoding=T.sRGBEncoding;
   const camera=new T.OrthographicCamera(-1,1,1,-1,.1,50);camera.position.set(0,4,10);camera.lookAt(0,1,0);camera.updateMatrixWorld();
   const robot=spec=>{
    const r=new T.Group();r.scale.setScalar(.72);
    const mat=new T.MeshStandardMaterial({color:spec.bodyColor,roughness:.6}),dark=new T.MeshStandardMaterial({color:spec.accentColor,roughness:.7}),white=new T.MeshStandardMaterial({color:0xf0f9f6});
    function mesh(geo,m,x,y,z,parent=r){const n=new T.Mesh(geo,m);n.position.set(x,y,z);parent.add(n);return n;}
    mesh(new T.SphereGeometry(.43,24,16),mat,0,1.4,0).scale.set(1,1.2,.7);
    const head=new T.Group();head.name='avatar-head';head.position.y=2.25;r.add(head);
    mesh(new T.SphereGeometry(.49,24,16),mat,0,0,0,head).scale.set(1,.9,.8);
    for(const x of [-.17,.17])mesh(new T.SphereGeometry(.085,12,8),dark,x,.04,.36,head);
    mesh(new T.BoxGeometry(.21,.04,.04),white,0,-.16,.38,head);
    mesh(new T.CylinderGeometry(.025,.025,.22,8),dark,0,.51,0,head);mesh(new T.SphereGeometry(.065,12,8),white,0,.64,0,head);
    for(const side of ['left','right']){const sign=side==='left'?-1:1;
     const arm=new T.Group();arm.name='avatar-arm-'+side;arm.position.set(sign*.49,1.7,0);r.add(arm);mesh(new T.CylinderGeometry(.12,.12,.64,12),dark,0,-.31,0,arm);
     const leg=new T.Group();leg.name='avatar-leg-'+side;leg.position.set(sign*.2,.96,0);r.add(leg);mesh(new T.CylinderGeometry(.14,.14,.78,12),dark,0,-.37,0,leg);mesh(new T.SphereGeometry(.19,16,10),white,0,-.77,.08,leg).scale.set(1,.55,1.5);
    }return r;
   };
   const wardrobe=(r,s)=>{
    const material=color=>{const m=new T.MeshStandardMaterial({color,roughness:.94});m.color.convertSRGBToLinear();return m;};
    const accent=material(s.accessoryColor),pants=material(s.pantsColor),light=material(0xe4ddcd);
    const box=(name,w,h,d,x,y,z,m=accent)=>{const mesh=new T.Mesh(new T.BoxGeometry(w,h,d),m);mesh.name='rpg-'+name;mesh.position.set(x,y,z);r.add(mesh);return mesh;};
    const panel=(name,points,z,m=accent)=>{const shape=new T.Shape();points.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();const mesh=new T.Mesh(new T.ShapeGeometry(shape),m);mesh.name='rpg-'+name;mesh.position.z=z;r.add(mesh);return mesh;};
    if(s.vest){box('vest',.60,.53,.025,0,1.33,.322);panel('vest-v-neck',[[-.19,1.60],[.19,1.60],[0,1.36]],.341,light);}
    if(s.neckwear==='tie'){panel('tie',[[0,1.76],[-.055,1.65],[-.045,1.33],[0,1.26],[.045,1.33],[.055,1.65]],.365);box('tie-knot',.09,.09,.05,0,1.70,.375);}
    if(s.neckwear==='scarf'){box('scarf-collar',.41,.10,.49,0,1.77,0);box('scarf-tail',.13,.41,.05,.13,1.52,.37);box('scarf-tail-short',.12,.28,.05,-.05,1.59,.375);}
    if(s.brooch){const pin=new T.Mesh(new T.SphereGeometry(.052,10,8),material(0xc8af70));pin.name='rpg-brooch';pin.position.set(-.23,1.60,.37);pin.scale.z=.35;r.add(pin);}
    if(s.backpack){box('backpack',.52,.61,.25,0,1.40,-.32);box('backpack-pocket',.37,.24,.05,0,1.24,-.465,light);for(const x of [-.23,.23])box('backpack-strap',.055,.55,.035,x,1.47,.345);}
    if(s.bottomStyle==='skirt'){const mesh=new T.Mesh(new T.CylinderGeometry(.30,.43,.47,12),pants);mesh.name='rpg-skirt';mesh.position.y=.80;r.add(mesh);}
   };
   const buildModel=c=>{const r=c.role==='robot'?robot(c.appearance):window.campusExplorer.createCharacter(c.appearance);if(c.role==='teacher')wardrobe(r,c.appearance);r.traverse(n=>{if(n.material?.transparent&&n.name!=='avatar-glasses')n.visible=false;});return r;};
   const models=characters.map(c=>{const r=buildModel(c),head=r.getObjectByName('avatar-head');const body=new T.Group();body.name='rpg-q-body';for(const child of [...r.children])if(child!==head)body.add(child);r.add(body);body.scale.set(.88,.68,.88);head.scale.multiplyScalar(1.65);head.position.y=1.84*.68+.49*1.65;r.updateMatrixWorld(true);scene.add(r);r.visible=false;return r;});
   const visibleBounds=r=>{const bounds=new T.Box3();r.updateMatrixWorld(true);r.traverse(n=>{if(!n.geometry)return;let a=n,visible=true;while(a&&a!==r){if(!a.visible)visible=false;a=a.parent;}if(!visible)return;if(!n.geometry.boundingBox)n.geometry.computeBoundingBox();bounds.union(n.geometry.boundingBox.clone().applyMatrix4(n.matrixWorld));});return bounds;};
   const ratios=models.map(r=>visibleBounds(r.getObjectByName('avatar-head')).getSize(new T.Vector3()).y/visibleBounds(r).getSize(new T.Vector3()).y);
   const pose=(r,row,col)=>{r.rotation.y=-col*Math.PI/4;const step=[0,.48,-.48][row];for(const [name,sign]of [['arm-left',-1],['arm-right',1],['leg-left',1],['leg-right',-1]])r.getObjectByName('avatar-'+name).rotation.x=step*sign;r.updateMatrixWorld(true);};
   // Capture bounds across EVERY model, direction and pose before fixing a shared camera scale.
   let minX=Infinity,maxX=-Infinity,minY=Infinity,maxY=-Infinity;
   for(const r of models)for(let row=0;row<3;row++)for(let col=0;col<8;col++){pose(r,row,col);const b=new T.Box3().setFromObject(r);for(const x of [b.min.x,b.max.x])for(const y of [b.min.y,b.max.y])for(const z of [b.min.z,b.max.z]){const v=new T.Vector3(x,y,z).applyMatrix4(camera.matrixWorldInverse);minX=Math.min(minX,v.x);maxX=Math.max(maxX,v.x);minY=Math.min(minY,v.y);maxY=Math.max(maxY,v.y);}}
   const centerY=(minY+maxY)/2,halfHeight=Math.max((maxY-minY)/2,(maxX-minX)/2*88/64)*1.10,halfWidth=halfHeight*64/88;
   camera.left=-halfWidth;camera.right=halfWidth;camera.top=centerY+halfHeight;camera.bottom=centerY-halfHeight;camera.updateProjectionMatrix();
   const groundAnchor=new T.Vector3(0,0,0).project(camera);const anchor={x:(groundAnchor.x+1)*32,y:(1-groundAnchor.y)*44};
   const atlases=[];
   for(let i=0;i<models.length;i++){const r=models[i];r.visible=true;const canvas=document.createElement('canvas');canvas.width=512;canvas.height=264;const ctx=canvas.getContext('2d');
    for(let row=0;row<3;row++)for(let col=0;col<8;col++){pose(r,row,col);renderer.render(scene,camera);ctx.drawImage(renderer.domElement,col*64,row*88,64,88);}
    r.visible=false;atlases.push(canvas.toDataURL('image/png').split(',')[1]);
   }
   // Portraits render the matching wardrobe on the uncompressed upper body.
   const portraits=[];renderer.setPixelRatio(2);renderer.setSize(256,320);
   const portraitCamera=new T.OrthographicCamera(-1,1,1,-1,.1,50);portraitCamera.position.set(0,1.8,10);portraitCamera.lookAt(0,1.8,0);portraitCamera.updateMatrixWorld();
   for(const c of characters){const r=buildModel(c);r.getObjectByName('avatar-head').scale.multiplyScalar(1.18);r.rotation.y=-.08;scene.add(r);r.updateMatrixWorld(true);const headBounds=visibleBounds(r.getObjectByName('avatar-head')),full=visibleBounds(r),top=headBounds.max.y+.10,bottom=.95*r.scale.y;let halfHeight=(top-bottom)/2,halfWidth=halfHeight*256/320;
    const requiredWidth=Math.max(Math.abs(full.min.x),Math.abs(full.max.x))*1.10;if(halfWidth<requiredWidth){halfWidth=requiredWidth;halfHeight=halfWidth*320/256;}
    portraitCamera.left=-halfWidth;portraitCamera.right=halfWidth;portraitCamera.top=top-1.8;portraitCamera.bottom=top-halfHeight*2-1.8;portraitCamera.updateProjectionMatrix();renderer.render(scene,portraitCamera);portraits.push(renderer.domElement.toDataURL('image/png').split(',')[1]);scene.remove(r);
   }
   renderer.dispose();return {atlases,portraits,proportions:{headBodyRatio:{min:Math.min(...ratios),max:Math.max(...ratios),mean:ratios.reduce((a,b)=>a+b,0)/ratios.length},bodyScale:{x:.88,y:.68,z:.88},headPosition:1.84*.68+.49*1.65,portraitHeadScale:1.18},anchor,camera:{halfHeight,centerY,view:'front +Z, elevated camera, orthographic'}};
  },{characters});
  const directory=path.join(root,'public/assets/characters/guide-rpg/style-v3');fs.mkdirSync(directory,{recursive:true});
  result.atlases.forEach((base64,i)=>fs.writeFileSync(path.join(directory,characters[i].id+'.png'),Buffer.from(base64,'base64')));
  fs.mkdirSync(path.join(directory,'portraits'),{recursive:true});result.portraits.forEach((base64,i)=>fs.writeFileSync(path.join(directory,'portraits',characters[i].id+'.png'),Buffer.from(base64,'base64')));
  const manifest={version:1,artVersion:'creative-style-v3',source:{directory:'campus-explorer',sha256,model:'window.campusExplorer.createCharacter',exportedAt:new Date().toISOString()},tile:{width:64,height:88,columns:8,rows:3},directions,poses:['idle','leftstep','rightstep'],anchor:result.anchor,headScale:1.65,proportions:result.proportions,portraitSize:{width:512,height:640},rotationRadians:directions.map((_,i)=>-i*Math.PI/4),camera:result.camera,characters};
  fs.mkdirSync(path.join(root,'public/data'),{recursive:true});fs.writeFileSync(path.join(root,'public/data/rpg-characters.json'),JSON.stringify(manifest,null,2)+'\n');
  fs.copyFileSync(path.join(root,'public/data/rpg-characters.json'),path.join(root,'public/data/rpg-characters-v3.json'));
  console.log(JSON.stringify({characters:characters.length,sourceSha256:sha256,camera:result.camera}));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1)});






