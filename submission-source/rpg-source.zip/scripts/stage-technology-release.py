from pathlib import Path
import shutil, hashlib, json, zipfile
source = Path(__file__).resolve().parents[1]
release = source.parent / 'rpg2-release'
target = release / 'public/proposal/rpg'
original = source.parent / 'future-campus-rpg'
# Additive copy: keep every existing asset, especially the anniversary integration.
for file in (source / 'dist').rglob('*'):
    if not file.is_file(): continue
    relative = file.relative_to(source / 'dist')
    if str(relative).replace('\\', '/') in ['index.html', 'presentation.html', 'data/campus.runtime.json']: continue
    if str(relative).replace('\\', '/').startswith('assets/rpg/teachers/'): continue
    dest = target / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(file, dest)
html = (source / 'dist/presentation.html').read_text(encoding='utf-8')
html = html.replace('</body>', '<script defer src="./anniversary-reward.js"></script></body>')
(target / 'index.html').write_text(html, encoding='utf-8')
changed = []
for directory in ['src', 'scripts', 'docs', 'public/data']:
    base = source / directory
    for file in base.rglob('*'):
        if not file.is_file(): continue
        relative = file.relative_to(source)
        previous = original / relative
        if not previous.exists() or previous.read_bytes() != file.read_bytes(): changed.append(str(relative).replace('\\', '/'))
record = release / 'submission-source/rpg2-campus-data'
(record / 'pilot-changed-files.json').write_text(json.dumps(changed, ensure_ascii=False, indent=2), encoding='utf-8')
with zipfile.ZipFile(release / 'submission-source/rpg-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for directory in ['src', 'scripts', 'docs', 'public']:
        for file in (source / directory).rglob('*'):
            relative = file.relative_to(source)
            if str(relative).replace('\\', '/').startswith('public/assets/rpg/teachers/'): continue
            if file.is_file(): archive.write(file, relative)
    for file in source.iterdir():
        if file.is_file() and file.suffix in ['.json', '.html', '.ts', '.yaml', '.md', '.cjs', '.js']:
            archive.write(file, file.name)
for folder, name in [('technology-pilot-qa', 'pilot-local-browser-check.json'), ('published-rpg-qa', 'original-mode-local-check.json')]:
    shutil.copy2(source / 'output' / folder / 'results.json', record / name)
manifest_file = target / 'data/manifest.json'
manifest = json.loads(manifest_file.read_text(encoding='utf-8'))
manifest.update(stage='technology-pilot-ready', playablePilot=True, pilotMode='canvas-presentation-opt-in')
manifest['notes'] = ['Original campus remains the default. Technology pilot is selected with its own button.', 'Pilot loads shared JSON plus compact runtime on demand; full navigation graph remains deferred.', 'Geometry is schematic guide data, not surveyed measurements. Phaser scenes are not migrated in this stage.']
manifest['pilotRuntime'] = {'file': 'technology-demo-runtime.json', 'sha256': hashlib.sha256((target / 'data/technology-demo-runtime.json').read_bytes()).hexdigest(), 'bytes': (target / 'data/technology-demo-runtime.json').stat().st_size}
manifest_file.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'changedSourceFiles':len(changed), 'target':str(target)}, ensure_ascii=False))
