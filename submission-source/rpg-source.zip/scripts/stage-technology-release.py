from pathlib import Path
import shutil, hashlib, json, zipfile
source = Path(__file__).resolve().parents[1]
release = source.parent / 'rpg2-release'
target = release / 'public/proposal/rpg'
original = source.parent / 'future-campus-rpg'
# Additive copy: keep every existing asset, especially the anniversary integration.
for file in (source / 'dist').rglob('*'):
    if not file.is_file(): continue
    relative = file.relative_to(source / 'dist')
    if 'style-v2' in relative.parts or relative.name == 'rpg-characters-v2.json': continue
    if str(relative).replace('\\', '/') in ['index.html', 'presentation.html', 'data/campus.runtime.json']: continue
    if str(relative).replace('\\', '/').startswith('assets/rpg/teachers/'): continue
    dest = target / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(file, dest)
html = (source / 'dist/presentation.html').read_text(encoding='utf-8')
html = html.replace('</body>', '<script defer src="./anniversary-reward.js"></script></body>')
(target / 'index.html').write_text(html, encoding='utf-8')
changed = []
for directory in ['src', 'scripts', 'docs', 'public/data', 'public/assets/characters/guide-rpg']:
    base = source / directory
    for file in base.rglob('*'):
        if not file.is_file(): continue
        relative = file.relative_to(source)
        previous = original / relative
        if not previous.exists() or previous.read_bytes() != file.read_bytes(): changed.append(str(relative).replace('\\', '/'))
record = release / 'submission-source/rpg2-campus-data'
(record / 'pilot-changed-files.json').write_text(json.dumps(changed, ensure_ascii=False, indent=2), encoding='utf-8')
with zipfile.ZipFile(release / 'submission-source/rpg-source.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for directory in ['src', 'scripts', 'docs', 'public']:
        for file in (source / directory).rglob('*'):
            relative = file.relative_to(source)
            if 'style-v2' in relative.parts or relative.name == 'rpg-characters-v2.json': continue
            if str(relative).replace('\\', '/').startswith('public/assets/rpg/teachers/'): continue
            if file.is_file(): archive.write(file, relative)
    for file in source.iterdir():
        if file.is_file() and file.suffix in ['.json', '.html', '.ts', '.yaml', '.md', '.cjs', '.js']:
            archive.write(file, file.name)
for folder, name in [('technology-pilot-qa', 'pilot-local-browser-check.json'), ('published-rpg-qa', 'original-mode-local-check.json')]:
    shutil.copy2(source / 'output' / folder / 'results.json', record / name)
shutil.copy2(source / 'output/original-characters-qa/results.json', record / 'characters-local-browser-check.json')
shutil.copy2(source / 'output/original-characters-qa/recovery.json', record / 'characters-failure-recovery.json')
manifest_file = target / 'data/manifest.json'
manifest = json.loads(manifest_file.read_text(encoding='utf-8'))
manifest.update(stage='original-campus-rpg-characters-ready', playablePilot=True, pilotMode='original-campus-technology-floors')
manifest['notes'] = ['The original illustrated campus is the only playable outdoor scene. Its existing technology door leads to source-backed floors.', 'All 91 staff are in the searchable roster; game NPC positions are illustrative, not live locations.', 'Indoor geometry is schematic guide data, not surveyed measurements. Phaser scenes are not migrated in this stage.']
manifest['pilotRuntime'] = {'file': 'technology-demo-runtime.json', 'sha256': hashlib.sha256((target / 'data/technology-demo-runtime.json').read_bytes()).hexdigest(), 'bytes': (target / 'data/technology-demo-runtime.json').stat().st_size}
manifest['characters'] = {'file':'rpg-characters-v4.json', 'sha256':hashlib.sha256((target / 'data/rpg-characters-v4.json').read_bytes()).hexdigest(), 'count':109, 'teachers':91, 'directions':8, 'poses':3}
manifest['characters'].update(style='chibi-v3', portraits=109, portraitSize=[512,640])
manifest['characters'].update(encoding='lossless-webp', preload='player-current-and-next-cohort')
manifest['characters']['roamingCaps'] = {'desktop':{'teacher':3,'student':3}, 'phone':{'teacher':1,'student':2}}
manifest['collisionAudit'] = {'footprints':62, 'sourcePixels':[1525,1031], 'baseWorld':[2400,1624], 'geometry':'ground footprints on retained illustration; not survey measurements'}
plan = json.loads((source / 'public/data/campus-plan-115.json').read_text(encoding='utf-8'))
manifest['stage'] = 'plan-115-checked-floor-expansion'
manifest['plan115'] = {'file':'campus-plan-115.json', 'buildingRecords':len(plan['buildings']), 'enabledBuildingRecords':sum(bool(b['enabledLevels']) for b in plan['buildings']), 'enabledFloors':sum(len(b['enabledLevels']) for b in plan['buildings']), 'sourcePlanSha256':plan['plan']['sha256'], 'deferred':['gym-bld:floor-2', 'gym-bld:floor-3'], 'geometry':'source-derived schematic floors; outdoor anchors on retained illustration, not surveyed entrance positions', 'navigation':'collision-aware manual routes and scene doorway guidance'}
manifest['notes'] = ['The original illustrated campus and public URL are retained. Annual plan checks gate enabled floors.', 'Indoor floor geometry and outdoor game entrance anchors are schematic, not measured campus geometry.', 'Grade 7 side-wing labels were checked horizontally: 704 is 2F and 708 is 3F. Activity centre upper floors remain unverified.', 'Room names marked pending remain pending. NPCs are game characters, not live people or online players.']
manifest_file.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'changedSourceFiles':len(changed), 'target':str(target)}, ensure_ascii=False))


