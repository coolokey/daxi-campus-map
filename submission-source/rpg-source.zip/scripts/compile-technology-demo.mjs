import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const sourceUrl=new URL('../public/data/campus.runtime.json',import.meta.url);
const raw=await readFile(sourceUrl,'utf8');
const data=JSON.parse(raw),ids=new Set(data.pilotRoute.nodeIds);
const nodes=data.navigation.nodes.filter(node=>ids.has(node.id));
if(nodes.length!==ids.size)throw new Error('Pilot route references missing navigation nodes');
const compact={...data,scope:'pilot-route-only',fullRuntimeSha256:createHash('sha256').update(raw).digest('hex'),
  navigation:{gateNodeId:data.navigation.gateNodeId,nodes}};
const output=JSON.stringify(compact);
await writeFile(new URL('../public/data/technology-demo-runtime.json',import.meta.url),output,'utf8');
console.info(`${nodes.length} route nodes, ${data.collisionVolumes.length} colliders, ${Buffer.byteLength(output)} bytes`);
