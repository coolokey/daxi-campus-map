"""Re-encode existing art without resizing, quantization or changing source PNGs."""
import json
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parents[1] / 'public'
registry = json.loads((root / 'data/rpg-characters-v3.json').read_text(encoding='utf-8'))
registry['sourceArtVersion'] = registry['artVersion']
registry['artVersion'] = 'creative-style-v4-lossless'
for character in registry['characters']:
    for key in ['atlas', 'portrait']:
        source = root / character[key]
        relative = character[key].replace('/style-v3/', '/style-v4-webp/').replace('.png', '.webp')
        target = root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with Image.open(source) as image:
            image.save(target, format='WEBP', lossless=True, exact=True, method=6)
        character[key] = relative
(root / 'data/rpg-characters-v4.json').write_text(json.dumps(registry, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
print('Encoded 109 atlases and 109 portraits; original PNGs preserved.')
