from pathlib import Path
r=Path(__file__).resolve().parents[1];p=r/'src/presentation/cartoon-renderer.ts';s=p.read_text(encoding='utf-8')
s=s.replace(" poly([q[1],q[2],lift(q[2],h),lift(q[1],h)],wall);poly([q[2],q[3],lift(q[3],h),lift(q[2],h)],'#d1d9c5');",'')
s=s.replace('  const at=(t:number,z:number)=>','  poly([a,b,lift(b,h),lift(a,h)],a===q[1]?wall:\'#d1d9c5\');\n  const at=(t:number,z:number)=>')
start=s.index(' // Bevels stay within');end=s.index(' // The shared renderer',start)
s=s[:start]+''' // Roof types follow the guide; heights remain compact for gameplay.
 const roof=buildingRoof(r,h,unit,id),screenV=(p:{x:number;y:number;z:number})=>{const q=projectIso(p);return {x:q.x,y:q.y-p.z};};
 const faces=[...roof.faces].sort((a,b)=>a.reduce((s,p)=>s+p.x+p.y,0)/a.length-b.reduce((s,p)=>s+p.x+p.y,0)/b.length);
 for(const [index,face] of faces.entries()){
  const ps=face.map(screenV);ctx.save();if(behind&&foot&&surfaceCoversActor(ps,foot,u))ctx.globalAlpha=.24;
  poly(ps,soften(color,index%2?.18:.38),soften(color,.06),.8);
  if(face.length===4){const [a,b,c,d]=ps;const count=Math.min(22,Math.max(3,Math.round(Math.hypot(b.x-a.x,b.y-a.y)/(unit*1.4))));for(let i=1;i<count;i++){const f=i/count;line({x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f},{x:d.x+(c.x-d.x)*f,y:d.y+(c.y-d.y)*f},'#f9f3df45',.7);}}
  ctx.restore();
 }
 const roofScreen=roof.faces.flat().map(screenV);ctx.save();if(behind&&foot&&surfaceCoversActor(screen,foot,u))ctx.globalAlpha=.24;
 for(let i=1;i<3;i++)line(screenV(roof.corners[i]),screenV(roof.corners[i+1]),'#f4ecd5',2);
 if(roof.ridge.length)line(screenV(roof.ridge[0]),screenV(roof.ridge[1]),soften(color,.55),2.2);
 if(roof.solar&&r.width>unit*8&&r.height>unit*8){
  // Source guide places solar rows on the activity centre's large roof.
  for(let row=0;row<3;row++)for(let col=0;col<4;col++){
   const x=r.x+r.width*(.18+col*.16),y=r.y+r.height*(.2+row*.2),w=r.width*.13,d=r.height*.14;
   const ps=[{x,y},{x:x+w,y},{x:x+w,y:y+d},{x,y:y+d}].map(p=>screenV({...p,z:h+unit*.28}));
   poly(ps,'#557b8b','#b7cbd0',.7);line(ps[0],ps[2],'#9cbac180',.6);
  }
 }
 ctx.restore();void roofScreen;
''' +s[end:]
p.write_text(s,encoding='utf-8')
p=r/'src/presentation/model-renderer.ts';s=p.read_text(encoding='utf-8')
s=s.replace('if(blocked)ctx.globalAlpha=.28;', 'if(blocked&&realistic)ctx.globalAlpha=.28;')
s=s.replace('paintCartoonBuilding(ctx,r,h,info.unit,unit,s.id);','paintCartoonBuilding(ctx,r,h,info.unit,unit,s.id,player);')
s=s.replace('cartoonBuildingHeight(h,info.unit)+info.unit*.8','cartoonBuildingHeight(h,info.unit)+info.unit*1.4')
# Draw entry markings directly on the existing trigger, never invent door positions.
s=s.replace("tile(portal.trigger,'#b28b4e55','#f4e6c6');", "tile(portal.trigger,info.outdoor?'#eee5cdbb':'#b28b4e55',info.outdoor?'#6f9b8b':'#f4e6c6');if(info.outdoor){const q=projectIso(p);ctx.save();ctx.strokeStyle=portal.destinationMapId.includes('tech')?'#659cac':'#a78c5b';ctx.lineWidth=2*unit;ctx.beginPath();ctx.ellipse(q.x,q.y,12*unit,6*unit,0,0,Math.PI*2);ctx.stroke();ctx.restore();}")
p.write_text(s,encoding='utf-8')
print('Building artwork integrated')
