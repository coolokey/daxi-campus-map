const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
test('teacher game styles offer distinct mature colors, silhouettes and accessories',()=>{
 const m=JSON.parse(fs.readFileSync(path.join(__dirname,'../public/data/rpg-characters.json')));const teachers=m.characters.filter(c=>c.role==='teacher');
 assert.ok(new Set(teachers.map(c=>c.appearance.shirtColor)).size>=12,'At least 12 teacher clothing colors');
 assert.ok(new Set(teachers.map(c=>c.appearance.pantsColor)).size>=6,'At least 6 trouser colors');
 assert.ok(new Set(teachers.map(c=>c.appearance.clothingStyle)).size>=4);
 assert.equal(new Set(teachers.map(c=>c.styleSignature)).size,91,'Each teacher has a unique outfit combination');
 assert.deepEqual(new Set(teachers.map(c=>c.appearance.glasses)),new Set([true,false]));
 for(const c of teachers){assert.equal(c.styleOrigin,'creative-rpg');assert.ok(c.sourceAppearance);for(const key of ['hairStyle','hairColor'])if(key in c.sourceAppearance)assert.equal(c.appearance[key],c.sourceAppearance[key]);if(c.sourceAppearance.glasses)assert.equal(c.appearance.glasses,true);}
});
const {teacherStyle}=require('./deterministic-style.cjs');
test('ID styling is deterministic, preserves hair and explicit glasses, independent of roster order',()=>{
 const p={id:'staff-001',gender:'female',appearance:{hairStyle:'long',hairColor:0x39312a,shirtColor:0x123456,glasses:true}};
 const first=teacherStyle(p);teacherStyle({id:'unrelated'});assert.deepEqual(teacherStyle(p),first);assert.deepEqual(first.sourceAppearance,p.appearance);assert.equal(first.appearance.hairColor,p.appearance.hairColor);assert.equal(first.appearance.hairStyle,'long');assert.equal(first.appearance.glasses,true);assert.equal(p.appearance.shirtColor,0x123456);
});
