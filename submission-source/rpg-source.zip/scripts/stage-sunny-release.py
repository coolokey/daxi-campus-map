from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-model-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';manifest_file=release/'public/proposal/rpg/data/manifest.json'
manifest=json.loads(manifest_file.read_text(encoding='utf-8'))
manifest.update(stage='sunny-campus-three-centers',visualTheme={'name':'Sunny meadow smart campus','sky':'blue sky and white clouds','ground':'green meadow and warm paving','buildings':'cream facade, terracotta roofs, individual windows','geometryChanged':False},threeCenters={'topics':['incenter','centroid','circumcenter'],'stations':3,'questions':6,'hintLayers':2,'sourceRooms':['tech-building:1:TC-N-1:life-tech-1','tech-building:2:TC-N-2:physics-lab','tech-building:2:TC-NE-2:tech-smart'],'progress':'browser-only anonymous local progress; page-memory fallback','legacyEnergyQuestRetained':True})
manifest['notes']=['The public RPG URL and guide website remain unchanged. Original plan and illustration assets are retained.','Natural sunny art uses the existing isometric geometry, collisions and character system.','Three-center exploration requires discovering real room stations and completing them in order; correct answers show explanations before continuing.','NPCs are game characters. Progress is local, anonymous, and not uploaded. The legacy five-question energy quest remains available.']
manifest_file.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/sunny-three-centers';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/sunny-three-centers-release.md',source/'docs/superpowers/plans/2026-10-27-sunny-three-centers.md',source/'output/sunny-three-centers-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':manifest['stage'],'record':str(record)},ensure_ascii=False))
