from pathlib import Path
import runpy,json,shutil,hashlib
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-woodland-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='hex-adventure-spacious-campus'
m['visualTheme'].update(name='六角冒險校園',buildings='original low cartoon buildings with independent roof colors and logical floor badges',ground='hex grass and cream paved entrances; original sports fields retained',geometryChanged=True,buildingLayoutChanged=True)
m['outdoorLayout']={'config':'cartoon-campus-v1.json','buildingFootprintScale':0.74,'centersPreserved':True,'interiorMapsChanged':False,'collisionEntrancesMinimapNavigationSynchronized':True,'interpretation':'compact game exterior; not surveyed real-world dimensions'}
m['woodlandTheme']['originalSchoolAppearanceOptionRetained']=False
m['woodlandTheme']['comparisonOptionRetained']=True
m['threeCenters']['presentation']='bright rounded numbered stage cards; original stations, questions, navigation and local progress retained'
m['notes'].append('Original hex-terrain inspired artwork; no PaGamO assets, territory claiming, PvP or multiplayer added. Building exterior centers retained with compact footprints; original interior data unchanged.')
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/hex-campus';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/hex-campus-release.md',source/'docs/superpowers/plans/2026-10-28-hex-campus.md',source/'output/hex-campus-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
