from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-ecology-release.py'),run_name='__main__')
release=source.parent/'rpg2-release'
f=release/'public/proposal/rpg/data/manifest.json'
m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='agriculture-vocational-farm'
m['farm']={'file':'campus-farm-v1.json','beds':12,'cropTypes':6,'cropSpriteCache':12,'stages':['young','mature'],'minimap':True,'navigation':True,'physicalBedsAndFixtures':True,'scene':'outdoor','originalTrackChanged':False,'surveyed':False,'cultivationSaveSystem':False,'testsPassed':175}
m['roadNetwork'].update(pavingRects=7,totalOutdoorPaths=8)
m['collisionAudit']['geometry']+='; farm beds, equipment and open-gate wooden fence'
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/farm'
record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/farm-release.md',source/'docs/superpowers/plans/2026-11-01-vocational-farm.md',source/'output/farm-qa/results.json']:
    if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
