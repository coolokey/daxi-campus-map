from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-hex-campus-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='gate-landmarks-and-complete-palm-avenue'
m['entranceLandmarks']={'file':'entrance-landmarks-v1.json','palmTrees':20,'avenueSourceZ':[89,171],'worldSouthZ':182,'landmarks':['palm avenue','Jiekou trail entrance','Chiang statue courtyard','grandstand and flagpoles'],'collision':'trunks, sign, statue base, stage walls and columns, flagpoles','navigation':'outdoor landmark choices in campus directory; minimap has avenue and landmark markers','originalGuideChanged':False,'sourcePlanChanged':False}
m['notes'].append('Exterior approach extends the RPG world to include the existing guide palm avenue; original building centers and interior maps retained. Stage uses planar movement, not a new height physics system.')
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/entrance-landmarks';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/entrance-landmarks-release.md',source/'docs/superpowers/plans/2026-10-28-entrance-landmarks.md',source/'output/entrance-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
