from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-pavilion-activities-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='palm-gardens-creek-and-outer-forest'
m['surroundings']={'file':'campus-surroundings-v1.json','forestTreesAndBamboo':98,'plantClusters':68,'flowerShrubs':6,'distantHills':7,'butterflyVisibleCaps':{'desktop':3,'phone':2},'birds':2,'proceduralSpriteCache':24,'existingTreeSpritesReused':True,'worldBoundsChanged':False,'creekAndBridgeCollisionShared':True,'surveyed':False,'googleImageryUsedAsTextures':False,'regressionPassed':187,'finalFocusedPassed':11}
m['collisionAudit']['geometry']+='; exterior grove trunks, flower shrub cores, creek water minus passable observation deck, benches, stones and bridge posts'
m['roadNetwork']['totalOutdoorPaths']=9
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/surroundings';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/campus-surroundings-release.md',source/'docs/superpowers/plans/2026-11-01-campus-surroundings.md',source/'output/surroundings-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
