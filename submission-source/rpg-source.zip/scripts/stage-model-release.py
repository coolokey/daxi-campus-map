from pathlib import Path
import hashlib,json,shutil,zipfile,filecmp
source=Path(__file__).resolve().parents[1]
release=source.parent/'rpg2-release'
target=release/'public/proposal/rpg'
dist=source/'dist'
changed=[]
def copy(file,dest):
    if dest.exists() and filecmp.cmp(file,dest,shallow=False):return
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,dest);changed.append(str(dest.relative_to(release)).replace('\\','/'))
for file in dist.rglob('*'):
    if not file.is_file():continue
    rel=file.relative_to(dist);path=str(rel).replace('\\','/')
    if path in ['index.html','presentation.html','data/campus.runtime.json'] or path.startswith('assets/rpg/teachers/') or 'style-v2' in rel.parts or rel.name=='rpg-characters-v2.json':continue
    copy(file,target/rel)
html=(dist/'presentation.html').read_text(encoding='utf-8').replace('</body>','<script defer src="./anniversary-reward.js"></script></body>')
(target/'index.html').write_text(html,encoding='utf-8');changed.append('public/proposal/rpg/index.html')
manifest_file=target/'data/manifest.json';manifest=json.loads(manifest_file.read_text(encoding='utf-8'));model=json.loads((source/'public/data/campus-model-v2.json').read_text(encoding='utf-8'))
manifest.update(stage='latest-model-isometric-rpg',modelV2={'file':'campus-model-v2.json','sha256':hashlib.sha256((target/'data/campus-model-v2.json').read_bytes()).hexdigest(),'source':model['source'],'buildings':len(model['buildings']),'floors':sum(b['floors'] for b in model['buildings']),'spaces':sum(len(b['rooms']) for b in model['buildings'])},notes=['The public RPG URL is retained. The guide source and original plan/map assets are not changed.','The latest guide compiler supplies schematic geometry, entrances, rooms and stairs; this is not surveyed geometry.','Canvas isometric projection and upright eight-direction characters share world collision and navigation. Indoor maps use cutaway walls.','NPCs are game characters, not online players. Multiplayer and creature training are not included in this release.'])
manifest['collisionAudit']={'geometry':'latest-model-v2 footprints, source perimeter, pond and forecourt tree trunks','playerFootRadius':11,'scales':[1,1.5,2],'navigation':'cached components and collision-checked routes'}
manifest_file.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');changed.append('public/proposal/rpg/data/manifest.json')
record=release/'submission-source/rpg2-campus-data/model-v2';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/model-v2-release.md',source/'docs/plans/2026-10-27-model-25d.md',source/'output/model-v2-qa/release-verification.json']:
    if file.exists():copy(file,record/file.name)
with zipfile.ZipFile(release/'submission-source/rpg-source.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for directory in ['src','scripts','docs','public']:
        for file in (source/directory).rglob('*'):
            relative=file.relative_to(source);path=str(relative).replace('\\','/')
            if not file.is_file() or 'style-v2' in relative.parts or relative.name=='rpg-characters-v2.json' or path.startswith('public/assets/rpg/teachers/'):continue
            archive.write(file,relative)
    for file in source.iterdir():
        if file.is_file() and file.suffix in ['.json','.html','.ts','.yaml','.md','.cjs','.js']:archive.write(file,file.name)
changed.append('submission-source/rpg-source.zip')
(source/'output/model-v2-qa/staged-files.json').write_text(json.dumps(sorted(set(changed)),ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'copiedChanged':len(set(changed)),'target':str(target)},ensure_ascii=False))
