from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-west-paths-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='reference-parking-a-b'
m['parking']={'file':'parking-layout-v1.json','source':'guide landscape-world.js and outdoor.parking; A/B user reference','bicycles':22,'scooters':16,'cars':15,'posts':22,'navigationTargets':3,'accessibleBayClear':True,'canopyRoofsCollide':False,'bodiesAndPostsCollide':True,'minimap':True,'surveyed':False,'testsPassed':168}
m['collisionAudit']['geometry']+='; parked vehicle bodies and shelter posts registered before navigation'
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/parking';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/parking-release.md',source/'docs/superpowers/plans/2026-11-01-parking.md',source/'output/parking-qa/results.json']:shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
