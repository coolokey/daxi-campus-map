from pathlib import Path
import runpy,json,shutil,hashlib
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-stone-paving-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
plan=source/'public/data/campus-boundary-v1.json';data=json.loads(plan.read_text(encoding='utf-8'))
m['stage']='source-gate-solid-perimeter'
m['visualTheme']['geometryChanged']=True;m['visualTheme']['buildingLayoutChanged']=False
m['boundary']={'file':'campus-boundary-v1.json','sha256':hashlib.sha256(plan.read_bytes()).hexdigest(),'source':data['source'],'appearance':['single gold-ball tower','low left post','retracted main gate','open pedestrian wicket','cream-blue guardhouse with red gable roof','masonry walls and front metal railings'],'collision':'continuous source perimeter strips and posts; gate parts below player height; overhead shaft and roof remain traversable below','playerHeightGuideUnits':data['playerHeight'],'sourceBuildingLayoutChanged':False}
m['collisionAudit']['geometry']='source buildings, continuous perimeter strips and posts, ground-level gate parts, pond and tree trunks'
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/boundary';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/boundary-release.md',source/'output/boundary-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
