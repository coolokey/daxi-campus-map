from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-plan-roads-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='western-campus-walking-paths'
m['roadNetwork'].update(entrancePaths=6,totalOutdoorPaths=7,westPaths=3,testsPassed=165)
m['roadNetwork']['westernDestinations']=['司令台','學生活動中心東門','資源回收室北門']
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/west-paths';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/west-paths-release.md',source/'docs/superpowers/plans/2026-11-01-west-paths.md',source/'output/west-paths-qa/results.json']:shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
