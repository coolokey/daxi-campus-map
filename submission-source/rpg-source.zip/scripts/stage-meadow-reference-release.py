from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-fine-terrain-release.py'),run_name='__main__')
release=source.parent/'rpg2-release'
f=release/'public/proposal/rpg/data/manifest.json'
m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='soft-meadow-campus-reference'
m['fineTerrain']['active']=False
m['visualTheme'].update(name='晴日草甸校園',ground='continuous blended grass with cached tufts and flowers; warm gravel paving on existing roads',trees='layered low-poly style crowns and forked trunks, shared trunk collision and selective canopy fade',ui='cream and forest green')
m['meadowTheme']={'file':'meadow-theme-v1.json','rendering':'native Canvas 2.5D, existing isometric engine','cachedTreeVariants':12,'cachedGroundTextures':2,'guideTreePositionsAdded':9,'broadleafTrees':22,'palms':20,'pondCollision':'overlapping water-body bands registered before first navigation; existing shore barriers retained','sourceScreenshotsUsedAsAssets':False,'originalCampusModelChanged':False,'testsPassed':162}
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/meadow-reference'
record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/meadow-reference-release.md',source/'docs/superpowers/plans/2026-10-31-meadow-reference.md',source/'output/meadow-reference-qa/results.json']:
 shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
