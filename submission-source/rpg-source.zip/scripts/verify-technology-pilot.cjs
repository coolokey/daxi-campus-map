const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require(process.env.CAMPUS_PLAYWRIGHT_MODULE||path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));
const url=process.env.CAMPUS_QA_URL||'http://127.0.0.1:8770/proposal/rpg/';
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true}),out='output/technology-pilot-qa',results=[],errors=[],failed=[];fs.mkdirSync(out,{recursive:true});
 try{
  const page=await browser.newPage({viewport:{width:1440,height:900},hasTouch:true});
  page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)failed.push(r.url());});
  await page.addInitScript(()=>{window.questEvents=[];window.snapshotFrames=0;window.addEventListener('campus:snapshot',e=>{window.testWorld=e.detail;window.snapshotFrames++});window.addEventListener('campus:pilot-ready',e=>window.testPilot=e.detail);window.addEventListener('campus:quest-complete',e=>questEvents.push(e.detail));});
  await page.goto(url,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.testWorld?.map.id==='campus');
  const initial=await page.evaluate(()=>performance.getEntriesByType('resource').map(r=>r.name));assert.ok(!initial.some(s=>/technology-demo-runtime|campus\.runtime/.test(s)),'Pilot data must load on demand');
  await page.getByLabel('校園世界比例').selectOption('1');assert.equal(await page.locator('#pilot-mode').count(),0);await page.waitForTimeout(250);
  await page.screenshot({path:out+'/01-gate.png'});results.push('existing game retained; pilot loaded on demand at gate');
  async function driveTo(dest){
   for(let tries=0;tries<30;tries++){
    const p=await page.evaluate(()=>({x:testWorld.player.x,y:testWorld.player.y})),dx=dest.x-p.x,dy=dest.y-p.y;
    if(Math.hypot(dx,dy)<=7)return;
    const kx=Math.abs(dx)>4?(dx>0?'ArrowRight':'ArrowLeft'):null,ky=Math.abs(dy)>4?(dy>0?'ArrowDown':'ArrowUp'):null;
    if(!kx&&!ky)return;
    if(kx)await page.keyboard.down(kx);if(ky)await page.keyboard.down(ky);
    try{await page.waitForFunction(({dest,kx,ky})=>{
      const p=testWorld.player;return(kx&&(kx==='ArrowRight'?p.x>=dest.x-3:p.x<=dest.x+3))||(ky&&(ky==='ArrowDown'?p.y>=dest.y-3:p.y<=dest.y+3));
    },{dest,kx,ky},{timeout:Math.ceil(Math.hypot(dx,dy)/220*1000)+10000,polling:'raf'});}catch(error){console.log('WALK FAILURE',JSON.stringify({dest,kx,ky,errors,state:await page.evaluate(()=>({player:testWorld.player,mapId:testWorld.map.id,hidden:document.hidden,frames:window.snapshotFrames,status:document.getElementById('world-status').textContent,colliders:testWorld.map.collisionZones.filter(r=>testWorld.player.x+20>r.x&&testWorld.player.x-20<r.x+r.width&&testWorld.player.y+20>r.y&&testWorld.player.y-20<r.y+r.height)}))}));await page.screenshot({path:out+'/failure.png'});throw error;}finally{if(kx)await page.keyboard.up(kx);if(ky)await page.keyboard.up(ky);}
   }
   throw Error('Cannot reach '+JSON.stringify(dest));
  }
  async function walkRoute(id,reverse=false){
   let points=await page.evaluate(id=>testPilot.routes[id],id);if(reverse)points.reverse();
   // Collapse only collinear segments, keeping every original turn and endpoint.
   points=points.filter((p,i,a)=>!i||Math.hypot(p.x-a[i-1].x,p.y-a[i-1].y)>.001);
   points=points.filter((p,i,a)=>{if(!i||i===a.length-1)return true;const before=a[i-1],after=a[i+1];return Math.abs((p.x-before.x)*(after.y-p.y)-(p.y-before.y)*(after.x-p.x))>0.001;});
   for(const point of points)await driveTo(point);
  }
  async function transition(expected){await page.keyboard.press('e');await page.waitForFunction(id=>testWorld.map.id===id,expected,{timeout:6000});await page.waitForTimeout(100);}
  for(const point of [{x:1090,y:1360},{x:1090,y:1380},{x:1930,y:1380},{x:1930,y:850}])await driveTo(point);await transition('pilot-tech-1');await page.screenshot({path:out+'/02-floor1.png'});results.push('real keyboard walk along clear roads to source entrance and enter 1F');
  await walkRoute('pilot-tech-1');await transition('pilot-tech-2');await page.screenshot({path:out+'/03-floor2.png'});results.push('real keyboard corridor walk and south stair transition to 2F');
  await walkRoute('pilot-tech-2');await page.keyboard.press('e');await page.waitForSelector('#dialogue:not([hidden])');
  await page.waitForFunction(()=>{const image=document.querySelector('.dialogue-portrait img');return image?.complete&&image.naturalWidth===512;});
  assert.ok((await page.locator('.dialogue-portrait img').getAttribute('alt')).includes('數學任務導師'));
  await page.screenshot({path:out+'/04-mentor.png'});const acceptedAt=await page.evaluate(()=>({x:testWorld.player.x,y:testWorld.player.y}));
  await page.locator('#pilot-accept').click();await page.waitForSelector('.question-runner');
  await page.getByRole('button',{name:'2',exact:true}).click();assert.ok(await page.getByRole('status').getByText(/數線/).count());
  for(const answer of ['8','5','16','3 × 3 × 3','6'])await page.getByRole('button',{name:answer,exact:true}).click();
  await page.getByRole('heading',{name:'能源核心修復成功',exact:true}).waitFor();assert.deepEqual(await page.evaluate(()=>questEvents),[{questId:'energy-core'}]);
  await page.screenshot({path:out+'/05-complete.png'});await page.getByRole('button',{name:'返回校園探索',exact:true}).click();
  assert.deepEqual(await page.evaluate(()=>({x:testWorld.player.x,y:testWorld.player.y})),acceptedAt);results.push('mentor dialogue accepts original five questions, wrong answer hint, reward, one completion event and return to same room');
  await walkRoute('pilot-tech-2',true);await transition('pilot-tech-1');await walkRoute('pilot-tech-1',true);await transition('campus');results.push('real keyboard return via 2F stairs, 1F corridor and exterior exit');
  for(const [name,width,height]of[['ipad',820,1180],['mobile',390,844],['small-mobile',320,568],['landscape',844,390]]){
   await page.setViewportSize({width,height});await page.waitForTimeout(100);assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
   const mini=await page.locator('.world-minimap').boundingBox(),controls=await page.locator('.native-controls').boundingBox();
   const overlap=mini.x<controls.x+controls.width&&mini.x+mini.width>controls.x&&mini.y<controls.y+controls.height&&mini.y+mini.height>controls.y;assert.ok(!overlap,'Minimap must not overlap movement controls');
   await page.locator('.world-minimap').tap();await page.getByRole('button',{name:'返回探索',exact:true}).tap();await page.screenshot({path:out+'/'+name+'.png'});
  }
  results.push('iPad and phone portrait/landscape layout, minimap touch and controls');
  await page.waitForFunction(()=>testWorld.map.id==='campus');results.push('exit returns to original illustrated campus without alternate mode');
  assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);const report={url,results,errors,failed};fs.writeFileSync(out+'/results.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});




