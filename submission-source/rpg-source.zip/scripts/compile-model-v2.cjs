const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto'),cp=require('node:child_process');
const root=path.resolve(__dirname,'..'),source=path.resolve(root,'../rpg2-release'),folder=path.join(source,'public/campus-explorer');
const files=['campus-data.js','spatial-plan-data.js','spatial-plan.js','walk-world-math.js','outdoor-plan.js'];
const context=vm.createContext({window:{}}),sources=[];
for(const file of files){const raw=fs.readFileSync(path.join(folder,file),'utf8');sources.push({file,sha256:crypto.createHash('sha256').update(raw).digest('hex')});vm.runInContext(raw,context,{filename:file,timeout:5000});}
const data=vm.runInContext(`(()=>{const layouts=BUILDINGS_CONFIG.map(CampusSpatialPlan.layout);return {buildings:layouts.map(l=>({id:l.id,name:l.b.name,floors:l.b.floors,bounds:l.bounds,footprints:l.footprints,corridors:l.corridors,cells:l.cells,stairs:l.stairs,ramps:l.ramps,platforms:l.platforms,rooms:l.rooms,entrances:l.entrances,facadeFeatures:l.facadeFeatures,confidence:l.confidence})),junctions:CampusSpatialPlan.junctions(layouts),outdoor:CampusOutdoorPlan}})()`,context);
const forecourtRaw=fs.readFileSync(path.join(folder,'campus-forecourt.js'),'utf8');
sources.push({file:'campus-forecourt.js',sha256:crypto.createHash('sha256').update(forecourtRaw).digest('hex')});
const forecourtPlan=vm.runInContext(`(()=>{const entrance=CampusOutdoorPlan.entrance;${forecourtRaw.slice(forecourtRaw.indexOf('  const corners='),forecourtRaw.indexOf('  const group='))}return plan;})()`,context);
const model=JSON.parse(JSON.stringify(data));
model.forecourt=JSON.parse(JSON.stringify(forecourtPlan));model.version=2;model.source={referenceUrl:'https://coolokey.github.io/daxi-campus-map/proposal/campus/campus-explorer/index.html?build=8bd36601b4d9',commit:cp.execFileSync('git',['rev-parse','HEAD'],{cwd:source,encoding:'utf8'}).trim(),files:sources,geometry:'latest guide compiler, illustrative dimensions, not surveyed'};
// Retain source room identity and code separately. Never fold separate floor spaces into one ID.
for(const b of model.buildings)for(const r of b.rooms){r.sourceId=r.id;r.id=`${b.id}:${r.floor}:${r.spaceCode||r.code||r.sourceId}:${r.sourceId}`;}
const ids=model.buildings.flatMap(b=>b.rooms.map(r=>r.id));if(new Set(ids).size!==ids.length)throw Error('Duplicate source room identity');
fs.writeFileSync(path.join(root,'public/data/campus-model-v2.json'),JSON.stringify(model,null,2)+'\n');
fs.writeFileSync(path.join(root,'src/presentation/model-catalog.json'),JSON.stringify({source:model.source,buildings:model.buildings.map(b=>({buildingId:b.id,name:b.name,enabledLevels:Array.from({length:b.floors},(_,i)=>i+1),note:'最新版校園模型；尺寸與門位為導覽示意。'})),rooms:model.buildings.flatMap(b=>b.rooms.map(r=>({roomId:r.id,buildingId:b.id,floorId:`${b.id}:floor-${r.floor}`,sourceName:r.name,enabled:true}))),roomOverrides:[]},null,2)+'\n');
console.log(JSON.stringify({source:model.source.commit,buildings:model.buildings.length,floors:model.buildings.reduce((n,b)=>n+b.floors,0),rooms:ids.length}));
