from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-farm-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json'
m=json.loads(f.read_text(encoding='utf-8'));m['stage']='west-flower-border-and-athletics'
m['athleticsGarden']={'file':'athletics-garden-v1.json','plantClusters':84,'raisedShrubs':12,'equipment':7,'solidFootprints':23,'lanes':6,'trackDimensionsChanged':False,'surveyedOrCertified':False,'spriteCache':12,'regressionPassed':178,'finalFocusedPassed':15}
m['collisionAudit']['geometry']+='; west flower shrub cores, infield equipment and bunting poles'
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/athletics-garden';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/athletics-garden-release.md',source/'docs/superpowers/plans/2026-11-01-athletics-garden.md',source/'output/athletics-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
