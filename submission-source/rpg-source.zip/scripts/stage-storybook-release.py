from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-surroundings-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='sunny-storybook-campus-art'
m['storybookArt']={'date':'2026-11-02','buildingPalettes':11,'fineBrickTexture':'procedural cached 256px canvas','pathsAndCollisionsChanged':False,'additionalNetworkImages':0,'repeatedRoofBadges':False,'regressionPassed':187,'shortViewportSecondaryFlowHidden':True}
m['visualTheme']['ground']='storybook fine brick on existing masonry, meadow trails and reduced grass detail; original imagegen paving retained in wood comparison mode'
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/storybook';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/storybook-campus-release.md',source/'docs/superpowers/plans/2026-11-02-storybook-campus.md',source/'output/storybook-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
