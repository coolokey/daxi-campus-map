const fs=require('node:fs'),assert=require('node:assert/strict');
const {chromium}=require(process.env.USERPROFILE+'/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const url=process.env.CAMPUS_QA_URL||'http://127.0.0.1:8770/proposal/rpg/';
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true}),out='output/clarity-field-qa',results=[],errors=[],failed=[];fs.mkdirSync(out,{recursive:true});
 try{
  for(const [width,height,dpr]of[[1440,900,1],[1440,900,2],[390,844,2],[390,844,3]]){
   const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:dpr,hasTouch:true});page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)failed.push(r.url());});
   await page.addInitScript(()=>{
    addEventListener('campus:viewport',e=>window.view=e.detail);addEventListener('campus:snapshot',e=>window.world=e.detail);addEventListener('campus:characters-ready',e=>window.characters=e.detail);
    const draw=CanvasRenderingContext2D.prototype.drawImage,arc=CanvasRenderingContext2D.prototype.arc,text=CanvasRenderingContext2D.prototype.fillText;
    CanvasRenderingContext2D.prototype.drawImage=function(image,...a){if(this.canvas.id==='world'&&image.src?.endsWith('daxi-future-campus-rpg-v1.png'))window.originalPngUsed=true;return draw.call(this,image,...a);};
    CanvasRenderingContext2D.prototype.arc=function(x,y,r,...a){if(this.canvas.closest('.world-minimap')&&r===11){const t=this.getTransform();window.marker={x:t.e,y:t.f,radius:r*t.a/Math.min(2,devicePixelRatio)};}return arc.call(this,x,y,r,...a);};
    CanvasRenderingContext2D.prototype.fillText=function(t,...a){if(this.canvas.closest('.world-minimap')&&t==='你在這裡')window.markerLabel=t;return text.call(this,t,...a);};
   });
   await page.goto(url,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.view&&window.characters?.count===109&&window.marker&&window.originalPngUsed);
   const size=await page.evaluate(()=>({view,buffer:{width:document.getElementById('world').width,height:document.getElementById('world').height},marker,markerLabel}));
   assert.equal(size.buffer.width,width*Math.min(2,dpr));assert.equal(size.buffer.height,height*Math.min(2,dpr));assert.equal(size.view.width,width/.75);assert.equal(size.view.height,height/.75);assert.equal(size.marker.radius,11);assert.equal(size.markerLabel,'你在這裡');
   const checkMarker=async()=>{await page.waitForTimeout(120);const m=await page.evaluate(()=>{const c=document.querySelector('.world-minimap canvas'),r=c.getBoundingClientRect(),d=Math.min(2,devicePixelRatio);return {x:marker.x,y:marker.y,expectedX:world.player.x/world.map.width*r.width*d,expectedY:world.player.y/world.map.height*Math.round(r.width*world.map.height/world.map.width)*d};});assert.ok(Math.abs(m.x-m.expectedX)<1&&Math.abs(m.y-m.expectedY)<1,'Minimap player coordinates match world');};
   await checkMarker();await page.screenshot({path:`${out}/default-${width}-${dpr}.png`});
   if(dpr===1){
    async function drive(goal){for(let tries=0;tries<40;tries++){const p=await page.evaluate(()=>({x:world.player.x,y:world.player.y})),dx=goal.x-p.x,dy=goal.y-p.y;if(Math.hypot(dx,dy)<7)return;const kx=Math.abs(dx)>4?(dx>0?'ArrowRight':'ArrowLeft'):null,ky=Math.abs(dy)>4?(dy>0?'ArrowDown':'ArrowUp'):null;if(!kx&&!ky)return;for(const k of [kx,ky].filter(Boolean))await page.keyboard.down(k);try{await page.waitForFunction(({goal,kx,ky})=>{const p=world.player;return(kx&&(kx==='ArrowRight'?p.x>=goal.x-3:p.x<=goal.x+3))||(ky&&(ky==='ArrowDown'?p.y>=goal.y-3:p.y<=goal.y+3));},{goal,kx,ky},{timeout:Math.ceil(Math.hypot(dx,dy)/220*1000)+7000,polling:'raf'});}finally{for(const k of [kx,ky].filter(Boolean))await page.keyboard.up(k);}}throw Error('Field route blocked '+JSON.stringify(goal));}
    for(const scale of [1,1.5,2]){
     await page.getByLabel('校園世界比例').selectOption(String(scale));await page.waitForTimeout(150);
     for(const p of [{x:1090,y:950},{x:720,y:950},{x:720,y:770},{x:720,y:515}])await drive({x:p.x*scale,y:p.y*scale});
     assert.ok(await page.evaluate(s=>Math.hypot(world.player.x-720*s,world.player.y-515*s)<7,scale));await checkMarker();await page.screenshot({path:`${out}/field-${scale}.png`});
     results.push(`real keyboard enters running track and central turf at ${scale}x`);
     for(const p of [{x:720,y:770},{x:720,y:950},{x:1090,y:950},{x:1090,y:1360},{x:1180,y:1360}])await drive({x:p.x*scale,y:p.y*scale});
    }
   }
   await page.locator('.world-minimap').tap();await page.getByRole('button',{name:'返回探索',exact:true}).tap();results.push(`${width}x${height} DPR ${dpr}: native backing, original PNG, visible minimap beacon and correct world projection`);await page.close();
  }
  assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);const report={url,results,errors,failed,sourceResolution:{width:1525,height:1031},true4kArtwork:false};fs.writeFileSync(out+'/results.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
