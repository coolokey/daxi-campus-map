"""Verify real decoded pixels, transparency, dimensions and transfer reduction."""
import json
from pathlib import Path
from PIL import Image, ImageChops

root = Path(__file__).resolve().parents[1] / 'public'
old = json.loads((root / 'data/rpg-characters-v3.json').read_text(encoding='utf-8'))
new = json.loads((root / 'data/rpg-characters-v4.json').read_text(encoding='utf-8'))
assert len(new['characters']) == 109
totals = {key: {'before': 0, 'after': 0} for key in ['atlas', 'portrait']}
for a, b in zip(old['characters'], new['characters']):
    assert a['id'] == b['id']
    for key in ['atlas', 'portrait']:
        assert b[key].endswith('.webp')
        original, compressed = root / a[key], root / b[key]
        with Image.open(original) as left, Image.open(compressed) as right:
            left, right = left.convert('RGBA'), right.convert('RGBA')
            assert left.size == right.size, (a['id'], key, 'size')
            assert ImageChops.difference(left.getchannel('A'), right.getchannel('A')).getbbox() is None, (a['id'], key, 'alpha')
            # Fully transparent RGB is not displayed; every visible/antialiased pixel must match exactly.
            mask = left.getchannel('A').point(lambda value: 255 if value else 0)
            diff = ImageChops.difference(left.convert('RGB'), right.convert('RGB'))
            assert ImageChops.multiply(diff, Image.merge('RGB', (mask, mask, mask))).getbbox() is None, (a['id'], key, 'visible pixels')
        totals[key]['before'] += original.stat().st_size
        totals[key]['after'] += compressed.stat().st_size
for key, value in totals.items():
    value['savedPercent'] = round(100 * (1 - value['after'] / value['before']), 2)
    assert value['savedPercent'] > 40, (key, value)
output = root.parent / 'output/character-loading-qa'
output.mkdir(parents=True, exist_ok=True)
(output / 'compression.json').write_text(json.dumps(totals, indent=2), encoding='utf-8')
print(json.dumps(totals, indent=2))
