const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..');
const deps=process.env.USERPROFILE+'/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/';
test('all source staff and RPG variants have safe complete transparent atlases',()=>{
 const manifestPath=path.join(root,'public/data/rpg-characters.json');
 assert.ok(fs.existsSync(manifestPath),'Character manifest must be generated');
 const m=JSON.parse(fs.readFileSync(manifestPath));const sourceDirectory=process.env.RPG_GUIDE_SOURCE||'F:/1151005---創意教學/daxi-campus-map/public/campus-explorer';assert.equal(m.source.directory,'campus-explorer');assert.ok(m.anchor.x>0&&m.anchor.x<64&&m.anchor.y>0&&m.anchor.y<88);
 assert.equal(m.characters.length,109);assert.equal(new Set(m.characters.map(c=>c.id)).size,109);
 for(const [name,hash] of Object.entries(m.source.sha256))assert.equal(require('node:crypto').createHash('sha256').update(fs.readFileSync(path.join(sourceDirectory,name))).digest('hex'),hash,'Source hash remains unchanged: '+name);
 const context={window:{}};vm.runInNewContext(fs.readFileSync(path.join(sourceDirectory,'staff-data.js'),'utf8'),context);
 assert.deepEqual(m.characters.filter(c=>c.role==='teacher').map(c=>c.id),Array.from(context.window.CampusStaffData.people,p=>p.id));
 for(const source of context.window.CampusStaffData.people){const c=m.characters.find(c=>c.id===source.id);for(const [key,value]of Object.entries(source.appearance||{}))assert.equal(c.sourceAppearance[key],value);assert.equal(c.appearanceStatus,source.appearance?'source':'generic');}
 assert.equal(m.characters.filter(c=>c.role==='student').length,12);assert.equal(m.characters.filter(c=>c.role==='player').length,4);
 assert.deepEqual(m.directions,['down','down-left','left','up-left','up','up-right','right','down-right']);
 assert.ok(!/\.jpg|\.jpeg|staff-photos|private/i.test(JSON.stringify(m.characters)),'No photo references in exported character data');
 const {PNG}=require(deps+'pngjs');
 for(const c of m.characters){
  assert.ok(['source','generic'].includes(c.appearanceStatus));assert.ok(c.appearance);
  const p=PNG.sync.read(fs.readFileSync(path.join(root,'public',c.atlas)));assert.equal(p.width,512,c.id);assert.equal(p.height,264,c.id);
  assert.notDeepEqual(p.data.subarray(0,512*88*4),p.data.subarray(512*88*4,512*176*4),c.id+': idle and walk must differ');
  for(let row=0;row<3;row++)for(let col=0;col<8;col++){
   let count=0;for(let y=0;y<88;y++)for(let x=0;x<64;x++){
    const a=p.data[((row*88+y)*512+col*64+x)*4+3];if(a)count++;
    if(x===0||x===63||y===0||y===87)assert.equal(a,0,`${c.id}: clipped tile ${col},${row}`);
   }assert.ok(count>200,`${c.id}: empty tile ${col},${row}`);
  }
 }
});


test('Q world sprites and matching rendered half-body portraits use versioned assets',()=>{
 const m=JSON.parse(fs.readFileSync(path.join(root,'public/data/rpg-characters.json')));assert.equal(m.artVersion,'creative-style-v3');assert.ok(m.proportions.headBodyRatio.min>=.48);assert.ok(m.proportions.headBodyRatio.max<=.70);assert.equal(m.headScale,1.65);
 const {PNG}=require(deps+'pngjs');for(const c of m.characters){assert.ok(c.atlas.includes('/style-v3/'));assert.ok(c.portrait.endsWith('/portraits/'+c.id+'.png'));const p=PNG.sync.read(fs.readFileSync(path.join(root,'public',c.portrait)));assert.equal(p.width,512);assert.equal(p.height,640);let count=0,minY=640,maxY=0;for(let y=0;y<640;y++)for(let x=0;x<512;x++){const a=p.data[(y*512+x)*4+3];if(a){count++;minY=Math.min(y,minY);maxY=Math.max(y,maxY);}if(y===0||x===0||x===511)assert.equal(a,0,c.id+' portrait top/side safety');}assert.ok(count>48000&&count<512*640*.85,c.id+' useful portrait coverage');assert.ok(minY<120&&maxY>580,c.id+' upper-body framing');}
});
