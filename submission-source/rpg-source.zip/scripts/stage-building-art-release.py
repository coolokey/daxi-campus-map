from pathlib import Path
import json
import runpy
import shutil

source = Path(__file__).resolve().parents[1]
runpy.run_path(str(source / 'scripts/stage-character-loading-release.py'), run_name='__main__')
release = source.parent / 'rpg2-release'
manifest_path = release / 'public/proposal/rpg/data/manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
manifest['stage'] = 'storybook-campus-building-art'
manifest['buildingArt'] = {
    'file': 'building-art-v1.json',
    'roofTypesFollowCampusGuide': True,
    'floorBandsFollowSourceFloorCount': True,
    'perSurfaceOcclusion': True,
    'portalsAndFootprintsChanged': False,
    'focusedTestsPassed': 11,
    'regressionTestsPassed': 192,
    'desktopAndPhoneVisualCheck': True,
}
manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
record = release / 'submission-source/rpg2-campus-data/building-art'
record.mkdir(parents=True, exist_ok=True)
shutil.copy2(source / 'docs/building-art-plan.md', record / 'building-art-plan.md')
shutil.copy2(source / 'public/data/building-art-v1.json', record / 'building-art-v1.json')
print(f'Building art release staged: {record}')
