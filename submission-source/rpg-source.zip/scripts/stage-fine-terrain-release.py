from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-basketball-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='fine-hex-terrain-nine-natural-shades'
m['fineTerrain']={'hexRadius':2.4,'previousHexRadius':5.2,'shades':9,'details':'sparse grass and tiny flowers; subtle seams','variation':'stable per-cell hash, independent of camera','rendering':'inverse-camera candidate range with per-cell culling','worldGeometryChanged':False,'collisionChanged':False}
m['visualTheme']['ground']='fine hex grass in nine natural green/yellow-green/sage shades with subtle seams and sparse ground details; existing paved roads and sports fields retained'
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/fine-terrain';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/fine-terrain-release.md',source/'docs/superpowers/plans/2026-10-31-fine-terrain.md',source/'output/fine-terrain-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
