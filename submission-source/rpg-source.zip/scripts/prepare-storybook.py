from pathlib import Path
import zipfile
root=Path(__file__).resolve().parents[1]
out=root/'backups/rpg-before-storybook-20261102.zip'
if out.exists():raise SystemExit('Backup already exists; do not overwrite')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['src','public','scripts','docs']:
  for p in (root/folder).rglob('*'):
   if p.is_file():z.write(p,p.relative_to(root))
 for name in ['presentation.html','package.json','vite.config.ts']:
  z.write(root/name,name)
(root/'output/storybook-qa').mkdir(parents=True,exist_ok=True)
print(out)
