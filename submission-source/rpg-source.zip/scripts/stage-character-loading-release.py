from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-storybook-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='storybook-character-loading-improvement'
m['characterLoading']={'runtimeManifest':'rpg-characters-runtime-v1.json','originalBytes':72966,'runtimeBytes':31702,'earlyPlayerAndGuardPreload':True,'rotationWaitsForReadyAtlas':True,'deferredRosterCards':True,'testsPassed':20,'imageQualityChanged':False}
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/character-loading';record.mkdir(parents=True,exist_ok=True)
shutil.copy2(source/'docs/character-loading-release.md',record/'character-loading-release.md')
print('Character loading release staged')
