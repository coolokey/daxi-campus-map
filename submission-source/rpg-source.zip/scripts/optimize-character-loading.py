from pathlib import Path
import json,zipfile
r=Path(__file__).resolve().parents[1];out=r/'backups/character-loading-before-20261102.zip'
files=['presentation.html','src/presentation/character-world.ts','src/presentation/character-runtime.test.ts']
if not out.exists():
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for f in files:z.write(r/f,f)
source=json.loads((r/'public/data/rpg-characters-v4.json').read_text(encoding='utf-8'))
data={k:source[k] for k in ['tile','directions','anchor']}
keys=['id','name','role','title','destination','appearanceStatus','atlas','portrait']
data['characters']=[{**{k:c[k] for k in keys if k in c},'appearance':{}} for c in source['characters']]
p=r/'public/data/rpg-characters-runtime-v1.json';p.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
print(json.dumps({'originalBytes':(r/'public/data/rpg-characters-v4.json').stat().st_size,'runtimeBytes':p.stat().st_size,'characters':len(data['characters'])}))
(r/'output/character-loading-qa').mkdir(parents=True,exist_ok=True)
