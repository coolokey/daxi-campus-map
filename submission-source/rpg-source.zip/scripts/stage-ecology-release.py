from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-parking-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='moderate-campus-ecology'
m['ecology']={'file':'campus-ecology-v1.json','habitatZones':16,'maxPlantCandidates':94,'maxButterflyPool':12,'dragonflyPool':4,'desktopVisibleCaps':{'butterflies':4,'dragonflies':3},'mobileVisibleCaps':{'butterflies':2,'dragonflies':2},'mobileCssBreakpoint':640,'reducedMotion':True,'staticSpriteCache':12,'collisionChanged':False,'testsPassed':172}
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/ecology';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/ecology-release.md',source/'docs/superpowers/plans/2026-11-01-campus-ecology.md',source/'output/ecology-qa/results.json']:shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
