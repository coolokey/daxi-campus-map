from pathlib import Path
import zipfile,re,json
r=Path(__file__).resolve().parents[1]
backup=r/'backups/building-art-before-20261103.zip'
if not backup.exists():
 with zipfile.ZipFile(backup,'w',zipfile.ZIP_DEFLATED) as z:
  for p in (r/'src/presentation').glob('*'):
   if p.is_file():z.write(p,p.relative_to(r))
guide=r.parent/'daxi-campus-map/public/campus-explorer/campus-data.js'
s=guide.read_text(encoding='utf-8');pitched=[]
for block in re.split(r'\n  \{\n',s):
 m=re.match(r'    id: "([^"]+)"',block)
 if m and 'hasPitchedRoof: true' in block:pitched.append(m[1])
d={'pitchedBuildings':pitched,'solarBuilding':'gym-bld','source':'daxi-campus-map/public/campus-explorer/campus-data.js and explorer.js','note':'Source roof types; compact RPG elevations, no changes to footprints or entrances.'}
(r/'public/data/building-art-v1.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'output/building-art-qa').mkdir(parents=True,exist_ok=True)
print(d)
