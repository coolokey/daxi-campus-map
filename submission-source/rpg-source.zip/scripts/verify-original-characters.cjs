const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require(process.env.USERPROFILE+'/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const url=process.env.CAMPUS_QA_URL||'http://127.0.0.1:8772/presentation.html';
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true}),out='output/original-characters-qa',errors=[],failed=[],results=[];fs.mkdirSync(out,{recursive:true});
 try{
  const page=await browser.newPage({viewport:{width:1440,height:900},hasTouch:true});
  page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()>=400)failed.push(r.url());});
  await page.addInitScript(()=>{
   window.spriteDraws=[];
   const draw=CanvasRenderingContext2D.prototype.drawImage;
   CanvasRenderingContext2D.prototype.drawImage=function(image,...a){if(image.src?.includes('/guide-rpg/')){spriteDraws.push({src:image.src,column:a[0]/64,row:a[1]/88,width:a[6]*this.getTransform().a/Math.min(2,devicePixelRatio),height:a[7]*this.getTransform().d/Math.min(2,devicePixelRatio)});if(spriteDraws.length>12000)spriteDraws.shift();}return draw.call(this,image,...a);};
   addEventListener('campus:snapshot',e=>window.testWorld=e.detail);addEventListener('campus:characters-ready',e=>window.charactersReady=e.detail);
  });
  await page.goto(url,{waitUntil:'networkidle'});try{await page.waitForFunction(()=>window.charactersReady?.count===109);}catch(e){console.log('CHARACTER INIT',JSON.stringify({errors,failed,state:await page.evaluate(()=>({ready:window.charactersReady,status:document.querySelector('.character-status')?.textContent}))}));throw e;}
  assert.deepEqual(await page.evaluate(()=>charactersReady.roles),{teacher:91,student:12,guard:1,player:4,robot:1});
  assert.equal(await page.evaluate(()=>testWorld.npcs.filter(n=>n.kind==='teacher').length),3);
  assert.equal(await page.evaluate(()=>testWorld.npcs.filter(n=>n.kind==='student').length),3);
  assert.equal(await page.locator('#pilot-mode').count(),0);assert.equal(await page.evaluate(()=>testWorld.map.id),'campus');
  await page.getByLabel('校園世界比例').selectOption('1');await page.waitForTimeout(350);
  await page.waitForFunction(()=>spriteDraws.some(d=>d.src.includes('player-male-uniform')));
  await page.screenshot({path:out+'/01-original-campus.png'});results.push('original colorful campus retained, alternate outdoor removed, all 109 characters registered');
  await page.keyboard.down('ArrowDown');await page.waitForTimeout(350);await page.keyboard.up('ArrowDown');
  for(const keys of [['ArrowDown'],['ArrowDown','ArrowLeft'],['ArrowLeft'],['ArrowLeft','ArrowUp'],['ArrowUp'],['ArrowUp','ArrowRight'],['ArrowRight'],['ArrowRight','ArrowDown']]){
   for(const key of keys)await page.keyboard.down(key);await page.waitForTimeout(240);for(const key of keys)await page.keyboard.up(key);await page.waitForTimeout(40);
  }
  const frames=await page.evaluate(()=>spriteDraws.filter(d=>d.src.includes('player-male-uniform')));
  assert.equal(new Set(frames.map(f=>f.column)).size,8);assert.ok(frames.some(f=>f.row===0)&&frames.some(f=>f.row===1)&&frames.some(f=>f.row===2));
  assert.ok(frames.every(f=>Math.abs(f.width-48)<.01&&Math.abs(f.height-66)<.01));results.push('actual rendering uses eight directions, idle plus both walking poses, fixed character size');
  for(const scale of ['2','1.5','1']){await page.getByLabel('校園世界比例').selectOption(scale);await page.waitForTimeout(150);}
  const dimensions=await page.evaluate(()=>spriteDraws.filter(d=>d.src.includes('player-male-uniform')).map(d=>[d.width,d.height]));assert.ok(dimensions.every(([w,h])=>Math.abs(w-48)<.01&&Math.abs(h-66)<.01));
  await page.getByRole('button',{name:'校園角色',exact:true}).click();await page.getByLabel('角色類別').selectOption('teacher');
  assert.equal(await page.locator('.character-card').count(),91);await page.getByLabel('搜尋校園名冊').fill('游貿仁');assert.equal(await page.locator('.character-card').count(),1);
  const before=await page.evaluate(()=>({...testWorld.player}));await page.getByRole('button',{name:'邀請到校園',exact:true}).click();
  await page.getByRole('button',{name:'女生・便服',exact:true}).click();await page.getByRole('button',{name:'關閉',exact:true}).click();await page.waitForTimeout(150);
  assert.deepEqual(await page.evaluate(()=>({...testWorld.player})),before);await page.waitForFunction(()=>testWorld.npcs.some(n=>n.name==='游貿仁'));
  await page.waitForFunction(()=>spriteDraws.some(d=>d.src.includes('player-female-casual')));assert.equal(await page.evaluate(()=>localStorage.getItem('campus:rpg-player')),'player-female-casual');
  await page.screenshot({path:out+'/02-character-choice.png'});results.push('all 91 teachers searchable, selected teacher invited without moving player, player appearance changes and persists');
  const starts=await page.evaluate(()=>testWorld.npcs.map(n=>({id:n.id,x:n.x,y:n.y})));
  await page.waitForFunction(starts=>testWorld.npcs.some(n=>{const p=starts.find(p=>p.id===n.id);return p&&Math.hypot(n.x-p.x,n.y-p.y)>6;}),starts);results.push('characters autonomously walk on collision-checked game routes');
  await page.getByRole('button',{name:'快速體驗數學任務',exact:true}).click();await page.getByRole('button',{name:/返回校園/}).first().click();await page.waitForTimeout(150);
  for(const [name,width,height]of[['ipad',820,1180],['mobile',390,844],['small-mobile',320,568],['landscape',844,390]]){
   await page.setViewportSize({width,height});await page.waitForTimeout(250);assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
   if(width<700){assert.equal(await page.evaluate(()=>testWorld.npcs.filter(n=>n.id.startsWith('guide-teacher-')).length),1);assert.equal(await page.evaluate(()=>testWorld.npcs.filter(n=>n.kind==='student').length),2);}
   const mini=await page.locator('.world-minimap').boundingBox(),controls=await page.locator('.native-controls').boundingBox(),entry=await page.locator('.character-entry').boundingBox();
   const overlap=(a,b)=>a.x<b.x+b.width&&a.x+a.width>b.x&&a.y<b.y+b.height&&a.y+a.height>b.y;
   assert.ok(!overlap(mini,controls)&&!overlap(mini,entry),'Map and controls must be independently usable');
   await page.getByRole('button',{name:'校園角色',exact:true}).tap();await page.getByRole('button',{name:'關閉',exact:true}).tap();await page.waitForTimeout(100);
   await page.locator('.world-minimap').tap();await page.getByRole('button',{name:'返回探索',exact:true}).tap();await page.waitForTimeout(100);
   await page.screenshot({path:out+'/'+name+'.png'});
  }
  results.push('desktop, iPad-sized and phone portrait/landscape character panels, touch map, actor caps and non-overlapping controls');
  assert.deepEqual(errors,[]);assert.deepEqual(failed,[]);const report={url,results,errors,failed};fs.writeFileSync(out+'/results.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});


