const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require(process.env.USERPROFILE+'/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const url=process.env.CAMPUS_QA_URL||'http://127.0.0.1:8772/presentation.html';
(async()=>{
 const browser=await chromium.launch({channel:'msedge',headless:true}),errors=[];
 try{
  const page=await browser.newPage({viewport:{width:1440,height:900}});page.on('pageerror',e=>errors.push(e.message));
  await page.addInitScript(()=>{addEventListener('campus:viewport',e=>window.testViewport=e.detail);addEventListener('campus:snapshot',e=>window.testWorld=e.detail);addEventListener('campus:characters-ready',e=>window.charactersReady=e.detail);});
  let injected=false;await page.route('**/data/rpg-characters*.json',async route=>{if(!injected){injected=true;await route.fulfill({status:503,body:'temporary test failure'});}else await route.continue();});
  await page.goto(url,{waitUntil:'networkidle'});await page.waitForFunction(()=>document.getElementById('world-status').dataset.characterError);
  const color=await page.evaluate(()=>{const c=document.getElementById('world'),{map,player}=testWorld,v=testViewport,x=Math.max(0,Math.min(map.width-v.width,player.x-v.width/2)),y=Math.max(0,Math.min(map.height-v.height,player.y-v.height/2));return [...c.getContext('2d').getImageData(Math.round((player.x-x)*v.zoom*v.pixelRatio),Math.round(((player.y-y)*v.zoom-15)*v.pixelRatio),1,1).data];});
  assert.deepEqual(color,[8,123,168,255],'Player must remain visibly rendered on registry failure');
  const x=await page.evaluate(()=>testWorld.player.x);await page.keyboard.down('ArrowRight');await page.waitForTimeout(250);await page.keyboard.up('ArrowRight');assert.ok(await page.evaluate(x=>testWorld.player.x>x+10,x));
  await page.waitForTimeout(100);assert.ok(await page.evaluate(()=>document.getElementById('world-status').textContent.includes('載入失敗')));
  await page.getByRole('button',{name:'校園角色',exact:true}).click();await page.getByRole('button',{name:'重試載入角色',exact:true}).click();await page.waitForFunction(()=>window.charactersReady?.count===109);
  assert.ok(await page.evaluate(()=>!document.getElementById('world-status').dataset.characterError));await page.getByRole('button',{name:'關閉',exact:true}).click();
  assert.deepEqual(errors,[]);fs.mkdirSync('output/original-characters-qa',{recursive:true});const report={url,injectedHttpStatus:503,visibleFallback:true,movementPreserved:true,retryRestoresAllCharacters:true,errors};fs.writeFileSync('output/original-characters-qa/recovery.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});



