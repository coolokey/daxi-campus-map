const {createHash}=require('node:crypto');
// Invented RPG wardrobe: neither a likeness claim nor a record of real clothing.
const shirts=[0x526b80,0x8a5866,0x587c70,0xb08750,0x77668a,0x476f79,0x98735f,0x697b4e,0xa25f51,0x788fa0,0x9a7f98,0x4f606d,0xb39e7c,0x76867e,0x655b78,0x805c45];
const trousers=[0x39434f,0x5a5350,0x70624f,0x4c5e55,0x514d67,0x73777a,0x3c5360,0x806a60];
function teacherStyle(person){
 const h=createHash('sha256').update(person.id).digest(),sourceAppearance={...(person.appearance||{})};
 const appearance={...sourceAppearance,gender:sourceAppearance.gender||person.gender||'male',role:'teacher',clothingStyle:['blazer','cardigan','shirt','polo'][h[0]%4],shirtColor:shirts[h[1]%shirts.length],pantsColor:trousers[h[2]%trousers.length],glasses:sourceAppearance.glasses===true||h[3]%3===0,neckwear:['none','tie','scarf','none'][h[4]%4],accessoryColor:shirts[h[5]%shirts.length],backpack:h[6]%3===0,brooch:h[7]%2===0,bottomStyle:h[8]%5===0?'skirt':'trousers',vest:h[9]%4===0};
 const keys=['clothingStyle','shirtColor','pantsColor','glasses','neckwear','accessoryColor','backpack','brooch','bottomStyle','vest'];
 return {appearance,sourceAppearance,styleOrigin:'creative-rpg',styleSignature:keys.map(k=>String(appearance[k])).join('|')};
}
module.exports={teacherStyle};
