from pathlib import Path
import runpy,json,shutil,hashlib
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-boundary-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'));theme=source/'public/data/woodland-theme-v1.json'
m['stage']='daxi-woodcraft-campus'
m['visualTheme'].update(name='大溪木藝學園',buildings='ivory plaster, timber lattice windows, gray hipped roofs and deep eaves; historic-street facade ornaments on selected existing buildings',ground='green lawns with source planting, stone-paved entrances, original roadway and parking',geometryChanged=True,buildingLayoutChanged=False)
m['woodlandTheme']={'file':'woodland-theme-v1.json','sha256':hashlib.sha256(theme.read_bytes()).hexdigest(),'interpretation':'inspired game artwork, not historical reconstruction or actual school renovation','furniture':'three candidate benches anchored to existing planting; only clear positions are placed, with matching collisions','originalSchoolAppearanceOptionRetained':True,'sourceBuildingFloorRoomDataChanged':False}
m['boundary']['appearance']=['original gate geometry with warm plaster and wood-toned trim','old-street arch motif on the existing tower cap','gray guardhouse roof','muted stone walls and timber-colored railings']
m['collisionAudit']['geometry']+='; collision-checked game benches near planting'
m['threeCenters']['presentation']='wooden signboard and stamp-inspired numbered stages; original stations, questions, navigation and local progress retained'
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/woodland';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/woodland-release.md',source/'docs/superpowers/plans/2026-10-28-woodland-campus.md',source/'output/woodland-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
