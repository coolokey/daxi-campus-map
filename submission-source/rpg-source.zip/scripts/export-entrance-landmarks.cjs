const fs=require('fs'),vm=require('vm'),crypto=require('crypto'),path=require('path');
const root=path.resolve('..','rpg2-release','public','campus-explorer'),model=JSON.parse(fs.readFileSync('public/data/campus-model-v2.json','utf8'));
const text=fs.readFileSync(path.join(root,'entrance-avenue.js'),'utf8');
const v=vm.runInNewContext(text+';({plan:CampusEntranceAvenue.plan,palms:CampusEntranceAvenue.palms,trail:CampusEntranceAvenue.trail})',{CampusOutdoorPlan:model.outdoor,Math});
const names=['entrance-avenue.js','explorer.js','outdoor-world.js'];
const data={version:1,source:{commit:'34fcc53cb1677ef4feaa9864af07d99af744c56e',files:names.map(file=>({file,sha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')})),note:'Source guide dimensions are illustrative; artwork adapted to RPG. Original guide files unchanged.'},...v,statue:{...model.outdoor.entrance.target,width:4.2,depth:3.4,height:4.7},stage:model.outdoor.stage,targets:[{id:'palm-avenue',name:'椰林大道',x:v.plan.x,z:160},{id:'jiekou-trail',name:'街口溪生態步道入口',...v.trail.entry},{id:'statue',name:'蔣公銅像庭園',x:model.outdoor.entrance.target.x,z:model.outdoor.entrance.target.z+6},{id:'grandstand',name:'司令台',x:-62,z:3}]};
fs.writeFileSync('public/data/entrance-landmarks-v1.json',JSON.stringify(data,null,2)+'\n');
