from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-athletics-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='lan-pavilion-and-site-activities'
m['pavilionActivities']={'file':'pavilion-activities-v1.json','pavilionSourceCenter':{'x':-18,'z':-66},'pavilionSolidFootprints':11,'activities':['basketball','gardening','running'],'existingStudentAtlasesReused':True,'desktopNpcCount':7,'phoneNpcCount':5,'pauseWithGame':True,'movementCollisionChecked':True,'farmApproachAdjusted':True,'regressionPassed':183,'finalFocusedPassed':22,'surveyed':False}
m['characters']['roamingCaps']={'desktop':{'teacher':3,'studentActivities':3,'guard':1},'phone':{'teacher':1,'studentActivities':3,'guard':1}}
m['collisionAudit']['geometry']+='; source-position Lan pavilion columns and seats with open front'
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/pavilion-activities';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/pavilion-activities-release.md',source/'docs/superpowers/plans/2026-11-01-pavilion-activities.md',source/'output/pavilion-activity-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
