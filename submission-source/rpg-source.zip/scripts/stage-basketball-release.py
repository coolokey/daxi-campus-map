from pathlib import Path
import runpy,json,shutil
source=Path(__file__).resolve().parents[1]
runpy.run_path(str(source/'scripts/stage-entrance-release.py'),run_name='__main__')
release=source.parent/'rpg2-release';f=release/'public/proposal/rpg/data/manifest.json';m=json.loads(f.read_text(encoding='utf-8'))
m['stage']='basketball-complex-restored'
m['basketball']={'file':'basketball-courts-v1.json','courts':3,'hoops':6,'source':'guide createBasketballComplex','collision':'low support pads only; floor and overhead backboards traversable','navigation':True,'minimap':True,'guideAndOriginalPlanUnchanged':True}
f.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=release/'submission-source/rpg2-campus-data/basketball';record.mkdir(parents=True,exist_ok=True)
for file in [source/'docs/basketball-release.md',source/'docs/superpowers/plans/2026-10-30-basketball.md',source/'output/basketball-qa/results.json']:
 if file.exists():shutil.copy2(file,record/file.name)
print(json.dumps({'stage':m['stage'],'record':str(record)},ensure_ascii=False))
